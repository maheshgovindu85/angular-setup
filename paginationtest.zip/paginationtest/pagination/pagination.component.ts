import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { RouterLink, RouterModule } from '@angular/router';

@Component({
  selector: 'app-pagination',
  standalone: true,
  imports: [CommonModule,RouterModule,RouterLink],
  templateUrl: './pagination.component.html',
  styleUrl: './pagination.component.scss'
})
export class PaginationComponent {
  @Input() currentPage: number;
  @Input() totalPages: number;
  @Output() pageChange = new EventEmitter<number>();

  pages: (number | string)[] = [];

  constructor() {}

  ngOnInit(): void {
    this.calculatePages();
  }
  calculatePages(): void {
    const visibleRange =5 ; // How many pages to show before and after current
    const firstPages = [1, 2, 3,4,5]; // Always show first few pages
    const lastPages = [this.totalPages]; // Always show last page
    this.pages = [];

    // Show the first pages
    if (this.currentPage < 5) {
      this.pages = [...firstPages, '...',...lastPages];
    } else if (this.currentPage >= this.totalPages - visibleRange) {
      this.pages = [1, '...',...Array.from({ length: 5}, (_, i) => this.totalPages - 2 + i)];
    } else {
      this.pages = [1, '...',...Array.from({ length: 3}, (_, i) => this.currentPage + i - 1), '...',...lastPages];
    }
  }

  onPageChange(pageNumber: number | string): void {
    if (typeof pageNumber === 'number') {
      this.currentPage = pageNumber;
      this.calculatePages(); // Recalculate the pages when the current page changes
      this.pageChange.emit(pageNumber);
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.onPageChange(this.currentPage + 1);
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.onPageChange(this.currentPage - 1);
    }
  }

  
}
