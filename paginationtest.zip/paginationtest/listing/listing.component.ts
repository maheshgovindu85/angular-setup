import { Component, OnInit } from '@angular/core';
import { PaginationComponent } from "../../common-plugins/pagination/pagination.component";
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-listing',
    standalone: true,
    templateUrl: './listing.component.html',
    styleUrl: './listing.component.scss',
    imports: [PaginationComponent,CommonModule]
})
export class ListingComponent implements OnInit{
  displayedData :any= [];
  currentPage = 1;
  pageSize = 10; // 5 pages for 100 records
 
  data:any=[]
  totalItems:number
  totalPages: number

  getData(): any[] {
    return this.data;
  }

  ngOnInit() {
    this.data = Array.from({ length: 200 }, (_, i) => ({
      id: i + 1,
      name: `Item ${i + 1}`,
      description: `Description for Item ${i + 1}`,
    }));
    this.totalItems = this.data.length
    this.totalPages = Math.ceil(this.totalItems / this.pageSize);
    this.updateDisplayedData();
  }

  updateDisplayedData(): void {
    const start = (this.currentPage - 1) * this.pageSize;
    this.displayedData = this.data.slice(start, start + this.pageSize);
  }

  onPageChange(pageNumber: number): void {
    this.currentPage = pageNumber;
    this.updateDisplayedData();
  }
}
