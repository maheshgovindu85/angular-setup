import { ModuleWithProviders, NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { StaticLayoutsModule } from './layouts/static/static-layout.module';
import { CustomerDashboardLayoutsModule } from './layouts/customer-dashboard/customer-layout.module';
import { AdminDashboardLayoutsModule } from './layouts/admin-dashboard/admin-layout.module';

@NgModule({
  imports: [StaticLayoutsModule, AdminDashboardLayoutsModule, CustomerDashboardLayoutsModule],
  exports: [StaticLayoutsModule, AdminDashboardLayoutsModule, HttpClientModule, CustomerDashboardLayoutsModule],
  providers: [],
})

export class SharedModule {

  static forRoot(): ModuleWithProviders<SharedModule> {
    return { ngModule: SharedModule };
  }

}
