import { Component, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { BasePlugin } from '../../../plugins/base.plugin';
import { PluginMaster } from '../../../master/plugin.master';
import { ComponentManagerService } from '../../../services/component-manager.service';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { forkJoin, Subscription } from 'rxjs';
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'app-admin-toolbar',
  templateUrl: './admin-toolbar.component.html',
  styleUrls: ['./admin-toolbar.component.scss'],
})

export class AdminDashboardToolbarComponent extends BasePlugin implements OnInit, OnDestroy {

  public pluginMaster = PluginMaster;
  allAdminToolbarData: any;
  userProfileData: any;
  updateNotificationCount: Subscription | undefined;

  selectedProfileFiles = [];
  selectedImageFileEvent: any;
  selectedImagefileType: any;
  imagePreview: any = [];
  selectedFiles: any = [];
  picFiles: any;
  uploadedImageUrls: any = [];
  userProfileImage: any = [];
  selectedUserType: any;

  allNotificationCount: any = [];
  allUserNotifications: any = [];
  allAdminNotifyCountData: any = [];

  constructor(
    public componentManagerService: ComponentManagerService,
    public router: Router,
    private auth: AuthService,
  ) {
    super(componentManagerService, router);
  }

  logout() {
    this.auth.logOut();
  }

  ngOnInit(): void {
    this.getNotificationTabCount();
    this.updateNotificationCount = this.componentManagerService.updateAdminNotificationCount$.subscribe(
      product => {
        this.getNotificationTabCount();
      });
  }


notificationCheck(){
  if (this.componentManagerService.isMobile) {
    $(" .notification_view").toggleClass("dropdownopn");
    $(" .profile_view").removeClass("dropdownopn");
  }
}
profilecheck(){
  if (this.componentManagerService.isMobile) {
    $(" .profile_view").toggleClass("dropdownopn");
    $(" .notification_view").removeClass("dropdownopn");
  }
}


  setId() {
    return PluginMaster.ADMIN_DASHBOARD_TOOLBAR;
  }

  actionFromPlugin() { }


  logOut() {
    this.auth.logOut()
  }

  getNotificationTabCount() {
    // this.componentManagerService.loader = true;
    const dataObj = {
      userUdId: this.componentManagerService.user.udId,
      userType: 'ADMIN',
    }
    this.callDataJunction('GET_NOTIFICATION_COUNT', dataObj).subscribe(res => {
      if (res.status) {
        this.allAdminNotifyCountData = res.data;

        // this.componentManagerService.loader = false;
      } else {
        // this.componentManagerService.loader = false;
      }
    });
  }

  goToForgotPswd() {
    this.router.navigate(['/changepassword', this.componentManagerService.user.udId]);
  }


  // updateNotifications(rowData: any, index: number) {
  //   const dataObj = {
  //     notificationSendListUdId: rowData.NotificationSendListUdId,
  //   }
  //   this.callDataJunction('UPDATE_NOTIFICATION', dataObj).subscribe(res => {
  //     if (res.status) {
  //       this.getNotificationTabCount();
  //       if (!!rowData?.redirectUrl) {
  //         this.router.navigate([rowData?.redirectUrl]);
  //       }
  //     } else {
  //     }
  //   });
  // }


  ngOnDestroy() {

    if (this.updateNotificationCount) {
      this.updateNotificationCount.unsubscribe();
    }

  }
  
}
