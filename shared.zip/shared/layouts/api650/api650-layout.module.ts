import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminDashboardToolbarComponent } from './admin-toolbar/admin-toolbar.component';
import { AdminDashboardSidebarComponent } from './admin-sidebar/admin-sidebar.component';
import { AdminDashboardWrapperComponent } from './admin-wrapper/admin-wrapper.component';
import { TooltipModule } from 'primeng/tooltip';
import { BadgeModule } from 'primeng/badge';
import { NotificationsTabModule } from '../../plugins/notificationtab/notificationtab.module';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

@NgModule({
  imports: [CommonModule, RouterModule, BadgeModule, ProgressSpinnerModule, NotificationsTabModule, TooltipModule, FormsModule, ReactiveFormsModule],
  declarations: [AdminDashboardSidebarComponent, AdminDashboardToolbarComponent, AdminDashboardWrapperComponent],
  exports: [AdminDashboardSidebarComponent, AdminDashboardToolbarComponent, AdminDashboardWrapperComponent]
})

export class AdminDashboardLayoutsModule { }
