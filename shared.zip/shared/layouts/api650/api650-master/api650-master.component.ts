import { AfterViewInit, ChangeDetectorRef, Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { ComponentManagerService } from '../../../services/component-manager.service';

@Component({
  selector: 'app-admin-wrapper',
  templateUrl: './admin-wrapper.component.html',
})

export class AdminDashboardWrapperComponent implements AfterViewInit {

  constructor(
    public componentManagerService: ComponentManagerService,
    public router: Router,
    public authService: AuthService,
    private cdr: ChangeDetectorRef,

  ) { }

  ngOnInit(): void {

  }


  ngAfterViewInit() {
    this.cdr.detectChanges();
  }


}
