import { Component, OnInit } from '@angular/core';
import { BasePlugin } from '../../../plugins/base.plugin';
import { PluginMaster } from '../../../master/plugin.master';
import { ComponentManagerService } from '../../../services/component-manager.service';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
declare var $: any;
const LINKS: any[] = [
  { link: '/home', name: 'home', icon: 'home' },
  { link: '/mock', name: 'mock', icon: 'info_outline' },
  { link: '/async', name: 'async-http', icon: 'swap_vert' },
  { link: '/back', name: 'back-http', icon: 'swap_vert' },
  { link: '/static/back', name: 'static-back-http', icon: 'swap_vert' },
  { link: '/nonexistent', name: 'nonexistent', icon: 'error' }
];

@Component({
  selector: 'app-admin-sidebar',
  templateUrl: './admin-sidebar.component.html',
  styleUrls: ['./admin-sidebar.component.scss']
})

export class AdminDashboardSidebarComponent extends BasePlugin implements OnInit {
  public links: any[] = [];
  showSidebar: boolean = false;
  showSubmenuModes: string[] = ['slide', 'expand'];
  positionModes: string[] = ['left', 'right'];
  showModes: string[] = ['push', 'shrink', 'overlap'];
  selectedOpenMode: string = 'shrink';
  selectedPosition: string = 'left';
  selectedRevealMode: string = 'slide';
  elementAttr: any;
  getData: any;
  closeParent = true;
  projectUDID: any;
  mainCat: any;
  droppedGroup: any;
  allAdminData: any;
  sidebarTabDisplay: boolean = true;

  constructor(
    public componentManagerService: ComponentManagerService,
    public router: Router
  ) {
    super(componentManagerService, router);
  }

  ngOnInit(): void {
    this.getAdminDataById()

    if(this.componentManagerService.user.adminType == "BATCHADMIN")
    {
      this.sidebarTabDisplay = false;
    }
    else if(this.componentManagerService.user.adminType == "SUPER")
    {
      this.sidebarTabDisplay = true;
    }

   
    
    this.togglebutton();


    this.togglebutton();
    if (this.isBrowser) {
      var desktopView = $(document).width();
      if (desktopView >= 769) {
        // 768>=
        $(".toggle-icon .button-collapse").hide();
      } else {
        $(".toggle-icon .button-collapse").show();
        // Show sideNav
        $('.toggle-icon .button-collapse').on('click', function (e: any) {  //on body click
          e.stopPropagation();
          $('.sidebar').toggleClass('active');
          // click on menu
        });
        $('body,html').on('click', function (e: any) {  //remove sidebar on body click
          e.stopPropagation();
          $("#sidebar-main").removeClass("active");
          //remove sidebar on body click
        });
      }
    }
  }

  setId() {
    return PluginMaster.ADMIN_DASHBOARD_SIDEBAR;
  }

  actionFromPlugin() { }

  activateTab(tab: any) {
    this.componentManagerService = tab;
    this.showSidebar = !this.showSidebar;
    this.router.navigate([`/admin/${tab}`]);
    // this.closeParent = false;
    if (tab === 'dashboard' || tab === 'myprofile' || tab === 'management'
      || tab === 'candidates' || tab === 'batch' || tab === 'assessment' || tab === 'notifications') {
      this.closeParent = true;
    } else {
      this.closeParent = false;
    }

  }

  routeMainCategory(params: any) {
    this.mainCat = params.item.label;
  }

  toggleNavbar() {
    $("#sidebar-main").removeClass("active");
    $(".sidebar-one").removeClass("sidebar-active");
    $(".main-wrap").removeClass("main-wrap-active");
    // $('.body,html').click(function(){

    //  });
  }

  toggleSidebar() {
    this.showSidebar = !this.showSidebar;
  }


  toggleDropDown(param: any) {
    if (this.droppedGroup === param) {
      this.droppedGroup = '';
    } else {
      this.droppedGroup = param;
    }
  }

  togglebutton() {
    $(".sidebar-one").toggleClass("sidebar-active");
    $(".main-wrap").toggleClass("main-wrap-active");
  }


  myCloseEvent() {
    this.closeParent = false;
  }



  getAdminDataById() {
    this.componentManagerService.loader = true;
    const dataObj = {
      adminUdId: this.componentManagerService.user.udId,
      columns: 'userName, udId, email, mobile, createdDate,adminType',
      validation: {
        udId: this.componentManagerService.user.udId,
      }
    }
    this.callDataJunction('GET_ADMIN', dataObj).subscribe(res => {
      if (res.status) {
        this.allAdminData = res.data[0];
       
        this.componentManagerService.loader = false;
      } else {
        this.componentManagerService.loader = false;
      }
    });
  }

}
