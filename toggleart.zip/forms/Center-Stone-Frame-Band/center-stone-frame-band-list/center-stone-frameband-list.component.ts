import { CenterStoneframeBand } from "@/_models/cs_frame_band";
import { AlertService, AuthenticationService } from "@/_services";
import { CenterStoneFrameBandService } from "@/_services/cs_frame_band.service";
import { Component } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";

@Component({
  selector: "app-center-stone-frameband-list",
  templateUrl: "./center-stone-frameband-list.component.html",
  styleUrls: ["./center-stone-frameband-list.component.css"],
})
export class CenterStoneFramebandListComponent {
  centerStoneFrameBandList: any = [];
  searchForm: FormGroup;
  filterCenterStoneframeBandList: any = [];
  isChecked: boolean;
  list: any = [];

    constructor(
      private router: Router,
      private formBuilder: FormBuilder,
      private alertService: AlertService,
      private authenticationService: AuthenticationService,
      private CenterStoneFramebandService: CenterStoneFrameBandService,
      private store: Store<{ centerstoneframeband: CenterStoneframeBand[] }>
    ) {}
   
    ngOnInit() {
      this.getCenterStoneFrameband();
      this.createSearchForm();
      }

      getCenterStoneFrameband() {
        this.CenterStoneFramebandService.getAll().subscribe((data) => {
          if (data) {
            console.log("all data",data)
            this.list = data;
    
            this.centerStoneFrameBandList = this.list.data;
            console.log("all data",this.centerStoneFrameBandList)
    
            for (let i = 0; i < this.centerStoneFrameBandList.length; i++) {
              this.centerStoneFrameBandList[i].isactive =
                this.centerStoneFrameBandList[i].isactive === "N" ? false : true;
              this.centerStoneFrameBandList[i].SrNo = i + 1;
            }
            this.filterCenterStoneframeBandList = this.centerStoneFrameBandList;
          }
        });
      }

      changeStatus(e, data: any) {
        this.isChecked = e.checked;
        const dataObj = {
          id: data.id,
          isactive: this.isChecked ? "Y" : "N",
        };
        this.CenterStoneFramebandService.updateCenteStoneFrameBand(
          dataObj
        ).subscribe((data: CenterStoneframeBand) => {
          this.getCenterStoneFrameband();
          this.alertService.success("Status Updated successfully!", true);
          this.router.navigate(["AdminCenterStoneFrameband/list"]);
        });
      }

      createSearchForm() {
        this.searchForm = this.formBuilder.group({
          keyword: [""],
        });
      }
      clear() {
        this.searchForm.get("keyword")?.setValue("");
        this.searchGrid();
      }

      searchGrid() {
        let keyword = this.searchForm.controls['keyword'].value;
        if (keyword === '') {
          this.filterCenterStoneframeBandList = this.centerStoneFrameBandList;
        } else {
          keyword = keyword.toLowerCase();
          this.filterCenterStoneframeBandList = this.centerStoneFrameBandList.filter((event) => {           
            return (
              (event.productname && event.productname.toLowerCase().includes(keyword)) ||
              (event.product_sub_type && event.product_sub_type.toLowerCase().includes(keyword)) ||
              (event.name && event.name.toLowerCase().includes(keyword)) ||
              (event.designno && event.designno.toLowerCase().includes(keyword)) ||
              (event.variant && event.variant.toLowerCase().includes(keyword)) ||
              (event.csSize && event.csSize.toLowerCase().includes(keyword)) ||
              (event.csType && event.csType.toLowerCase().includes(keyword)) ||
              (event.merchantname && event.merchantname.toLowerCase().includes(keyword)) ||
              (event.collectionName && event.collectionName.toLowerCase().includes(keyword))
            );
          });
        }
      }
}