import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { ProductTypeService } from "@/_services/product-type.service";
import { VendorService } from "@/_services/vendor.service";
import { Component, ViewChild } from "@angular/core";
import { FormArray, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { environment } from "environments/environment";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { CollectionService } from "@/_services/collection.service";
import { MerchantCollectionService } from "@/_services/merchant-collection.service";
import { CenterStoneTypeService } from "@/_services/cs_type.service";
import { CenterStoneVariantService } from "@/_services/cs_variant.service";
import {
  braceletBR,
  BRSize,
  colorList,
  diamondType,
  goldCalculate,
  ringBR,
} from "@/masters/common.master";
import { DiamondShapeService } from "@/_services/diamondshape.service";
import { GlobalColorPreferenceService } from "@/_services/global-color-preference.service";
import { GemstoneService } from "@/_services/gemstone.service";
import { CenterStoneSizeService } from "@/_services/cs_size.service";
import { CenterStoneFamilyname } from "@/_models/cs_familyname";
// import {AccordionModule} from 'primeng/accordion';
import { CenterStoneFamilynameService } from "@/_services/cs_familyname.service";
import { DiamondCaratService } from "@/_services/diamondcarat.service";
import { CenterStoneFrameBandService } from "@/_services/cs_frame_band.service";
import { CenterStoneframeBand } from "@/_models/cs_frame_band";
import { ThrowStmt } from "@angular/compiler";

@Component({
  selector: "app-center-stone-frameband-add",
  templateUrl: "./center-stone-frameband-add.component.html",
  styleUrls: ["./center-stone-framband-add.component.css"],
})
export class CenterStoneFramebandAddComponent {
  centerStoneFramebandAddForm: FormGroup;
  addFamilyForm: FormGroup;
  loading = false;
  submitted = false;
  vendor_id: number;
  merchant_id: number;
  merchantList: any = [];
  list: any = [];
  wtValue: any;
  productList: any = [];
  productSubList: any = [];
  filteredProductSubList: any = [];
  merchantCollectionList: any = [];
  merchantData: any = [];
  merchantSetData: any = [];
  merchantListAll: any = [];
  getCollectionList: any = [];
  gemstoneColorList: any = [];
  diamondCaratList: any = [];
  filtermerchantCollectionList: any = [];
  centerTypeStoneList: any = [];
  centerStoneVariantList: any = [];
  diamondShapeList: any = [];
  merchantListLogin: any;
  gemstoneList: any = [];
  centerStoneSizeList: any = [];
  csSizeList: any = [];
  colorList = colorList;
  wt: number = 0;
  calcgold = [];
  calcgolditem: {
    kt: null;
    wt: null;
    brsize: null;
  };
  gold: any = {
    kt: 22,
    wt22: null,
    wt18: null,
    wt14: null,
  };
  positionList: any = [
    { id: "other" },
    { id: "flat-left" },
    { id: "flat-centre" },
    { id: "flat-right" },
    { id: "model-left" },
    { id: "model-centre" },
    { id: "model-right" },
    { id: "side" },
  ];
  public adminId = `${environment.adminId}`;
  goldCalculate = goldCalculate;
  BRSize = [];
  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();
  modelImage: any;
  partImagePath: any;
  public path = `${environment.apiUrl}`;
  displayFamilyPop: boolean = false;
  getFrameBandFamilyNames: any = [];
  famList: any = [];
  FilterFrameBandFamilyNames: any = [];
  filterCenterStoneVariantList: any = [];
  diamondType = diamondType;
  centerStoneType: any;
  csSizeValue: any;
  getCsFamilyList: any = [];
  FilterGetCsFamilyList: any = [];
  getDropFamilyList: any = [];
  FilterGetDropFamilyList: any = [];
  displayBR = true;
  frameBandID: any;
  frameBandData: any = [];
  mode: string = "ADD";
  filtermerchantCollectionListData: any = [];
  displayGoldCalPopUp: boolean = false;
  addWt: any;
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private vendorservices: VendorService,
    private collectionService: CollectionService,
    private ProductSubTypeService: ProductSubTypeService,
    private authenticationService: AuthenticationService,
    private producttypeService: ProductTypeService,
    private vendorauthenticationService: VendorAuthenticationService,
    private merchantCollectionService: MerchantCollectionService,
    private centerStoneTypeService: CenterStoneTypeService,
    private centerstonvarianService: CenterStoneVariantService,
    private DiamondShapeService: DiamondShapeService,
    private GlobalColorPreferenceService: GlobalColorPreferenceService,
    private GemstoneService: GemstoneService,
    private centerstonsizeService: CenterStoneSizeService,
    private CenterStoneFamilynameService: CenterStoneFamilynameService,
    private DiamondCaratService: DiamondCaratService,
    private CenterStoneFramebandService: CenterStoneFrameBandService,
    private route: ActivatedRoute
  ) {
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id =
        this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.createForm();
    this.famForm();
    this.getCollectionData();
    this.getMerchantList();
    this.getProductList();
    this.getProductSubTypeData();
    this.getAllCenterStoneList();
    this.centerStoneSizevariantList();
    this.diamondShapeData();
    this.gemStoneColor();
    this.gemStoneColor();
    this.genStoneData();
    this.getCenterStoneSizeList();
    this.getDiamondCaratList();
    this.getCSFamilyFamilyBrand();
    this.getCsFamilyDesignList();
    this.getDropFamList();
    ////edit
    this.route.params.subscribe((params) => {
      if (!!params.id) {
        this.frameBandID = params.id;

        this.mode = "EDIT";
        this.getFrameBandById();
      }
    });
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.centerStoneFramebandAddForm.controls;
  }

  get formValidationState() {
    return this.centerStoneFramebandAddForm.controls;
  }

  createForm() {
    this.centerStoneFramebandAddForm = this.formBuilder.group({
      isactive: [""],
      name: ["", Validators.required],
      merchantid: [this.merchant_id, Validators.required],
      product_id: ["", Validators.required],
      product_sub_type: ["", Validators.required],
      collection_id: ["", Validators.required],
      merchantCollection: [""],
      designno: ["", Validators.required],
      frame_family: [""],
      cs_family: [""],
      drop_family: [""],
      imagecolor: [""],

      // csSizeGold: [""],
      csSize: this.formBuilder.array([this.Initial_CsSize()]),
      // csSize: this.formBuilder.array([this.Initial_CsSizeFrameBandSetup()]),
      multipleImages: this.formBuilder.array([this.Initial_Multiple()]),
    });
  }

  getProductSubTypeData() {
    this.ProductSubTypeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.productSubList = this.list.data;
          if (this.mode !== "EDIT") {
            this.filteredProductSubList = this.productSubList.filter(
              (c) => c.merchantid == this.merchant_id
            );
          }
          if (this.centerStoneFramebandAddForm.value.product_id) {
            this.productOnChange();
          }
          this.filtermerchantCollection();
        });
      }
    });
  }

  filtermerchantCollection() {
    this.productOnChange();

    this.filtermerchantCollectionList = this.merchantCollectionList.filter(
      (c) => c.merchantid === this.centerStoneFramebandAddForm.value.merchantid
    );

    this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(
      (c) => c.merchantid == this.centerStoneFramebandAddForm.value.merchantid
    );
    //Frame Band Family
    this.FilterFrameBandFamilyNames = this.getFrameBandFamilyNames.filter(
      (c) => c.merchant_id == this.centerStoneFramebandAddForm.value.merchantid
    );

    //Cs Family
    this.FilterGetCsFamilyList = this.getCsFamilyList.filter(
      (c) => c.merchant_id == this.centerStoneFramebandAddForm.value.merchantid
    );

    //Drop Family
    this.FilterGetDropFamilyList = this.getDropFamilyList.filter(
      (c) => c.merchant_id == this.centerStoneFramebandAddForm.value.merchantid
    );

    this.csSizeList = this.centerStoneSizeList.filter(
      (c) => c.merchant_id == this.centerStoneFramebandAddForm.value.merchantid
    );
  }
  showCalPopUp(itemROw, e: any) {
    this.displayGoldCalPopUp = true;
    this.goldCalculation(itemROw, e);
  }
  productOnChange() {
    if (this.centerStoneFramebandAddForm.value.product_id == 1) {
      this.displayBR = false;
      this.BRSize = braceletBR;
    } else if (this.centerStoneFramebandAddForm.value.product_id == 4) {
      this.BRSize = ringBR;
      this.displayBR = false;
    } else {
      this.displayBR = true;
      this.BRSize = [];
    }

    if (this.productSubList.length > 0) {
      if (this.centerStoneFramebandAddForm.value.product_id != "")
        this.filteredProductSubList = this.productSubList.filter(
          (c) =>
            c.product_id ===
              this.centerStoneFramebandAddForm.value.product_id &&
            c.merchantid == this.centerStoneFramebandAddForm.value.merchantid
        );
      else
        this.filteredProductSubList = this.productSubList.filter(
          (c) =>
            c.merchantid == this.centerStoneFramebandAddForm.value.merchantid
        );
    }
  }

  diamondShapeData() {
    this.DiamondShapeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.diamondShapeList = data;
        });
      }
    });
  }

  genStoneData() {
    this.GemstoneService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneList = data;
        });
      }
    });
  }

  gemStoneColor() {
    this.GlobalColorPreferenceService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneColorList = data;
        });
      }
    });
  }

  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantData = data;

          this.merchantSetData = this.merchantData.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });
        });
      }
    });
  }

  getProductList() {
    this.producttypeService.getAll().subscribe((data) => {
      if (data) {
        //
        setTimeout(() => {
          this.productList = data;
        });
      }
    });
  }

  centerStoneSizevariantList() {
    this.centerstonvarianService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;
        this.centerStoneVariantList = this.list.data;
        if (this.mode !== "EDIT") {
          this.filterCenterStoneVariantList =
            this.centerStoneVariantList.filter(
              (c) =>
                c.merchantid ==
                this.centerStoneFramebandAddForm.value.merchantid
            );
        }
      }
    });
  }

  getAllCenterStoneList() {
    this.centerStoneTypeService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;
        this.centerTypeStoneList = this.list.data;
      }
    });
  }

  // add family...

  showAddFamilyPop() {
    this.displayFamilyPop = true;
  }

  famForm() {
    this.addFamilyForm = this.formBuilder.group({
      name: [""],
      merchantid: [""],
      type: ["Frameband"],
    });
  }

  submitFamilyPop() {
    this.addFamilyForm
      .get("merchantid")
      .setValue(this.centerStoneFramebandAddForm.value.merchantid);
    const dataObj = {
      name: this.addFamilyForm.value.name,
      merchant_id: this.addFamilyForm.value.merchantid,
      type: this.addFamilyForm.value.type,
    };
    if (this.addFamilyForm.valid) {
      this.CenterStoneFamilynameService.save(dataObj).subscribe(
        (data: CenterStoneFamilyname) => {
          this.getCSFamilyFamilyBrand();
          this.alertService.success("Family Added successfully!", true);
          this.displayFamilyPop = false;
        }
      );
    }
  }

  ///#Regin Family Brand
  getCSFamilyFamilyBrand() {
    this.FilterFrameBandFamilyNames = [];
    this.CenterStoneFramebandService.getCSFamilyFamilyBrand().subscribe(
      (data) => {
        if (data) {
          this.famList = data;
          this.getFrameBandFamilyNames = this.famList.data;
          // if (this.mode !== "EDIT") {
            this.FilterFrameBandFamilyNames =
              this.getFrameBandFamilyNames.filter(
                (c) =>
                  c.merchant_id ==
                  this.centerStoneFramebandAddForm.value.merchantid
              );
          // }
        }
      }
    );
  }

  /// //// Cs Family   list////

  getCsFamilyDesignList() {
    this.CenterStoneFramebandService.getCSFamilyDesign().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.getCsFamilyList = this.list.data;
          if (this.mode !== "EDIT") {
            this.FilterGetCsFamilyList = this.getCsFamilyList.filter(
              (c) =>
                c.merchant_id ==
                this.centerStoneFramebandAddForm.value.merchantid
            );
          }
        });
      }
    });
  }

  /// //// Drop Family   list////

  getDropFamList() {
    this.CenterStoneFramebandService.getFamilyDrop().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.getDropFamilyList = this.list.data;
          if (this.mode !== "EDIT") {
            this.FilterGetDropFamilyList = this.getDropFamilyList.filter(
              (c) =>
                c.merchant_id ==
                this.centerStoneFramebandAddForm.value.merchantid
            );
          }
        });
      }
    });
  }

  getCollectionData() {
    this.collectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.getCollectionList = data;
        });
      }
    });
    this.merchantCollectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.merchantCollectionList = this.list.data.filter(x => x.isactive == 'Y');
          this.filtermerchantCollectionList =
            this.merchantCollectionList.filter(
              (c) =>
                c.merchantid ===
                this.centerStoneFramebandAddForm.value.merchantid
            );
        });
      }
    });
  }

  getCenterStoneSizeList() {
    this.centerstonsizeService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;
        this.centerStoneSizeList = this.list.data.filter(
          (x) => x.isactive == "Y"
        );
        this.centerStoneSizeList.map((data) => {
          data.csSize = data.cs_length + " * " + data.cs_width;
          return data;
        });
        if (this.mode !== "EDIT") {
          this.csSizeList = this.centerStoneSizeList.filter(
            (c) =>
              c.merchant_id == this.centerStoneFramebandAddForm.value.merchantid
          );
        }
      }
    });
  }

  //// diamond   list////

  getDiamondCaratList() {
    this.DiamondCaratService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.diamondCaratList = data;
          this.diamondCaratList.sort((a, b) => {
            return a.carat_name - b.carat_name;
          });
        });
      }
    });
  }

  changeType(event) {
    this.centerStoneType = event.value;
    const index = this.centerTypeStoneList.findIndex(
      (x: any) => x.id === this.centerStoneType
    );
  }

  // changeCsSize(event) {
  //   // this.csSizeValue = event.value
  // }

  // changeCalculation(csSizeIndex) {
  //   // this.goldCalculation(this.centerStoneFramebandAddForm.get("csSize").value[csSizeIndex].Kt, this.centerStoneFramebandAddForm.get("csSize").value[csSizeIndex].gold);
  //   // this.goldCalculation(csSizeIndex);
  // }

  // valuechange(csSizeIndex) {
  //   // this.centerStoneFramebandAddForm.value.product_id
  //   // this.goldCalculat/ion(csSizeIndex);
  // }
  // sizeChange(e, gl, csSizeIndex) {
  //   // if (this.centerStoneFramebandAddForm.value.product_sub_type = 1) {
  //   this.cssize(csSizeIndex).value;

  //   // }
  //   // else if (this.centerStoneFramebandAddForm.value.product_sub_type = 4) {
  //   if (gl == 22) {
  //     this.addWt = 0.17;
  //   }
  //   // else if (this.centerStoneFramebandAddForm.value.gold == '18') {
  //   //   this.addWt = 0.15
  //   // }
  //   // else if (this.centerStoneFramebandAddForm.value.gold == '14') {
  //   //   this.addWt = 0.13
  //   // }
  //   if (e.value == 8 || e.value == 9) {
  //     this.gold.wt22 = this.wt;
  //     this.gold.wt18 = this.wt;
  //     this.gold.wt14 = this.wt;
  //   } else if (e.value == 10 || e.value == 11) {
  //     this.gold.wt22 = this.wt + this.addWt;
  //     this.gold.wt18 = this.wt + this.addWt;
  //     this.gold.wt14 = this.wt + this.addWt;
  //   } else if (e.value == 12 || e.value == 13) {
  //     this.gold.wt22 = this.wt + this.addWt;
  //     this.gold.wt18 = this.wt + this.addWt;
  //     this.gold.wt14 = this.wt + this.addWt;
  //   } else if (e.value == 14 || e.value == 15) {
  //     this.gold.wt22 = this.wt + this.addWt;
  //     this.gold.wt18 = this.wt + this.addWt;
  //     this.gold.wt14 = this.wt + this.addWt;
  //   } else if (e.value == 16 || e.value == 17) {
  //     this.gold.wt22 = this.wt + this.addWt;
  //     this.gold.wt18 = this.wt + this.addWt;
  //     this.gold.wt14 = this.wt + this.addWt;
  //   }
  //   // }
  // }

  goldCalculation(itemROw, i) {
    let kt = parseInt(itemROw.value.Kt);
    let wt  = parseFloat(itemROw.value.gold);
    let brsize = itemROw.value.brsize;

    
    const productid = this.centerStoneFramebandAddForm.value.product_id;
    const result = [];
    this.calcgold = [];
    if (productid == 1) {
      //Bracelet
      if (kt == 22) {
        if (brsize == 2.2) {
          result.push({ kt: 22, wt: wt, brsize: 2.2 });
          result.push({ kt: 22, wt: wt + 0.69, brsize: 2.4 });
          result.push({ kt: 22, wt: wt + 0.69 + 0.69, brsize: 2.6 });
        }
        if (brsize == 2.4) {
          result.push({ kt: 22, wt: wt, brsize: 2.4 });
          result.push({ kt: 22, wt: wt + 0.69, brsize: 2.6 });
        }
        if (brsize == 2.6) {
          result.push({ kt: 22, wt: wt, brsize: 2.6 });
        }
        let base18 = this.convertto18Kt(result);
        let base14 = this.convertto14Kt(base18);
        this.calcgold = result.concat(base18, base14);
      } else if (kt == 18) {
        if (brsize == 2.2) {
          result.push({ kt: 18, wt: wt, brsize: 2.2 });
          result.push({ kt: 18, wt: wt + 0.6, brsize: 2.4 });
          result.push({ kt: 18, wt: wt + 0.6 + 0.6, brsize: 2.6 });
        }
        if (brsize == 2.4) {
          result.push({ kt: 22, wt: wt, brsize: 2.4 });
          result.push({ kt: 22, wt: wt + 0.6, brsize: 2.6 });
        }
        if (brsize == 2.6) {
          result.push({ kt: 22, wt: wt, brsize: 2.6 });
        }
        let base14 = this.convertto14Kt(result);
        this.calcgold = result.concat(base14);
      } else {
        if (brsize == 2.2) {
          this.calcgold.push({ kt: 14, wt: wt, brsize: 2.2 });
          this.calcgold.push({ kt: 14, wt: wt + 0.52, brsize: 2.4 });
          this.calcgold.push({ kt: 14, wt: wt + 0.52 + 0.52, brsize: 2.6 });
        }
        if (brsize == 2.4) {
          this.calcgold.push({ kt: 22, wt: wt, brsize: 2.4 });
          this.calcgold.push({ kt: 22, wt: wt + 0.52, brsize: 2.6 });
        }
        if (brsize == 2.6) {
          this.calcgold.push({ kt: 22, wt: wt, brsize: 2.6 });
        }
      }
    } else if (productid == 4) {
      // Ring
      if (kt == 22) {
        if (brsize == 8 || brsize == 9) {
          if(brsize == 8) {
          result.push({ kt: 22, wt: wt, brsize: 8 });
          }
          result.push({ kt: 22, wt: wt, brsize: 9 });
          result.push({ kt: 22, wt: wt + 0.17, brsize: 10 });
          result.push({ kt: 22, wt: wt + 0.17, brsize: 11 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17, brsize: 12 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17, brsize: 13 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17 + 0.17, brsize: 14 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17 + 0.17, brsize: 15 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17 + 0.17 + 0.17, brsize: 16 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17 + 0.17 + 0.17, brsize: 17 });
        }
        if (brsize == 10 || brsize == 11) {
          if(brsize == 10) {
          result.push({ kt: 22, wt: wt, brsize: 10 });
          }
          result.push({ kt: 22, wt: wt, brsize: 11 });
          result.push({ kt: 22, wt: wt + 0.17, brsize: 12 });
          result.push({ kt: 22, wt: wt + 0.17, brsize: 13 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17, brsize: 14 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17, brsize: 15 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17 + 0.17, brsize: 16 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17 + 0.17, brsize: 17 });
        }
        if (brsize == 12 || brsize == 13) {
          if(brsize == 12) {
          result.push({ kt: 22, wt: wt, brsize: 12 });
          }
          result.push({ kt: 22, wt: wt, brsize: 13 });
          result.push({ kt: 22, wt: wt + 0.17, brsize: 14 });
          result.push({ kt: 22, wt: wt + 0.17, brsize: 15 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17, brsize: 16 });
          result.push({ kt: 22, wt: wt + 0.17 + 0.17, brsize: 17 });
        }
        if (brsize == 14 || brsize == 15) {
          if(brsize == 14) {
          result.push({ kt: 22, wt: wt, brsize: 14 });
          }
          result.push({ kt: 22, wt: wt, brsize: 15 });
          result.push({ kt: 22, wt: wt + 0.17, brsize: 16 });
          result.push({ kt: 22, wt: wt + 0.17, brsize: 17 });
        }
        if (brsize == 16 || brsize == 17) {
          if(brsize == 16) {
          result.push({ kt: 22, wt: wt, brsize: 16 });
          }
          result.push({ kt: 22, wt: wt, brsize: 17 });
        }
        
        let base18 = this.convertto18Kt(result);
        let base14 = this.convertto14Kt(base18);
        this.calcgold = result.concat(base18, base14);
      } else if (kt == 18) {
        if (brsize == 8 || brsize == 9) {
          if(brsize == 8) {
          result.push({ kt: 18, wt: wt, brsize: 8 });
          }
          result.push({ kt: 18, wt: wt, brsize: 9 });
          result.push({ kt: 18, wt: wt +  0.15, brsize: 10 });
          result.push({ kt: 18, wt: wt +  0.15, brsize: 11 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15, brsize: 12 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15, brsize: 13 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15 +  0.15, brsize: 14 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15 +  0.15, brsize: 15 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15 +  0.15 +  0.15, brsize: 16 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15 +  0.15 +  0.15, brsize: 17 });
        }
        if (brsize == 10 || brsize == 11) {
          if(brsize == 10) {
          result.push({ kt: 18, wt: wt, brsize: 10 });
          }
          result.push({ kt: 18, wt: wt, brsize: 11 });
          result.push({ kt: 18, wt: wt +  0.15, brsize: 12 });
          result.push({ kt: 18, wt: wt +  0.15, brsize: 13 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15, brsize: 14 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15, brsize: 15 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15 +  0.15, brsize: 16 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15 +  0.15, brsize: 17 });
        }
        if (brsize == 12 || brsize == 13) {
          if(brsize == 12) {
          result.push({ kt: 18, wt: wt, brsize: 12 });
          }
          result.push({ kt: 18, wt: wt, brsize: 13 });
          result.push({ kt: 18, wt: wt +  0.15, brsize: 14 });
          result.push({ kt: 18, wt: wt +  0.15, brsize: 15 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15, brsize: 16 });
          result.push({ kt: 18, wt: wt +  0.15 +  0.15, brsize: 17 });
        }
        if (brsize == 14 || brsize == 15) {
          if(brsize == 14) {
          result.push({ kt: 18, wt: wt, brsize: 14 });
          }
          result.push({ kt: 18, wt: wt, brsize: 15 });
          result.push({ kt: 18, wt: wt +  0.15, brsize: 16 });
          result.push({ kt: 18, wt: wt +  0.15, brsize: 17 });
        }
        if (brsize == 16 || brsize == 17) {
          if(brsize == 16) {
          result.push({ kt: 18, wt: wt, brsize: 16 });
          }
          result.push({ kt: 18, wt: wt, brsize: 17 });
        }
        let base14 = this.convertto14Kt(result);
        this.calcgold = result.concat(base14);
      } else {
        if (brsize == 8 || brsize == 9) {
          if(brsize == 8) {
          result.push({ kt: 14, wt: wt, brsize: 8 });
          }
          result.push({ kt: 14, wt: wt, brsize: 9 });
          result.push({ kt: 14, wt: wt +  0.13, brsize: 10 });
          result.push({ kt: 14, wt: wt +  0.13, brsize: 11 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13, brsize: 12 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13, brsize: 13 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13 +  0.13, brsize: 14 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13 +  0.13, brsize: 15 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13 +  0.13 +  0.13, brsize: 16 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13 +  0.13 +  0.13, brsize: 17 });
        }
        if (brsize == 10 || brsize == 11) {
          if(brsize == 10) {
          result.push({ kt: 14, wt: wt, brsize: 10 });
          }
          result.push({ kt: 14, wt: wt, brsize: 11 });
          result.push({ kt: 14, wt: wt +  0.13, brsize: 12 });
          result.push({ kt: 14, wt: wt +  0.13, brsize: 13 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13, brsize: 14 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13, brsize: 15 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13 +  0.13, brsize: 16 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13 +  0.13, brsize: 17 });
        }
        if (brsize == 12 || brsize == 13) {
          if(brsize == 12) {
          result.push({ kt: 14, wt: wt, brsize: 12 });
          }
          result.push({ kt: 14, wt: wt, brsize: 13 });
          result.push({ kt: 14, wt: wt +  0.13, brsize: 14 });
          result.push({ kt: 14, wt: wt +  0.13, brsize: 15 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13, brsize: 16 });
          result.push({ kt: 14, wt: wt +  0.13 +  0.13, brsize: 17 });
        }
        if (brsize == 14 || brsize == 15) {
          if(brsize == 14) {
          result.push({ kt: 14, wt: wt, brsize: 14 });
          }
          result.push({ kt: 14, wt: wt, brsize: 15 });
          result.push({ kt: 14, wt: wt +  0.13, brsize: 16 });
          result.push({ kt: 14, wt: wt +  0.13, brsize: 17 });
        }
        if (brsize == 16 || brsize == 17) {
          if(brsize == 16) {
          result.push({ kt: 14, wt: wt, brsize: 16 });
          }
          result.push({ kt: 14, wt: wt, brsize: 17 });
        }
        this.calcgold = result;
      }
    } else {
      if (kt == 22) {
        result.push({ kt: 22, wt: wt, brsize: "" });
        let base18 = this.convertto18Kt(result);
        let base14 = this.convertto14Kt(base18);
        this.calcgold = result.concat(base18, base14);
      } else if (kt == 18) {
        result.push({ kt: 18, wt: wt, brsize: "" });
        let base14 = this.convertto14Kt(result);
        this.calcgold = result.concat(base14);
      } else {
        this.calcgold.push({ kt: 14, wt: wt, brsize: "" });
      }
    }
    this.centerStoneFramebandAddForm.controls['csSize']["controls"][i].controls["calcgold"].setValue(this.calcgold);
  }

  convertto18Kt(data) {
    let result = [];
    data.forEach((element) => {
      result.push({ kt: 18, wt: element.wt * 0.873, brsize: element.brsize });
    });
    return result;
  }

  convertto14Kt(data) {
    let result = [];
    data.forEach((element) => {
      result.push({ kt: 14, wt: element.wt * 0.864, brsize: element.brsize });
    });
    return result;
  }
  // ///////calculation for gold/////////

  // const calcgold = [];

  // const ktValues = [22, 18, 14];

  // const brSizes = [2.2, 2.4, 2.6];

  // // Loop through each kt value
  // for (const kt of ktValues) {

  //   // Loop through each BR size
  //   for (const brsize of brSizes) {

  //     // Calculate the weight for the current kt and BR size
  //     let wt = 1;
  //     if (kt === 22) {
  //       if (brsize === 2.2) {
  //         wt += 0.69;
  //       } else if (brsize === 2.4) {
  //         wt *= 0.873;
  //       } else if (brsize === 2.6) {
  //         wt *= 0.873 * 0.864;
  //       }
  //     } else if (kt === 18) {
  //       if (brsize === 2.2) {
  //         wt *= 0.873;
  //       } else if (brsize === 2.4) {
  //         wt *= 0.873 * 0.864;
  //       } else if (brsize === 2.6) {
  //         wt *= 0.873 * 0.864 * 0.853;
  //       }
  //     } else if (kt === 14) {
  //       if (brsize === 2.2) {
  //         wt *= 0.864;
  //       } else if (brsize === 2.4) {
  //         wt *= 0.864 * 0.853;
  //       } else if (brsize === 2.6) {
  //         wt *= 0.864 * 0.853 * 0.84;
  //       }
  //     }

  //     // Add the result array
  //     calcgold.push({ kt: kt, BRsize: brsize, wt: wt });

  //   }

  // }

  // console.log(calcgold)

  ////FormArray fo CS SIZE Start////
  Initial_CsSize() {
    return this.formBuilder.group({
      variant: [""],
      centerStoneType: [""],
      csSize: [""],
      noAUtoSizing: [""],
      gold: [""],
      Kt: [""],
      brsize: [""],
      calcgold: [""],
      yoffsetcoordinate: [""],
      diamond: this.formBuilder.array([this.Initial_Diamond()]),
      gemstone: this.formBuilder.array([this.Initial_GemStones()]),
    });
  }

  get csSize(): FormArray {
    return this.centerStoneFramebandAddForm.get("csSize") as FormArray;
  }

  addCsSize() {
    this.csSize.push(this.Initial_CsSize());
    // this.csSize().push(this.Initial_CsSizeFrameBandSetup());
  }
  removeCsSizeList(index: number) {
    this.csSize.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
    // this.removeCsSizeFrameBandSetup(index)
  }

  ////FormArray fo CS SIZE End ////

  //////
  //#region csSIzeFrma bandDesign

  Initial_CsSizeFrameBandSetup() {
    return this.formBuilder.group({
      gold: [""],
      Kt: [""],
      brsize: [""],
      yoffsetcoordinate: [""],
      diamond: this.formBuilder.array([this.Initial_Diamond()]),
      gemstone: this.formBuilder.array([this.Initial_GemStones()]),
    });
  }

  // csSize(): FormArray {
  //   return this.centerStoneFramebandAddForm.get("csSize") as FormArray;
  // }

  // addCsSIzeFrameBand() {
  //   this.csSize().push(this.Initial_CsSizeFrameBandSetup());
  // }

  // removeCsSizeFrameBandSetup(index: number) {
  //   this.csSize().removeAt(index);
  // }

  //#region csSIzeFrma bandDesign

  ///Diamond formArray/////
  Initial_Diamond() {
    return this.formBuilder.group({
      brSize: [""],
      wt: [""],
      nos: [""],
      shape: [""],
      twt: [""],
      diaType: [""],
      allbr: [""],
    });
  }

  designdiamond(empIndex: number): FormArray {
    return this.csSize.at(empIndex).get("diamond") as FormArray;
  }

  diamond(diamondIndex): FormArray {
    return this.csSize.at(diamondIndex).get("diamond") as FormArray;
  }

  addDiamond(diamondIndex) {
    this.designdiamond(diamondIndex).push(this.Initial_Diamond());
  }

  removeDiamondList(csSizeIndex: number, diamondIndex: number) {
    this.designdiamond(csSizeIndex).removeAt(diamondIndex);
  }

  ///Gemstone FormArray/////

  Initial_GemStones() {
    return this.formBuilder.group({
      brSize: [""],
      name: [""],
      size: [""],
      shape: [""],
      wt: [""],
      nos: [""],
      color: [""],
      twt: [""],
      allbr: [""],
    });
  }

  designgemstone(empIndex: number): FormArray {
    return this.csSize.at(empIndex).get("gemstone") as FormArray;
  }

  cssize(empIndex: number): FormArray {
    return this.csSize.at(empIndex) as FormArray;
  }

  get gemstone(): FormArray {
    return this.centerStoneFramebandAddForm.get("gemstone") as FormArray;
  }

  addGemStones(gemstoneIndex) {
    this.designgemstone(gemstoneIndex).push(this.Initial_GemStones());
  }

  removeFGemStoneList(csSizeIndex: number, gemstoneIndex: number) {
    this.designgemstone(csSizeIndex).removeAt(gemstoneIndex);
  }

  ///Gemstone FormArray/////

  // /add Gemstones data Form End

  wtChange(e: any, i: any, csSizeIndex: any) {
    this.wtValue = e;
    let diaWt = this.designdiamond(csSizeIndex)["controls"][i].value.wt
    let val =
    diaWt *
      this.designdiamond(csSizeIndex)["controls"][i].value.nos;
    let data = Math.round(val * 100) / 100;
    this.designdiamond(csSizeIndex)["controls"][i]["controls"]["twt"].setValue(
      data
    );
  }

  nosChange(e: any, i: any, csSizeIndex: any) {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)
        : t;
    // let result = this.diamondCaratList.filter(
    //   (c) => c.id === this.designdiamond(csSizeIndex)["controls"][i].value.wt
    // );
    let diaWt = this.designdiamond(csSizeIndex)["controls"][i].value.wt
    let val =
    diaWt *
      this.designdiamond(csSizeIndex)["controls"][i].value.nos;
    let data = Math.round(val * 100) / 100;
    this.designdiamond(csSizeIndex)["controls"][i]["controls"]["twt"].setValue(
      data
    );
  }

  twtChange(e: any, i: any, csSizeIndex: any) {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)
        : t;
    // let result = this.diamondCaratList.filter(
    //   (c) => c.id === this.designdiamond(csSizeIndex)["controls"][i].value.wt
    // );
    let diaWt = this.designdiamond(csSizeIndex)["controls"][i].value.wt

    let val =
      this.designdiamond(csSizeIndex)["controls"][i].value.twt /
      diaWt;
    let data = Math.round(val * 100) / 100;
    this.designdiamond(csSizeIndex)["controls"][i]["controls"]["nos"].setValue(
      data
    );
  }

  ///gemstone add form value chnage
  gemWtChange(e: any, i: any,csSizeIndex: any) {
    this.wtValue = e;
    let result = this.designgemstone(csSizeIndex)["controls"][i].value.wt;
    let val =
      result * this.designgemstone(csSizeIndex)["controls"][i].value.nos;
    let data = Math.round(val * 100) / 100;
    this.designgemstone(csSizeIndex)["controls"][i]["controls"]["twt"].setValue(
      data
    );
  }
  gemNosChange(e: any, i: any, csSizeIndex: any) {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)
        : t;
    let result = this.designgemstone(csSizeIndex)["controls"][i].value.wt;
    let val =
      result * this.designgemstone(csSizeIndex)["controls"][i].value.nos;
    let data = Math.round(val * 100) / 100;
    this.designgemstone(csSizeIndex)["controls"][i]["controls"]["twt"].setValue(
      data
    );
  }

  gemTwtChange(e: any, i: any, csSizeIndex: any) {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)
        : t;
    let result = this.designgemstone(csSizeIndex)["controls"][i].value.wt;
    let val =
      this.designgemstone(csSizeIndex)["controls"][i].value.twt / result;
    let data = Math.round(val * 100) / 100;
    this.designgemstone(csSizeIndex)["controls"][i]["controls"]["nos"].setValue(
      data
    );
  }

  ///gemstone add form value chnage''

  /// Multiple images ///

  selectedFiles(files: File[], index) {
    for (var i = 0; i < files.length; i++) {
      this.fileindexposition++;
      this.FileListMap.set(index, files[i]);
    }
  }

  Initial_Multiple() {
    return this.formBuilder.group({
      images: [""],
      displayUser: [""],
      selectColor: [""],
      secondOption: [""],
      Position: [""],
      modelImage: [""],
      csSize: [""],
    });
  }

  get multipleImages() {
    return this.centerStoneFramebandAddForm.get("multipleImages") as FormArray;
  }

  removeRow(index: number) {
    this.multipleImages.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  toggledisplayuser(i: number) {
    if (
      this.centerStoneFramebandAddForm.value.multipleImages[i].displayUser ==
      true
    ) {
      this.centerStoneFramebandAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["secondOption"].setValue(false);
    }
  }

  togglesecond(i: number) {
    if (
      this.centerStoneFramebandAddForm.value.multipleImages[i].secondOption ==
      true
    ) {
      this.centerStoneFramebandAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["displayUser"].setValue(false);
    }
  }

  validatePosition(e: any, i: number, color: string, csSizes: any) {
    let aFormArray = this.centerStoneFramebandAddForm.get("multipleImages");
    if (e.value !== "other") {
      this.centerStoneFramebandAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["displayUser"].setValue(false);
      this.centerStoneFramebandAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["secondOption"].setValue(false);

      let countPos = 0;
      for (let c of aFormArray["controls"]) {
        if (
          c.controls["Position"].value === e.value &&
          c.controls["selectColor"].value === color &&
          c.controls["csSize"].value === csSizes
        ) {
          countPos++;
        }
        if (countPos > 1) {
          this.centerStoneFramebandAddForm.controls["multipleImages"][
            "controls"
          ][i].controls["Position"].setValue("");
          this.alertService.success(
            "Postion Already available for selected color",
            false
          );
          break;
        }
      }
    }
  }

  // image Upload

  onModelImageSelect(files: File[]) {
    var base64valueModel;
    for (var element = 0; element < files.length; element++) {
      const readerModel = new FileReader();
      readerModel.readAsDataURL(files[element]);
      readerModel.onload = (event: any) => {
        if (event.target.result) {
          base64valueModel = event.target.result;
          let dataModelObj = {
            base64format: base64valueModel,
            imagePath: files[0].name,
          };
          this.ProductSubTypeService.upload(dataModelObj).subscribe((data) => {
            this.modelImage = data["data"];
            this.partImagePath =
              this.path + "/imagepreview/getImage?imagename=" + this.modelImage;
            this.multipleImages.push(
              this.formBuilder.group({
                images: [this.partImagePath],
                displayUser: [
                  this.centerStoneFramebandAddForm.value.multipleImages
                    .displayUser === true
                    ? "Y"
                    : "N",
                ],
                selectColor: [
                  this.centerStoneFramebandAddForm.value.imagecolor,
                ],
                secondOption: [
                  this.centerStoneFramebandAddForm.value.multipleImages
                    .secondOption === true
                    ? "Y"
                    : "N",
                ],
                Position: [""],
                modelImage: [this.modelImage],
                csSize: [""],
              })
            );
          });
        }
      };
    }
  }

  onSubmit() {
    this.submitted = true;
    this.centerStoneFramebandAddForm.value.multipleImages.shift();

    if (this.centerStoneFramebandAddForm.value.merchantid === 22) {
      this.centerStoneFramebandAddForm.controls["collection_id"].setValidators(
        Validators.required
      );
      this.centerStoneFramebandAddForm.controls[
        "merchantCollection"
      ]?.clearValidators();
      this.centerStoneFramebandAddForm.controls["merchantCollection"].setErrors(
        null
      );
    } else if (this.centerStoneFramebandAddForm.value.merchantid !== 22) {
      this.centerStoneFramebandAddForm.controls[
        "merchantCollection"
      ].setValidators(Validators.required);
      this.centerStoneFramebandAddForm.controls[
        "collection_id"
      ]?.clearValidators();
      this.centerStoneFramebandAddForm.controls["collection_id"].setErrors(
        null
      );
    }
    if (this.centerStoneFramebandAddForm.valid) {
      const dataObj = {
        name: this.centerStoneFramebandAddForm.value.name,
        merchant_id: this.centerStoneFramebandAddForm.value.merchantid,
        productid: this.centerStoneFramebandAddForm.value.product_id,
        productsubtypeid:
          this.centerStoneFramebandAddForm.value.product_sub_type,
        designno: this.centerStoneFramebandAddForm.value.designno,
        collectionid: this.centerStoneFramebandAddForm.value.collection_id,
        merchantCollection:
          this.centerStoneFramebandAddForm.value.merchantCollection,
        frame_family: this.centerStoneFramebandAddForm.value.frame_family,
        cs_family: this.centerStoneFramebandAddForm.value.cs_family,
        drop_family: this.centerStoneFramebandAddForm.value.drop_family,
        variant: this.centerStoneFramebandAddForm.value.variant,
        cs_type: this.centerStoneFramebandAddForm.value.centerStoneType,
        cs_frameband: this.centerStoneFramebandAddForm.value.csSize,
        cs_image_comm: this.centerStoneFramebandAddForm.value.multipleImages,
      };

      this.CenterStoneFramebandService.save(dataObj).subscribe(
        (data: CenterStoneframeBand) => {
          this.alertService.success(
            "Centre Stone Frame Band  Saved successfully!",
            true
          );
          if (this.vendor_id) {
            this.router.navigate(["MerchantCenterStoneFrameband/list"]);
          } else {
            this.router.navigate(["AdminCenterStoneFrameband/list"]);
          }
        }
      );
    }
  }

  //// Edit Form

  getFrameBandById() {
    this.CenterStoneFramebandService.getCenteStoneFrameBandById({
      id: this.frameBandID,
    }).subscribe((data) => {
      if (data) {
        this.setFormValue(data);
      }
    });
  }

  @ViewChild('myImage') myImage;
  clearFile(){
    this.myImage.nativeElement.value = '';
  }

  setFormValue(data) {
    this.frameBandData = data.data;

    this.filteredProductSubList = this.productSubList.filter(
      (c) =>
        c.merchantid == this.frameBandData[0].merchant_id &&
        this.frameBandData[0].productid
    );

    this.filtermerchantCollectionList = this.merchantCollectionList.filter(
      (c) => c.merchantid === this.frameBandData[0].merchant_id
    );

    this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(
      (c) => c.merchantid == this.frameBandData[0].merchant_id
    );
    //Frame Band Family
    this.FilterFrameBandFamilyNames = this.getFrameBandFamilyNames.filter(
      (c) => c.merchant_id == this.frameBandData[0].merchant_id
    );

    //Cs Family
    this.FilterGetCsFamilyList = this.getCsFamilyList.filter(
      (c) => c.merchant_id == this.frameBandData[0].merchant_id
    );

    //Drop Family
    this.FilterGetDropFamilyList = this.getDropFamilyList.filter(
      (c) => c.merchant_id == this.frameBandData[0].merchant_id
    );

    this.csSizeList = this.centerStoneSizeList.filter(
      (c) => c.merchant_id == this.frameBandData[0].merchant_id
    );

    this.centerStoneFramebandAddForm
      .get("isactive")
      ?.setValue(this.frameBandData[0].isactive === "Y" ? true : false);
    this.centerStoneFramebandAddForm
      .get("name")
      ?.setValue(this.frameBandData[0]?.name);
    this.centerStoneFramebandAddForm
      .get("merchantid")
      ?.setValue(this.frameBandData[0].merchant_id);

    this.centerStoneFramebandAddForm
      .get("product_id")
      ?.setValue(this.frameBandData[0].productid);
    if (this.centerStoneFramebandAddForm.value.product_id == 1) {
      this.displayBR = false;
      this.BRSize = braceletBR;
    } else if (this.centerStoneFramebandAddForm.value.product_id == 4) {
      this.BRSize = ringBR;
      this.displayBR = false;
    } else {
      this.displayBR = true;
      this.BRSize = [];
    }
    this.centerStoneFramebandAddForm
      .get("product_sub_type")
      ?.setValue(this.frameBandData[0].productsubtypeid);
    this.centerStoneFramebandAddForm
      .get("designno")
      ?.setValue(this.frameBandData[0].designno);
    this.centerStoneFramebandAddForm
      .get("collection_id")
      ?.setValue(this.frameBandData[0].collectionid);
    this.centerStoneFramebandAddForm
      .get("merchantCollection")
      ?.setValue(this.frameBandData[0].merchantCollection);
    this.centerStoneFramebandAddForm
      .get("frame_family")
      ?.setValue(this.frameBandData[0].frame_family);
    this.centerStoneFramebandAddForm
      .get("cs_family")
      ?.setValue(this.frameBandData[0].cs_family);
    this.centerStoneFramebandAddForm
      .get("drop_family")
      ?.setValue(this.frameBandData[0].drop_family);

    var JsonData = this.frameBandData[0].cs_image_comm;
    var dataOfImage = JsonData;
    this.centerStoneFramebandAddForm.setControl(
      "multipleImages",
      this.setImageForm(dataOfImage)
    );

    var JsonImgData = this.frameBandData[0].cs_frameband;
    for (let index = 0; index < JsonImgData.length; index++) {
      const element = JsonImgData[index];
      this.addcsSizeForm(element);
    }

    this.csSizees.removeAt(0);
  }

  addcsSizeForm(s) {
    const lessonForm = this.formBuilder.group({
      variant: [s.variant],
      centerStoneType: [s.centerStoneType],
      csSize: [s.csSize],
      noAUtoSizing: [""],
      gold: [s.gold],
      Kt: [s.Kt],
      brsize: [s.brsize],
      calcgold:[s.calcgold],
      yoffsetcoordinate: [s.yoffsetcoordinate],
      diamond: this.formBuilder.array([]),
      gemstone: this.formBuilder.array([]),
    });
    let varydiamond = lessonForm.controls["diamond"] as FormArray;
    for (let index = 0; index < s.diamond.length; index++) {
      let result = this.adddiamondForm(s);
      varydiamond.push(result);
    }

    let varygemstone = lessonForm.controls["gemstone"] as FormArray;
    for (let index = 0; index < s.gemstone.length; index++) {
      let result = this.addgemstoneForm(s);
      varygemstone.push(result);
    }
    lessonForm.patchValue(s);
    this.csSizees.push(lessonForm);
  }

  adddiamondForm(s) {
    const lessonForm = this.formBuilder.group({
      brSize: [""],
      wt: [""],
      nos: [""],
      shape: [""],
      twt: [""],
      diaType: [""],
      allbr: [""],
    });

    lessonForm.patchValue(s);
    return lessonForm;
  }

  addgemstoneForm(s) {
    const lessonForm = this.formBuilder.group({
      brSize: [""],
      name: [""],
      size: [""],
      shape: [""],
      wt: [""],
      nos: [""],
      color: [""],
      twt: [""],
      allbr: [""],
    });

    lessonForm.patchValue(s);
    return lessonForm;
  }

  get csSizees() {
    return this.centerStoneFramebandAddForm.controls["csSize"] as FormArray;
  }

  setImageForm(dataOfMultipleImages): FormArray {
    const formArray = new FormArray([]);

    for (const s of dataOfMultipleImages) {
      //do something
      formArray.push(
        this.formBuilder.group({
          images: [s.images],
          displayUser: [s.displayUser],
          selectColor: [s.selectColor],
          secondOption: [s.secondOption],
          Position: [s.Position],
          csSize: [s.csSize],
          modelImage: [s.modelImage],
        })
      );
    }

    return formArray;
  }

  onUpdate() {
    this.submitted = true;

    if (this.centerStoneFramebandAddForm.value.merchantid === 22) {
      this.centerStoneFramebandAddForm.controls["collection_id"].setValidators(
        Validators.required
      );
      this.centerStoneFramebandAddForm.controls[
        "merchantCollection"
      ]?.clearValidators();
      this.centerStoneFramebandAddForm.controls["merchantCollection"].setErrors(
        null
      );
    } else if (this.centerStoneFramebandAddForm.value.merchantid !== 22) {
      this.centerStoneFramebandAddForm.controls[
        "merchantCollection"
      ].setValidators(Validators.required);
      this.centerStoneFramebandAddForm.controls[
        "collection_id"
      ]?.clearValidators();
      this.centerStoneFramebandAddForm.controls["collection_id"].setErrors(
        null
      );
    }

    if (this.centerStoneFramebandAddForm.valid) {
      const dataObj = {
        id: this.frameBandID,
        name: this.centerStoneFramebandAddForm.value.name,
        isactive:
          this.centerStoneFramebandAddForm.value.isactive == true ? "Y" : "N",
        merchant_id: this.centerStoneFramebandAddForm.value.merchantid,
        productid: this.centerStoneFramebandAddForm.value.product_id,
        productsubtypeid:
          this.centerStoneFramebandAddForm.value.product_sub_type,
        designno: this.centerStoneFramebandAddForm.value.designno,
        collectionid: this.centerStoneFramebandAddForm.value.collection_id,
        merchantCollection:
          this.centerStoneFramebandAddForm.value.merchantCollection,
        frame_family: this.centerStoneFramebandAddForm.value.frame_family,
        cs_family: this.centerStoneFramebandAddForm.value.cs_family,
        drop_family: this.centerStoneFramebandAddForm.value.drop_family,
        variant: this.centerStoneFramebandAddForm.value.variant,
        cs_type: this.centerStoneFramebandAddForm.value.centerStoneType,
        cs_frameband: this.centerStoneFramebandAddForm.value.csSize,
        cs_image_comm: this.centerStoneFramebandAddForm.value.multipleImages,
      };

      this.CenterStoneFramebandService.updateCenteStoneFrameBand(
        dataObj
      ).subscribe((data: CenterStoneframeBand) => {
        this.alertService.success(
          "Centre Stone Frame Band  Updated successfully!",
          true
        );
        if (this.vendor_id) {
          this.router.navigate(["MerchantCenterStoneFrameband/list"]);
        } else {
          this.router.navigate(["AdminCenterStoneFrameband/list"]);
        }
      });
    }
  }

  backList() {
    if (this.vendor_id) {
      this.router.navigate(["MerchantCenterStoneFrameband/list"]);
    } else {
      this.router.navigate(["AdminCenterStoneFrameband/list"]);
    }
  }
}
