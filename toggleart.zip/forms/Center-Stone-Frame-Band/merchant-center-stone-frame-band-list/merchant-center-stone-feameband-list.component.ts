import { CenterStoneframeBand } from "@/_models/cs_frame_band";
import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { CenterStoneFrameBandService } from "@/_services/cs_frame_band.service";
import { Component } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";

@Component({
  selector: "app-merchant-center-stone-frameband-list",
  templateUrl: "./merchant-center-stone-frameband-list.component.html",
  styleUrls: ["./merchant-center-stone-frameband-list.component.css"],
})
export class MerchantCenterStoneFramebandListComponent {
  centerStoneFrameBandList: any = [];
  searchForm: FormGroup;
  filterMerchantCenterStoneframeBandList: any = [];
  isChecked: boolean;
  list: any = [];
  vendor_id: number;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private CenterStoneFramebandService: CenterStoneFrameBandService,
    private vendorauthenticationService: VendorAuthenticationService,
    private store: Store<{ centerstoneframeband: CenterStoneframeBand[] }>
  ) {
    if (!this.vendorauthenticationService.vendorcurrentUserValue) {
      this.router.navigate(["merchant"]);
    }
  }

  ngOnInit() {
    this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id;

    this.getCenterStoneFrameband();
    this.createSearchForm();
  }

  getCenterStoneFrameband() {
    const dataObj = {
      merchant_id: this.vendor_id,
    };
    this.CenterStoneFramebandService.getCS_FrameBandbyMerchantid(
      dataObj
    ).subscribe((data) => {
      if (data) {
        this.list = data;

        this.centerStoneFrameBandList = this.list.data;

        for (let i = 0; i < this.centerStoneFrameBandList.length; i++) {
          this.centerStoneFrameBandList[i].isactive =
            this.centerStoneFrameBandList[i].isactive === "N" ? false : true;
          this.centerStoneFrameBandList[i].SrNo = i + 1;
        }
        this.filterMerchantCenterStoneframeBandList =
          this.centerStoneFrameBandList;
      }
    });
  }

  changeStatus(e, data: any) {
    this.isChecked = e.checked;
    const dataObj = {
      id: data.id,
      isactive: this.isChecked ? "Y" : "N",
    };
    this.CenterStoneFramebandService.updateCenteStoneFrameBand(
      dataObj
    ).subscribe((data: CenterStoneframeBand) => {
      this.getCenterStoneFrameband();
      this.alertService.success("Status Updated successfully!", true);
    });
  }

  createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [""],
    });
  }
  clear() {
    this.searchForm.get("keyword")?.setValue("");
    this.searchGrid();
  }

  searchGrid() {
    let keyword = this.searchForm.controls['keyword'].value;
    if (keyword === '') {
      this.filterMerchantCenterStoneframeBandList = this.centerStoneFrameBandList;
    } else {
      keyword = keyword.toLowerCase();
      this.filterMerchantCenterStoneframeBandList = this.centerStoneFrameBandList.filter((event) => {
        return (
          (event.productname && event.productname.toLowerCase().includes(keyword)) ||
          (event.product_sub_type && event.product_sub_type.toLowerCase().includes(keyword)) ||
          (event.name && event.name.toLowerCase().includes(keyword)) ||
          (event.designno && event.designno.toLowerCase().includes(keyword)) ||
          (event.variant && event.variant.toLowerCase().includes(keyword)) ||
          (event.csSize && event.csSize.toLowerCase().includes(keyword)) ||
          (event.csType && event.csType.toLowerCase().includes(keyword)) ||
          (event.collectionName && event.collectionName.toLowerCase().includes(keyword))
        );
      });
    }
  }
}
