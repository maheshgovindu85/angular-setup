import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { VendorService } from "@/_services/vendor.service";
import { Component } from "@angular/core";
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { environment } from "environments/environment";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { CenterStoneVariantService } from "@/_services/cs_variant.service";
import { CenterStoneSizeService } from "@/_services/cs_size.service";
import { CenterStoneFrameBandService } from "@/_services/cs_frame_band.service";
import { diamondType, goldCalculate } from "@/masters/common.master";
import { DiamondCaratService } from "@/_services/diamondcarat.service";
import { DiamondShapeService } from "@/_services/diamondshape.service";
import { GemstoneService } from "@/_services/gemstone.service";
import { GlobalColorPreferenceService } from "@/_services/global-color-preference.service";
import { CenterStoneAutoSizeDropService } from "@/_services/cs_auto_size_drop.service";
import { CenterStoneAutoSizeDrop } from "@/_models/cs_suto_size_drop";
import { AddFamilyService } from "@/_services/add-family.service";
import { invalid } from "moment";


@Component({
  selector: "app-auto-size-drop-add",
  templateUrl: "./auto-size-drop-add.component.html",
  styleUrls: ["./auto-size-drop-add.component.css"],
})
export class AutoSizeDropAddComponent {
  centerStoneAutoSizeDropAddForm: FormGroup;
  submitted: boolean;
  merchant_id: number;
  merchantListAll: any = [];
  merchantData: any = [];
  merchantSetData: any = [];
  vendor_id: number;
  merchantListLogin: any;
  merchantCollectionList: any = [];
  centerStoneVariantList: any = [];
  list: any = [];
  productList: any = [];
  productSubList: any = [];
  filteredProductSubList: any = [];
  public adminId = `${environment.adminId}`;
  filtermerchantCollectionList: any = [];
  filterCenterStoneVariantList: any = [];
  centerStoneSizeList: any = [];
  csSizeList: any = [];
  famList: any = [];
  getFrameBandFamilyNames: any = [];
  FilterFrameBandFamilyNames: any = [];
  FilterCsSizeList: any = [];
  goldCalculate = goldCalculate;
  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();
  diamondCaratList: any = [];
  wtValue: any;
  FilterGetCsFamilyList: any = [];
  getCsFamilyList: any = [];
  diamondType = diamondType;
  diamondShapeList: any = [];
  gemstoneList: any = [];
  gemstoneColorList: any = [];
  dataId: any;
  mode: any;
  familyNameDrop: any = [];
  familyName: any = [];
  dropName: any = [];
  dropNameList: any = [];
  csSizeDropList: any = [];
  filterCsDropList: any = [];
  gold: any = [{
    kt: 22,
    wt22: null,
    wt18: null,
    wt14: null
  }];



  wt: number = 0;
  FilterDropNameList: any = [];
  displayGoldCalPopUp: boolean = false;
  FilterDropList: any = [];



  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private vendorservices: VendorService,
    private authenticationService: AuthenticationService,
    private vendorauthenticationService: VendorAuthenticationService,
    private ProductSubTypeService: ProductSubTypeService,
    private centerstonvarianService: CenterStoneVariantService,
    private centerstonsizeService: CenterStoneSizeService,
    private CenterStoneFramebandService: CenterStoneFrameBandService,
    private DiamondCaratService: DiamondCaratService,
    private DiamondShapeService: DiamondShapeService,
    private GemstoneService: GemstoneService,
    private GlobalColorPreferenceService: GlobalColorPreferenceService,
    private AddFamilyService: AddFamilyService,
    private CenterStoneAutoSizeDropService: CenterStoneAutoSizeDropService,
  ) {
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id =
        this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.getMerchantList();
    this.createForm();
    this.centerStonevariantList();
    this.getCenterStoneSizeList();
    this.getCsFamilyDesignList();
    this.getDiamondCaratList();
    this.diamondShapeData();
    this.getStoneData();
    this.gemStoneColor();
    this.getFamilyname();
    this.getDropname();
    this.getDropCsSize();
    this.route.params
      .subscribe(params => {
        if (!!params.id) {
          this.dataId = params.id;
          this.mode = 'EDIT';
          this.getAutoSizeDropById(params);
        }
      });
  }
  get f() {
    return this.centerStoneAutoSizeDropAddForm.controls;
  }

  createForm() {
    this.centerStoneAutoSizeDropAddForm = this.formBuilder.group({
      isactive: [""],
      merchant_Id: [this.merchant_id],
      dropname: ["", Validators.required],
      dropfamily: [""],
      csDef: this.formBuilder.array([this.Initial_CsSize()])
    });
  }

  getDropname() {
    let dropN = this.centerStoneAutoSizeDropAddForm.get('dropfamily').value;
    this.CenterStoneAutoSizeDropService.getLongDesignDropName().subscribe((data) => {
      this.dropName = data;
      this.FilterDropNameList = this.dropName.data.filter(c => c.merchant_id == this.centerStoneAutoSizeDropAddForm.get('merchant_Id').value && c.family.every(val => dropN.includes(val)));
    });
  }

  showDropNames(e) {
    this.getDropname();
    // let dropFamID = e.value;
    // this.FilterDropList = this.FilterDropNameList.filter(c => c.family.every(val => dropFamID.includes(val)) );
  }

  // callDropName(){
  //   let dropN = this.centerStoneAutoSizeDropAddForm.get('dropfamily').value;
  //   this.FilterDropList = this.FilterDropNameList
  //   this.showDropNames(dropN);
  // }
  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantData = data;

          this.merchantSetData = this.merchantData.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });
          this.merchantListAll = this.merchantSetData;
        });
      }
    });
  }



  getFamilyname() {
    this.AddFamilyService.getfamily_drop_byMerchantid({
      merchant_id: this.centerStoneAutoSizeDropAddForm.value.merchant_Id,
    }).subscribe((data) => {
      this.familyNameDrop = data;
      this.familyName = this.familyNameDrop.data.filter(c => c.merchant_id == this.centerStoneAutoSizeDropAddForm.get('merchant_Id').value);
    });
  }
  centerStonevariantList() {
    this.centerstonvarianService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;
        this.centerStoneVariantList = this.list.data;
        this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(c => c.merchantid == this.merchant_id);
      }
    });
  }

  getDropCsSize() {
    this.CenterStoneAutoSizeDropService.getAutoSizeDropCsSize({
      merchant_id: this.centerStoneAutoSizeDropAddForm.value.merchant_Id,
    }).subscribe((data) => {
      if (data) {
        this.list = data;
        this.csSizeDropList = this.list.data;
        this.filterCsDropList = this.csSizeDropList.filter(c => c.merchantid === this.centerStoneAutoSizeDropAddForm.get('merchant_Id').value && c.csSize !== "");
      }
    })
  }

  showVariantName(e: any) {
    this.getDropname();
    this.getFamilyname();
    this.getDropCsSize();
    let merchantId = e;
    this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(c => c.merchantid == merchantId);
    this.FilterFrameBandFamilyNames = this.getFrameBandFamilyNames.filter((c) => c.merchant_id == merchantId);
    this.FilterCsSizeList = this.centerStoneSizeList.filter((c) => c.merchant_id == merchantId);
    this.FilterGetCsFamilyList = this.getCsFamilyList.filter(
      (c) => c.merchant_id == this.centerStoneAutoSizeDropAddForm.value.merchantId
    );

  }

  getCenterStoneSizeList() {
    this.centerstonsizeService.getAll()
      .subscribe(data => {
        if (data) {
          this.list = data;
          this.centerStoneSizeList = this.list.data.filter(
            (x) => x.isactive == "Y"
          );
          this.centerStoneSizeList.map(data => {
            data.csSize = data.cs_length + ' * ' + data.cs_width;
            return data;
          });
          this.FilterCsSizeList = this.centerStoneSizeList.filter((c) => c.merchant_id == this.centerStoneAutoSizeDropAddForm.value.merchant_Id);
        }
      });
  }
  // getCenterStoneSizeList() {
  //   this.centerstonsizeService.getAll()
  //     .subscribe(data => {
  //       if (data) {
  //         this.list = data;
  //         this.centerStoneSizeList = this.list.data;

  //         this.FilterCsSizeList = this.centerStoneSizeList.filter((c) => c.merchant_id == this.merchant_id);

  //         this.FilterCsSizeList.map(data => {
  //           data.csSize = data.cs_length + ' * ' + data.cs_width;
  //           return data;
  //         });
  //         this.csSizeList = this.centerStoneSizeList;
  //       }
  //     });
  // }

  /// //// Cs Family   list////

  getCsFamilyDesignList() {
    this.CenterStoneFramebandService.getCSFamilyDesign().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.getCsFamilyList = this.list.data;
          this.FilterGetCsFamilyList = this.getCsFamilyList.filter(
            (c) => c.merchant_id == this.merchant_id
          );
        });
      }
    });
  }


  // /add diamond data form
  Initial_Diamond() {
    return this.formBuilder.group({
      type: [""],
      wt: [""],
      nos: [""],
      shape: [""],
      twt: [""],
    });
  }

  wtChange(e: any, i: any, csSizeIndex: any) {
    this.wtValue = e;
    let diaWt = this.csDefdiamond(csSizeIndex)['controls'][i].value.wt
    let val = diaWt * this.csDefdiamond(csSizeIndex)['controls'][i].value.nos;
    let data = Math.round(val * 100) / 100
    this.csDefdiamond(csSizeIndex)['controls'][i]['controls']['twt'].setValue(data);
  }
  nosChange(e: any, i: any, csSizeIndex: any) {
    var t = e.target.value;
    e.target.value = t.indexOf('.') >= 0 ? t.substr(0, t.indexOf('.')) + t.substr(t.indexOf('.'), 3) : t;
    // let result = this.diamondCaratList.filter(c => c.id === this.csDefdiamond(csSizeIndex)['controls'][i].value.wt);
    let diaWt = this.csDefdiamond(csSizeIndex)['controls'][i].value.wt
    let val = diaWt * this.csDefdiamond(csSizeIndex)['controls'][i].value.nos;
    let data = Math.round(val * 100) / 100
    this.csDefdiamond(csSizeIndex)['controls'][i]['controls']['twt'].setValue(data);
  }

  twtChange(e: any, i: any, csSizeIndex: any) {
    var t = e.target.value;
    e.target.value = t.indexOf('.') >= 0 ? t.substr(0, t.indexOf('.')) + t.substr(t.indexOf('.'), 3) : t;
    // let result = this.diamondCaratList.filter(c => c.id === this.csDefdiamond(csSizeIndex)['controls'][i].value.wt);
    let diaWt = this.csDefdiamond(csSizeIndex)['controls'][i].value.wt
    let val = this.csDefdiamond(csSizeIndex)['controls'][i].value.twt / diaWt;
    let data = Math.round(val * 100) / 100
    this.csDefdiamond(csSizeIndex)['controls'][i]['controls']['nos'].setValue(data);
  }

  // /add diamond data  End form


  ///gemstone add form value chnage''
  gemWtChange(e: any, i: any,  csSizeIndex: any) {
    this.wtValue = e;
    let result = this.csDefgemstone(csSizeIndex)['controls'][i].value.wt;
    let val = result * this.csDefgemstone(csSizeIndex)['controls'][i].value.nos;
    let data = Math.round(val * 100) / 100
    this.csDefgemstone(csSizeIndex)['controls'][i]['controls']['twt'].setValue(data);
  }
  gemNosChange(e: any, i: any, csSizeIndex: any) {
    var t = e.target.value;
    e.target.value = t.indexOf('.') >= 0 ? t.substr(0, t.indexOf('.')) + t.substr(t.indexOf('.'), 3) : t;
    let result = this.csDefgemstone(csSizeIndex)['controls'][i].value.wt;
    let val = result * this.csDefgemstone(csSizeIndex)['controls'][i].value.nos;
    let data = Math.round(val * 100) / 100
    this.csDefgemstone(csSizeIndex)['controls'][i]['controls']['twt'].setValue(data);
  }

  gemTwtChange(e: any, i: any, csSizeIndex: any) {
    var t = e.target.value;
    e.target.value = t.indexOf('.') >= 0 ? t.substr(0, t.indexOf('.')) + t.substr(t.indexOf('.'), 3) : t;
    let result = this.csDefgemstone(csSizeIndex)['controls'][i].value.wt;
    let val = this.csDefgemstone(csSizeIndex)['controls'][i].value.twt / result;
    let data = Math.round(val * 100) / 100
    this.csDefgemstone(csSizeIndex)['controls'][i]['controls']['nos'].setValue(data);
  }



  // gold calculation
  changeCalculation(e, i) {
    this.goldCalculation(e.value, this.wt, i);
  }

  valuechange(newValue, csSizeIndex) {
    var t = newValue.target.value;

    newValue.target.value = t.indexOf('.') >= 0 ? t.substr(0, t.indexOf('.')) + t.substr(t.indexOf('.'), 4) : t;
    this.wt = newValue.target.value
    this.goldCalculation(this.centerStoneAutoSizeDropAddForm.value.csDef[csSizeIndex].gold, this.wt, csSizeIndex);
  }

  goldCalculation(kt, wt, i) {
    if (kt == 22) {
   
      this.centerStoneAutoSizeDropAddForm.value.csDef[i].wt22 = wt;   
      this.centerStoneAutoSizeDropAddForm.value.csDef[i].wt18 = wt * 0.873;
      this.centerStoneAutoSizeDropAddForm.value.csDef[i].wt14 = this.centerStoneAutoSizeDropAddForm.value.csDef[i].wt18 * 0.864;
     
    
    } else if (kt == 18) {      
      this.centerStoneAutoSizeDropAddForm.value.csDef[i].wt18 = wt;
      this.centerStoneAutoSizeDropAddForm.value.csDef[i].wt14 = this.centerStoneAutoSizeDropAddForm.value.csDef[i].wt18 * 0.864;
    } else {  
      this.centerStoneAutoSizeDropAddForm.value.csDef[i].wt14 = wt;
    }
    console.log('this.centerStoneAutoSizeDropAddForm.value.csDef[i]:', this.centerStoneAutoSizeDropAddForm.value.csDef[i]);
  }




  //// diamond   list////

  getDiamondCaratList() {
    this.DiamondCaratService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.diamondCaratList = data;
          this.diamondCaratList.sort((a, b) => {
            return a.carat_name - b.carat_name;
          });
        });
      }
    });
  }

  ////diamond shape
  diamondShapeData() {
    this.DiamondShapeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.diamondShapeList = data;
        });
      }
    });
  }

  // /gemStones List

  getStoneData() {
    this.GemstoneService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneList = data;
        });
      }
    });
  }

  // /ggemStones color List

  gemStoneColor() {
    this.GlobalColorPreferenceService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneColorList = data;
        });
      }
    });
  }


  // /add Gemstones data form
  Initial_GemStones() {
    return this.formBuilder.group({
      name: [""],
      size: [""],
      shape: [""],
      wt: [""],
      nos: [""],
      color: [""],
      twt: ['']
    });
  }



  csDef(): FormArray {
    return this.centerStoneAutoSizeDropAddForm.get("csDef") as FormArray;
  }


  addCsSize() {
    // this.gold.push({
    //   kt: 22,
    //   wt22: null,
    //   wt18: null,
    //   wt14: null
    // })
    this.csDef().push(this.Initial_CsSize());
  }
  removeCsSizeList(index: number) {
    this.csDef().removeAt(index);
    // this.gold.splice(index, 1)
  }

  Initial_CsSize() {
    return this.formBuilder.group({
      csSizeDrop: [""],
      gold: ["22", Validators.required],
      wt: ["", Validators.required],
      gemstone: this.formBuilder.array([this.Initial_GemStones()]),
      diamond: this.formBuilder.array([this.Initial_Diamond()]),
    });
  }

  csDefdiamond(empIndex: number): FormArray {
    return this.csDef()
      .at(empIndex)
      .get('diamond') as FormArray;
  }

  csDefgemstone(empIndex: number): FormArray {
    return this.csDef()
      .at(empIndex)
      .get('gemstone') as FormArray;
  }

  diamond(diamondIndex): FormArray {
    return this.csDef().at(diamondIndex).get('diamond') as FormArray;
  }

  addDiamond(diamondIndex) {
    this.csDefdiamond(diamondIndex).push(this.Initial_Diamond());
  }

  removeDiamondList(csSizeIndex: number, diamondIndex: number) {
    this.csDefdiamond(csSizeIndex).removeAt(diamondIndex);
  }

  gemstone(gemstoneIndex): FormArray {
    return this.csDef().at(gemstoneIndex).get('diamond') as FormArray;
  }

  addGemStones(gemstoneIndex) {
    this.csDefgemstone(gemstoneIndex).push(this.Initial_GemStones());
  }

  removeFGemStoneList(csSizeIndex: number, gemstoneIndex: number) {
    this.csDefgemstone(csSizeIndex).removeAt(gemstoneIndex);
  }
  // /add Gemstones data Form End

  onSubmit() {
    this.submitted = true;
    if (this.centerStoneAutoSizeDropAddForm.valid) {
      const dataObj = {
        merchant_id: this.centerStoneAutoSizeDropAddForm.value.merchant_Id,
        dropname: this.centerStoneAutoSizeDropAddForm.value.dropname,
        dropfamily: this.centerStoneAutoSizeDropAddForm.value.dropfamily,
        csdef: this.centerStoneAutoSizeDropAddForm.value.csDef,
      }
      this.CenterStoneAutoSizeDropService.save(dataObj).subscribe((data: CenterStoneAutoSizeDrop) => {
        this.alertService.success('Center Stone Auto Size Drop saved successfully!', true);
        if (this.vendor_id) {
          this.router.navigate(["MerchantAutoSizeDrop/list"]);
        } else {
          this.router.navigate(["AdminAutoSizeDrop/list"]);
        }
      });
    }
  }

  getAutoSizeDropById(id) {
    this.CenterStoneAutoSizeDropService.getCSAutoSizeDropbyid(id).subscribe((data) => {
      if (data) {
        this.csDef().removeAt(0);
        this.setFormValue(data);        
      }
    });
  }

  setFormValue(data) {
    // console.log("🚀 ~ file: auto-size-drop-add.component.ts:546 ~ AutoSizeDropAddComponent ~ setFormValue ~ data:", data.data)
    let editData = data.data;
    this.familyName = this.familyNameDrop.data.filter(c => c.merchant_id == editData[0].merchant_id);
    
    this.centerStoneAutoSizeDropAddForm.get('isactive').setValue(editData[0].isactive == 'Y' ? true : false);
    this.centerStoneAutoSizeDropAddForm.get('merchant_Id').setValue(editData[0].merchant_id);
    this.centerStoneAutoSizeDropAddForm.get('dropfamily').setValue(editData[0].dropfamily);    
    this.centerStoneAutoSizeDropAddForm.get('dropname').setValue(editData[0].dropname);
    var JsonData = editData[0].csdef;
    
    for (let index = 0; index < JsonData.length; index++) {
      const element = JsonData[index];
      // console.log("🚀 ~ file: auto-size-drop-add.component.ts:558 ~ AutoSizeDropAddComponent ~ setFormValue ~ element:", element)
      this.addcsSizeForm(element, index);     
    }
    // this.csDef().removeAt(0);
    // this.csDef().removeAt(0);   
    // this.SetcsDef.removeAt(0);
    
    this.showVariantName(editData[0].merchant_id);
  }

  addcsSizeForm(s, i) {
    console.log("🚀 ~ file: auto-size-drop-add.component.ts:568 ~ AutoSizeDropAddComponent ~ addcsSizeForm ~ s:", s)
    const lessonForm = this.formBuilder.group({
      csSizeDrop: [s.csSizeDrop],
      wt: [s.wt],
      wt22: [],
      wt18: [],
      wt14: [],
      gold: [Number(s.gold)],
      diamond: this.formBuilder.array([]),
      gemstone: this.formBuilder.array([]),
    });
    let varydiamond = lessonForm.controls["diamond"] as FormArray;
    for (let index = 0; index < s.diamond.length; index++) {
      let result = this.adddiamondForm(s.diamond);
      varydiamond.push(result)
    }
   
    let varygemstone = lessonForm.controls["gemstone"] as FormArray;
   
    for (let index = 0; index < s.gemstone.length; index++) {
      let result = this.addgemstoneForm(s.gemstone);
      varygemstone.push(result)
    }
    lessonForm.patchValue(s);
    this.csDef().push(lessonForm);
    this.goldCalculation(s.gold, s.wt, i);
  }

  get SetcsDef() {
    return this.centerStoneAutoSizeDropAddForm.controls[
      "csdef"
    ] as FormArray;
  }

  adddiamondForm(s) {
    const lessonForm = this.formBuilder.group({
      type: [""],
      wt: [""],
      nos: [""],
      shape: [""],
      twt: [""],
    });

    lessonForm.patchValue(s);
    return lessonForm;
  }

  addgemstoneForm(s) {
    const lessonForm = this.formBuilder.group({
      name: [""],
      size: [""],
      shape: [""],
      wt: [""],
      nos: [""],
      color: [""],
      twt: ['']
    });

    lessonForm.patchValue(s);
    return lessonForm;
  }

  setCsDefForm(dataOfcsDef): FormArray {
    const formArray = new FormArray([]);
    dataOfcsDef.forEach((s) => {
      formArray.push(
        this.formBuilder.group({
          wt: [s.wt],
          gold: [s.gold],
          diamond: this.formBuilder.array([this.Initial_Diamond()]),
          gemstone: this.formBuilder.array([this.Initial_GemStones()]),
        })
      );
    });
    return formArray;
  }
  setDiamondForm(dataOfdiamond): FormArray {
    const formArray = new FormArray([]);
    dataOfdiamond.forEach((s) => {
      formArray.push(
        this.formBuilder.group({
          type: [s.type],
          wt: [s.wt],
          nos: [s.nos],
          shape: [s.shape],
          twt: [s.twt],
        })
      );
    });
    return formArray;
  }

  setGemstoneForm(dataOfgemstone): FormArray {
    const formArray = new FormArray([]);
    dataOfgemstone.forEach((s) => {
      formArray.push(
        this.formBuilder.group({
          name: [s.name],
          size: [s.size],
          shape: [s.shape],
          wt: [s.wt],
          nos: [s.nos],
          color: [s.color],
          twt: [s.twt],
        })
      );
    });
    return formArray;
  }

  onUpdate() {
    this.submitted = true;
    if (this.centerStoneAutoSizeDropAddForm.valid) {
      const dataObj = {
        id: this.dataId,
        isactive: this.centerStoneAutoSizeDropAddForm.value.isactive === true ? 'Y' : 'N',
        merchant_id: this.centerStoneAutoSizeDropAddForm.value.merchant_Id,
        dropname: this.centerStoneAutoSizeDropAddForm.value.dropname,
        dropfamily: this.centerStoneAutoSizeDropAddForm.value.dropfamily,
        csdef: this.centerStoneAutoSizeDropAddForm.value.csDef,
      }
      this.CenterStoneAutoSizeDropService.updateCSAutoSizeDrop(dataObj).subscribe((data: CenterStoneAutoSizeDrop) => {
        this.alertService.success('Center Stone Auto Size Drop Updated successfully!', true);
        if (this.vendor_id) {
          this.router.navigate(["MerchantAutoSizeDrop/list"]);
        } else {
          this.router.navigate(["AdminAutoSizeDrop/list"]);
        }
      });
    }
  }

  backList() {
    if (this.vendor_id) {
      this.router.navigate(["/MerchantAutoSizeDrop/list"]);
    } else {
      this.router.navigate(["/AdminAutoSizeDrop/list"]);
    }
  }

  showPopUp() {
    this.displayGoldCalPopUp = true;
  }


}
