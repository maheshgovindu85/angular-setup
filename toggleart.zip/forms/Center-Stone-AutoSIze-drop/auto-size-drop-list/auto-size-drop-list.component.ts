import { CenterStoneVariant } from "@/_models/cs_variant";
import { AlertService, AuthenticationService } from "@/_services";
import { CenterStoneAutoSizeDropService } from "@/_services/cs_auto_size_drop.service";
import { Component, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs/internal/Observable";

@Component({
  selector: "app-auto-size-drop-list",
  templateUrl: "./auto-size-drop-list.component.html",
  styleUrls: ["./auto-size-drop-list.component.css"],
})
export class AutoSIzeDropListComponent {

  centerStoneAutoSizeDropList: any = [];
  searchForm: FormGroup;
  filterCenterStoneAutoSizeDropList: any = [];
  isChecked: boolean;
  list: any = [];

    constructor(
      private router: Router,
      private formBuilder: FormBuilder,
      private alertService: AlertService,
      private authenticationService: AuthenticationService,
      private CenterStoneAutoSizeDropService: CenterStoneAutoSizeDropService,
      private store: Store<{ producttypes: CenterStoneVariant[] }>
    ) {
      
    }
   
    ngOnInit() {
      this.centerStoneSizevariantList()
      this.createSearchForm()
      }

      centerStoneSizevariantList(){
        this.CenterStoneAutoSizeDropService.getAll()
        .subscribe(data => {
          if (data) {
            this.list = data;
            
              this.centerStoneAutoSizeDropList = this.list.data;
              
              for (let i = 0; i < this.centerStoneAutoSizeDropList.length; i++) {
                this.centerStoneAutoSizeDropList[i].isactive = this.centerStoneAutoSizeDropList[i].isactive === 'N' ? false : true;
                this.centerStoneAutoSizeDropList[i].SrNo = i + 1;
              }
              this.filterCenterStoneAutoSizeDropList = this.centerStoneAutoSizeDropList;
              
          }
        });
      }

      changeStatus(e,data: any){
        this.isChecked = e.checked;
        const dataObj = {
          id: data.id,
          isactive : this.isChecked ? 'Y' : 'N',
        };
        this.CenterStoneAutoSizeDropService.updateCSAutoSizeDrop(dataObj).subscribe((data: CenterStoneVariant) => {
          this.centerStoneSizevariantList();
          this.alertService.success('Status Updated successfully!', true);
            this.router.navigate(["AdminAutoSizeDrop/list"]);          
          });
      
      }

      createSearchForm() {
        this.searchForm = this.formBuilder.group({
          keyword: [''],
        });
      }
      clear() {
        this.searchForm.get('keyword')?.setValue('');
        this.searchGrid();
      }

      searchGrid() {
        let keyword = this.searchForm.controls['keyword'].value;
        if (keyword === '') {
          this.filterCenterStoneAutoSizeDropList = this.centerStoneAutoSizeDropList;
        } else {
          keyword = keyword.toLowerCase();
          this.filterCenterStoneAutoSizeDropList = this.centerStoneAutoSizeDropList.filter((event) => {
            return (
              (event.dropname && event.dropname.toLowerCase().includes(keyword))||
              (event.dropfamily && event.dropfamily.toLowerCase().includes(keyword))||
              (event.cssize && event.cssize.toLowerCase().includes(keyword))||
              (event.merchantname && event.merchantname.toLowerCase().includes(keyword))
            );
          });
        }
      }
}