import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { MatFormFieldModule } from '@angular/material/form-field';

import { CollectionType } from '@/_models/collectiontype';
import { CollectionTypeAdd } from '@/_store/collectiontype/collectiontype.actions';

import { AlertService, AuthenticationService, CollectiontypeService } from '@/_services';

@Component({
  selector: 'app-collection-type-add',
  templateUrl: './collection-type-add.component.html',
  styleUrls: ['./collection-type-add.component.css']
})
export class CollectionTypeAddComponent implements OnInit {

  collectiontypeAddForm: FormGroup;
  loading = false;
  submitted = false;
  collectiontypes: Observable<CollectionType[]>;
  submitted2 = false;


  constructor(private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private collectionTypeService: CollectiontypeService,
    private store: Store<{ collectiontypes: CollectionType[] }>) { }

  ngOnInit(): void {
    this.collectiontypeAddForm = this.formBuilder.group({
      id: 0,
      typename: ['', Validators.required],
      isactive: [true],
      isdelete: ['N']
    });
  }

  get formValidationState2() {
    return this.collectiontypeAddForm.controls;
  }

  get f() { return this.collectiontypeAddForm.controls; }
  onSubmit() {
    this.submitted = true;
    this.submitted2 = true;

    // reset alerts on submit
    this.alertService.clear();

    if (this.collectiontypeAddForm.invalid) {
      return;
    }

    this.loading = true;
    this.collectionTypeService
      .save(this.collectiontypeAddForm.value)
      .subscribe((data: CollectionType) => {
        //this.store.dispatch(new DiamondCaratAdd(this.diamondCaratAddForm.value));
        // this.store.dispatch(new CollectionTypeAdd(data));
        //console.log(this.store);
        this.alertService.success('Collection Type saved successfully!', true);
        this.router.navigate(['collectiontype/list']);
      });
  }
}
