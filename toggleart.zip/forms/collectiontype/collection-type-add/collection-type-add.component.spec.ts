import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CollectionTypeAddComponent } from './collection-type-add.component';

describe('CollectionTypeAddComponent', () => {
  let component: CollectionTypeAddComponent;
  let fixture: ComponentFixture<CollectionTypeAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CollectionTypeAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollectionTypeAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
