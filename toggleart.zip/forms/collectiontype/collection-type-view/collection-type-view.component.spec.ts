import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CollectionTypeViewComponent } from './collection-type-view.component';

describe('CollectionTypeViewComponent', () => {
  let component: CollectionTypeViewComponent;
  let fixture: ComponentFixture<CollectionTypeViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CollectionTypeViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollectionTypeViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
