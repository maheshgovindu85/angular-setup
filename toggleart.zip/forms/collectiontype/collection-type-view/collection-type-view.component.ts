import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

import { CollectionType } from '@/_models/collectiontype';
import { CollectionTypeGetAll,CollectionTypeRemove} from '@/_store/collectiontype/collectiontype.actions';
import * as collectiontype_selector from '@/_store/collectiontype/collectiontype.selector';
import { AlertService, AuthenticationService, CollectiontypeService, EncryptDecryptService } from '@/_services';

@Component({
  selector: 'app-collection-type-view',
  templateUrl: './collection-type-view.component.html'
})
export class CollectionTypeViewComponent implements OnInit {

  collectiontypeFilterForm: FormGroup;
  collectiontypes: Observable<CollectionType[]>;
  dataSource: MatTableDataSource<CollectionType>;
  closeResult: string;
  search_text = "";
  collectionTypeList: any= [];
  searchForm:FormGroup;
  filterCollectionTyeList: any=[]

  displayedColumns: string[] = ['typename', 'isactive', 'actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private collectiontypeService: CollectiontypeService,
    private store: Store<{ collectiontypes: CollectionType[] }>
  ) {
    this.collectiontypeFilterForm = formBuilder.group({
      search_text: ''
    });

    this.collectiontypeFilterForm.valueChanges.subscribe(value => {
      // console.log(value);
      const filter = {
        ...value,
        search_text: value.search_text.trim().toLowerCase()
      } as string;
      // console.log(filter);
      this.dataSource.filter = filter;
    });
  }

  ngOnInit(): void {
    this.createSearchForm();
  }

  ngAfterViewInit() {
    // this.store.pipe(select(collectiontype_selector.getAllCollectionType()))
    this.collectiontypeService.getAll()
    .subscribe(data => {
      if (data) {
        // console.log(data);
        setTimeout(() => {
          this.collectionTypeList.paginator = this.paginator;
          this.collectionTypeList =data;
          for(let i =0; i <this.collectionTypeList.length;i++){
            this.collectionTypeList[i].isactive = this.collectionTypeList[i].isactive === 'N' ? false : true;
          }
          this.collectionTypeList.sort((a,b) => {
            return new Date(b.savedate).getTime() - new Date(a.savedate).getTime();
          });
          this.collectionTypeList.sort((a,b) => {
            return  new Date(b.modifydate).getTime() - new Date(a.modifydate).getTime();
          });
          this.filterCollectionTyeList=this.collectionTypeList
        });
      }
    });
  }

  DeleteCollectionType(collectionTypeId, isactive) {
    this.collectiontypeService
        .delete(collectionTypeId, isactive)
        .subscribe((data: CollectionType[]) => {
          this.store.dispatch(new CollectionTypeRemove(collectionTypeId));
      });
  }


  // Search button function start
  createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [''],
    });
  }
  clear() {
    this.searchForm.get('keyword')?.setValue('');
    this.searchGrid();
  }
  searchGrid() {
    let keyword = this.searchForm.controls['keyword'].value;
    if (keyword === '') {
      this.filterCollectionTyeList = this.collectionTypeList;
    } else {
      keyword = keyword.toLowerCase();
      this.filterCollectionTyeList = this.collectionTypeList.filter((event) => {
        return (
          (event.typename && event.typename.toLowerCase().includes(keyword))
        );
      });
    }
  }

}
