import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { CollectionType } from '@/_models/collectiontype';
import { CollectionTypeUpdate } from '@/_store/collectiontype/collectiontype.actions';
import * as collectiontype_selector from '@/_store/collectiontype/collectiontype.selector';

import { AlertService, AuthenticationService, CollectiontypeService } from '@/_services';

@Component({
  selector: 'app-collection-type-edit',
  templateUrl: './collection-type-edit.component.html',
  styleUrls: ['./collection-type-edit.component.css']
})
export class CollectionTypeEditComponent implements OnInit {

  collectiontypeEditForm: FormGroup;
  loading = false;
  submitted = false;
  collectiontypes: Observable<CollectionType[]>;
  collectiontype: any;
  setActivated = false;
  submitted2 = false;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private collectiontypeService: CollectiontypeService,
    private store: Store<{ collectiontypes: CollectionType[] }>) {

    if (this.authenticationService.currentUserValue) {
      const id = this.route.snapshot.params.id;
      // this.store.select(collectiontype_selector.getCollectionTypeById(id))
      collectiontypeService.get(id)
        .subscribe((data) => {
          this.collectiontype = data;

          if (this.collectiontype.isactive === 'Y') {
            this.setActivated = true
          } else {
            this.setActivated = false
          }

          this.collectiontypeEditForm = this.formBuilder.group({
            id: [this.collectiontype.id, Validators.required],
            typename: [this.collectiontype.typename, Validators.required],
            isactive: [this.setActivated],
            isdelete: [this.collectiontype.isdelete]
          });

        });
    }
    else {
      this.router.navigate(['login']);
    }

  }

  ngOnInit(): void {
    this.collectiontypeEditForm = this.formBuilder.group({
      id: [0, Validators.required],
      typename: ['', Validators.required],
      isactive: ['Y'],
      isdelete: ['N']
    });
  }

  get formValidationState2() {
    return this.collectiontypeEditForm.controls;
  }


  get f() { return this.collectiontypeEditForm.controls; }

  onSubmit() {
    this.submitted = true;
    this.submitted2 = true;

    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.collectiontypeEditForm.invalid) {
      return;
    }

    this.loading = true;
    this.collectiontypeService
      .save(this.collectiontypeEditForm.value)
      .subscribe((data: CollectionType) => {
        // console.log(data);
        // this.store.dispatch(new CollectionTypeUpdate(data));
        // console.log(this.store);
        this.alertService.success('Collection Type updated successfully!', true);
        this.router.navigate(['collectiontype/list']);
      });
  }

}
