import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CollectionTypeEditComponent } from './collection-type-edit.component';

describe('CollectionTypeEditComponent', () => {
  let component: CollectionTypeEditComponent;
  let fixture: ComponentFixture<CollectionTypeEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CollectionTypeEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollectionTypeEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
