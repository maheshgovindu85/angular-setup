import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toggle-art-homepage',
  templateUrl: './toggle-art-homepage.component.html',
  styleUrls: ['./toggle-art-homepage.component.css']
})
export class ToggleArtHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
