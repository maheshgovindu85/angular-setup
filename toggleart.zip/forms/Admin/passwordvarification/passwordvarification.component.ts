import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Chainwidth } from '@/_models/chainwidth';
import { ChainwidthAdd } from '@/_store/chainwidth/chainwidth.actions';
import { AlertService, AuthenticationService, MetalService } from '@/_services';
import { ChainwidthService } from '@/_services/chainwidth.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogData } from '@/forms/vendor/collection/v-collection-view/v-collection-view.component';

@Component({
  selector: 'app-passwordvarification',
  templateUrl: './passwordvarification.component.html',
  styleUrls: ['./passwordvarification.component.css']
})
export class PasswordvarificationComponent implements OnInit {


  AdminModificationForm: FormGroup;
  loading = false;
  submitted = false;
  currencies: Observable<Chainwidth[]>;
  public isactive: boolean = true;
  varificationpass: any;

  constructor(
    public dialogRef: MatDialogRef<PasswordvarificationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router,
    private formBuilder: FormBuilder,
    public dialog: MatDialog,
    private alertService: AlertService,
    private authenticationService: AuthenticationService) {

    if (!this.authenticationService.currentUserValue) {
      this.router.navigate(['login']);
    }
  }

  async ngOnInit() {

    this.AdminModificationForm = this.formBuilder.group({
      id: 0,
      name: ['', Validators.required],
      email_id: ['', Validators.required],
      contact_no: ['', Validators.required],
      password: ['', Validators.required],
      oldpassword: ['', Validators.required],
      isdelete: ['N']
    });

    this.AdminModificationForm = this.data.varificationdata;
  }

  get f() { return this.AdminModificationForm.controls; }

  onSubmit() {
    this.submitted = true;

    this.alertService.clear();

    console.log(this.AdminModificationForm.value);
    if (this.AdminModificationForm.invalid) {
      return;
    }
    this.loading = true;

    this.authenticationService.verifyAdmin(this.AdminModificationForm.value).then(data => {
      if (data == true) {
        this.dialogRef.close(data);
      } else {
        this.loading = false;
        this.alertService.error('invalid credentials,try again')
      }
    })
  }
}