import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Chainwidth } from '@/_models/chainwidth';
import { ChainwidthAdd } from '@/_store/chainwidth/chainwidth.actions';
import { AlertService, AuthenticationService, MetalService } from '@/_services';
import { ChainwidthService } from '@/_services/chainwidth.service';
import { MatDialog } from '@angular/material/dialog';
import { PasswordvarificationComponent } from '../passwordvarification/passwordvarification.component';


@Component({
  selector: 'app-profile-update',
  templateUrl: './profile-update.component.html',
  styleUrls: ['./profile-update.component.css']
})
export class ProfileUpdateComponent implements OnInit {
  AdminModificationForm: FormGroup;
  loading = false;
  submitted = false;
  currencies: Observable<Chainwidth[]>;
  public isactive: boolean = true;
  varificationpass: any;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    public dialog: MatDialog,
    private alertService: AlertService,
    private authenticationService: AuthenticationService) {

    if (!this.authenticationService.currentUserValue) {
      this.router.navigate(['login']);
    }
  }

  async ngOnInit() {

    this.AdminModificationForm = this.formBuilder.group({
      id: 0,
      name: ['', Validators.required],
      email_id: ['', Validators.required],
      contact_no: ['', Validators.required],
      password: ['', Validators.required],
      isdelete: ['N'],
      oldpassword: ['NA', Validators.required],
    });

    if (this.authenticationService.currentUserValue.id) {
      await this.authenticationService.findAdminByid(this.authenticationService.currentUserValue.id).then(data => {
        this.varificationpass = data.password;
        this.AdminModificationForm.get('id').setValue(data.id);
        this.AdminModificationForm.get('name').setValue(data.name);
        this.AdminModificationForm.get('email_id').setValue(data.email_id);
        this.AdminModificationForm.get('contact_no').setValue(data.contact_no);
        this.AdminModificationForm.get('password').setValue(data.password);
      })
    }
  }

  get f() { return this.AdminModificationForm.controls; }

  onSubmit() {
    this.submitted = true;

    this.alertService.clear();

    if (this.AdminModificationForm.invalid) {
      return;
    }
    this.loading = true;

    const dialogRef = this.dialog.open(PasswordvarificationComponent, {
      width: '600px',
      data: { varificationdata: this.AdminModificationForm },
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == true) {
        this.alertService.success('Update credentials successfully');
        this.loading = false;
      } else {
        this.alertService.error('invalid credentials,try again');
        this.loading = false;
      }
    });
  }
}