import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { takeUntil } from 'rxjs/operators';

import { AlertService, AuthenticationService, EncryptDecryptService, VendorAuthenticationService } from '@/_services';

import { Studdedtype } from '@/_models/studdedtype';
import { StuddedtypeGetAll, StuddedtypeRemove } from '@/_store/studdedtype/studdedtype.actions';
import * as studdettype_selector from '@/_store/studdedtype/studdedtype.selector';
import { StuddedtypeService } from '@/_services/studdedtype.service';
import { VendormakingchargesService } from '@/_services/vendormakingcharges.service';
import { VendorService } from '@/_services/vendor.service';

@Component({
  selector: 'app-view-merchant-activity',
  templateUrl: './view-merchant-activity.component.html',
  styleUrls: ['./view-merchant-activity.component.css']
})
export class ViewMerchantActivityComponent implements OnInit {


  unsubscribe$: Subject<boolean> = new Subject<boolean>();
  studdedtypes: Observable<Studdedtype[]>;
  dataSource: MatTableDataSource<Studdedtype>;
  closeResult: string;
  searchForm: FormGroup;
  search_text = "";

  displayedColumns: string[] = ['position', 'action', 'savedate',];
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private vendorservices: VendorAuthenticationService,
    private vendorauthenticationService: VendorAuthenticationService,
    private VendormakingchargesService: VendormakingchargesService,
  ) {
    // redirect if already logged in
    if (!this.authenticationService.currentUserValue) {
      this.router.navigate(['login']);
    }

    // console.log('in metallist ngAfterViewInit');
    vendorservices.VendorActivityList(route.snapshot.params.id)
      .subscribe(data => {
        if (data) {
          setTimeout(() => {
            this.dataSource = new MatTableDataSource(data);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;

            this.dataSource.filterPredicate = ((data, filter) => {
              const a = !filter.search_text ||
                data.action.toString().trim().toLowerCase().includes(filter.search_text) ||
                data.savedate.toString().trim().toLowerCase().includes(filter.search_text);
              return a;
            }) as (PeriodicElement, string) => boolean;
          });
        }
      });

    this.searchForm = formBuilder.group({
      search_text: ''
    });

    this.searchForm.valueChanges.subscribe(value => {
      console.log(value);
      const filter = {
        ...value,
        search_text: value.search_text.trim().toLowerCase()
      } as string;
      console.log(filter);
      this.dataSource.filter = filter;
    });
  }

  ngOnInit() {
  }

  ngAfterViewInit() {

  }

}
