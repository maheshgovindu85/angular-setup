import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMerchantActivityComponent } from './view-merchant-activity.component';

describe('ViewMerchantActivityComponent', () => {
  let component: ViewMerchantActivityComponent;
  let fixture: ComponentFixture<ViewMerchantActivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewMerchantActivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMerchantActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
