import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateDesignAnnotationsComponent } from './create-design-annotations.component';

describe('CreateDesignAnnotationsComponent', () => {
  let component: CreateDesignAnnotationsComponent;
  let fixture: ComponentFixture<CreateDesignAnnotationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateDesignAnnotationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateDesignAnnotationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
