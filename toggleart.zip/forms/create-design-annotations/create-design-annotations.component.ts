import {
  Component,
  OnInit,
  Input,
  OnDestroy,
  ViewChild,
  ViewContainerRef,
  Output,
  HostListener,
  EventEmitter,
  ComponentRef,
  ComponentFactory,
  ElementRef,
  ComponentFactoryResolver
} from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
// import { CdkDragDrop, moveItemInArray, transferArrayItem, copyArrayItem } from '@angular/cdk/drag-drop';

import { AlertService, AuthenticationService } from '@/_services';

import { AnnotationButtonComponent } from '../../_components/annotation-button/annotation-button.component';
import { resetFakeAsyncZone } from '@angular/core/testing';

@Component({
  selector: 'create-design-annotations',
  templateUrl: './create-design-annotations.component.html',
  styleUrls: ['./create-design-annotations.component.css']
})

export class CreateDesignAnnotationsComponent implements OnInit, OnDestroy {
  designForm: FormGroup;
  left: number = 0;
  cmpt = this;

  @ViewChild('capa', { read: ViewContainerRef }) capa1: ViewContainerRef;
  @ViewChild('capa') capaElementRef1: ElementRef;

  @ViewChild('capa2', { read: ViewContainerRef }) capa2: ViewContainerRef;
  @ViewChild('capa2') capaElementRef2: ElementRef;
  @Input('width') width: number;
  @Input('height') height: number;
  //@Input('annotation') annotation: boolean;
  // private componentRef: ComponentRef<AnnotationButtonComponent>;
  private number1 = 1;
  private number2 = 1;
  private components: [ComponentRef<AnnotationButtonComponent>];

  charms1 = [
    { 'id': '1', 'type': 'charm', name: 'charm 1', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm1.png', 'price': 110 },
    { 'id': '2', 'type': 'charm', name: 'charm 2', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm2.png', 'price': 220 },
    { 'id': '3', 'type': 'charm', name: 'charm 3', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm3.png', 'price': 330 },
    { 'id': '4', 'type': 'charm', name: 'charm 4', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm4.png', 'price': 440 },
    { 'id': '5', 'type': 'charm', name: 'charm 5', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm5.png', 'price': 550 },
    { 'id': '6', 'type': 'charm', name: 'charm 6', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm6.png', 'price': 660 },
    { 'id': '7', 'type': 'charm', name: 'charm 7', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm7.png', 'price': 770 },
    { 'id': '8', 'type': 'charm', name: 'charm 8', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm8.png', 'price': 880 }
  ];
  charms2 = [
    { 'id': '11', 'type': 'charm', name: 'charm 11', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm1.png', 'price': 110 },
    { 'id': '12', 'type': 'charm', name: 'charm 12', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm2.png', 'price': 220 },
    { 'id': '13', 'type': 'charm', name: 'charm 13', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm3.png', 'price': 330 },
    { 'id': '14', 'type': 'charm', name: 'charm 14', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm4.png', 'price': 440 },
    { 'id': '15', 'type': 'charm', name: 'charm 15', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm5.png', 'price': 550 },
    { 'id': '16', 'type': 'charm', name: 'charm 16', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm6.png', 'price': 660 },
    { 'id': '17', 'type': 'charm', name: 'charm 17', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm7.png', 'price': 770 },
    { 'id': '18', 'type': 'charm', name: 'charm 18', 'img_url': 'http://krisnela.validateideas.com/ToggleArt/images/charm8.png', 'price': 880 }
  ];

  items1: any = [];
  items2: any = [];
  //selected_charms: any = [];

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private resolver: ComponentFactoryResolver) {
    // if (!this.authenticationService.currentUserValue) {
    //   this.router.navigate(['login']);
    // }
    this.createForm();

    //this.annotation = this.annotation ? this.annotation : false;
  }

  ngOnInit() {
  }

  createForm() {
    this.designForm = this.formBuilder.group({});
  }

  // convenience getter for easy access to form fields
  get f() { return this.designForm.controls; }

  ngOnDestroy() {
    this.components.forEach((component) => {
      component.destroy();
    });
  }

  dblClick($event) {
    $event.preventDefault();
    // console.log($event);
    this.addComponent($event);
  }

  addComponent($event: any) {
    // console.log(this.capaElementRef);
    const factory: ComponentFactory<AnnotationButtonComponent> = this.resolver.resolveComponentFactory(AnnotationButtonComponent);
    const viewContainer: ViewContainerRef = this.capa1;
    const component: ComponentRef<AnnotationButtonComponent> = viewContainer.createComponent(factory, 0);
    // this.componentRef = viewContainer.createComponent(factory, 0);
    this.components === void 0 ? this.components = [component] : this.components.push(component);
    this.setInitAttributes(component, $event);
    this.insertComponentInLayer(component, $event);
    this.setEvents(component, $event);
  }

  setInitAttributes(component: ComponentRef<AnnotationButtonComponent>, $event: any) {
    component.location.nativeElement.style.position = 'absolute';
    component.location.nativeElement.style.left = ($event.offsetX - 20) + 'px';
    component.location.nativeElement.style.top = ($event.offsetY - 20) + 'px';
    component.location.nativeElement.setAttribute('draggable', 'true');
  }

  setEvents(component: ComponentRef<AnnotationButtonComponent>, $event: any) {
    component.location.nativeElement.ondrag = (e) => {
      //return false;
      e.preventDefault();
      // console.log('Drag', e, e.layerX, ' ', e.layerY);
      // console.log(window.screenX, window.scrollY);
      const scrollX = window.pageXOffset;
      const scrollY = window.pageYOffset;
      component.location.nativeElement.style.left = (e.x - this.capaElementRef1.nativeElement.offsetLeft - 25) + scrollX + 'px';
      component.location.nativeElement.style.top = (e.y - this.capaElementRef1.nativeElement.offsetTop - 25) + scrollY + 'px';
      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
    };
    component.location.nativeElement.ondragstart = function (e) {
      //return false;
      const clone = this.cloneNode(true);
      clone.style.backgroundColor = 'red';
      clone.style.display = 'none'; /* or visibility: hidden, or any of the above */
      document.body.appendChild(clone);
      e.dataTransfer.setDragImage(clone, 0, 0);
    };
    component.location.nativeElement.ondragend = (e) => {
      //return false;
      const scrollX = window.pageXOffset;
      const scrollY = window.pageYOffset;
      e.preventDefault();
      // console.log('Drag end', e);
      // console.log(e.dataTransfer);
      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
      // console.log(e.path);
      const annotation_no = e.path[0].innerText.replace('x', '');
      console.log('annotation no. : ', annotation_no);
      const left = (e.x - this.capaElementRef1.nativeElement.offsetLeft - 25) + scrollX;
      const top = (e.y - this.capaElementRef1.nativeElement.offsetTop - 25) + scrollY;
      component.location.nativeElement.style.left = left + 'px';
      component.location.nativeElement.style.top = top + 'px';

      this.items1 = this.items1.map(i => {
        if (i.id * 1 === annotation_no * 1) {
          return { ...i, x: left, y: top };
        }
        return i;
      });

    };
  }

  insertComponentInLayer(component: ComponentRef<AnnotationButtonComponent>, $event: any) {
    // alert('in insert');
    document.querySelector('[meta-id="capa"]').appendChild(component.location.nativeElement);
    // console.log(component.instance);
    const instance = (<AnnotationButtonComponent>component.instance);
    instance.n = this.number1;
    this.number1++;

    const delbtn = component.location.nativeElement.getElementsByClassName('delete_annotation')[0];
    delbtn.addEventListener('click', this.deleteAnnotation1.bind(this), false);
    // delbtn.addEventListener('click', function (event) {
    //   // alert('delete clicked');
    //   // console.log(delbtn.closest('app-annotation-button'));
    //   const instance = (<AnnotationButtonComponent>delbtn.closest('app-annotation-button').closest('#button'));
    //   const del_no = delbtn.id;
    //   // alert(del_no);
    //   document.querySelector('[meta-id="capa"]').removeChild(delbtn.closest('app-annotation-button'));
    //   console.log(this);
    //   this.items.splice(del_no-1, 1);
    // });

    this.items1.push({
      id: instance.n,
      x: component.location.nativeElement.offsetLeft,
      y: component.location.nativeElement.offsetTop
    });
    // console.log('annotations -> ');
    // console.log(this.items);
  }

  deleteAnnotation1(event) {
    // alert('delete clicked');
    // console.log(event.path[0]);
    const delbtn = event.path[0];
    // console.log(delbtn.closest('app-annotation-button'));
    const instance = (<AnnotationButtonComponent>delbtn.closest('app-annotation-button').closest('#button'));
    const del_no = delbtn.id;
    // alert(del_no);
    document.querySelector('[meta-id="capa"]').removeChild(delbtn.closest('app-annotation-button'));
    // console.log(this);

    this.items1.forEach((element, index) => {
      if (element.id * 1 === del_no * 1) this.items1.splice(index, 1);
    });

    // console.log(this.items);
    this.resetAnnotations1();
  }

  resetAnnotations1() {
    const a: any = document.getElementsByTagName('app-annotation-button');
    // console.log(a);
    if (a.length > 0) {
      this.number1 = 0;
      for (var i = 0; i < document.getElementsByTagName('app-annotation-button').length; i++) {
        // console.log(a[i].getElementsByClassName('delete_annotation')[0]);
        // const ctrl = a[i];
        a[i].getElementsByClassName('delete_annotation')[0].id = i + 1 + '';
        a[i].getElementsByTagName('p')[0].innerText = i + 1 + '';
        this.number1 = i + 1;
      };
      this.number1++;
    }
    this.items1.forEach((element, index) => {
      // console.log(index);
      element.id = index + 1;
    });
  }

  addCharm1(id, charm, img) {
    // console.log(img);
    const a = document.getElementsByTagName('app-annotation-button');
    // console.log(a);
    const index = id * 1 - 1;

    // const parent_element = document.getElementsByTagName('app-annotation-button')[index];

    const parent_element = this.capaElementRef1.nativeElement.getElementsByTagName('app-annotation-button')[index];

    this.removeAllChildNodes(parent_element);
    const image = img.target.cloneNode();
    parent_element.appendChild(image);

    this.items1 = this.items1.map(i => {
      if (i.id === id) {
        return { ...i, charm: charm };
      }
      return i;
    });

    console.log('this.items -> ');
    console.log(this.items1);
  }

  removeAllChildNodes(parent) {
    while (parent.firstChild) {
      parent.removeChild(parent.firstChild);
    }
  }



  dblClick2($event) {
    $event.preventDefault();
    // console.log($event);
    this.addComponent2($event);
  }


  addComponent2($event: any) {
    // console.log(this.capaElementRef);
    const factory2: ComponentFactory<AnnotationButtonComponent> = this.resolver.resolveComponentFactory(AnnotationButtonComponent);
    const viewContainer2: ViewContainerRef = this.capa2;
    const component2: ComponentRef<AnnotationButtonComponent> = viewContainer2.createComponent(factory2, 0);
    // this.componentRef = viewContainer.createComponent(factory, 0);
    this.components === void 0 ? this.components = [component2] : this.components.push(component2);
    this.setInitAttributes(component2, $event);
    this.insertComponentInLayer2(component2, $event);
    this.setEvents2(component2, $event);
  }


  setEvents2(component: ComponentRef<AnnotationButtonComponent>, $event: any) {
    component.location.nativeElement.ondrag = (e) => {
      //return false;
      e.preventDefault();
      // console.log('Drag', e, e.layerX, ' ', e.layerY);
      // console.log(window.screenX, window.scrollY);
      const scrollX = window.pageXOffset;
      const scrollY = window.pageYOffset;
      component.location.nativeElement.style.left = (e.x - this.capaElementRef2.nativeElement.offsetLeft - 25) + scrollX + 'px';
      component.location.nativeElement.style.top = (e.y - this.capaElementRef2.nativeElement.offsetTop - 25) + scrollY + 'px';
      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
    };
    component.location.nativeElement.ondragstart = function (e) {
      //return false;
      const clone = this.cloneNode(true);
      clone.style.backgroundColor = 'red';
      clone.style.display = 'none'; /* or visibility: hidden, or any of the above */
      document.body.appendChild(clone);
      e.dataTransfer.setDragImage(clone, 0, 0);
    };
    component.location.nativeElement.ondragend = (e) => {
      //return false;
      const scrollX = window.pageXOffset;
      const scrollY = window.pageYOffset;
      e.preventDefault();
      // console.log('Drag end', e);
      // console.log(e.dataTransfer);
      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
      // console.log(e.path);
      const annotation_no = e.path[0].innerText.replace('x', '');
      console.log('2 annotation no. : ', annotation_no);
      const left = (e.x - this.capaElementRef2.nativeElement.offsetLeft - 25) + scrollX;
      const top = (e.y - this.capaElementRef2.nativeElement.offsetTop - 25) + scrollY;
      component.location.nativeElement.style.left = left + 'px';
      component.location.nativeElement.style.top = top + 'px';

      this.items2 = this.items2.map(i => {
        if (i.id * 1 === annotation_no * 1) {
          return { ...i, x: left, y: top };
        }
        return i;
      });

    };
  }

  insertComponentInLayer2(component: ComponentRef<AnnotationButtonComponent>, $event: any) {
    // alert('in insert');
    document.querySelector('[meta-id="capa2"]').appendChild(component.location.nativeElement);
    // console.log(component.instance);
    const instance = (<AnnotationButtonComponent>component.instance);
    instance.n = this.number2;
    this.number2++;

    const delbtn = component.location.nativeElement.getElementsByClassName('delete_annotation')[0];
    delbtn.addEventListener('click', this.deleteAnnotation2.bind(this), false);


    this.items2.push({
      id: instance.n,
      x: component.location.nativeElement.offsetLeft,
      y: component.location.nativeElement.offsetTop
    });
    // console.log('annotations -> ');
    // console.log(this.items);
  }

  deleteAnnotation2(event) {
    // alert('delete clicked');
    // console.log(event.path[0]);
    const delbtn = event.path[0];
    // console.log(delbtn.closest('app-annotation-button'));
    const instance = (<AnnotationButtonComponent>delbtn.closest('app-annotation-button').closest('#button'));
    const del_no = delbtn.id;
    // alert(del_no);
    document.querySelector('[meta-id="capa2"]').removeChild(delbtn.closest('app-annotation-button'));
    // console.log(this);

    this.items2.forEach((element, index) => {
      if (element.id * 1 === del_no * 1) this.items2.splice(index, 1);
    });

    // console.log(this.items);
    this.resetAnnotations2();
  }

  resetAnnotations2() {
    const a: any = document.getElementsByTagName('app-annotation-button');
    // console.log(a);
    if (a.length > 0) {
      this.number2 = 0;
      for (var i = 0; i < document.getElementsByTagName('app-annotation-button').length; i++) {
        // console.log(a[i].getElementsByClassName('delete_annotation')[0]);
        // const ctrl = a[i];
        a[i].getElementsByClassName('delete_annotation')[0].id = i + 1 + '';
        a[i].getElementsByTagName('p')[0].innerText = i + 1 + '';
        this.number2 = i + 1;
      };
      this.number2++;
    }
    this.items2.forEach((element, index) => {
      // console.log(index);
      element.id = index + 1;
    });
  }

  addCharm2(id, charm, img) {
    // console.log(img);
    const a = document.getElementsByTagName('app-annotation-button');
    // console.log(a);
    const index = id * 1 - 1;
    // const parent_element = document.getElementsByTagName('app-annotation-button')[index];
    const parent_element = this.capaElementRef2.nativeElement.getElementsByTagName('app-annotation-button')[index];

    // const div_element = parent_element.getElementsByTagName('div')[0];
    // console.log(div_element);
    // parent_element.removeChild(div_element);
    this.removeAllChildNodes(parent_element);
    const image = img.target.cloneNode();
    parent_element.appendChild(image);

    this.items2 = this.items2.map(i => {
      if (i.id === id) {
        return { ...i, charm: charm };
      }
      return i;
    });

    console.log('this.items -> ');
    console.log(this.items2);
  }

}

