import { CenterStonePredefine } from "@/_models/cs_predefine";
import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { CenterStonePredefineService } from "@/_services/cs_predefine.service";
import { Component, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";

@Component({
  selector: "app-center-stone-predefined-list",
  templateUrl: "./merchant-center-stone-predefined-list.component.html",
  styleUrls: ["./merchant-center-stone-predefined-list.component.css"],
})
export class MerchantCenterStonePredefinedListComponent {
  centerstonePredefinedFilterForm: FormGroup;
  centerstonepredefined: Observable<CenterStonePredefine[]>;
  dataSource: MatTableDataSource<CenterStonePredefine>;
  closeResult: string;
  search_text = "";
  centerstonePredefinedList: any = [];
  searchForm: FormGroup;
  filterMerchantCenterstonePredefinedList: any = [];
  isChecked: boolean;
  list: any = [];
  vendor_id: number;
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private centerstonpredefinedService: CenterStonePredefineService,
    private vendorauthenticationService: VendorAuthenticationService,

    private store: Store<{ centerstonepredefined: CenterStonePredefine[] }>
  ) {
    if (!this.vendorauthenticationService.vendorcurrentUserValue) {
      this.router.navigate(["merchant"]);
    }
  }

  ngOnInit() {
    this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id;
    this.getCenterStonePredefined();
    this.createSearchForm();
  }

  getCenterStonePredefined() {
    const dataObj = {
      merchant_id: this.vendor_id,
    };
    this.centerstonpredefinedService
      .getCS_PredefinebyMerchantid(dataObj)
      .subscribe((data) => {
        if (data) {
          this.list = data;
          this.centerstonePredefinedList = this.list.data;
          for (let i = 0; i < this.centerstonePredefinedList.length; i++) {
            this.centerstonePredefinedList[i].isactive =
              this.centerstonePredefinedList[i].isactive === "N" ? false : true;
            this.centerstonePredefinedList[i].SrNo = i + 1;
          }
          this.filterMerchantCenterstonePredefinedList =
            this.centerstonePredefinedList;
        }
      });
  }

  changeStatus(e, data: any) {
    this.isChecked = e.checked;
    const dataObj = {
      id: data.id,
      isactive: this.isChecked ? "Y" : "N",
    };
    this.centerstonpredefinedService
      .updateCenteStonePredefine(dataObj)
      .subscribe((data: CenterStonePredefine) => {
        this.getCenterStonePredefined();
        this.alertService.success("Status Updated successfully!", true);
        this.router.navigate(["MerchantCenterStonePredefined/list"]);
      });
  }

  createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [""],
    });
  }
  clear() {
    this.searchForm.get("keyword")?.setValue("");
    this.searchGrid();
  }

  searchGrid() {
    let keyword = this.searchForm.controls["keyword"].value;
    if (keyword === "") {
      this.filterMerchantCenterstonePredefinedList =
        this.centerstonePredefinedList;
    } else {
      keyword = keyword.toLowerCase();
      this.filterMerchantCenterstonePredefinedList =
        this.centerstonePredefinedList.filter((event) => {
          return (
            (event.name && event.name.toLowerCase().includes(keyword)) ||
            (event.designno &&
              event.designno.toLowerCase().includes(keyword)) ||
            (event.productname &&
              event.productname.toLowerCase().includes(keyword)) ||
            (event.collectionName &&
              event.collectionName.toLowerCase().includes(keyword)) ||
            (event.product_sub_type &&
              event.product_sub_type.toLowerCase().includes(keyword)) ||
            (event.type &&
              event.type.toLowerCase().includes(keyword)) ||
            (event.merchantname &&
              event.merchantname.toLowerCase().includes(keyword))
            //(event.product_sub_type === Number(keyword))
          );
        });
    }
  }
}
