import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { VendorService } from "@/_services/vendor.service";
import { Component } from "@angular/core";
import { FormArray, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { diamondType } from "@/masters/common.master";

import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { ProductTypeService } from "@/_services/product-type.service";
import { environment } from "environments/environment";
import { CenterStoneTypeService } from "@/_services/cs_type.service";
import { CollectionService } from "@/_services/collection.service";
import { MerchantCollectionService } from "@/_services/merchant-collection.service";
import { GemstoneService } from "@/_services/gemstone.service";
import { CenterStoneSizeService } from "@/_services/cs_size.service";
import { CenterStonePredefineService } from "@/_services/cs_predefine.service";
import { CenterStonePredefine } from "@/_models/cs_predefine";
import { CenterStoneFrameBandService } from "@/_services/cs_frame_band.service";
import { AddFamilyService } from "@/_services/add-family.service";
import { CenterStoneDefinitionService } from "@/_services/cs_definition.service";
import { CenterStoneVariantService } from "@/_services/cs_variant.service";

@Component({
  selector: "app-center-stone-predefined-add",
  templateUrl: "./center-stone-predefined-add.component.html",
  styleUrls: ["./center-stone-predefined-add.component.css"],
})
export class CenterStonePredefinedAddComponent {
  centerStonePredefinedAddForm: FormGroup;
  loading = false;
  submitted = false;
  merchantListAll: any = [];
  merchantData: any = [];
  merchantSetData: any = [];
  vendor_id: number;
  merchant_id: number;
  merchantList: any = [];
  merchantListLogin: any;
  list: any = [];
  productList: any = [];
  productSubList: any = [];
  filteredProductSubList: any = [];
  centerStoneFrameBandList: any = [];
  diamondType = diamondType;
  positionList: any = [{ id: "other" }];
  centerTypeStoneList: any = [];
  getCollectionList: any = [];
  gemstoneList: any = [];
  filtermerchantCollectionList: any = [];
  merchantCollectionList: any = [];
  public adminId = `${environment.adminId}`;
  centerStoneSizeList: any = [];
  csSizeList: any = [];
  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();
  modelImage: any;
  partImagePath: any;
  public path = `${environment.apiUrl}`;
  getDropFamilyList: any = [];
  FilterGetDropFamilyList: any = [];
  getCsFamilyList: any = [];
  FilterGetCsFamilyList: any = [];
  mode: String = "ADD";
  dataId: any;
  familyNameDrop: any = [];
  familyName: any = [];
  filtergetCollectionList: any = [];
  filtercenterStoneFrameBandList: any = [];
  isslusionDesignnameList: any = [];
  filterIllusionDesignnameList: any = [];
  centerStoneVariantList: any = [];
  filterCenterStoneVariantList: any = [];
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private vendorservices: VendorService,
    private ProductSubTypeService: ProductSubTypeService,
    private authenticationService: AuthenticationService,
    private producttypeService: ProductTypeService,
    private vendorauthenticationService: VendorAuthenticationService,
    private centerStoneTypeService: CenterStoneTypeService,
    private collectionService: CollectionService,
    private merchantCollectionService: MerchantCollectionService,
    private GemstoneService: GemstoneService,
    private centerstonsizeService: CenterStoneSizeService,
    private centerstonPredefinedService: CenterStonePredefineService,
    private AddFamilyService: AddFamilyService,
    private CenterStoneFramebandService: CenterStoneFrameBandService,
    private CenterStoneDefinitionService: CenterStoneDefinitionService,
    private centerstonvarianService: CenterStoneVariantService
  ) {
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id =
        this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.getCollectionData();
    this.getMerchantList();
    this.getDropFamList();
    this.getProductSubTypeData();
    this.createForm();
    this.getProductList();
    this.getAllCenterStoneList();
    this.genStoneData();
    this.getCenterStoneSizeList();
    this.getCenterStoneFrameband();
    this.centerStoneSizevariantList();
    this.getCsFamilyDesignList();
    this.getFamilyname();
    this.getCenterStoneDesign();
    this.route.params.subscribe((params) => {
      if (!!params.id) {
        this.dataId = params.id;
        this.mode = "EDIT";
        this.getCenteStonePreById(params);
        this.centerStoneSizevariantList();
      }
    });
  }

  centerStoneSizevariantList() {
    this.centerstonvarianService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;
        this.centerStoneVariantList = this.list.data;
        this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(
          (c) =>
            c.merchantid == this.centerStonePredefinedAddForm.value.merchantid
        );
      }
    });
  }

  createForm() {
    this.centerStonePredefinedAddForm = this.formBuilder.group({
      isactive: [""],
      name: ["", Validators.required],
      merchantid: [this.merchant_id],
      product_id: ["", Validators.required],
      product_sub_type: ["", Validators.required],
      collection_id: ["", Validators.compose([Validators.required])],
      merchantCollection: ["", Validators.compose([Validators.required])],
      designNo: ["", Validators.required],
      description: [""],
      frame_band_id: ["", Validators.required],
      drop_name: [""],
      cs_predefine: this.formBuilder.array([this.Initial_CenterSToneFOrm()]),
      multipleImages: this.formBuilder.array([this.Initial_Multiple()]),
    });
  }

  get f() {
    return this.centerStonePredefinedAddForm.controls;
  }

  get cs_predefine(): FormArray {
    return this.centerStonePredefinedAddForm.get("cs_predefine") as FormArray;
  }

  addCs_predefine() {
    this.cs_predefine.push(this.Initial_CenterSToneFOrm());
  }

  Initial_CenterSToneFOrm() {
    return this.formBuilder.group({
      centerStoneType: ["", Validators.required],
      csSize: [""],
      // diaType: [""],
      // gemstone_name: [""],
      csDesign_name: [""],
      csShapes: [""]
    });
  }

  getFamilyname() {
    this.AddFamilyService.getfamily_drop_byMerchantid({
      merchant_id: this.centerStonePredefinedAddForm.value.merchantid,
    }).subscribe((data) => {
      this.familyNameDrop = data;
      this.familyName = this.familyNameDrop.data.filter((c) => 
      c.merchant_id === this.centerStonePredefinedAddForm.value.merchantid
      );;
    });
  }

  removeRowCenterStoneForm(index: number) {
    this.cs_predefine.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }
  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantData = data;

          this.merchantSetData = this.merchantData.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });
          this.merchantListAll = this.merchantSetData;
        });
      }
    });
  }
  getCenterStoneSizeList() {
    this.centerstonsizeService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;
        this.centerStoneSizeList = this.list.data.filter(
          (x) => x.isactive == "Y"
        );
        this.centerStoneSizeList.map((data) => {
          data.csSize = data.cs_length + " * " + data.cs_width;
          return data;
        });
        if (this.mode !== "EDIT") {
          this.csSizeList = this.centerStoneSizeList.filter(
            (c) =>
              c.merchantid ===
              this.centerStonePredefinedAddForm.value.merchantid
          );
        }
      }
    });
  }
  getCenterStoneFrameband() {
    this.CenterStoneFramebandService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          //  
          this.centerStoneFrameBandList = this.list.data;
          this.filtercenterStoneFrameBandList = this.centerStoneFrameBandList.filter(
            (c)=>this.centerStonePredefinedAddForm.value.merchantid);   
                   

        });
      }
    });
  }
  getProductList() {
    this.producttypeService.getAll().subscribe((data) => {
      if (data) {
        //
        setTimeout(() => {
          this.productList = data;
        });
      }
    });
  }

  getProductSubTypeData() {
    this.ProductSubTypeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.productSubList = this.list.data;
          if (this.mode !== "EDIT") {
            this.filteredProductSubList = this.productSubList.filter(
              (c) => c.merchantid == this.merchant_id
            );
          }
          if (this.centerStonePredefinedAddForm.value.product_id) {
            this.productOnChange();
          }
          this.filtermerchantCollection();
        });
      }
    });
  }

  getCenterStoneDesign() {
    const dataObj = {
      merchant_id: this.centerStonePredefinedAddForm.get('merchantid').value,
    };
    this.CenterStoneDefinitionService.getCS_definitionbyMerchantid(dataObj).subscribe(
      (data) => {        
        if (data) {
          this.list = data;         
          this.isslusionDesignnameList = this.list.data;
          this.filterIllusionDesignnameList = this.list.data.filter(x => x.displayName);
          // this.filterIllusionDesignnameList =
          //   this.isslusionDesignnameList.filter(c =>c.typeId === this.centerStonePredefinedAddForm.get('merchantid').value && c.designName !== "");
          }
      });
  }

  filterCentrStoneDesign(i) {
    
  }
  filtermerchantCollection() {
    this.productOnChange();
    this.getFamilyname();
    this.getDropFamList();
    this.getCenterStoneSizeList();
    this.getCenterStoneDesign();
    

    this.filtermerchantCollectionList = this.merchantCollectionList.filter(
      (c) => c.merchantid === this.centerStonePredefinedAddForm.value.merchantid
      );
      
    ///drop family name
    this.FilterGetDropFamilyList = this.getDropFamilyList.filter(
      (c) => c.merchant_id == this.centerStonePredefinedAddForm.value.merchantid
    );
    this.FilterGetCsFamilyList = this.getCsFamilyList.filter(
      (c) => c.merchant_id == this.centerStonePredefinedAddForm.value.merchantid
    );

    this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(
      (c) =>
        c.merchantid == this.centerStonePredefinedAddForm.value.merchantid
    );
   
  }

  productOnChange() {
    this.filtercenterStoneFrameBandList = this.centerStoneFrameBandList.filter((c) =>
      c.product_id === this.centerStonePredefinedAddForm.value.product_id
    );
    this.FilterGetDropFamilyList = this.getDropFamilyList.filter(
      (c) => c.product_id === this.centerStonePredefinedAddForm.value.product_id
    );


    if (this.productSubList.length > 0) {
      if (this.centerStonePredefinedAddForm.value.product_id != "")
        this.filteredProductSubList = this.productSubList.filter(
          (c) =>
            c.product_id ===
            this.centerStonePredefinedAddForm.value.product_id &&
            c.merchantid == this.centerStonePredefinedAddForm.value.merchantid
        );
      else
        this.filteredProductSubList = this.productSubList.filter(
          (c) =>
            c.merchantid == this.centerStonePredefinedAddForm.value.merchantid
        );
    }
  }

  getAllCenterStoneList() {
    this.centerStoneTypeService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;
        this.centerTypeStoneList = this.list.data;
      }
    });
  }

  getCollectionData() {
    this.collectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.getCollectionList = data;
        });
      }
    });
    this.merchantCollectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantCollectionList = data["data"].filter(x => x.isactive == 'Y');
          if (this.mode !== "EDIT") {
            this.filtermerchantCollectionList =
              this.merchantCollectionList.filter(
                (c) =>
                  c.merchantid ===
                  this.centerStonePredefinedAddForm.value.merchantid
              );
          }
        });
      }
    });
  }

  genStoneData() {
    this.GemstoneService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneList = data;
        });
      }
    });
  }

  /// //// Drop Family   list////

  getDropFamList() {
    this.CenterStoneFramebandService.getLongDesignDropName().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          
          this.getDropFamilyList = this.list.data;
          this.FilterGetDropFamilyList = this.getDropFamilyList;
          
          if (this.mode !== "EDIT") {
            this.FilterGetDropFamilyList = this.getDropFamilyList.filter(
              (c) => c.product_id == this.centerStonePredefinedAddForm.value.product_id
            );
          }
        });
      }
    });
  }

  /// //// Cs Family   list////

  getCsFamilyDesignList() {
    this.CenterStoneFramebandService.getCSFamilyDesign().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.getCsFamilyList = this.list.data;
          if (this.mode !== "EDIT") {
            this.FilterGetCsFamilyList = this.getCsFamilyList.filter(
              (c) => c.merchant_id == this.merchant_id
            );
          }
        });
      }
    });
  }

  /// images ///

  selectedFiles(files: File[], index) {
    for (var i = 0; i < files.length; i++) {
      this.fileindexposition++;
      this.FileListMap.set(index, files[i]);
    }
  }

  Initial_Multiple() {
    return this.formBuilder.group({
      images: [""],
      displayUser: [""],
      secondOption: [""],
    });
  }

  get multipleImages() {
    return this.centerStonePredefinedAddForm.get("multipleImages") as FormArray;
  }

  removeRow(index: number) {
    this.multipleImages.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  onModelImageSelect(files: File[]) {
    var base64valueModel;
    for (var element = 0; element < files.length; element++) {
      const readerModel = new FileReader();
      readerModel.readAsDataURL(files[element]);
      readerModel.onload = (event: any) => {
        if (event.target.result) {
          base64valueModel = event.target.result;
          let dataModelObj = {
            base64format: base64valueModel,
            imagePath: files[0].name,
          };
          this.ProductSubTypeService.upload(dataModelObj).subscribe((data) => {
            this.modelImage = data["data"];
            this.partImagePath =
              this.path + "/imagepreview/getImage?imagename=" + this.modelImage;
            this.multipleImages.push(
              this.formBuilder.group({
                images: [this.partImagePath],
                displayUser: [''],
                secondOption: [''],
                modelImage: [this.modelImage],
              })
            );
          });
        }
      };
    }
  }

  toggledisplayuser(i: number) {
    if (
      this.centerStonePredefinedAddForm.value.multipleImages[i].displayUser ==
      true
    ) {
      this.centerStonePredefinedAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["secondOption"].setValue(false);
    }
  }

  togglesecond(i: number) {
    if (
      this.centerStonePredefinedAddForm.value.multipleImages[i].secondOption ==
      true
    ) {
      this.centerStonePredefinedAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["displayUser"].setValue(false);
    }
  }

  onSubmit() {
    this.submitted = true;
    this.alertService.clear();
    this.centerStonePredefinedAddForm.value.multipleImages.shift();

    if (this.centerStonePredefinedAddForm.value.merchantid == this.adminId) {
      this.centerStonePredefinedAddForm.controls["collection_id"].setValidators(Validators.required);
      this.centerStonePredefinedAddForm.controls["merchantCollection"]?.clearValidators();
      this.centerStonePredefinedAddForm.controls["merchantCollection"].setErrors(null);
      
    }  else if(this.centerStonePredefinedAddForm.value.merchantid != this.adminId) {
      this.centerStonePredefinedAddForm.controls["merchantCollection"].setValidators(Validators.required);
      this.centerStonePredefinedAddForm.controls["collection_id"]?.clearValidators();
      this.centerStonePredefinedAddForm.controls["collection_id"].setErrors(null);
    }

    if (this.centerStonePredefinedAddForm.valid) {
      const dataObj = {
        name: this.centerStonePredefinedAddForm.value.name,
        merchant_id: this.centerStonePredefinedAddForm.value.merchantid,
        productid: this.centerStonePredefinedAddForm.value.product_id,
        productsubtypeid:
          this.centerStonePredefinedAddForm.value.product_sub_type,
        frame_band_id: this.centerStonePredefinedAddForm.value.frame_band_id,
        drop_name: this.centerStonePredefinedAddForm.value.drop_name,
        description: this.centerStonePredefinedAddForm.value.description,
        designno: this.centerStonePredefinedAddForm.value.designNo,
        collectionid: this.centerStonePredefinedAddForm.value.collection_id,
        merchantCollection:
          this.centerStonePredefinedAddForm.value.merchantCollection,
        cs_predefine: this.centerStonePredefinedAddForm.value.cs_predefine,
        Image: this.centerStonePredefinedAddForm.value.multipleImages,
      };
      this.centerstonPredefinedService
        .save(dataObj)
        .subscribe((data: CenterStonePredefine) => {
          this.alertService.success(
            "Center Stone Predefined saved successfully!",
            true
          );
          if (this.vendor_id) {
            this.router.navigate(["MerchantCenterStonePredefined/list"]);
          } else {
            this.router.navigate(["AdminCenterStonePredefined/list"]);
          }
        });
    }
  }

  onUpdate() {
    this.submitted = true;
    this.alertService.clear();
    
    if (this.centerStonePredefinedAddForm.value.merchantid == this.adminId) {
      this.centerStonePredefinedAddForm.controls["collection_id"].setValidators(Validators.required);
      this.centerStonePredefinedAddForm.controls["merchantCollection"]?.clearValidators();
      this.centerStonePredefinedAddForm.controls["merchantCollection"].setErrors(null);
      
    }  else if(this.centerStonePredefinedAddForm.value.merchantid != this.adminId) {
      this.centerStonePredefinedAddForm.controls["merchantCollection"].setValidators(Validators.required);
      this.centerStonePredefinedAddForm.controls["collection_id"]?.clearValidators();
      this.centerStonePredefinedAddForm.controls["collection_id"].setErrors(null);
    }

    if (this.centerStonePredefinedAddForm.valid) {
      const dataObj = {
        id: this.dataId,
        isactive:
          this.centerStonePredefinedAddForm.value.isactive == true ? "Y" : "N",
        name: this.centerStonePredefinedAddForm.value.name,
        merchant_id: this.centerStonePredefinedAddForm.value.merchantid,
        productid: this.centerStonePredefinedAddForm.value.product_id,
        productsubtypeid:
          this.centerStonePredefinedAddForm.value.product_sub_type,
        frame_band_id: this.centerStonePredefinedAddForm.value.frame_band_id,
        drop_name: this.centerStonePredefinedAddForm.value.drop_name,
        designno: this.centerStonePredefinedAddForm.value.designNo,
        description: this.centerStonePredefinedAddForm.value.description,
        collectionid: this.centerStonePredefinedAddForm.value.collection_id,
        merchantCollection:
          this.centerStonePredefinedAddForm.value.merchantCollection,
        cs_predefine: this.centerStonePredefinedAddForm.value.cs_predefine,
        Image: this.centerStonePredefinedAddForm.value.multipleImages,
      };
      this.centerstonPredefinedService
        .updateCenteStonePredefine(dataObj)
        .subscribe((data: CenterStonePredefine) => {
          this.alertService.success(
            "Center Stone Predefined updated successfully!",
            true
          );
          if (this.vendor_id) {
            this.router.navigate(["MerchantCenterStonePredefined/list"]);
          } else {
            this.router.navigate(["AdminCenterStonePredefined/list"]);
          }
        });
    }
  }
  getProductSubType() {
    this.ProductSubTypeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.productSubList = this.list.data;
          this.filteredProductSubList = this.productSubList.filter(
            (c) =>
              c.merchantid ==
              this.centerStonePredefinedAddForm.value.merchant_id
          );
          if (this.centerStonePredefinedAddForm.value.product_id) {
            this.productOnChange();
          }
        });
      }
    });
  }
  getCenteStonePreById(id) {
    this.centerstonPredefinedService
      .getCenteStonePredefineById(id)
      .subscribe((data) => {
        if (data) {
          this.setFormValue(data);
          this.getProductSubType();
          this.filtermerchantCollection();
        }
      });
  }

  setFormValue(data) {
    let editData = data.data;
    this.csSizeList = this.centerStoneSizeList.filter(c => c.merchant_id === editData[0].merchant_id)
    this.filteredProductSubList = this.productSubList.filter(
      (c) => c.merchantid == editData[0].merchant_id
    );

    this.filtermerchantCollectionList = this.merchantCollectionList.filter(
      (c) => c.merchantid === editData[0].merchant_id
    );

    ///drop family name
    this.FilterGetDropFamilyList = this.getDropFamilyList.filter(
      (c) => c.product_id == editData[0].product_id
    );
    this.FilterGetCsFamilyList = this.getCsFamilyList.filter(
      (c) => c.merchant_id == editData[0].merchant_id
    );

    this.filtercenterStoneFrameBandList = this.centerStoneFrameBandList.filter(
      (c) => c.product_id === editData[0].product_id
    );

    
    this.filterIllusionDesignnameList =this.isslusionDesignnameList.filter((c) => c.merchantId ==
    editData[0].merchant_id
    );

    this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(
      (c) =>
        c.merchantid == editData[0].merchant_id
    );

    this.centerStonePredefinedAddForm
      .get("isactive")
      .setValue(editData[0].isactive === "Y" ? true : false);
    this.centerStonePredefinedAddForm
      .get("merchantid")
      .setValue(editData[0].merchant_id);
    this.centerStonePredefinedAddForm
      .get("product_id")
      .setValue(editData[0].productid);
    this.centerStonePredefinedAddForm
      .get("product_sub_type")
      .setValue(editData[0].productsubtypeid);
    this.centerStonePredefinedAddForm
      .get("collection_id")
      .setValue(editData[0].collectionid);
    this.centerStonePredefinedAddForm
      .get("merchantCollection")
      .setValue(editData[0].merchantCollection);
    this.centerStonePredefinedAddForm.get("name").setValue(editData[0].name);
    this.centerStonePredefinedAddForm
      .get("drop_name")
      .setValue(editData[0].drop_name);
    this.centerStonePredefinedAddForm
      .get("designNo")
      .setValue(editData[0].designno);
    this.centerStonePredefinedAddForm
      .get("description")
      .setValue(editData[0].description);
    this.centerStonePredefinedAddForm
      .get("frame_band_id")
      .setValue(editData[0].frame_band_id);
    var JsonData = editData[0].cs_predefine;
    var dataOfPredefine = JsonData;
    console.log('dataOfPredefine:', dataOfPredefine);
    this.centerStonePredefinedAddForm.setControl(
      "cs_predefine",
      this.setPredefineForm(dataOfPredefine)
    );
    var JsonData = editData[0].Image;
    var dataOfImage = JsonData;
    this.centerStonePredefinedAddForm.setControl(
      "multipleImages",
      this.setImageForm(dataOfImage)
    );
  }

  setPredefineForm(dataOfPredefine): FormArray {
    const formArray = new FormArray([]);
    dataOfPredefine.forEach((s) => {
      formArray.push(
        this.formBuilder.group({
          centerStoneType: [s.centerStoneType, Validators.required],
          csDesign_name: [s.csDesign_name],
          csSize: [s.csSize],
          csShapes: [s.csShapes]
          // diaType: [s.diaType],
          // gemstone_name: [s.gemstone_name],
        })
      );
    });
    return formArray;
  }

  setImageForm(dataOfMultipleImages): FormArray {
    const formArray = new FormArray([]);
    dataOfMultipleImages.forEach((s) => {
      formArray.push(
        this.formBuilder.group({
          images: [s.images],
          displayUser: [s.displayUser],
          secondOption: [s.secondOption],
        })
      );
    });
    return formArray;
  }

  backList() {
    if (this.vendor_id) {
      this.router.navigate(["MerchantCenterStonePredefined/list"]);
    } else {
      this.router.navigate(["AdminCenterStonePredefined/list"]);
    }
  }
}
