import { CenterStonePredefine } from "@/_models/cs_predefine";
import { AlertService, AuthenticationService } from "@/_services";
import { CenterStonePredefineService } from "@/_services/cs_predefine.service";
import { Component, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";

@Component({
  selector: "app-center-stone-predefined-list",
  templateUrl: "./center-stone-predefined-list.component.html",
  styleUrls: ["./center-stone-predefined-list.component.css"],
})
export class CenterStonePredefinedListComponent {

  centerstonePredefinedFilterForm: FormGroup;
  centerstonepredefined: Observable<CenterStonePredefine[]>;
  dataSource: MatTableDataSource<CenterStonePredefine>;
  closeResult: string;
  search_text = "";
  centerstonePredefinedList: any= [];
  searchForm:FormGroup;
  filtercenterstonePredefinedList: any=[]
  isChecked:boolean;
  list: any=[];

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private centerstonpredefinedService: CenterStonePredefineService,
    private store: Store<{ centerstonepredefined: CenterStonePredefine[] }>
  ) {

  }
  

  ngOnInit() {
    this.getCenterStonePredefined();
    this.createSearchForm();
  }

  getCenterStonePredefined() {
    this.centerstonpredefinedService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;

        this.centerstonePredefinedList = this.list.data;

        for (let i = 0; i < this.centerstonePredefinedList.length; i++) {
          this.centerstonePredefinedList[i].isactive =
            this.centerstonePredefinedList[i].isactive === "N" ? false : true;
          this.centerstonePredefinedList[i].SrNo = i + 1;
        }
        this.filtercenterstonePredefinedList = this.centerstonePredefinedList;
      }
    });
  }

  changeStatus(e, data: any) {
    this.isChecked = e.checked;
    const dataObj = {
      id: data.id,
      isactive: this.isChecked ? "Y" : "N",
    };
    this.centerstonpredefinedService.updateCenteStonePredefine(
      dataObj
    ).subscribe((data: CenterStonePredefine) => {
      this.getCenterStonePredefined();
      this.alertService.success("Status Updated successfully!", true);
      this.router.navigate(["AdminCenterStonePredefined/list"]);
    });
  }

  createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [""],
    });
  }
  clear() {
    this.searchForm.get("keyword")?.setValue("");
    this.searchGrid();
  }

  searchGrid() {
    let keyword = this.searchForm.controls["keyword"].value;
    console.log(keyword);
    
    if (keyword === "") {
      this.filtercenterstonePredefinedList = this.centerstonePredefinedList;
    } else {
      keyword = keyword.toLowerCase();
      this.filtercenterstonePredefinedList =
        this.centerstonePredefinedList.filter((event) => {
          console.log(event.product_sub_type);
          
          return (
            (event.name && event.name.toLowerCase().includes(keyword)) ||
            (event.designno &&
              event.designno.toLowerCase().includes(keyword)) ||
            (event.productname &&
              event.productname.toLowerCase().includes(keyword)) ||
            (event.collectionName &&
              event.collectionName.toLowerCase().includes(keyword)) ||
            (event.product_sub_type &&
              event.product_sub_type.toLowerCase().includes(keyword)) ||
            (event.type &&
              event.type.toLowerCase().includes(keyword)) ||
            (event.merchantname &&
              event.merchantname.toLowerCase().includes(keyword))
            //(event.product_sub_type === Number(keyword))
          );
        });
    }
  }
    
}