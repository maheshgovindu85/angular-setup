import { Component, OnInit } from '@angular/core';
import * as collection_selector from '@/_store/collection/collection.selector';
import * as collectionimage_selector from '@/_store/collectionimage/collectionimage.selector';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertService, AuthenticationService, EncryptDecryptService } from '@/_services';
import { CollectionService } from '@/_services/collection.service';
import { CollectionImages } from '@/_models/collectionimages';
import { select, Store } from '@ngrx/store';
import { Collection } from '@/_models/collection';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { CollectionimageService } from '@/_services/collectionimage.service';
import { CollectionImageAdd } from '@/_store/collectionimage/collectionimage.actions';
@Component({
  selector: 'app-collection-images-add',
  templateUrl: './collection-images-add.component.html',
  styleUrls: ['./collection-images-add.component.css']
})
export class CollectionImagesAddComponent implements OnInit {

  collectionImagesAddForm: FormGroup;
  loading = false;
  submitted = false;
  visible:boolean = false;

  // uploadedFiles: File[] = [];

  collectionControl = new FormControl();
  collections = [];
  filteredCollections: Observable<any[]>;

  public selection: string;
  public customOption: string = 'customOption';
  getCollection_id;

  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private collectionService: CollectionService,
    private collectionImgService: CollectionimageService,
    private store: Store<{ collectionimages: CollectionImages[], collections: Collection[] }>
  ) {
    // redirect if already logged in
    if (!this.authenticationService.currentUserValue) {
      this.router.navigate(['login']);
    }
    else {
      this.createForm();
    }

  }

  ngOnInit(): void {
    // this.getCollections();

    this.collectionService.getAll()
      .subscribe(data => {
        this.collections = data;
        this.filteredCollections = this.collectionControl.valueChanges.pipe(
          startWith(''),
          map(name => name ? this.filterCollections(name) : this.collections.slice())
        );
      });

  }

  onclick(){
    this.visible = !this.visible
  }

  createForm() {
    this.collectionImagesAddForm = this.formBuilder.group({
      id: 0,
      collection_id: [0, Validators.required],
      collection_name: [''],
      img_type: [''],
      isdelete: ['N'],
      collectionImgDetails: this.formBuilder.array([this.Initial_Collection()])
    });
  }

  //get all Collection
  getCollections() {
    // this.store.pipe(select(collection_selector.getAllCollection()))
    this.collectionService.getAll()
      .subscribe(data => {
        this.collections = data;
      });
  }

  filterCollections(name: string) {
    if (!this.isNumber(name))
      return this.collections.filter(s => s.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }

  filterCountry(event) {
    //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
    let filtered : any[] = [];
    let query = event.query;

    for(let i = 0; i < this.collections.length; i++) {
        let collections = this.collections[i];
        if (collections.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
            filtered.push(collections);
        }
    }

    this.collections = filtered;
}

  getCollectionName(collection_id: number) {
    this.getCollection_id = collection_id;
    if (this.collections != null && collection_id != null)
      return this.collections.filter(m => m.id * 1 === collection_id * 1)[0].name;
  }

  selectedFiles(files: File[], index) {
    for (var i = 0; i < files.length; i++) {
      this.fileindexposition++;
      this.FileListMap.set(index, files[i]);
    }
  }

  Initial_Collection() {
    return this.formBuilder.group({
      img_vid_path: ['', Validators.required],
      org_file_name: [''],
      vendor: [''],
      customer: [''],
      preview_video: ['']
    });
  }

  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }

  onAddRow() {
    this.Collection.push(this.Initial_Collection());
  }

  get Collection() {
    return this.collectionImagesAddForm.get('collectionImgDetails') as FormArray;
  }

  removeRow(index: number) {
    this.Collection.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }
  // collectionImg

  onSubmit() {
    this.submitted = true;
    this.collectionImagesAddForm.get("collection_name").setValue(this.collectionImagesAddForm.value.collection_id.name)
    // this.collectionImagesAddForm.get("collection_name").setValue(this.collectionImagesAddForm.value.collection_id.collection_id)
    this.getCollection_id = this.collectionImagesAddForm.value.collection_id.id;
    
    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.collectionImagesAddForm.invalid) {
      return;
    }


    this.collectionImagesAddForm.get('collection_id').setValue(this.getCollection_id);

    // if (this.collectionControl.value !== undefined && this.collectionControl.value !== '') {
    //   var collection_name = this.collectionImagesAddForm.value.collection_name.name;
    //   this.collectionImagesAddForm.get("collection_name").setValue(collection_name);
    // }
    const formData = new FormData();
    formData.append('collectionImg', JSON.stringify(this.collectionImagesAddForm.value));
    
    this.FileListMap.forEach((value: File, key: number) => {
      formData.append("files", value);
    });
    formData.append('collection_id', JSON.stringify(this.getCollection_id));

    this.loading = true;
    this.collectionImgService
      .save(formData)
      .subscribe((data: CollectionImages) => {
        // this.store.dispatch(new CollectionImageAdd(this.collectionImagesAddForm.value));
        this.alertService.success('Collection Images saved successfully!', true);
        this.router.navigate(['collectionimages/list']);
      });

  }
}
