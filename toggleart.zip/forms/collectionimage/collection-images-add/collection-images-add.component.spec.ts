import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CollectionImagesAddComponent } from './collection-images-add.component';

describe('CollectionImagesAddComponent', () => {
  let component: CollectionImagesAddComponent;
  let fixture: ComponentFixture<CollectionImagesAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CollectionImagesAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollectionImagesAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
