import { CollectionImages } from '@/_models/collectionimages';
import { AlertService, AuthenticationService, EncryptDecryptService } from '@/_services';
import { CollectionimageService } from '@/_services/collectionimage.service';
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import * as collectionimage_selector from '@/_store/collectionimage/collectionimage.selector';
import * as collection_selector from '@/_store/collection/collection.selector';
import { Observable } from 'rxjs';
import { Collection } from '@/_models/collection';
import { CollectionService } from '@/_services/collection.service';
import { map, startWith } from 'rxjs/operators';
import { CollectionImageUpdate } from '@/_store/collectionimage/collectionimage.actions';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';

@Component({
  selector: 'app-collection-images-edit',
  templateUrl: './collection-images-edit.component.html',
  styleUrls: ['./collection-images-edit.component.css']
})
export class CollectionImagesEditComponent implements OnInit {

  collectionImagesEditForm: FormGroup;
  loading = false;
  submitted = false;
  collectionimages: Observable<CollectionImages[]>;
  collectionimage: any;
  collection_Images = [];
  image_name: string;

  setVendor = false;
  setCustomer = false;

  uploadedFiles: File;
  fileList: File[] = [];

  myControl = new FormControl();
  collections: any[];
  filteredcollection: Observable<any[]>;

  setRadioBtn;
  radioSel: any;
  getCollection_id;

  public selection: string;
  public customOption: string = 'customOption';

  constructor(private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private encryptdecryptService: EncryptDecryptService,
    public collectionImageService: CollectionimageService,
    private collectionService: CollectionService,
    private store: Store<{ collectionimages: CollectionImages[], collections: Collection[] }>
  ) {

    if (this.authenticationService.currentUserValue) {
      const id = this.route.snapshot.params.id;

      collectionImageService.GetListOfCollection().subscribe(
        (data) => {
          this.collections = data;
          this.filteredcollection = this.myControl.valueChanges
            .pipe(
              startWith(''),
              map(coll => coll ? this.filterCollection(coll) : this.collections.slice()),
            );
        });

      this.collectionImagesEditForm = this.formBuilder.group({
        id: ['', Validators.required],
        collection_id: [0, Validators.required],
        collection_name: [''],
        collectionImgDetails: formBuilder.array([]),
        deletedCollectionimages: formBuilder.array([])
      });

      collectionImageService.GetCollectionDetails(id)
        .subscribe((data) => {
          this.collectionimage = data;
          this.myControl.setValue(this.collectionimage[0].collection_id);
          this.createForm(data);
          this.getSelecteditem();
        });
    }
    else {
      this.router.navigate(['login']);
    }
  }

  deleteimages(index, id) {
    var formgroup = this.formBuilder.group({
      id: [id, Validators.required]
    })
    this.deletedCollectionimagesArray.push(formgroup);
    this.Collection.removeAt(index);
  }

  ngOnInit() {

  }
  createForm(details) {
    this.collectionImagesEditForm = this.formBuilder.group({
      collection_id: [this.collectionimage[0].collection_id, Validators.required],
      collection_name: [''],
      collectionImgDetails: this.Initial_Collection(details),
      deletedCollectionimages: this.formBuilder.array([])
    });
    
  }

  getSelecteditem() {
    this.selection = this.setRadioBtn;
  }

  Initial_Collection(Product_details): FormArray {
    const formArray = new FormArray([]);
    Product_details.forEach(s => {
      formArray.push(this.formBuilder.group({
        id: [s.id, Validators.required],
        img_type: [s.img_type, Validators.required],
        img_vid_path: [s.img_vid_path, Validators.required],
        base64: [this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + s.img_vid_path],
        org_file_name: [s.org_file_name],
        vendor: [s.vendor == 'Y' ? true : false],
        customer: [s.customer == 'Y' ? true : false],
        preview_video: [s.preview_video]
      }));
    });
    return formArray;
  }

  appendEmptyCollection() {
    return this.formBuilder.group({
      id: [0, Validators.required],
      img_type: ['', Validators.required],
      img_vid_path: ['', Validators.required],
      org_file_name: [],
      base64: [''],
      vendor: ['N'],
      customer: ["N"],
      preview_video: ['N'],
    });
  }


  Onselectedfiles(files: File[], i_parent: number) {
    var a = this.Collection.controls[i_parent] as FormArray;
    var imgtype = a.controls['img_type'] as FormArray;
    var setoppisitimagetype: any = files[0].type == 'image' ? 'video' : 'image'
    imgtype.setValue(setoppisitimagetype)

    for (var i = 0; i < files.length; i++) {
      this.Add_file_form(files[i], i_parent);
    }
  }

  Add_file_form(files: File, i: number) {
    var base64value;
    const reader = new FileReader();
    reader.readAsDataURL(files);
    reader.onload = (event: any) => {

      if (event.target.result) {
        base64value = event.target.result;
        var a = this.Collection.controls[i] as FormArray;
        var b = a.controls['base64'] as FormArray;
        b.setValue(base64value);
        var imgtype = a.controls['img_type'] as FormArray;
        var setimagetype: any = this.IsImage(files.type) == true ? 'image' : 'video';
        imgtype.setValue(setimagetype)

        var imagepath = a.controls['img_vid_path'] as FormArray;
        var path: any = 'NA';
        imagepath.setValue(path);
        var filename = a.controls['org_file_name'] as FormArray;
        var og_name: any = files.name;
        filename.setValue(og_name);
      }
    }

  }


  IsImage(name: string) {
    return name.includes('image')
  }
  IsVideo(name: string) {
    return name.includes('video')
  }

  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }

  VendorChange(event, index: number) {
    var a = this.Collection.controls[index] as FormArray;
    var b = a.controls['vendor'] as FormArray;
    b.setValue(event.checked);
  }

  CustomerChange(event, index: number) {
    var a = this.Collection.controls[index] as FormArray;
    var b = a.controls['customer'] as FormArray;
    b.setValue(event.checked);
  }

  selectedFiles(files: File) {
    this.uploadedFiles = files;
    this.fileList = [];
    this.image_name = files[0].name;
  }


  get f() { return this.collectionImagesEditForm.controls; }

  onAddRow() {
    this.Collection.push(this.appendEmptyCollection());
  }
  get Collection() {
    return this.collectionImagesEditForm.get('collectionImgDetails') as FormArray;
  }

  get deletedCollectionimagesArray() {
    return this.collectionImagesEditForm.get('deletedCollectionimages') as FormArray;
  }

  removeRow(index: number) { this.Collection.removeAt(index); }

  onSubmit() {
    this.submitted = true;

    // reset alerts on submit
    this.alertService.clear();
    
    // stop here if form is invalid
    if (this.collectionImagesEditForm.invalid) {
      return;
    }
    if (this.myControl.value !== undefined && this.myControl.value !== '') {
      var collection_name = this.collections.filter(m => m.id === this.myControl.value)[0].name;
      this.collectionImagesEditForm.get("collection_name").setValue(collection_name);
    }
    
    

    this.loading = true;
    this.collectionImageService
      .Update(this.collectionImagesEditForm.value)
      .subscribe((data) => {
        this.alertService.success('Collection Image updated successfully!', true);
        this.router.navigate(['collectionimages/list']);
      });
  }

  //For Collcetion 
  filterCollection(name: string) {
    
    if (!this.isNumber(name))
      return this.collections.filter(m => m.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getCollectionName(typeId: number) {
    if (this.collections != null && typeId != null && typeId != 0) {
      return this.collections.filter(s => s.id === typeId)[0].name;
    }
  }
}
