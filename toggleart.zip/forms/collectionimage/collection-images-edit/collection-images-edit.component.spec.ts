import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CollectionImagesEditComponent } from './collection-images-edit.component';

describe('CollectionImagesEditComponent', () => {
  let component: CollectionImagesEditComponent;
  let fixture: ComponentFixture<CollectionImagesEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CollectionImagesEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollectionImagesEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
