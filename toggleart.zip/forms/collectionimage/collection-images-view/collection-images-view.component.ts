import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';


import { CollectionImages } from '@/_models/collectionimages';
import { CollectionImageGetAll, CollectionImageRemove } from '@/_store/collectionimage/collectionimage.actions';
import { CollectionimageService } from '@/_services/collectionimage.service';
import * as collectionimage_selector from '@/_store/collectionimage/collectionimage.selector';
import { AlertService, AuthenticationService, CollectiontypeService, EncryptDecryptService } from '@/_services';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { MatDialog } from '@angular/material/dialog';
import { CollectionImagesPopupComponent } from '@/forms/collection_imagesPopup/collection-images-popup/collection-images-popup.component';

@Component({
  selector: 'app-collection-images-view',
  templateUrl: './collection-images-view.component.html',
  styleUrls: ['./collection-images-view.component.css']
})
export class CollectionImagesViewComponent implements OnInit {

  collectionImageFilterForm: FormGroup;
  collectionimages: Observable<CollectionImages[]>;
  dataSource: MatTableDataSource<CollectionImages>;
  closeResult: string;
  search_text = "";
  collectionImagesList: any = [];
  searchForm:FormGroup;
  filterCollectionTyeList: any=[]

  displayedColumns: string[] = ['collection_name', 'actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private metalgoldcolorservice: MetalgoldcolorService,
    public collectionImageService: CollectionimageService,
    public dialog: MatDialog,
    private store: Store<{ collectionimages: CollectionImages[] }>
  ) {
    this.collectionImageFilterForm = formBuilder.group({
      search_text: ''
    });

    this.collectionImageFilterForm.valueChanges.subscribe(value => {
      const filter = {
        ...value,
        search_text: value.search_text.trim().toLowerCase()
      } as string;
      this.dataSource.filter = filter;
    });
  }

  ngOnInit(): void {
    this.createSearchForm();
  }

  ngAfterViewInit() {
    this.collectionImageService
      // .getAll()
      .getCollectionlist()
      .subscribe((data: CollectionImages[]) => {
        // this.store.dispatch(new CollectionImageGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
        // });
        // this.store.pipe(select(collectionimage_selector.getAllCollectionImage())).subscribe(data => {
        if (data) {
          setTimeout(() => {
            this.dataSource = new MatTableDataSource(data);
            this.castingImages(data);
            this.collectionImagesList = data;
            this.filterCollectionTyeList = this.collectionImagesList;
            this.filterCollectionTyeList.sort((a,b) => {
              return new Date(b.savedate).getTime() - new Date(a.savedate).getTime();
            });
  
            this.filterCollectionTyeList.sort((a,b) => {
              return  new Date(b.modifydate).getTime() - new Date(a.modifydate).getTime();
            });
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;

            this.dataSource.filterPredicate = ((data, filter) => {
              const a = !filter.search_text ||
                data.collection_name.toString().trim().toLowerCase().includes(filter.search_text);
              return a;
            }) as (PeriodicElement, string) => boolean;
          });
        }
      });
  }

  DeleteCollection(collectionImageId, isactive) {
    this.collectionImageService
      .delete(collectionImageId, isactive)
      .subscribe((data: CollectionImages[]) => {
        this.store.dispatch(new CollectionImageRemove(collectionImageId));
      });
  }

  DeleteCollectionImg(collectionImageId, index) {
    this.collectionImageService
      .delete(collectionImageId, "Y")
      .subscribe((data) => {
        // this.store.dispatch(new DiamondColorPurityRemove(colorid));
        this.dataSource.data.splice(index, 1);
        this.dataSource._updateChangeSubscription();
        this.alertService.success('deleted successfully!', true);

      });
  }

  public castingImages(collimgs: any[]) {
    for (let i = 0; i < collimgs.length; i++) {
      collimgs[i].picture = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + collimgs[i].img_vid_path;
    }
  }

  OpenIgesPopup(id) {
    const dialogRef = this.dialog.open(CollectionImagesPopupComponent, {
      // width: '250px',

      data: { id: id }
    });

    dialogRef.afterClosed().subscribe(result => {
    });

  }

  // Search button function start
  createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [''],
    });
  }
  clear() {
    this.searchForm.get('keyword')?.setValue('');
    this.searchGrid();
  }
  searchGrid() {
    let keyword = this.searchForm.controls['keyword'].value;
    if (keyword === '') {
      this.filterCollectionTyeList = this.collectionImagesList;
    } else {
      keyword = keyword.toLowerCase();
      this.filterCollectionTyeList = this.collectionImagesList.filter((event) => {
        return (
          (event.collection_name && event.collection_name.toLowerCase().includes(keyword))
        );
      });
    }
  }

}
