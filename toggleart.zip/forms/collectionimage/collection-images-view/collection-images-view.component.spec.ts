import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CollectionImagesViewComponent } from './collection-images-view.component';

describe('CollectionImagesViewComponent', () => {
  let component: CollectionImagesViewComponent;
  let fixture: ComponentFixture<CollectionImagesViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CollectionImagesViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollectionImagesViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
