import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toggle-art-home-aboutus',
  templateUrl: './toggle-art-home-aboutus.component.html',
  styleUrls: ['./toggle-art-home-aboutus.component.css']
})
export class ToggleArtHomeAboutusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
