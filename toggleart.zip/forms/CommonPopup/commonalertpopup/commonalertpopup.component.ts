import { ClientDesignAnnoationProductViewComponent } from '@/forms/Client_Pages/client-design-annoation-productview/client-design-annoation-productview';
import { ClientDesignCustomizePageComponent } from '@/forms/Client_Pages/client-design-customize-page/client-design-customize-page.component';
import { CompareproductComponent } from '@/forms/Client_Pages/compareproduct/compareproduct.component';
import { DialogData } from '@/forms/Client_Pages/view-customer-bracelet-info/view-customer-bracelet-info.component';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-commonalertpopup',
  templateUrl: './commonalertpopup.component.html',
  styleUrls: ['./commonalertpopup.component.css']
})
export class CommonalertpopupComponent implements OnInit {
  productname;
  forwhat;
  constructor(
    public dialogRef: MatDialogRef<CompareproductComponent, ClientDesignAnnoationProductViewComponent>,
    public dialogRefData: MatDialogRef<ClientDesignCustomizePageComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    this.productname = data.name;
    this.forwhat = data.mission;
  }

  ngOnInit(): void {
  }

  closealert() {
    this.dialogRef.close();
    this.dialogRefData.close();
  }

}
