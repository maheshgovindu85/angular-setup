import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VendorContactusListComponent } from './vendor-contactus-list.component';

describe('VendorContactusListComponent', () => {
  let component: VendorContactusListComponent;
  let fixture: ComponentFixture<VendorContactusListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VendorContactusListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VendorContactusListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
