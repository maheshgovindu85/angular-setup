import { CenterStoneType } from "@/_models/cs_type";
import { AlertService } from "@/_services";
import { CenterStoneTypeService } from "@/_services/cs_type.service";
import { Component } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs/internal/Observable";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { environment } from "environments/environment";



@Component({
  selector: "app-center-stone-type-add",
  templateUrl: "./center-stone-type-add.component.html",
  styleUrls: ["./center-stone-type-add.component.css"],
})
export class CenterStoneTypeAddComponent {

  centerstonetypeAddForm: FormGroup;
  loading = false;
  submitted = false;
  centerstonetypes: Observable<CenterStoneType[]>;
  dataObj: { base64format: any; imagePath: string; };
  typeImage: any;
  typeImagePath: any;
  public path = `${environment.apiUrl}`;
    constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private centerStoneTypeService:CenterStoneTypeService,
    private alertService: AlertService,
    private ProductSubTypeService: ProductSubTypeService,
    private store: Store<{ centerstonetypes: CenterStoneType[] }>
    ) {}
   
    ngOnInit() {
      this.centerstonetypeAddForm = this.formBuilder.group({
        name: ['', Validators.required],
        base64format: [''],
      })
      }

      get formValidationState() {
        return this.centerstonetypeAddForm.controls;
      }
      onSelectedFiles(files: File[]) {
        var base64value;
        const reader = new FileReader();
        
        reader.readAsDataURL(files[0]);
        reader.onload = (event: any) => {
          if (event.target.result) {
            base64value = event.target.result;
            this.dataObj= {
              base64format: base64value,
              imagePath: files[0].name,
            }
            this.centerstonetypeAddForm.get('base64format').setValue(base64value);
            this.ProductSubTypeService.upload(this.dataObj).subscribe((data) => {
              this.typeImage = data["data"];
              this.typeImagePath = this.path + "/imagepreview/getImage?imagename=" + this.typeImage;
             
            });
          }
        }
      }
       onSubmit(){
        this.submitted = true;
        this.alertService.clear();
        if (this.centerstonetypeAddForm.valid) {
          const dataObj={
            name: this.centerstonetypeAddForm.value.name,
            image: this.typeImagePath
          }
          this.centerStoneTypeService.save(dataObj).subscribe((data: CenterStoneType) => {
            this.alertService.success('Center Stone Type saved successfully!', true);
            this.router.navigate(['/AdminCenterStoneType/list']);
          });
        } else{
          return;
        }
       }
}