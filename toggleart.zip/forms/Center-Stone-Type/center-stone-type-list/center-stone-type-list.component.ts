import { CenterStoneType } from "@/_models/cs_type";
import { AlertService, AuthenticationService } from "@/_services";
import { CenterStoneTypeService } from "@/_services/cs_type.service";
import { Component, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs/internal/Observable";

@Component({
  selector: "app-center-stone-type-list",
  templateUrl: "./center-stone-type-list.component.html",
  styleUrls: ["./center-stone-type-list.component.css"],
})
export class CenterStoneTypeListComponent {

  centerstonetypeFilterForm: FormGroup;
  centerstonetypes: Observable<CenterStoneType[]>;
  dataSource: MatTableDataSource<CenterStoneType>;
  closeResult: string;
  search_text = "";
  centerStoneTypeList: any = [];
  searchForm: FormGroup;
  filterCenterStoneTypeList: any = []
  isChecked: boolean;
  list: any = [];
  centerTypeStoneList: any = [];
  displayedColumns: string[] = ['name', 'isactive', 'actions'];


  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private centerStoneTypeService: CenterStoneTypeService,
    private store: Store<{ centerstonetypes: CenterStoneType[] }>
  ) {
    if (!this.authenticationService.currentUserValue) {
    }
  }

  ngOnInit() {
    this.getAllCenterStoneList();
    this.createSearchForm();
  }

  getAllCenterStoneList() {
    this.centerStoneTypeService.getAll()
      .subscribe(data => {
        if (data) {
          this.list = data;
          
            this.centerTypeStoneList = this.list.data;
            
            for (let i = 0; i < this.centerTypeStoneList.length; i++) {
              this.centerTypeStoneList[i].isactive = this.centerTypeStoneList[i].isactive === 'N' ? false : true;
              this.centerTypeStoneList[i].SrNo = i + 1;
            }
            this.filterCenterStoneTypeList = this.centerTypeStoneList;
            
        }
      });
  }

  changeStatus(e, data: any) {
    this.isChecked = e.checked;
    const dataObj = {
      id: data.id,
      isactive: this.isChecked ? 'Y' : 'N',
    };
    this.centerStoneTypeService.updateCenterStoneType(dataObj).subscribe((data: CenterStoneType) => {
      this.alertService.success('Status Updated successfully!', true);
    });

  }

  // Search button function start
  createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [''],
    });
  }
  clear() {
    this.searchForm.get('keyword')?.setValue('');
    this.searchGrid();
  }
  searchGrid() {
    let keyword = this.searchForm.controls['keyword'].value;
    if (keyword === '') {
      this.filterCenterStoneTypeList = this.centerTypeStoneList;
    } else {
      keyword = keyword.toLowerCase();
      this.filterCenterStoneTypeList = this.centerTypeStoneList.filter((event) => {
        return (
          (event.name && event.name.toLowerCase().includes(keyword))
        );
      });
    }
  }
}