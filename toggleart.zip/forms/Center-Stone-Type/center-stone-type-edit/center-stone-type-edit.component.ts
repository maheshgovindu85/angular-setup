
import { CenterStoneType } from "@/_models/cs_type";
import { AlertService, AuthenticationService } from "@/_services";
import { CenterStoneTypeService } from "@/_services/cs_type.service";
import { Component } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { Observable } from "rxjs/internal/Observable";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { environment } from "environments/environment";


@Component({
  selector: "app-center-stone-type-edit",
  templateUrl: "./center-stone-type-edit.component.html",
  styleUrls: ["./center-stone-type-edit.component.css"],
})
export class CenterStoneTypeEditComponent {

  centerstonetypeEditForm: FormGroup;
  loading = false;
  submitted = false;
  centerstonetypes:Observable<CenterStoneType[]>;
  centerstonetype: any;
  setActivated = false;
  submitted2 = false;
  typeid: number;
  typeData: any = [];
  typeList: any = [];
  dataObj: { base64format: any; imagePath: string; };
  typeImage: any;
  public path = `${environment.apiUrl}`;
  typeImagePathSet: any = null;
  typeImagePath: string;


    constructor(
    private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private ProductSubTypeService: ProductSubTypeService,

    private centerStoneTypeService:CenterStoneTypeService,
    ) {
      if (!this.authenticationService.currentUserValue) {
      }
    }

    ngOnInit(): void {
      this.typeid = this.route.snapshot.params.id;
      this.createForm()
      this.getAllTypeById()
      // this.getTypeList()
    }

    get formValidationState() {
      return this.centerstonetypeEditForm.controls;
    }
  
    createForm() {
      this.centerstonetypeEditForm = this.formBuilder.group({
        name: ['', Validators.required],
        isactive: [''],
        base64format: [''],
      });
    }
  
    get f() { 
      return this.centerstonetypeEditForm.controls; 
    }

    getAllTypeById() {
      this.centerStoneTypeService.getCenterStoneTypebyid({
        id: this.typeid,
      }).subscribe((data) => {
        if (data) {

          this.setFormValue(data);
        }
      });
    }

    setFormValue(data) {
      this.typeData = data.data;
      this.centerstonetypeEditForm.get("name") ?.setValue(this.typeData[0].name);
      this.centerstonetypeEditForm.get("isactive")?.setValue(this.typeData[0].isactive === 'Y' ? true : false);
      this.typeImagePathSet= this.typeData[0].image;
    }

    onSelectedFiles(files: File[]) {
      var base64value;
      const reader = new FileReader();
      
      reader.readAsDataURL(files[0]);
      reader.onload = (event: any) => {
        this.typeImagePathSet = (<FileReader>event.target).result;

        if (event.target.result) {
          base64value = event.target.result;
          this.dataObj= {
            base64format: base64value,
            imagePath: files[0].name,
          }
          this.centerstonetypeEditForm.get('base64format').setValue(base64value);
          
          this.ProductSubTypeService.upload(this.dataObj).subscribe((data) => {
            this.typeImagePath = this.path + "/imagepreview/getImage?imagename=" + data["data"];
           
          });
        }
      }
    }
    

    onSubmit() {
      this.submitted = true;
      this.alertService.clear();
      if (this.centerstonetypeEditForm.valid) {
        const dataObj = {
          id: this.typeid,
          name: this.centerstonetypeEditForm.value.name, 
          isactive: this.centerstonetypeEditForm.value.isactive ? "Y" : "N",
          image: this.typeImagePath
        };

        this.centerStoneTypeService.updateCenterStoneType(dataObj).subscribe(
          (data: CenterStoneType) => {
            this.alertService.success('Center Stone Type updated successfully!', true);
            this.router.navigate(['/AdminCenterStoneType/list']);
          }
        );
      }

    }
  
}