import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CollectionImagesPopupComponent } from './collection-images-popup.component';

describe('CollectionImagesPopupComponent', () => {
  let component: CollectionImagesPopupComponent;
  let fixture: ComponentFixture<CollectionImagesPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CollectionImagesPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollectionImagesPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
