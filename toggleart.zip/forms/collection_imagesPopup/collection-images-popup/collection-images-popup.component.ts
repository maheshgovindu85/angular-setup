import { DialogData } from '@/forms/vendor/collection/v-collection-view/v-collection-view.component';
import { CollectionimageService } from '@/_services/collectionimage.service';
import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { environment } from 'environments/environment';


@Component({
  selector: 'app-collection-images-popup',
  templateUrl: './collection-images-popup.component.html',
  styleUrls: ['./collection-images-popup.component.css']
})
export class CollectionImagesPopupComponent implements OnInit {

  @ViewChild('videoPlayer') videoplayer: ElementRef;
  public rowid;
  public Collectionwise_imges;
  collectionname;
  constructor(
    public collectionImageService: CollectionimageService,
    public dialogRef: MatDialogRef<CollectionImagesPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) {
    this.rowid = data.id;
  }

  ngOnInit(): void {

    this.collectionImageService
      // .getAll()
      .getColletionwiseImg(this.rowid).subscribe((data: any) => {
        this.Collectionwise_imges = data;
        this.collectionname = data[0].collection_name;
      })
  }

  deleteimage(id){
    var cnfrm = confirm('Are you sure want Deleted This Containt ?');
    if(cnfrm){
      this.collectionImageService.deleteCollectionImages(id).subscribe(()=>{
        this.Collectionwise_imges.forEach((element,index) => {
          if(element.id == id){
            this.Collectionwise_imges.splice(index,1)
          }
        });
      })
    }else{

    }
  }

  getvideo(name) {
    return `${environment.apiUrl}/imagepreview/getImage?imagename=` + name;
  }

  toggleVideo(event: any) {
    this.videoplayer.nativeElement.play();
  }

}
