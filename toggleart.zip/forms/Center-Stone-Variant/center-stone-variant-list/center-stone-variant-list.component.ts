import { CenterStoneVariant } from "@/_models/cs_variant";
import { AlertService, AuthenticationService } from "@/_services";
import { CenterStoneVariantService } from "@/_services/cs_variant.service";
import { Component, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs/internal/Observable";

@Component({
  selector: "app-center-stone-variant-list",
  templateUrl: "./center-stone-variant-list.component.html",
  styleUrls: ["./center-stone-variant-list.component.css"],
})
export class CenterStoneVariantListComponent {

  centerstonevariantFilterForm: FormGroup;
  centerstonevarian: Observable<CenterStoneVariant[]>;
  dataSource: MatTableDataSource<CenterStoneVariant>;
  closeResult: string;
  search_text = "";
  centerstonevariantList: any= [];
  searchForm:FormGroup;
  filtercenterstonevarianList: any=[]
  isChecked:boolean;
  list: any=[];

  displayedColumns: string[] = ['name','merchant_id', 'shape', 'degree', 'isactive', 'actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

    constructor(
      private router: Router,
      private formBuilder: FormBuilder,
      private alertService: AlertService,
      private authenticationService: AuthenticationService,
      private centerstonvarianService: CenterStoneVariantService,
      private store: Store<{ producttypes: CenterStoneVariant[] }>
    ) {
      this.filtercenterstonevarianList = formBuilder.group({
        search_text: ''
      });

      this.filtercenterstonevarianList.valueChanges.subscribe(value => {
        // console.log(value);
        const filter = {
          ...value,
          search_text: value.search_text.trim().toLowerCase()
        } as string;
        // console.log(filter);
        this.dataSource.filter = filter;
      });
    }
   
    ngOnInit() {
      this.centerStoneSizevariantList()
      this.createSearchForm()
      }

      centerStoneSizevariantList(){
        this.centerstonvarianService.getAll()
        .subscribe(data => {
          if (data) {
            this.list = data;
            
              this.centerstonevariantList = this.list.data;
              
              for (let i = 0; i < this.centerstonevariantList.length; i++) {
                this.centerstonevariantList[i].isactive = this.centerstonevariantList[i].isactive === 'N' ? false : true;
                this.centerstonevariantList[i].SrNo = i + 1;
              }
              this.filtercenterstonevarianList = this.centerstonevariantList;
              
          }
        });
      }

      changeStatus(e,data: any){
        this.isChecked = e.checked;
        const dataObj = {
          id: data.id,
          isactive : this.isChecked ? 'Y' : 'N',
        };
        this.centerstonvarianService.updateCenterStoneVariant(dataObj).subscribe((data: CenterStoneVariant) => {
          this.centerStoneSizevariantList();
          this.alertService.success('Status Updated successfully!', true);
          this.router.navigate(['AdminCenterStoneVariant/list']);
        });
      
      }

      createSearchForm() {
        this.searchForm = this.formBuilder.group({
          keyword: [''],
        });
      }
      clear() {
        this.searchForm.get('keyword')?.setValue('');
        this.searchGrid();
      }

      searchGrid() {
        let keyword = this.searchForm.controls['keyword'].value;
        if (keyword === '') {
          this.filtercenterstonevarianList = this.centerstonevariantList;
        } else {
          keyword = keyword.toLowerCase();
          this.filtercenterstonevarianList = this.centerstonevariantList.filter((event) => {
            return (
              (event.name && event.name.toLowerCase().includes(keyword))||
              (event.cs_shape && event.cs_shape.toLowerCase().includes(keyword))||
              (event.cs_degree && event.cs_degree.toLowerCase().includes(keyword))||
              (event.merchant_id === Number(keyword) )||
              (event.merchantname && event.merchantname.toLowerCase().includes(keyword))
              // (event.merchantname && event.merchantname.toLowerCase().includes(keyword))
              
            );
          });
        }
      }
}