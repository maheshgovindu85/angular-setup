
import { CenterStoneVariant } from "@/_models/cs_variant";
import { AlertService, AuthenticationService, DiamondShapeService, VendorAuthenticationService } from "@/_services";
import { CenterStoneVariantService } from "@/_services/cs_variant.service";
import { VendorService } from "@/_services/vendor.service";
import { Component } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { environment } from "environments/environment";
import { Observable } from "rxjs";
import { degree } from "@/masters/common.master";
@Component({
  selector: "app-center-stone-variant-add",
  templateUrl: "./center-stone-variant-add.component.html",
  styleUrls: ["./center-stone-variant-add.component.css"],
})
export class CenterStoneVariantAddComponent {

  centerStoneVariantAddForm: FormGroup;
  loading = false;
  submitted = false;
  submitted2 = false;
  stonsize: Observable<CenterStoneVariant[]>;
  vendor_id:any;
  merchantListAll:any=[];
  merchant_id:number;
  public adminId=`${environment.adminId}`;
  merchantData: any =[];
  merchantSetData: any =[];
  shapeList: any = [];
  degree = degree;
    constructor(
      private router: Router,
      private formBuilder: FormBuilder,
      private alertService: AlertService,
      private authenticationService: AuthenticationService,
      private centerstonvarianService: CenterStoneVariantService,
      private vendorauthenticationService:VendorAuthenticationService,
      private vendorservices: VendorService,
      private DiamondShapeService: DiamondShapeService,
      private store: Store<{ centerstoneVariant: CenterStoneVariant[] }>
    ) {
      if (!this.authenticationService.currentUserValue) {
        this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id; 
        this.merchant_id = this.vendor_id;
      } else {
        this.adminId = JSON.parse(this.adminId);
        this.merchant_id = JSON.parse(this.adminId);
      }
    }
   
    ngOnInit() {
      this.shapeData();
      this.createForm();
      this.getMerchantList();
      }

      get formValidationState() {
        return this.centerStoneVariantAddForm.controls;
      }
      get f() {
        return this.centerStoneVariantAddForm.controls;
      }

      createForm() {
        this.centerStoneVariantAddForm = this.formBuilder.group({
        
          name:['', Validators.required],
          merchant_id: [this.merchant_id],
          cs_shape: ['', Validators.required],
          cs_degree: ['',Validators.required],
        });
      }

      getMerchantList() {
        this.vendorservices.getAll().subscribe((data) => {
          if (data) {
            setTimeout(() => {
              
              this.merchantData = data;
    
              this.merchantSetData = this.merchantData.map((user) => {
                user.merchantId =
                  user.id + " | " + user.firstname + " | " + user.company;
                return user;
              });
              this.merchantListAll = this.merchantSetData;
            });
          }
        });
      }

      onSubmit(){
        this.submitted = true;
        this.submitted2 = true;
        this.alertService.clear();
    
        if (this.centerStoneVariantAddForm.invalid) {
          return;
        }

        this.loading = true;
        this.centerstonvarianService
        .save(this.centerStoneVariantAddForm.value)
        .subscribe((data: CenterStoneVariant) => {
         console.log("my name.......",data)
          this.alertService.success('Center Stone Variant saved successfully!', true);
          if(this.vendor_id){
            this.router.navigate(["MerchantAdminCenterStoneVariant/list"]);
          } else{
            this.router.navigate(["AdminCenterStoneVariant/list"]);
          }
          // this.router.navigate(['/AdminCenterStoneVariant/list']);
        });
      }

      backToList() {
        if(this.vendor_id){
          this.router.navigate(["MerchantAdminCenterStoneVariant/list"]);
        } else{
          this.router.navigate(["AdminCenterStoneVariant/list"]);
        }
      }

      shapeData() {
        this.DiamondShapeService.getAll().subscribe((data) => {
          if (data) {
            setTimeout(() => {
              this.shapeList = data;
            });
          }
        });
      }
}