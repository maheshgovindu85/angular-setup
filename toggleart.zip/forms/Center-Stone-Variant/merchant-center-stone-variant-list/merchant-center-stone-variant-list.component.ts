import { CenterStoneVariant } from "@/_models/cs_variant";
import { AlertService, AuthenticationService, VendorAuthenticationService } from "@/_services";
import { CenterStoneVariantService } from "@/_services/cs_variant.service";
import { Component } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";

@Component({
  selector: "app-merchant-center-stone-variant-list",
  templateUrl: "./merchant-center-stone-variant-list.component.html",
  styleUrls: ["./merchant-center-stone-variant-list.component.css"],
})
export class MerchantCenterStoneVariantListComponent {

  merchantCenterVariantList: any =[];
  filterMerchantCenterVariantList:any =[]
  merchant_id:any;
  searchForm:FormGroup;
  isChecked:boolean;
  list: any=[];


    constructor(
      private formBuilder: FormBuilder,
      private router: Router,
      private alertService: AlertService,
      private authenticationService: AuthenticationService,
      private centerstonvarianService: CenterStoneVariantService,
      private store: Store<{ producttypes: CenterStoneVariant[] }>,
      private centerstonvariantService: CenterStoneVariantService,
      private vendorauthenticationService: VendorAuthenticationService,
    ) {
      if (!this.vendorauthenticationService.vendorcurrentUserValue) {
        this.router.navigate(['merchant_id']);
        this.merchant_id = this.vendorauthenticationService.vendorcurrentUserValue.id;
      }
    }
   
    ngOnInit() {
      this.merchant_id = this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.getCenterStoneVariant()
      this.createSearchForm()
      }

      getCenterStoneVariant(){
        const dataObj={
          "merchant_id": this.merchant_id
        }
        this.centerstonvariantService.getCS_VariantbyMerchantid(dataObj)
         .subscribe(data => {

          //console.log("all data....",data)
           if (data) {
            this.list = data;
            this.merchantCenterVariantList = this.list.data;
            for(let i =0; i <this.merchantCenterVariantList.length;i++){
              this.merchantCenterVariantList[i].isactive = this.merchantCenterVariantList[i].isactive === 'N' ? false : true;
              this.merchantCenterVariantList[i].srNo = i+1;
            }
             this.filterMerchantCenterVariantList = this.merchantCenterVariantList;
           }
         });
     }

     createSearchForm() {
      this.searchForm = this.formBuilder.group({
        keyword: [''],
      });
    }
    clear() {
      this.searchForm.get('keyword')?.setValue('');
      this.searchGrid();
    }

    searchGrid() {
      let keyword = this.searchForm.controls['keyword'].value;
      if (keyword === '') {
        this.filterMerchantCenterVariantList = this.merchantCenterVariantList;
      } else {
        keyword = keyword.toLowerCase();
        this.filterMerchantCenterVariantList = this.merchantCenterVariantList.filter((event) => {
          return (
            (event.name && event.name.toLowerCase().includes(keyword))||
            (event.cs_shape && event.cs_shape.toLowerCase().includes(keyword))||
            (event.cs_degree && event.cs_degree.toLowerCase().includes(keyword))
          );
        });
      }
    }

    changeStatus(e,data: any){
      this.isChecked = e.checked;
      const dataObj = {
        id: data.id,
        isactive : this.isChecked ? 'Y' : 'N',
      };
      this.centerstonvariantService.updateCenterStoneVariant(dataObj).subscribe((data: CenterStoneVariant) => {
        this.getCenterStoneVariant();
        this.alertService.success('Status Updated successfully!', true);
      });
     
     }
}