import { degree } from "@/masters/common.master";
import { CenterStoneVariant } from "@/_models/cs_variant";
import { AlertService, AuthenticationService, DiamondShapeService, VendorAuthenticationService } from "@/_services";
import { CenterStoneVariantService } from "@/_services/cs_variant.service";
import { VendorService } from "@/_services/vendor.service";
import { Component } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { environment } from "environments/environment";

@Component({
  selector: "app-center-stone-variant-edit",
  templateUrl: "./center-stone-variant-edit.component.html",
  styleUrls: ["./center-stone-variant-edit.component.css"],
})
export class CenterStoneVariantEditComponent {

  submitted = false;
  submitted2 = false;
  centerstonevariantEditForm: FormGroup;
  loading = false;
  vendor_id:any;
  merchant_id:number;
  variantid: number;
  merchantListAll:any=[];
  public adminId=`${environment.adminId}`;
  variantData: any = [];
  merchantData: any =[];
  merchantListLogin: any;
  merchantSetData: any =[];
  shapeList: any = [];
  degree = degree;

    constructor(
      private route: ActivatedRoute,
      private router: Router,
      private formBuilder: FormBuilder,
      private alertService: AlertService,
      private authenticationService: AuthenticationService,
      private centerstonvarianService: CenterStoneVariantService,
      private vendorauthenticationService:VendorAuthenticationService,
      private vendorservices: VendorService,
      private DiamondShapeService: DiamondShapeService,
      
      private store: Store<{ centerstonevariant: CenterStoneVariant[] }>
    ) {
      if (!this.authenticationService.currentUserValue) {
        this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id; 
        this.merchant_id = this.vendor_id;
      } else {
        this.adminId = JSON.parse(this.adminId);
        this.merchant_id = JSON.parse(this.adminId);
      }
    }
   
    ngOnInit() {
      this.variantid = this.route.snapshot.params.id;
      this.shapeData();     
      this.getMerchantList()
      this.createForm();
      this.getVariantById(); 
      }

      createForm() {
        this.centerstonevariantEditForm = this.formBuilder.group({
          name:['', Validators.required],
          merchant_id: [this.merchant_id],
          cs_shape: ['', Validators.required],
          cs_degree: ['',Validators.required],
          isactive: [true]
         
        });
      }
      get f() { 
        return this.centerstonevariantEditForm.controls; 
      }
      get formValidationState() {
        return this.centerstonevariantEditForm.controls;
      }

      getVariantById() {
        this.centerstonvarianService.getCenterStoneVariantbyid({
          id: this.variantid,
        }).subscribe((data) => {
          if (data) {  
            this.setFormValue(data);
          }
        });
      }

      setFormValue(data) {
        this.variantData = data.data; 
        this.centerstonevariantEditForm.get("name")?.setValue(this.variantData[0].name);
        this.centerstonevariantEditForm.get("merchant_id")?.setValue(this.variantData[0].merchant_id);
        this.centerstonevariantEditForm.get("cs_shape")?.setValue(parseInt(this.variantData[0].cs_shape));
        this.centerstonevariantEditForm.get("cs_degree")?.setValue(this.variantData[0].cs_degree);
        this.centerstonevariantEditForm.get("isactive")?.setValue(this.variantData[0].isactive === "Y" ? true : false);
      }

      
      getMerchantList() {
        this.vendorservices.getAll().subscribe((data) => {
          if (data) {
            setTimeout(() => {
              this.merchantData = data;
    
              this.merchantSetData = this.merchantData.map((user) => {
                user.merchantId =
                  user.id + " | " + user.firstname + " | " + user.company;
                return user;
              });
    
              if (!this.vendor_id) {
                this.merchantListAll = this.merchantSetData;
              } else {
                this.merchantListLogin = this.merchantSetData.filter(
                  (e) => e.id === this.vendor_id
                );
              }
            });
          }
        });
      }

      onSubmit() {
        this.submitted = true;
        this.submitted2 = true;
  
        this.alertService.clear();
    
        if (this.centerstonevariantEditForm.valid) {
          const dataObj = {
            id: this.variantid,
            name:this.centerstonevariantEditForm.value.name,
            merchant_id:this.centerstonevariantEditForm.value.merchant_id,
            cs_shape: this.centerstonevariantEditForm.value.cs_shape, 
            cs_degree: this.centerstonevariantEditForm.value.cs_degree,
            isactive: this.centerstonevariantEditForm.value.isactive ? "Y" : "N"
          };
  
          this.centerstonvarianService.updateCenterStoneVariant(dataObj).subscribe(
            (data: CenterStoneVariant) => {
              this.alertService.success(
                "Center Stone Variant Updated successfully!",
                true
              );
              this.alertService.success('Center Stone Variant updated successfully!', true);
              if(this.vendor_id){
                this.router.navigate(["MerchantAdminCenterStoneVariant/list"]);
              } else{
                this.router.navigate(["AdminCenterStoneVariant/list"]);
              }
            }
          );
        }
  
      }
      backToList() {
        if(this.vendor_id){
          this.router.navigate(["MerchantAdminCenterStoneVariant/list"]);
        } else{
          this.router.navigate(["AdminCenterStoneVariant/list"]);
        }
      }

      shapeData() {
        this.DiamondShapeService.getAll().subscribe((data) => {
          if (data) {
            setTimeout(() => {
              this.shapeList = data;
            });
          }
        });
      }

}