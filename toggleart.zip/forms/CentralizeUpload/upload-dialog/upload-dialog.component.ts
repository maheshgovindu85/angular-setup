import { AlertService, GemstoneShapeService } from '@/_services';
import { CentralizefileuploadService } from '@/_services/centralizefileupload.service';
import { GlobalColorPreferenceService } from '@/_services/global-color-preference.service';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
@Component({
  selector: 'app-upload-dialog',
  templateUrl: './upload-dialog.component.html',
  styleUrls: ['./upload-dialog.component.css']
})
export class UploadDialogComponent implements OnInit {


  selectedFiles = [];
  files: File[] = [];
  images: any;
  CentralizeUpload: FormGroup;
  DeleteImagesForm: FormGroup;
  alert = false;
  activeTab = 0;
  showFiller = false;
  date: Date;
  imageData = [];
  count = 0;
  imgStyle: String;
  //side-nav

  opened = false;
  imgSrc: any;
  imgId: any;
  imgName: any;
  tabSelected: any;
  openNav = false;

  alt: any;
  imgTitle: any;
  description: any;
  // im: ImageModel;
  // mi: MultiImage;

  ischeck: any;
  isChecked: boolean;
  products: any[];
  checkboxData: any;
  sendData: any;
  loading = false;

  goldcolorvariationavailfor: string[] = ['Chain Design and weight', 'Chain ring', 'Lock', 'Charm', 'Addon', 'Link Chain', 'Ball Pearl']

  public ServerURL;
  MasterControl = new FormControl();
  searchfromGallery = new FormControl();

  masters: string[] = ['Gold Colour', 'Central stone shape', 'Global Colour Preferance', 'Collection', 'Bracelet type', 'Chain Design and weight', 'Chain ring', 'Lock', 'Studded type', 'Predefined bracelet Structure', 'Charm', 'Addon', 'Link Chain', 'Ball Pearl'];
  filteredmasters: Observable<string[]>;

  Show_images_type: boolean = false;
  Show_images_position: boolean = false;

  productIdData: any;

  updateArray: Array<{ id: any, product_id: number, img_id: number, img_name: any, isdelete: any }> = [];

  finalArr: any[] = [];
  productName: any;
  multiId: any;

  colorCtrl = new FormControl();
  colors: any[];
  filteredColors: Observable<any[]>;

  goldColorCtrl1 = new FormControl();
  goldcolors1: any[];
  filteredGoldColor1: Observable<any[]>;

  public details_ofGoldColor;
  public details_ofCentralStoneShape;
  public details_ofGolbalColorPre;
  public details_ofBraceletType;
  public details_ofChainDesignWeight;
  public details_ofChainring;
  public details_ofLock;
  public details_ofStuddettype;
  public details_ofPRedesinedbracelet;
  public details_ofCharm;
  public details_ofAddon;
  public details_ofCollection;
  public details_ofballpearl;
  public details_oflinkchain;

  fileuploadLenght: number = 0;

  public dis_savebtn: boolean = false;

  isLoading = false;
  listproductImages;
  masterproductName = 'NA';

  @ViewChild("dbgold_info") div1: ElementRef;

  @ViewChild('drawer') propertydrower: ElementRef;

  deletedGalleryimages: any[] = [];
  filtered_images;

  constructor(
    // @Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<UploadDialogComponent>,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private centralizefileUpload: CentralizefileuploadService,
    private goldcolorSrvices: MetalgoldcolorService,
    private centralshapestone: GemstoneShapeService,
    private globalcolorPreferance: GlobalColorPreferenceService
  ) {

    this.centralizefileUpload.getMultipledetails()
      .subscribe((data) => {
        var JsonData = JSON.parse(JSON.stringify(data));
        var combo_goldcolour = JsonData.combo_goldcolour;
        var combo_centralShapeStone = JsonData.combo_centralShapeStone;
        var combo_globalcolorpre = JsonData.combo_globalcolorpre;

        var combo_bracelettype = JsonData.combo_bracelettype;
        var combo_chaindesignweight = JsonData.combo_chaindesignweight;
        var combo_chainRing = JsonData.combo_chainRing;
        var combo_lock = JsonData.combo_lock;
        var combo_studdedtype = JsonData.combo_studdedtype;
        var combo_predifinedStructure = JsonData.combo_predifinedStructure;
        var combo_charm = JsonData.combo_charm;
        var combo_addon = JsonData.combo_addon;
        var combo_collection = JsonData.combo_collection;
        var combo_ballpearl = JsonData.combo_ballpearl;
        var combo_linkchain = JsonData.combo_linkchain;

        this.details_ofGoldColor = combo_goldcolour;
        this.details_ofCentralStoneShape = combo_centralShapeStone;
        this.details_ofGolbalColorPre = combo_globalcolorpre;
        this.details_ofBraceletType = combo_bracelettype;
        this.details_ofChainDesignWeight = combo_chaindesignweight;
        this.details_ofChainring = combo_chainRing;
        this.details_ofLock = combo_lock;
        this.details_ofStuddettype = combo_studdedtype;
        this.details_ofPRedesinedbracelet = combo_predifinedStructure;
        this.details_ofCharm = combo_charm;
        this.details_ofAddon = combo_addon;
        this.details_ofCollection = combo_collection;
        this.details_ofballpearl = combo_ballpearl;
        this.details_oflinkchain = combo_linkchain;

      });

    this.ServerURL = metalgoldcolorservice.path;

    this.CentralizeUpload = formBuilder.group({
      fileUpload: formBuilder.array([]),
      deletedimages: formBuilder.array([]),
      isdelete: ['N']
    });
    //For Master Autocomplete
    this.filteredmasters = this.MasterControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );

    centralizefileUpload.GetGoldColor()
      .subscribe((data) => {
        this.goldcolors1 = data;
        this.filteredGoldColor1 = this.goldColorCtrl1.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterGoldColor1(color) : this.goldcolors1.slice())
          );
      });

    this.DeleteImagesForm = formBuilder.group({
      deleteseletedimage: formBuilder.array([])
    });
  }

  changeMaster(i: number) {
    var data = ((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['master'].value;
    (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(0);

    switch (data) {
      case 'Gold Colour':
        this.colors = this.details_ofGoldColor;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Central stone shape':
        this.colors = this.details_ofCentralStoneShape;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Global Colour Preferance':
        this.colors = this.details_ofGolbalColorPre;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Collection':
        this.colors = this.details_ofCollection;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);

        break;
      case 'Bracelet type':
        this.colors = this.details_ofBraceletType;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Chain Design and weight':
        this.colors = this.details_ofChainDesignWeight;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Chain ring':
        this.colors = this.details_ofChainring;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );

        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Lock':
        this.colors = this.details_ofLock;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );

        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Studded type':
        this.colors = this.details_ofStuddettype;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Predefined bracelet Structure':
        this.colors = this.details_ofPRedesinedbracelet;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(false);
        // (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['ismain_imagevalue']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['oppenismain_images']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Charm':
        this.colors = this.details_ofCharm;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['styddedtypeopen']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldgemstone_images_visible']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Addon':
        this.colors = this.details_ofAddon;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['styddedtypeopen']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldgemstone_images_visible']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Link Chain':
        this.colors = this.details_oflinkchain;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['styddedtypeopen']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldgemstone_images_visible']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
      case 'Ball Pearl':
        this.colors = this.details_ofballpearl;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldcolor']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['styddedtypeopen']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['images_view_type']).setValue(true);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['image_position']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['goldgemstone_images_visible']).setValue(false);
        (((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId']).setValue(this.colorCtrl.value);
        break;
    }
    this.fillGroupform(i);
  }

  changeProduct(i: number) {
    // var value = ((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId'].value;
    // console.log(value);
    // ((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['productId'].setValue(value);
  }

  ngOnInit(): void {

    this.imgStyle = 'img-style-unchange';

    this.centralizefileUpload.getAll().subscribe(
      res => {
        this.images = res;
        this.filtered_images = res;
      }
    )

    this.searchfromGallery.valueChanges.subscribe(value => {
      this.filtered_images = this.images;
      this.filtered_images = this.filtered_images.filter(f => f.file_originalname.includes(value))
    })
  }

  imagesPreview(image_path: string) {
    return this.ServerURL + '/images/' + image_path;
  }

  backButtonClick(index) {
    if (this.imageFormArray.at(index - 1)) {
      (this.imageFormArray.at(index) as FormArray).controls['visible'].patchValue(false);
      (this.imageFormArray.at(index - 1) as FormArray).controls['visible'].patchValue(true)
    }
  }

  FormwordButtonClick(index) {
    if (this.imageFormArray.at(index + 1)) {
      (this.imageFormArray.at(index) as FormArray).controls['visible'].patchValue(false);
      (this.imageFormArray.at(index + 1) as FormArray).controls['visible'].patchValue(true)
    }
  }

  ChangeMster(i: number) {

  }

  onUploadClick(ev) {
  }

  onSelect(event) {
    this.files.push(...event.addedFiles);
  }

  upload() {

    if (this.files.length < 1) {
      this.alertService.error('Please select a file to upload ..', true);
      return;
    }
    this.loading = true;
    for (var i = 0; i < this.files.length; i++) {

      const formData = new FormData();
      formData.append("files", this.files[i]);

      this.centralizefileUpload.save(formData).subscribe
        (
          data => {
            this.images = data;
            this.activeTab = 1;
            this.alertService.success('Data uploaded successfully', true);
            this.centralizefileUpload.getAll().subscribe(
              res => {
                this.images = res;
                this.filtered_images = res;
              }
            )
          }
        );
    }
    this.files = [];
  }
  onclear(event) {
    console.log(event);
    this.files = [];
  }

  onRemove(event) {
    this.files.splice(this.files.indexOf(event), 1);
  }

  clicked(data) {
    this.imgStyle = 'img-style-change';
  }

  log(state) {
    console.log(state);
  }

  raiseResize() {
    window.dispatchEvent(new Event('resize'));
  }

  onTabClick(event) {
    this.tabSelected = event.tab.textLabel;

    while (this.deletedimagesArray.controls.length !== 0) {
      this.deletedimagesArray.removeAt(0);
    }
    while (this.imageFormArray.controls.length !== 0) {
      this.imageFormArray.removeAt(0);
    }

    this.MasterControl.setValue("");

    if (event.tab.isActive == true) {
      this.opened = false;
    }
    if (this.tabSelected == 'Gallery') {
      this.centralizefileUpload.getAll().subscribe(
        res => {
          this.images = res;
          this.filtered_images = res;
        }
      )
    }
  }

  delete(id, name) {
  }

  get imageFormArray() {
    return this.CentralizeUpload.get('fileUpload') as FormArray;
  }

  get dleteimagesArray() {
    return this.DeleteImagesForm.get('deleteseletedimage') as FormArray;
  }

  SearchGalleryImages() {
  }

  fillGroupform(index: number) {
    var updatedarray: FormArray = this.imageFormArray.controls[index] as FormArray;
    console.log("Logi in");
    // console.log(updatedarray.controls['image_type'].value);
    this.imageFormArray.controls.forEach((properties: FormArray) => {
      properties.controls['master'].patchValue(updatedarray.controls['master'].value);
      properties.controls['productId'].patchValue(updatedarray.controls['productId'].value);
      properties.controls['image_type'].patchValue(updatedarray.controls['image_type'].value);
      properties.controls['modelimageposition'].patchValue(updatedarray.controls['modelimageposition'].value);
      properties.controls['goldcolor'].patchValue(updatedarray.controls['goldcolor'].value);
      properties.controls['colortableid'].patchValue(updatedarray.controls['colortableid'].value);
      properties.controls['gold_color_id'].patchValue(updatedarray.controls['gold_color_id'].value);
      properties.controls['styddedtypeopen'].patchValue(updatedarray.controls['styddedtypeopen'].value);
      properties.controls['stydettypevalue'].patchValue(updatedarray.controls['stydettypevalue'].value);
      properties.controls['images_view_type'].patchValue(updatedarray.controls['images_view_type'].value);
      properties.controls['image_position'].patchValue(updatedarray.controls['image_position'].value);
      properties.controls['vendor'].patchValue(updatedarray.controls['vendor'].value);
      properties.controls['customer'].patchValue(updatedarray.controls['customer'].value);
      // properties.controls['ismain_imagevalue'].patchValue(updatedarray.controls['ismain_imagevalue'].value);
      properties.controls['coll_image_type'].patchValue(updatedarray.controls['coll_image_type'].value);
      properties.controls['oppenismain_images'].patchValue(updatedarray.controls['master'].value == "Predefined bracelet Structure" ? true : false);

    })
  }

  checkedBox(event, data) {

    if (event.target.checked) {
      this.count = this.count + 1;

      this.finalArr.push(
        {
          img_id: data.id,
        }
      )

      this.dleteimagesArray.push(this.formBuilder.group({ imgid: data.id }))

      var images_form = this.formBuilder.group({
        id: [0, Validators.required],
        image: [data.file_path, Validators.required],
        originalfileName: [data.file_originalname],
        img_id: [data.id, Validators.required],
        master: [this.MasterControl.value, Validators.required],
        productId: [0, Validators.required],
        image_type: ['', Validators.required],
        modelimageposition: ['', Validators.required],
        visible: [this.imageFormArray.length == 0 ? true : false],

        goldcolor: [false],
        colortableid: [0],
        gold_color_id: [0],

        oppenismain_images: [false],
        ismain_imagevalue: [false],

        styddedtypeopen: [false],
        stydettypevalue: [''],

        images_view_type: [false],
        image_position: [false],

        goldgemstone_images_visible: [false],
        gold_gemstone_images: [''],

        vendor: [false],
        customer: [false],
        coll_image_type: ['image', Validators.required]
      })
      this.imageFormArray.push(images_form);
      this.fillGroupform(0)
    } else {
      this.imageFormArray.controls.forEach((element: FormArray, index) => {
        if (element.value.img_id === data.id) {
          this.imageFormArray.removeAt(index);
        }
      })

      this.dleteimagesArray.controls.forEach((element, index) => {
        if (element.value.imgid * 1 === data.id * 1) {
          this.dleteimagesArray.removeAt(index);
        }
      });

    }

    if (this.finalArr.length > 0) {
      this.opened = true;
    } else {
      this.opened = false;
    }

    this.imageFormArray.controls.forEach((element: FormArray, index) => {
      index == 0 ? element.controls['visible'].setValue(true) : element.controls['visible'].setValue(false);
    });
    this.fileuploadLenght = (this.imageFormArray.length - 1);
  }

  deleteGalleryimages() {
    this.centralizefileUpload.DeletedSeletedImages(this.DeleteImagesForm.value).subscribe(data => {

      this.centralizefileUpload.getAll().subscribe(
        res => {
          this.images = res;
        }
      )
      this.DeleteImagesForm.reset();
      this.alertService.success("selected images deleted successfully", true);
    })
  }

  mainimageChange(i: number, event) {
    var data = ((this.CentralizeUpload.get('fileUpload') as FormArray).controls[i] as FormArray).controls['ismain_imagevalue'] as FormArray;
    if (event.target.checked) {
      (this.CentralizeUpload.get('fileUpload') as FormArray).controls.forEach((element: FormArray) => {
        element.controls['ismain_imagevalue'].patchValue(false);
      })
      var tick: any = true;
      data.patchValue(tick);
    } else {
      var tick: any = false;
      data.patchValue(tick);
    }
  }

  ResetSearchImages() {
    this.MasterControl.setValue('');
    this.colorCtrl.setValue(0);
    this.listproductImages = [];
    this.CentralizeUpload.reset();
  }

  editChangemaster() {
    console.log("Get Call from Master change");
    this.CentralizeUpload.reset();
    switch (this.MasterControl.value) {
      case 'Gold Colour':
        this.colors = this.details_ofGoldColor;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Central stone shape':
        this.colors = this.details_ofCentralStoneShape;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Global Colour Preferance':
        this.colors = this.details_ofGolbalColorPre;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Collection':
        this.colors = this.details_ofCollection;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Bracelet type':
        this.colors = this.details_ofBraceletType;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Chain Design and weight':
        this.colors = this.details_ofChainDesignWeight;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Chain ring':
        this.colors = this.details_ofChainring;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Lock':
        this.colors = this.details_ofLock;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Studded type':
        this.colors = this.details_ofStuddettype;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Predefined bracelet Structure':
        this.colors = this.details_ofPRedesinedbracelet;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Charm':
        this.colors = this.details_ofCharm;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Addon':
        this.colors = this.details_ofAddon;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Link Chain':
        this.colors = this.details_oflinkchain;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
      case 'Ball Pearl':
        this.colors = this.details_ofballpearl;
        this.filteredColors = this.colorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(name => name ? this.filterColors(name) : this.colors.slice())
          );
        break;
    }

    this.colorCtrl.setValue(0);
    this.listproductImages = [];
    this.masterproductName = "NA";
  }

  deletemasterimages() {
    this.isLoading = true;
    this.centralizefileUpload.deletemasterimages(this.CentralizeUpload.value).subscribe(data => {
      this.isLoading = false;

      this.centralizefileUpload.getProductImagesByID(this.colorCtrl.value, this.MasterControl.value).subscribe((data: any) => {
        this.listproductImages = data.productimages;
        if (data.productimages[0])
          this.masterproductName = data.productimages[0].productname;
      });
      this.alertService.success("image deleted successfully", true);
      this.CentralizeUpload.reset();
      this.opened = false;

      while (this.deletedimagesArray.controls.length !== 0) {
        this.deletedimagesArray.removeAt(0);
      }
      while (this.imageFormArray.controls.length !== 0) {
        this.imageFormArray.removeAt(0);
      }
    }, error => this.isLoading = false)
  }

  EditSelectProduct() {
    if (this.colorCtrl.value !== 0 && this.colorCtrl.value * 1) {

      while (this.imageFormArray.controls.length !== 0) {
        this.imageFormArray.removeAt(0);
      }

      this.isLoading = true;
      this.centralizefileUpload.getProductImagesByID(this.colorCtrl.value, this.MasterControl.value).subscribe((data: any) => {

        // this.listproductImages = [].concat(data.productimages, this.images);
        this.listproductImages = data.productimages;
        if (data.productimages[0])
          this.masterproductName = data.productimages[0].productname;
        this.isLoading = false;
        //Set in in FormGroup
        // (data.productimages).forEach(element => {

        //   var images_form = this.formBuilder.group({
        //     id: [element.id ? element.id : 0, Validators.required],
        //     image: [element.file_path ? element.file_path : '', Validators.required],
        //     originalfileName: [element.file_originalname ? element.file_originalname : ''],
        //     img_id: [element.id ? element.id : 0, Validators.required],
        //     master: [this.MasterControl.value, Validators.required],
        //     productId: [element.productid ? element.productid : element.id, Validators.required],
        //     image_type: [element.imagetype ? element.imagetype : '', Validators.required],
        //     modelimageposition: [element.imageposition ? element.imageposition : '', Validators.required],
        //     visible: [this.imageFormArray.length == 0 ? true : false],

        //     goldcolor: [this.goldcolorvariationavailfor.includes(this.MasterControl.value)],
        //     gold_color_id: [element.colorvariationid ? element.colorvariationid : 0],
        //     colortableid: [element.colortableid ? element.colortableid : 0],

        //     oppenismain_images: [this.MasterControl.value == 'Predefined bracelet Structure'],
        //     ismain_imagevalue: [element.predefine_mainimg ? element.predefine_mainimg : false],

        //     styddedtypeopen: [false],
        //     stydettypevalue: [''],

        //     images_view_type: [this.goldcolorvariationavailfor.includes(this.MasterControl.value)],
        //     image_position: [this.MasterControl.value == 'Charm' || this.MasterControl.value == 'Addon'],

        //     goldgemstone_images_visible: [false],
        //     gold_gemstone_images: [''],
        //     vendor: [element.vendor == 'Y' ? true : false],
        //     customer: [element.customer == 'Y' ? true : false],
        //     coll_image_type: ['image', Validators.required]
        //   })
        //   // this.imageFormArray.push(images_form);
        // });

        this.fileuploadLenght = (this.imageFormArray.length - 1);
        // console.log(this.CentralizeUpload.value);
        //End Here
        // this.opened = true;
      }, error => this.isLoading = false)
    }
  }

  ClosePropertyPanel() {
    this.opened = false;
  }

  EditimageCheckbox(event, data) {

    if (event.target.checked) {
      var group = this.formBuilder.group({
        id: [data.id],
        master: [this.MasterControl.value],
        encodedpath: [data.file_path]
      })
      this.deletedimagesArray.push(group);

      var images_form = this.formBuilder.group({
        id: [data.id, Validators.required],
        image: [data.file_path, Validators.required],
        originalfileName: [data.fileoriginalname],
        img_id: [data.id, Validators.required],
        master: [this.MasterControl.value, Validators.required],
        productId: [this.colorCtrl.value, Validators.required],
        image_type: [data.imagetype, Validators.required],
        modelimageposition: [data.imageposition, Validators.required],
        visible: [this.imageFormArray.length == 1 ? true : false],

        goldcolor: [false],
        colortableid: [data.colortableid],
        gold_color_id: [data.colorvariationid],

        oppenismain_images: [false],
        ismain_imagevalue: [data.predefine_mainimg == 'true' ? true : false],

        styddedtypeopen: [false],
        stydettypevalue: [''],

        images_view_type: [false],
        image_position: [false],

        goldgemstone_images_visible: [false],
        gold_gemstone_images: [''],

        vendor: [data.vendor == 'Y' ? true : false],
        customer: [data.customer == 'Y' ? true : false],
        coll_image_type: ['image', Validators.required]
      })
      this.imageFormArray.push(images_form);
      this.changeMaster(this.imageFormArray.controls.length - 1)
    } else {
      this.imageFormArray.controls.forEach((element: FormArray, index) => {
        if (element.value.img_id * 1 == data.id * 1) {
          this.imageFormArray.removeAt(index);
        }
      })
      
      this.deletedimagesArray.controls.forEach((element, index) => {
        console.log(element);
        if (element.value.id * 1 == data.id * 1) {
          console.log('inside element');
          this.deletedimagesArray.removeAt(index);
        }
      });

      console.log(this.CentralizeUpload.value);
    }



    this.imageFormArray.controls.forEach((element: FormArray, index) => {
      index == 0 ? element.controls['visible'].setValue(true) : element.controls['visible'].setValue(false);
    });

    this.fileuploadLenght = (this.imageFormArray.length - 1);
    this.imageFormArray.controls.length == 0 ? this.opened = false : this.opened = true;
  }

  get deletedimagesArray() {
    return this.CentralizeUpload.get('deletedimages') as FormArray;
  }

  onSubmit() {
    this.dis_savebtn = true;

    this.imageFormArray.controls.forEach((element: FormArray) => {
      var master = element.value.master;

      while (this.deletedimagesArray.controls.length !== 0) {
        this.deletedimagesArray.removeAt(0);
      }

      switch (master) {
        case 'Gold Colour':
          element.controls['image_type'].setValue('invalid')
          element.controls['modelimageposition'].setValue('invalid')
          element.controls['gold_gemstone_images'].setValue('invalid')
          //For Collection
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('invalid')
          break;
        case 'Central stone shape':
          element.controls['image_type'].setValue('invalid')
          element.controls['modelimageposition'].setValue('invalid')
          element.controls['gold_gemstone_images'].setValue('invalid')
          //For Collection
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('invalid')
          break;
        case 'Global Colour Preferance':
          element.controls['image_type'].setValue('invalid')
          element.controls['modelimageposition'].setValue('invalid')
          element.controls['gold_gemstone_images'].setValue('invalid')
          //For Collection
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('invalid')
          break;
        case 'Collection':
          element.controls['image_type'].setValue('invalid')
          element.controls['modelimageposition'].setValue('invalid')
          element.controls['gold_gemstone_images'].setValue('invalid')
          break;
        case 'Bracelet type':
          element.controls['image_type'].setValue('invalid')
          element.controls['modelimageposition'].setValue('invalid')
          element.controls['gold_gemstone_images'].setValue('invalid')
          //For Collection
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('invalid')
          break;
        case 'Chain Design and weight':

          element.controls['modelimageposition'].setValue('invalid')
          element.controls['gold_gemstone_images'].setValue('invalid')
          //For Collection
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('invalid')
          break;
        case 'Chain ring':
          element.controls['modelimageposition'].setValue('invalid')
          element.controls['gold_gemstone_images'].setValue('invalid')
          //For Collection
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('invalid')
          break;
        case 'Lock':
          element.controls['modelimageposition'].setValue('invalid')
          element.controls['gold_gemstone_images'].setValue('invalid')
          //For Collection
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('invalid')
          break;
        case 'Studded type':
          element.controls['image_type'].setValue('invalid')
          element.controls['modelimageposition'].setValue('invalid')
          element.controls['gold_gemstone_images'].setValue('invalid')
          //For Collection
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('invalid')
          break;
        case 'Predefined bracelet Structure':
          element.controls['image_type'].setValue('invalid')
          element.controls['modelimageposition'].setValue('invalid')
          element.controls['gold_gemstone_images'].setValue('invalid')
          //For Collection
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('invalid')
          break;
        case 'Charm':
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          break;
        case 'Addon':
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('image')
          break;
        case 'Link Chain':
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('image')
          element.controls['modelimageposition'].setValue('Not Applicable')
          break;
        case 'Ball Pearl':
          element.controls['modelimageposition'].setValue('Not Applicable')
          element.controls['vendor'].setValue('invalid')
          element.controls['customer'].setValue('invalid')
          element.controls['coll_image_type'].setValue('image')
          break;
      }
    });


    this.imageFormArray.controls.forEach((element: FormArray, index) => {
      element.value.image_type !== 'model' ? element.controls['modelimageposition'].setValue('Not Applicable') : '';
    });

    console.log(this.findInvalidControls());
    if (!this.CentralizeUpload.valid) {
      this.alertService.error('Please Check All images Properties.')
      this.dis_savebtn = false;
      return
    }

    this.centralizefileUpload.link_images(this.CentralizeUpload.value).subscribe((res) => {
      this.dis_savebtn = false;
      this.finalArr = [];
      this.CentralizeUpload.reset();
      this.opened = false;

      while (this.imageFormArray.controls.length !== 0) {
        this.imageFormArray.removeAt(0);
      }

      if (this.tabSelected == "Gallery") {
        this.centralizefileUpload.getAll().subscribe(
          res => {
            this.images = res;
            this.filtered_images = res;
          }
        )
        this.alertService.success("Change updated", true);
      }
      if (this.tabSelected == "Search Images") {
        this.centralizefileUpload.getProductImagesByID(this.colorCtrl.value, this.MasterControl.value).subscribe((data: any) => {
          this.listproductImages = data.productimages;
          if (data.productimages[0])
            this.masterproductName = data.productimages[0].productname;
          this.alertService.success("Change updated", true);
        });
      }
    })
  }

  public findInvalidControls() {
    const invalid = [];
    const controls = this.CentralizeUpload.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        invalid.push(name);
      }
    }
    return invalid;
  }

  checkValue(event: any) {
  }

  filterGoldColor1(name: string) {
    if (!this.isNumber(name))
      return this.goldcolors1.filter(m => m.color.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }

  getGoldColorName1(goldcolorid: number) {
    if (this.goldcolors1 != null && goldcolorid != null && goldcolorid != 0)
      return this.goldcolors1.filter(m => m.id * 1 === goldcolorid * 1)[0].color;
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.masters.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
  }
  filterColors(name: string) {
    if (!this.isNumber(name))
      return this.colors.filter(s => s.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getColorName(colorId: number) {
    if (this.colors != null && colorId != null && colorId != 0) {
      return this.colors.filter(s => s.id === colorId)[0].name;
    }
  }
  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }

}
