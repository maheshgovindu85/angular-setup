﻿import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';

import { User } from '@/_models/user';
import { Metal } from '@/_models/metal';
import { MetalGetAll } from '@/_store/metal/metal.actions';
import { MetalPurity } from '@/_models/metalpurity';
import { MetalPurityGetAll } from '@/_store/metalpurity/metalpurity.actions';
import { MetalRate } from '@/_models/metalrate';
import { MetalRateGetAll } from '@/_store/metalrate/metalrate.actions';
import { Gemstone } from '@/_models/gemstone';
import { GemstoneGetAll } from '@/_store/gemstone/gemstone.actions';
import { GemstoneShape } from '@/_models/gemstoneshape';
import { GemstoneShapeGetAll } from '@/_store/gemstoneshape/gemstoneshape.actions';
import { GemstoneRate } from '@/_models/gemstonerate';
import { GemstoneRateGetAll } from '@/_store/gemstonerate/gemstonerate.actions';

import { DiamondCarat } from '@/_models/diamond_carat';
import { DiamondCaratGetAll } from '@/_store/diamond_carat/diamond_carat.actions';

import { DiamondColorPurity } from '@/_models/diamondcolorpurity';
import { DiamondColorPurityGetAll } from '@/_store/diamondcolorpurity/diamondcolorpurity.actions';

import { DiamondColor } from '@/_models/diamondcolor';
import { DiamondColorGetAll } from '@/_store/diamondcolor/diamondcolor.actions';

import { DiamondPurity } from '@/_models/diamondpurity';
import { DiamondPurityGetAll } from '@/_store/diamondpurity/diamondpurity.actions';

import { DiamondShape } from '@/_models/diamondshape';
import { DiamondShapeGetAll } from '@/_store/diamondshape/diamondshape.actions';

import { DiamondRate } from '@/_models/diamondrate';
import { DiamondRateGetAll } from '@/_store/diamondrate/diamondrate.actions';

import { CollectionType } from '@/_models/collectiontype';
import { CollectionTypeGetAll } from '@/_store/collectiontype/collectiontype.actions';

import { GemstoneType } from '@/_models/gemstonetype';
import { GemstoneTypeGetAll } from '@/_store/gemstonetype/gemstonetype.actions';

import { GlobalColorPreference } from '@/_models/global-color-preference';
import { GlobalColorPreferenceGetAll } from '@/_store/global-color-preference/global-color-preference.actions';

import { UserService, EncryptDecryptService, AuthenticationService, MetalService, MetalPurityService, MetalRateService, GemstoneService, GemstoneShapeService, GemstoneRateService, DiamondCaratService, DiamondColorPurityService, DiamondColorService, DiamondPurityService, DiamondShapeService, DiamondRateService, CollectiontypeService } from '@/_services';
import { GemstonetypeService } from '@/_services/gemstonetype.service';
import { GlobalColorPreferenceService } from '@/_services/global-color-preference.service';

import { ProductTypeService } from '@/_services/product-type.service';
import { producttypeGetAll } from '@/_store/producttype/product.actions';
import { Producttype } from '@/_models/producttype';

import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { Metalgoldcolor } from '@/_models/metalgoldcolor';
import { MetalGoldColorGetAll } from '@/_store/metalgoldcolor/metalgoldcolor.actions';
import { CollectionService } from '@/_services/collection.service';
import { Collection } from '@/_models/collection';
import { CollectionGetAll } from '@/_store/collection/collection.actions';
import { CollectionimageService } from '@/_services/collectionimage.service';
import { CollectionImages } from '@/_models/collectionimages';
import { CollectionImageGetAll } from '@/_store/collectionimage/collectionimage.actions';

import { DiamondrangeService } from '@/_services/diamondrange.service';
import { Diamondrange } from '@/_models/diamondrange';
import { DiamondrangeGetAll } from '@/_store/diamondrange/diamondrange.actions';

import { SolitaireRefrateService } from '@/_services/solitaire-refrate.service';
import { SolitaireRefrate } from '@/_models/solitaire-refrate';
import { SolitaireRefrateGetAll } from '@/_store/solitaire_refrate/solitraireRefRate.actions';

import { PlanmasterService } from '@/_services/planmaster.service';
import { Planmaster } from '@/_models/planmaster';
import { PlanmasterGetAll } from '@/_store/planmaster/planmaster.actions';

import { VendorService } from '@/_services/vendor.service';
import { Vendor } from '@/_models/vendor';

import { VendorGetAll } from '@/_store/vendor/vendor.actions';

import { ChaintypeService } from '@/_services/chaintype.service';
import { Chaintype } from '@/_models/chaintype';
import { chaintypeGetAll } from '@/_store/chaintype/chaintype.actions';

import { LockMasterService } from '@/_services/lock-master.service';
import { LockMaster } from '@/_models/lock-master';
import { LockMasterGetAll } from '@/_store/lock_master/lockmaster.actions';

import { ChainwidthService } from '@/_services/chainwidth.service';
import { Chainwidth } from '@/_models/chainwidth';
import { ChainwidthGetAll } from '@/_store/chainwidth/chainwidth.actions';

import { ChainDesignWeightService } from '@/_services/chain-design-weight.service';
import { ChainDesignWeight } from '@/_models/chain-design-weight';
import { ChainDesignWeightGetAll } from '@/_store/chaindesign_weight/chaindesign_weight.actions';

import { States } from '@/_models/states';
import { Cities } from '@/_models/cities';

import { StateCitySerivesService } from '@/_services/state-city-serives.service';

import { StatesGetAll } from '@/_store/states_store/state.actions';
import { CitiesGetAll } from '@/_store/city_store/city.actions';

import { BraceletLengthService } from '@/_services/bracelet-length.service';
import { BraceletLength } from '@/_models/braceletlength';
import { BraceletLengthGetAll } from '@/_store/braceletlength/braceletlength.actions';

import { BraceletTypeService } from '@/_services/bracelet-type.service';
import { BraceletType } from '@/_models/bracelettype';
import { BraceletTypeGetAll } from '@/_store/bracelettype/bracelettype.actions';

import { BraceletTypeRangeService } from '@/_services/bracelet-type-range.service';
import { BraceletTypeRange } from '@/_models/bracelettyperange';
import { BraceletTypeRangeGetAll } from '@/_store/bracelettyperange/bracelettyperange.actions';

import { CharmService } from '@/_services/charm.service';
import { Charm } from '@/_models/charm';
import { CharmGetAll } from '@/_store/charm/charm.actions';

import { AddonService } from '@/_services/addon.service';
import { Addon } from '@/_models/addon';
import { AddonGetAll } from '@/_store/addon/addon.actions';

import { ChainRingService } from '@/_services/chain-ring.service';
import { ChainRing } from '@/_models/chainring';
import { ChainRingGetAll } from '@/_store/chainring/chainring.actions';

import { StuddedtypeService } from '@/_services/studdedtype.service';
import { Studdedtype } from '@/_models/studdedtype';
import { StuddedtypeGetAll } from '@/_store/studdedtype/studdedtype.actions';

import { BallpearweightService } from '@/_services/ballpearweight.service';
import { Ballpearweighte } from '@/_models/ballpearweighte';
import { BallpearweighteGetAll } from '@/_store/ballpearweight/ballpearweight.actions';

import { LoosebraceletpatternService } from '@/_services/loosebraceletpattern.service';
import { Loosebraceletpattern } from '@/_models/loosebraceletpattern';
import { LoosebraceletpatternGetAll } from '@/_store/loosebraceletpattern/loosebraceletpattern.actions';

import { LinkchainwtService } from '@/_services/linkchainwt.service';
import { Linkchainwt } from '@/_models/linkchainwt';
import { LinkchainwtGetAll } from '@/_store/linkchainwt/linkchainwt.actions';

import { PredefinebraceletstructureService } from '@/_services/predefinebraceletstructure.service';
import { Predefinebraceletstructure } from '@/_models/predefinebraceletstructure';
import { PredefinebraceletstructureGetAll } from '@/_store/predefinebraceletstructure/predefinebraceletstructure.actions';

@Component({
  selector: 'home',
  templateUrl: 'home.component.html'
})
export class HomeComponent implements OnInit {
  currentUser: User;
  users = [];
  alive = true;

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private userService: UserService,
    private metalService: MetalService,
    private metalpurityService: MetalPurityService,
    private metalrateService: MetalRateService,
    private gemstoneService: GemstoneService,
    private gemstoneshapeService: GemstoneShapeService,
    private gemstonerateService: GemstoneRateService,
    private diamondCaratService: DiamondCaratService,
    private diamondColorPurityService: DiamondColorPurityService,
    private diamondColorService: DiamondColorService,
    private diamondPurityService: DiamondPurityService,
    private diamondShapeService: DiamondShapeService,
    private diamondRateService: DiamondRateService,
    private collectiontypeService: CollectiontypeService,
    private gemstonetypeService: GemstonetypeService,
    private productTypeService: ProductTypeService,
    private MetalgoldcolorService: MetalgoldcolorService,
    private globalcolorpreferenceService: GlobalColorPreferenceService,
    private diamondrangesrervices: DiamondrangeService,
    private solitaire_refRateservices: SolitaireRefrateService,
    private collectionService: CollectionService,
    private planmasterservices: PlanmasterService,
    private ChaintypeService: ChaintypeService,
    private LockMasterService: LockMasterService,
    public collectionImageService: CollectionimageService,
    private charmService: CharmService,
    private addonService: AddonService,
    private vedorServices: VendorService,
    private StateCitySerivesService: StateCitySerivesService,
    private chainwidthservice: ChainwidthService,
    private ChainDesignWeightService: ChainDesignWeightService,
    private braceletLengthService: BraceletLengthService,
    private braceletTypeService: BraceletTypeService,
    private braceletTypeRangeService: BraceletTypeRangeService,
    private chainRingService: ChainRingService,
    private StuddedtypeService: StuddedtypeService,
    private BallpearweightService: BallpearweightService,
    private LoosebraceletpatternService: LoosebraceletpatternService,
    private LinkchainwtService: LinkchainwtService,
    private PredefinebraceletstructureService: PredefinebraceletstructureService,
    private store: Store<{ metals: Metal[], }>
  ) {
    this.currentUser = this.authenticationService.currentUserValue;

    // const source = timer(1000, 1000); //every second
    // const source = timer(1000, 10000);
    // const subscribe = source.subscribe(val => this.refreshLocalStorage());
  }

  private updateSubscription: Subscription;

  ngOnInit() {
    console.log('in home -> ngOnInit');

    // this.updateSubscription = interval(1000).subscribe((val) => {
    //   this.updateStats()
    // });

    if (this.authenticationService.currentUserValue) {
      this.loadLocalStorage();
    }
    else {
      this.router.navigate(['login']);
    }
  }

  refreshLocalStorage() {
    console.log('in refreshLocalStorage');
  }

  testloadLocalStorage(data) {
    localStorage.setItem("test data refresh", data);
  }

  loadLocalStorage() {
    // console.log('load Metals');
    this.metalService
      .getAll()
      .subscribe((data: Metal[]) => {
        // console.log(data);
        // this.store.dispatch(new MetalGetAll(data));
        this.store.dispatch(new MetalGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });

    // console.log('load Metal Purity');
    this.metalpurityService
      .getAll()
      .subscribe((data: MetalPurity[]) => {
        // console.log(data);
        // this.store.dispatch(new MetalPurityGetAll(data));
        this.store.dispatch(new MetalPurityGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });

    // console.log('load Metal Rate');
    this.metalrateService
      .getAll()
      .subscribe((data: MetalRate[]) => {
        // console.log(data);
        // this.store.dispatch(new MetalRateGetAll(data));
        this.store.dispatch(new MetalRateGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });

    // console.log('load Gemstones');
    this.gemstoneService
      .getAll()
      .subscribe((data: Gemstone[]) => {
        // console.log(data);
        // this.store.dispatch(new GemstoneGetAll(data));
        this.store.dispatch(new GemstoneGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });

    // console.log('load Gemstone Shape');
    this.gemstoneshapeService
      .getAll()
      .subscribe((data: GemstoneShape[]) => {
        // console.log(data);
        // this.store.dispatch(new GemstoneShapeGetAll(data));
        this.store.dispatch(new GemstoneShapeGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });

    // console.log('load Gemstone Rate');
    this.gemstonerateService
      .getAll()
      .subscribe((data: GemstoneRate[]) => {
        // console.log(data);
        // this.store.dispatch(new GemstoneRateGetAll(data));
        this.store.dispatch(new GemstoneRateGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });


    // console.log('load DiamondCarat');
    this.diamondCaratService
      .getAll()
      .subscribe((data: DiamondCarat[]) => {
        // this.store.dispatch(new VendorGetAll(data));
        this.store.dispatch(new DiamondCaratGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });

    // console.log('load DiamondColorPurity');
    this.diamondColorPurityService
      .getAll()
      .subscribe((data: DiamondColorPurity[]) => {
        // this.store.dispatch(new VendorGetAll(data));
        this.store.dispatch(new DiamondColorPurityGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });

    this.diamondColorService
      .getAll()
      .subscribe((data: DiamondColor[]) => {
        this.store.dispatch(new DiamondColorGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });

    this.diamondPurityService
      .getAll()
      .subscribe((data: DiamondPurity[]) => {
        this.store.dispatch(new DiamondPurityGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });

    // console.log('load DiamondShape');
    this.diamondShapeService
      .getAll()
      .subscribe((data: DiamondShape[]) => {
        // this.store.dispatch(new VendorGetAll(data));
        this.store.dispatch(new DiamondShapeGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });

    // console.log('load DiamondRate');
    this.diamondRateService
      .getAll()
      .subscribe((data: DiamondRate[]) => {
        // this.store.dispatch(new VendorGetAll(data));
        this.store.dispatch(new DiamondRateGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
      });

    //  console.log('load type master');
    // this.collectiontypeService
    //   .getAll()
    //   .subscribe((data: CollectionType[]) => {
    //     this.store.dispatch(new CollectionTypeGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    //console.log('load gemstone type');
    // this.gemstonetypeService
    //   .getAll()
    //   .subscribe((data: GemstoneType[]) => {
    //     this.store.dispatch(new GemstoneTypeGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load Product type');
    // this.productTypeService
    //   .getAll()
    //   .subscribe((data: Producttype[]) => {
    //     // this.store.dispatch(new VendorGetAll(data));
    //     this.store.dispatch(new producttypeGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load Metal gold Color');
    // this.MetalgoldcolorService
    //   .getAll()
    //   .subscribe((data: Metalgoldcolor[]) => {
    //     // this.store.dispatch(new VendorGetAll(data));
    //     this.store.dispatch(new MetalGoldColorGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    //console.log('load global color preference');
    // this.globalcolorpreferenceService
    //   .getAll()
    //   .subscribe((data: GlobalColorPreference[]) => {
    //     this.store.dispatch(new GlobalColorPreferenceGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load Diamond Range');
    // this.diamondrangesrervices
    //   .getAll()
    //   .subscribe((data: Diamondrange[]) => {
    //     this.store.dispatch(new DiamondrangeGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load Solitaire Ref rate');
    // this.solitaire_refRateservices
    //   .getAll()
    //   .subscribe((data: SolitaireRefrate[]) => {
    //     // console.log(data);
    //     this.store.dispatch(new SolitaireRefrateGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load Plan Master');	
    // this.planmasterservices
    //   .getAll()
    //   .subscribe((data: Planmaster[]) => {
    //     // console.log(data);	
    //     this.store.dispatch(new PlanmasterGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });


    //console.log('load collection');
    // this.collectionService
    //   .getAll()
    //   .subscribe((data: Collection[]) => {
    //     this.store.dispatch(new CollectionGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load Vendor Master');	
    // this.vedorServices
    //   .getAll()
    //   .subscribe((data: Vendor[]) => {
    //     // console.log(data);	
    //     this.store.dispatch(new VendorGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load States services');	
    // this.StateCitySerivesService
    //   .getAllstates()
    //   .subscribe((data: States[]) => {
    //     console.log(data);
    //     this.store.dispatch(new StatesGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load city services');	
    // this.StateCitySerivesService
    //   .getAllCities()
    //   .subscribe((data: Cities[]) => {
    //     console.log(data);
    //     this.store.dispatch(new CitiesGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load Chaintype details');	
    // this.ChaintypeService
    //   .getAll()
    //   .subscribe((data: Chaintype[]) => {
    //     console.log(data);
    //     this.store.dispatch(new chaintypeGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load lock master');	
    // this.LockMasterService
    //   .getAll()
    //   .subscribe((data: LockMaster[]) => {
    //     console.log(data);
    //     this.store.dispatch(new LockMasterGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load Chain Design and Weight master');	
    // this.ChainDesignWeightService
    //   .getAll()
    //   .subscribe((data: ChainDesignWeight[]) => {
    //     console.log(data);
    //     this.store.dispatch(new ChainDesignWeightGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load Chain Width details');	
    // this.chainwidthservice
    //   .getAll()
    //   .subscribe((data: Chainwidth[]) => {
    //     console.log(data);
    //     this.store.dispatch(new ChainwidthGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // console.log('load Chain Width details');	
    // this.StuddedtypeService
    //   .getAll()
    //   .subscribe((data: Studdedtype[]) => {
    //     this.store.dispatch(new StuddedtypeGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });


    //console.log('load collection images');
    // this.collectionImageService
    //   .getAll()
    //   .subscribe((data: CollectionImages[]) => {
    //     this.store.dispatch(new CollectionImageGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });


    //console.log('load bracelet length');
    // this.braceletLengthService
    //   .getAll()
    //   .subscribe((data: BraceletLength[]) => {
    //     this.store.dispatch(new BraceletLengthGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    //console.log('load bracelet type');
    // this.braceletTypeService
    //   .getAll()
    //   .subscribe((data: BraceletType[]) => {
    //     this.store.dispatch(new BraceletTypeGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    //console.log('load bracelet type');
    // this.braceletTypeRangeService
    //   .getAll()
    //   .subscribe((data: BraceletTypeRange[]) => {
    //     this.store.dispatch(new BraceletTypeRangeGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    //console.log('load chain ring');
    // this.chainRingService
    //   .getAll()
    //   .subscribe((data: ChainRing[]) => {
    //     this.store.dispatch(new ChainRingGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    //console.log('load Ball Pear Weight');
    // this.BallpearweightService
    //   .getAll()
    //   .subscribe((data: Ballpearweighte[]) => {
    //     this.store.dispatch(new BallpearweighteGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    //console.log('Loose bracelet Pattern');
    // this.LoosebraceletpatternService
    //   .getAll()
    //   .subscribe((data: Loosebraceletpattern[]) => {
    //     this.store.dispatch(new LoosebraceletpatternGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    //console.log('Linkchainwt');
    // this.LinkchainwtService
    //   .getAll()
    //   .subscribe((data: Linkchainwt[]) => {
    //     this.store.dispatch(new LinkchainwtGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // this.charmService
    //   .getAll()
    //   .subscribe((data: Charm[]) => {
    //     this.store.dispatch(new CharmGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    // this.addonService
    //   .getAll()
    //   .subscribe((data: Addon[]) => {
    //     this.store.dispatch(new AddonGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

    //console.log('PredefinebraceletstructureService');
    // this.PredefinebraceletstructureService
    //   .getAll()
    //   .subscribe((data: Predefinebraceletstructure[]) => {
    //     this.store.dispatch(new PredefinebraceletstructureGetAll(this.encryptdecryptService.encrypt(JSON.stringify(data))));
    //   });

  }

  ngOnDestroy() {
    // this.updateSubscription.unsubscribe();
    this.alive = false; // switches your IntervalObservable off
  }

  updateStats() {
    // console.log('I am doing something every second');
  }
}
