import { Component, OnInit, ViewChild } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { Router } from "@angular/router";
import { Observable } from "rxjs";
import { select, Store } from "@ngrx/store";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { MatPaginator } from "@angular/material/paginator";

import { Collection } from "@/_models/collection";
import {
  CollectionGetAll,
  CollectionRemove,
} from "@/_store/collection/collection.actions";
import { CollectionService } from "@/_services/collection.service";
import * as collection_selector from "@/_store/collection/collection.selector";
import {
  AlertService,
  AuthenticationService,
  CollectiontypeService,
  EncryptDecryptService,
} from "@/_services";

@Component({
  selector: "app-collection-view",
  templateUrl: "./collection-view.component.html",
  styleUrls: ["./collection-view.component.css"],
})
export class CollectionViewComponent implements OnInit {
  collectionFilterForm: FormGroup;
  collections: Observable<Collection[]>;
  dataSource: MatTableDataSource<Collection>;
  closeResult: string;
  search_text = "";
  collectionList: any = [];
  searchForm: FormGroup;
  filterCollectionList: any = [];
  isChecked: boolean;

  displayedColumns: string[] = [
    "name",
    "descr",
    "makingprice",
    "isactive",
    "actions",
  ]; //'collection_typename'
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private collectionService: CollectionService,
    private store: Store<{ collections: Collection[] }>
  ) {
    this.collectionFilterForm = formBuilder.group({
      search_text: "",
    });

    this.collectionFilterForm.valueChanges.subscribe((value) => {
      // console.log(value);
      const filter = {
        ...value,
        search_text: value.search_text.trim().toLowerCase(),
      } as string;
      // console.log(filter);
      this.dataSource.filter = filter;
    });
  }

  ngOnInit(): void {
    this.createSearchForm();
  }

  ngAfterViewInit() {
    // this.store.pipe(select(collection_selector.getAllCollection()))
    this.collectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.dataSource = new MatTableDataSource(data);

          this.collectionList = data;
          for (let i = 0; i < this.collectionList.length; i++) {
            this.collectionList[i].isactive =
              this.collectionList[i].isactive === "N" ? false : true;
          }
          this.filterCollectionList = this.collectionList;
          this.filterCollectionList.sort((a,b) => {
            return new Date(b.savedate).getTime() - new Date(a.savedate).getTime();
          });
          this.filterCollectionList.sort((a,b) => {
            return  new Date(b.modifydate).getTime() - new Date(a.modifydate).getTime();
          });

          


          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;

          this.dataSource.filterPredicate = ((data, filter) => {
            const a =
              !filter.search_text ||
              data.name
                .toString()
                .trim()
                .toLowerCase()
                .includes(filter.search_text) ||
              // data.collection_typename.toString().trim().toLowerCase().includes(filter.search_text) ||
              data.descr
                .toString()
                .trim()
                .toLowerCase()
                .includes(filter.search_text) ||
              data.makingprice
                .toString()
                .trim()
                .toLowerCase()
                .includes(filter.search_text);
            return a;
          }) as (PeriodicElement, string) => boolean;
        });
      }
    });
  }

  changeStatus(e, data: any) {
    this.isChecked = e.checked;
    this.collectionService
      .delete(data.id, this.isChecked ? "Y" : "N")
      .subscribe((data: Collection[]) => {
        this.alertService.success('Status Updated successfully!', true);
      });
  }

  // Search button function start
  createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [""],
    });
  }
  clear() {
    this.searchForm.get("keyword")?.setValue("");
    this.searchGrid();
  }
  searchGrid() {
    let keyword = this.searchForm.controls["keyword"].value;
    if (keyword === "") {
      this.filterCollectionList = this.collectionList;
    } else {
      keyword = keyword.toLowerCase();
      this.filterCollectionList = this.collectionList.filter((event) => {
        return (
          (event.name && event.name.toLowerCase().includes(keyword)) ||
          (event.descr && event.descr.toLowerCase().includes(keyword)) ||
          (event.makingprice &&
            event.makingprice.toLowerCase().includes(keyword))
        );
      });
    }
  }
}
