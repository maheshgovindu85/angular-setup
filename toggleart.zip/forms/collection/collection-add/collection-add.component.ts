import { CollectionType } from '@/_models/collectiontype';
import { AlertService, AuthenticationService, CollectiontypeService, DiamondRateService, EncryptDecryptService } from '@/_services';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import * as collectiontype_selector from '@/_store/collectiontype/collectiontype.selector';
import { CollectionService } from '@/_services/collection.service';
import { Collection } from '@/_models/collection';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldControl } from '@angular/material/form-field';
import { CollectionAdd } from '@/_store/collection/collection.actions';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-collection-add',
  templateUrl: './collection-add.component.html',
  styleUrls: ['./collection-add.component.css']
})
export class CollectionAddComponent implements OnInit {
  @ViewChild("dia_Info") div1: ElementRef;

  collectionAddForm: FormGroup;
  loading = false;
  submitted = false;
  CollectionTypes = [];

  shapeCtrl = new FormControl();
  shapes: any[];
  filteredShapes: Observable<any[]>;

  goldKtCtrl = new FormControl();
  goldktlst: any[];
  filteredGoldKt: Observable<any[]>;

  diamondCaratCtrl = new FormControl();
  diamondCaratList: any[];
  filtereddiamondCarat: Observable<any[]>;
  diamondList: any;
  default_kt_id: string = "";

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private collectionTypeService: CollectiontypeService,
    private diamondRateService: DiamondRateService,
    private collectionService: CollectionService,
    private store: Store<{ collectiontypes: CollectionType[], collections: Collection[] }>
  ) {


  }

  ngOnInit(): void {

    //Get data For Diamond Shape 
    this.diamondRateService.getAllDiamondShapes()
      .subscribe((data) => {
        this.shapes = data;
        this.filteredShapes = this.shapeCtrl.valueChanges
          .pipe(
            startWith(''),
            map(shape => shape ? this.filterShapes(shape) : this.shapes.slice())
          );
      });


    this.getCollectionTypes();
    this.collectionAddForm = this.formBuilder.group({
      id: 0,
      name: ['', Validators.required],
      collectiontype_id: ['',Validators.required],
      descr: ['', Validators.required],
      makingprice: ['', Validators.required],
      isdefault: [false],
      default_private: [false],
      manufacturing_avail: [false],
      collection_3dm: [false],
      cam_piece: [false],
      stl: [false],
      rendered_video: [false],
      video_applicable: [false],
      retail_buy_limit: [''],
      img_price: ['', customVideoPriceValidator],
      video_price: ['', customVideoPriceValidator],
      price_3dm: [''],
      price_stl: [''],
      price_cam: [''],
      avg_gold_wt: ['0', Validators.required],
      min_gold_wt: ['', Validators.required],
      max_gold_wt: ['', Validators.required],
      avg_dia_wt: [0, Validators.required],
      min_dia_wt: [0, Validators.required],
      max_dia_wt: [0, Validators.required],
      price_range_from: [0, Validators.required],
      price_range_to: [0, Validators.required],
      isactive: [true],
      isdelete: ['N'],
      gold_kt_id: [this.default_kt_id, Validators.required],
      //gold_kt_id: ['', Validators.required],
      gold_kt: [''],
      dia_details: this.formBuilder.array([this.Initial_diamond()]),
      freecollection: [false]
    });

    this.collectionService.getAllGoldKt()
      .subscribe((data) => {
        // console.log(data);
        this.goldktlst = data;

        this.filteredGoldKt = this.goldKtCtrl.valueChanges
          .pipe(
            startWith(''),
            map(m => m ? this.filterGoldKt(m) : this.goldktlst.slice())
          );

        let res = this.goldktlst.filter(m => m.carat + "" === '18')[0];
        if (res !== undefined && res !== null) { this.default_kt_id = res.id; }

        this.goldKtCtrl.setValue(this.default_kt_id);
        this.collectionAddForm.get("gold_kt_id").setValue(this.goldKtCtrl.value);

       // let gt_value = this.default_kt_id;

      });


    this.diamondRateService.getAllDiamondcarat()
      .subscribe((data) => {
        this.diamondCaratList = data;
        this.filtereddiamondCarat = this.diamondCaratCtrl.valueChanges
          .pipe(
            startWith(''),
            map(carat => carat ? this.filterDaimondcaratdata(carat) : this.diamondCaratList.slice())
          );
      });

    this.collectionAddForm.get('video_applicable').valueChanges
      .subscribe(value => {
        this.collectionAddForm.get('video_price').updateValueAndValidity();
        this.collectionAddForm.get('img_price').updateValueAndValidity();
      });


  }

  Initial_diamond() {
    return this.formBuilder.group({
      id: [0, Validators.required],
      cltn_id: [0, Validators.required],
      avg_dia: [0, Validators.required],
      min_dia: ['',Validators.required],
      max_dia: ['',Validators.required],
      dia_wt_id: ['0', Validators.required],
      dia_wt: [''],
      shape_id: [0, Validators.required],
      isdelete: ['N']
    });
  }

  get Diamond() {
    return this.collectionAddForm.get('dia_details') as FormArray;
  }

  diamondOn(index){
    this.diamondList = this.collectionAddForm.get('dia_details') as FormArray; 
    const formGroup = this.diamondList.controls[index] as FormGroup;
    return formGroup;
  }

  AppendMoreDiamond() {
    
    this.Diamond.push(this.Initial_diamond());
  }

  DeleteDiamond(index: number) { this.Diamond.removeAt(index); }

  get f() { return this.collectionAddForm.controls; }

  
  onSubmit() {
    this.submitted = true;
    

    //this.collectionAddForm.get("gold_kt_id").setValue(this.goldKtCtrl.value);
    // reset alerts on submit
    this.alertService.clear();

    if (this.collectionAddForm.invalid) {
      return;
    }


    if (this.goldKtCtrl.value !== undefined && this.goldKtCtrl.value !== null && this.goldKtCtrl.value !== "") {
      var gold_kt = this.goldktlst.filter(m => m.id === this.goldKtCtrl.value)[0].carat;
      this.collectionAddForm.get("gold_kt").setValue(gold_kt);
    }

    // let carat_id;
    // this.Diamond.controls.forEach(element => {
    //   carat_id = element.value.dia_wt_id;
    //   var gemstone_name = this.diamondCaratList.filter(m => m.id === carat_id)[0].carat_name;
    //   element.value.dia_wt = gemstone_name;
    // });


    this.loading = true;
    this.collectionService
      .save(this.collectionAddForm.value)
      .subscribe((data: Collection) => {
        this.alertService.success('Collection saved successfully!', true);
        this.router.navigate(['collection/list']);
      });
  }

  getCollectionTypes() {
    // this.store.pipe(select(collectiontype_selector.getAllCollectionType()))
    this.collectionTypeService.getAll()
      .subscribe((data: any) => {
        this.CollectionTypes = data.filter(f => f.isactive == 'Y');
      });
  }

  filterShapes(name: string) {
    if (!this.isNumber(name))
      return this.shapes.filter(s => s.shape.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }

  getShapeName(shapeId: string) {
    if (this.shapes != null && shapeId != null && shapeId != '') {
      return this.shapes.filter(s => s.id === shapeId)[0].shape;
    }
  }

  //For Diamond Carat Autocomplete
  filterDaimondcaratdata(name: string) {
    if (!this.isNumber(name))
      return this.diamondCaratList.filter(s => s.carat_name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }

  getDiamodCaratnName(caratId: string) {
    if (this.shapes != null && caratId != null && caratId != '') {
      return this.diamondCaratList.filter(s => s.id === caratId)[0].carat_name;
    }
  }

  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }

  filterGoldKt(name: string) {
    // if (!this.isNumber(name))
    return this.goldktlst.filter(m => m.carat.toLowerCase().indexOf(name + "".toLowerCase()) >= 0);
  }

  getGoldKtName(ktid: number) {
    if (this.goldktlst != null && ktid != null && ktid != 0)
      return this.goldktlst.filter(m => m.id * 1 === ktid * 1)[0].carat;
  }
}

function customVideoPriceValidator(formControl: AbstractControl) {
  if (!formControl.parent) {
    return null;
  }

  if (formControl.parent.get('video_applicable').value) {
    return Validators.required(formControl);
  }
  return null;
}
