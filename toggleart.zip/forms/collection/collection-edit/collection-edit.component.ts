import { CollectionType } from '@/_models/collectiontype';
import { AlertService, AuthenticationService, CollectiontypeService, DiamondRateService, EncryptDecryptService } from '@/_services';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import * as collection_selector from '@/_store/collection/collection.selector';
import * as collectiontype_selector from '@/_store/collectiontype/collectiontype.selector';
import { CollectionService } from '@/_services/collection.service';
import { Collection } from '@/_models/collection';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldControl } from '@angular/material/form-field';
import { CollectionAdd, CollectionUpdate } from '@/_store/collection/collection.actions';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-collection-edit',
  templateUrl: './collection-edit.component.html',
  styleUrls: ['./collection-edit.component.css']
})
export class CollectionEditComponent implements OnInit {

  @ViewChild("dia_Info") div1: ElementRef;

  collectionEditForm: FormGroup;
  loading = false;
  submitted = false;
  collections: Observable<Collection[]>;
  collection: any;
  CollectionTypes = [];

  setActivated = false;
  setIsDefault = false;
  setDefaultPrivate = false;
  setManufacturingAvail = false;
  set3DM = false;
  setCamPiece = false;
  setStl = false;
  setRenderedVideo = false;
  setVideoAvail = false;

  shapeCtrl = new FormControl();
  shapes: any[];
  filteredShapes: Observable<any[]>;

  goldKtCtrl = new FormControl();
  goldktlst: any[];
  filteredGoldKt: Observable<any[]>;

  diamondCaratCtrl = new FormControl();
  diamondCaratList: any[];
  filtereddiamondCarat: Observable<any[]>;
  diamondList: any;
  constructor(private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private collectionTypeService: CollectiontypeService,
    private collectionService: CollectionService,
    private diamondRateService: DiamondRateService,
    private store: Store<{ collectiontypes: CollectionType[], collections: Collection[] }>
  ) {
    if (this.authenticationService.currentUserValue) {
      const id = this.route.snapshot.params.id;
      // this.store.select(collection_selector.getCollectionById(id))
      collectionService.get(id)
        .subscribe((data) => {
          this.collection = data;

          //Get data For Diamond Shape 
          this.diamondRateService.getAllDiamondShapes()
            .subscribe((data) => {
              this.shapes = data;
              this.filteredShapes = this.shapeCtrl.valueChanges
                .pipe(
                  startWith(''),
                  map(shape => shape ? this.filterShapes(shape) : this.shapes.slice())
                );
            });

          if (this.collection.isactive === 'Y') { this.setActivated = true } else { this.setActivated = false }
          if (this.collection.isdefault === 'Y') { this.setIsDefault = true } else { this.setIsDefault = false }
          if (this.collection.default_private === 'Y') { this.setDefaultPrivate = true } else { this.setDefaultPrivate = false }
          if (this.collection.manufacturing_avail === 'Y') { this.setManufacturingAvail = true } else { this.setManufacturingAvail = false }
          if (this.collection.collection_3dm === 'Y') { this.set3DM = true } else { this.set3DM = false }
          if (this.collection.cam_piece === 'Y') { this.setCamPiece = true } else { this.setCamPiece = false }
          if (this.collection.stl === 'Y') { this.setStl = true } else { this.setStl = false }
          if (this.collection.rendered_video === 'Y') { this.setRenderedVideo = true } else { this.setRenderedVideo = false }
          if (this.collection.video_applicable === 'Y') { this.setVideoAvail = true } else { this.setVideoAvail = false }


          this.collectionService.getMultipleModelDetails(id)
            .subscribe((data) => {
              var JsonData = JSON.parse(JSON.stringify(data));
              var cltnDiamond_Details = JsonData.cltnDiamond_Details;
              this.collectionEditForm = this.formBuilder.group({
                id: [this.collection.id, Validators.required],
                name: [this.collection.name, Validators.required],
                collectiontype_id: [this.collection.collectiontype_id, Validators.required],
                descr: [this.collection.descr, Validators.required],
                makingprice: [this.collection.makingprice, Validators.required],
                isactive: [this.setActivated],
                isdefault: [this.setIsDefault],
                default_private: [this.setDefaultPrivate],
                manufacturing_avail: [this.setManufacturingAvail],
                collection_3dm: [this.set3DM],
                cam_piece: [this.setCamPiece],
                stl: [this.setStl],
                rendered_video: [this.setRenderedVideo],
                video_applicable: [this.setVideoAvail],
                retail_buy_limit: [this.collection.retail_buy_limit],
                img_price: [this.collection.img_price, customVideoPriceValidator],
                video_price: [this.collection.video_price, customVideoPriceValidator],
                price_3dm: [this.collection.price_3dm],
                price_stl: [this.collection.price_stl],
                price_cam: [this.collection.price_cam],
                avg_gold_wt: [this.collection.avg_gold_wt, Validators.required],
                min_gold_wt: [this.collection.min_gold_wt, Validators.required],
                max_gold_wt: [this.collection.max_gold_wt, Validators.required],
                avg_dia_wt: [this.collection.avg_dia_wt],
                min_dia_wt: [this.collection.min_dia_wt],
                max_dia_wt: [this.collection.max_dia_wt],
                price_range_from: [this.collection.price_range_from, Validators.required],
                price_range_to: [this.collection.price_range_to, Validators.required],
                isdelete: [this.collection.isdelete],
                gold_kt_id: [0, Validators.required],
                gold_kt: [this.collection.gold_kt],
                dia_details: this.formBuilder.array([]),
                diamond_delete: this.formBuilder.array([]),
                freecollection: [this.collection.freecollection == 'Y' ? true : false]
              });
              this.collectionEditForm.setControl('dia_details', this.set_bpGoldform(cltnDiamond_Details));

              this.collectionEditForm.setControl('diamond_delete', this.set_Diamondform_delete());
            });
          this.collectionService.getAllGoldKt()
            .subscribe((data) => {
              this.goldktlst = data;

              this.filteredGoldKt = this.goldKtCtrl.valueChanges
                .pipe(
                  startWith(''),
                  map(m => m ? this.filterGoldKt(m) : this.goldktlst.slice())
                );
              let currGoldKtId = this.collection.gold_kt_id;
              if (currGoldKtId !== undefined && currGoldKtId !== null && currGoldKtId !== 0) {
                this.goldKtCtrl.setValue(currGoldKtId);
              }
              else {
                let res = this.goldktlst.filter(m => m.carat + "" === '18')[0];
                if (res !== undefined && res !== null) {
                  this.goldKtCtrl.setValue(res.id);
                }
              }

            });



          this.collectionEditForm.get('video_applicable').valueChanges
            .subscribe(value => {
              this.collectionEditForm.get('video_price').updateValueAndValidity();
              this.collectionEditForm.get('img_price').updateValueAndValidity();
            });


        });

      this.diamondRateService.getAllDiamondcarat()
        .subscribe((data) => {
          this.diamondCaratList = data;
          this.filtereddiamondCarat = this.diamondCaratCtrl.valueChanges
            .pipe(
              startWith(''),
              map(carat => carat ? this.filterDaimondcaratdata(carat) : this.diamondCaratList.slice())
            );
        });

      this.createForm(id);
    }
    else {
      this.router.navigate(['login']);
    }
  }

  createForm(id) {




  }

  ngOnInit(): void {
    this.collectionEditForm = this.formBuilder.group({
      id: 0,
      name: ['', Validators.required],
      collectiontype_id: ['', Validators.required],
      descr: ['', Validators.required],
      makingprice: ['', Validators.required],
      isdefault: [false],
      default_private: [false],
      manufacturing_avail: [false],
      collection_3dm: [false],
      cam_piece: [false],
      stl: [false],
      rendered_video: [false],
      video_applicable: [false],
      retail_buy_limit: [''],
      img_price: ['', customVideoPriceValidator],
      video_price: ['', customVideoPriceValidator],
      price_3dm: [''],
      price_stl: [''],
      price_cam: [''],
      avg_gold_wt: ['0', Validators.required],
      min_gold_wt: ['', Validators.required],
      max_gold_wt: ['', Validators.required],
      avg_dia_wt: [0, Validators.required],
      min_dia_wt: [0, Validators.required],
      max_dia_wt: [0, Validators.required],
      price_range_from: ['', Validators.required],
      price_range_to: [0, Validators.required],
      isactive: [true],
      isdelete: ['N'],
      gold_kt_id: ['', Validators.required],
      gold_kt: [''],
      dia_details: this.formBuilder.array([]),
      diamond_delete: this.formBuilder.array([]),
      freecollection: [false]
    });

    this.getCollectionTypes();
  }

  getCollectionTypes() {
    // this.store.pipe(select(collectiontype_selector.getAllCollectionType()))
    this.collectionTypeService.getAll()
      .subscribe((data: any) => {
        this.CollectionTypes = data.filter(f => f.isactive == 'Y');
      });
  }
  get f() { return this.collectionEditForm.controls; }


  Initial_diamond() {
    return this.formBuilder.group({
      id: [0, Validators.required],
      cltn_id: [0, Validators.required],
      avg_dia: [0, Validators.required],
      min_dia: ['', Validators.required],
      max_dia: ['', Validators.required],
      dia_wt_id: ['0', Validators.required],
      dia_wt: [''],
      shape_id: [0, Validators.required],
      isdelete: ['N']
    });
  }

  Initial_Diamond_Delete(dtlID) {
    return this.formBuilder.group({
      id: [dtlID],
    });
  }

  set_Diamondform_delete(): FormArray {
    const formArray = new FormArray([]);
    formArray.push(this.formBuilder.group({
      id: 0,
    }));
    return formArray;
  }
  diamondOn(index){
    this.diamondList = this.collectionEditForm.get('dia_details') as FormArray; 
    const formGroup = this.diamondList.controls[index] as FormGroup;
    return formGroup;
  }
  set_bpGoldform(Product_details): FormArray {
    const formArray = new FormArray([]);
    Product_details.forEach(s => {
      formArray.push(this.formBuilder.group({
        id: [s.id, Validators.required],
        cltn_id: [s.cltn_id, Validators.required],
        avg_dia: [s.avg_dia, Validators.required],
        min_dia: [s.min_dia, Validators.required],
        max_dia: [s.max_dia, Validators.required],
        dia_wt_id: [s.dia_wt_id, Validators.required],
        dia_wt: [0],
        shape_id: [s.shape_id, Validators.required],
        isdelete: ['N']
      }));
    });
    return formArray;
  }

  get Diamond() {
    return this.collectionEditForm.get('dia_details') as FormArray;
  }
  get Diamond_Delete() {
    return this.collectionEditForm.get('diamond_delete') as FormArray;
  }

  AppendMoreDiamond() {
    this.Diamond.push(this.Initial_diamond());
  }

  DeleteDiamond(index: number) {
    let dlt_diamond = this.Diamond.at(index).get("id").value;
    this.Diamond_Delete.push(this.Initial_Diamond_Delete(dlt_diamond));
    this.Diamond.removeAt(index);
  }


  onSubmit() {
    this.submitted = true;

    // this.collectionEditForm.get("gold_kt_id").setValue(this.goldKtCtrl.value);

    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.collectionEditForm.invalid) {
      return;
    }

    if (this.goldKtCtrl.value !== undefined && this.goldKtCtrl.value !== null && this.goldKtCtrl.value !== "") {
      var gold_kt = this.goldktlst.filter(m => m.id === this.goldKtCtrl.value)[0].carat;
      this.collectionEditForm.get("gold_kt").setValue(gold_kt);
    }

    // let carat_id;
    // this.Diamond.controls.forEach(element => {
    //   carat_id = element.value.dia_wt_id;
    //   var gemstone_name = this.diamondCaratList.filter(m => m.id === carat_id)[0].carat_name;
    //   element.value.dia_wt = gemstone_name;
    // });


    this.loading = true;
    this.collectionService
      .save(this.collectionEditForm.value)
      .subscribe((data: CollectionType) => {
        // console.log(data);
        // this.store.dispatch(new CollectionUpdate(data));
        this.alertService.success('Collection updated successfully!', true);
        this.router.navigate(['collection/list']);
      });
  }

  filterShapes(name: string) {
    if (!this.isNumber(name))
      return this.shapes.filter(s => s.shape.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }

  getShapeName(shapeId: string) {
    if (this.shapes != null && shapeId != null && shapeId != '') {
      return this.shapes.filter(s => s.id === shapeId)[0].shape;
    }
  }

  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }


  filterGoldKt(name: string) {
    // if (!this.isNumber(name))
    return this.goldktlst.filter(m => m.carat.toLowerCase().indexOf(name + "".toLowerCase()) >= 0);
  }

  getGoldKtName(ktid: number) {
    if (this.goldktlst != null && ktid != null && ktid != 0)
      return this.goldktlst.filter(m => m.id * 1 === ktid * 1)[0].carat;
  }

  //For Diamond Carat Autocomplete
  filterDaimondcaratdata(name: string) {
    if (!this.isNumber(name))
      return this.diamondCaratList.filter(s => s.carat_name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }

  getDiamodCaratnName(caratId: string) {
    if (this.shapes != null && caratId != null && caratId != '') {
      return this.diamondCaratList.filter(s => s.id === caratId)[0].carat_name;
    }
  }
}

function customVideoPriceValidator(formControl: AbstractControl) {
  if (!formControl.parent) {
    return null;
  }

  if (formControl.parent.get('video_applicable').value) {
    return Validators.required(formControl);
  }
  return null;
}
