import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantLongDesignDefinitionListComponent } from './Merchant-long-design-definition-list.component';

describe('MerchantLongDesignDefinitionListComponent', () => {
  let component: MerchantLongDesignDefinitionListComponent;
  let fixture: ComponentFixture<MerchantLongDesignDefinitionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantLongDesignDefinitionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantLongDesignDefinitionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
