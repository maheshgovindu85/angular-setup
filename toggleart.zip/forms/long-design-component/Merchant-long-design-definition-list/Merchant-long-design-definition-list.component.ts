import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs";

import { Producttype } from "@/_models/producttype";
import { LongDesignDefinitionService } from "@/_services/long-design-defifnition.service";


import { AlertService, AuthenticationService, MetalService, VendorAuthenticationService } from "@/_services";

@Component({
  selector: "app-merchant-long-design-definition-list",
  templateUrl: "./Merchant-long-design-definition-list.component.html",
  styleUrls: ["./Merchant-long-design-definition-list.component.css"],
})
export class MerchantLongDesignDefinitionListComponent implements OnInit {
  loading = false;
  submitted = false;
  currencies: Observable<Producttype[]>;
  public isactive: boolean = true;
  searchForm: FormGroup;
  isChecked:boolean;
  activeStatus: any;
  list: any=[];
  vendor_id:any;
  merchantDefinitionList: any =[];
  filterMerchantDefinitionList:any =[]

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private LongDesignDefinitionService: LongDesignDefinitionService,
    private vendorauthenticationService: VendorAuthenticationService,

  ) {
   // redirect if already logged in
   if (!this.vendorauthenticationService.vendorcurrentUserValue) {
    this.router.navigate(['merchant']);
    this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id;
  }

  // 
  }


  ngOnInit() {
    this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id;
    this.createSearchForm();
    this.getLongDesignDefiniData();
  }

 

  getLongDesignDefiniData(){
    const dataObj={
      "merchantid": this.vendor_id
    }
    this.LongDesignDefinitionService.getLongDesignDefinitionbyMerchantid(dataObj)
     .subscribe(data => {
       if (data) {
        this.list = data;
        this.merchantDefinitionList = this.list.data;
        for(let i =0; i <this.merchantDefinitionList.length;i++){
          this.merchantDefinitionList[i].isactive = this.merchantDefinitionList[i].isactive === 'N' ? false : true;
          this.merchantDefinitionList[i].srNo = i+1;
        }
         this.filterMerchantDefinitionList = this.merchantDefinitionList;
       }
     });
 }

// Search button function start
createSearchForm() {
 this.searchForm = this.formBuilder.group({
   keyword: [''],
 });
}
clear() {
 this.searchForm.get('keyword')?.setValue('');
 this.searchGrid();
}
searchGrid() {
 let keyword = this.searchForm.controls['keyword'].value;
 if (keyword === '') {
   this.filterMerchantDefinitionList = this.merchantDefinitionList;
 } else {
   keyword = keyword.toLowerCase();
   this.filterMerchantDefinitionList = this.merchantDefinitionList.filter((event) => {
     return (
       (event.designno && event.designno.toLowerCase().includes(keyword))||
       (event.designpart && event.designpart.toLowerCase().includes(keyword))||
       (event.partname && event.partname.toLowerCase().includes(keyword)) ||
       (event.collectionName && event.collectionName.toLowerCase().includes(keyword))||
       (event.productname && event.productname.toLowerCase().includes(keyword)) ||
       (event.product_sub_type && event.product_sub_type.toLowerCase().includes(keyword))    
     );
   });
 }
}

changeStatus(e,data: any){
 this.isChecked = e.checked;
 const dataObj = {
   id: data.id,
   isactive : this.isChecked ? 'Y' : 'N',
 };
 this.LongDesignDefinitionService.getLongDesignDefinitionUpdate(dataObj).subscribe((data: LongDesignDefinitionService) => {
   this.getLongDesignDefiniData();
   this.alertService.success('Status Updated successfully!', true);
 });

}
 
 

  
}
