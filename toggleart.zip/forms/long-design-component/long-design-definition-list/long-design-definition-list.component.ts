import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs";

import { Producttype } from "@/_models/producttype";
import { LongDesignDefinitionService } from "@/_services/long-design-defifnition.service";


import { AlertService, AuthenticationService, MetalService } from "@/_services";

@Component({
  selector: "app-long-design-definition-list",
  templateUrl: "./long-design-definition-list.component.html",
  styleUrls: ["./long-design-definition-list.component.css"],
})
export class LongDesignDefinitionListComponent implements OnInit {
  loading = false;
  submitted = false;
  currencies: Observable<Producttype[]>;
  public isactive: boolean = true;
  longDefinitionList: any = [];
  searchForm: FormGroup;
  longDesignDefList:any =[];
  isChecked:boolean;
  activeStatus: any;
  longDesignDefinitionFilter: any =[];
  list: any=[];

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private LongDesignDefinitionService: LongDesignDefinitionService,
    private store: Store<{ producttypes: Producttype[] }>
  ) {
    if (!this.authenticationService.currentUserValue) {
    }
  }

  ngOnInit() {
    this.createSearchForm();
    this.getLongDesignDefiniData();
  }

 

  getLongDesignDefiniData(){
    this.LongDesignDefinitionService.getAll()
     .subscribe(data => {
       if (data) {
         
         setTimeout(() => {
           this.list = data;
          this.longDesignDefList = this.list.data;
          for(let i =0; i <this.longDesignDefList.length;i++){
           this.longDesignDefList[i].isactive = this.longDesignDefList[i].isactive === 'N' ? false : true;
           this.longDesignDefList[i].srNo = i+1;
         }
          this.longDesignDefinitionFilter = this.longDesignDefList;
         });
       }
     });
 }

// Search button function start
createSearchForm() {
 this.searchForm = this.formBuilder.group({
   keyword: [''],
 });
}
clear() {
 this.searchForm.get('keyword')?.setValue('');
 this.searchGrid();
}
searchGrid() {
 let keyword = this.searchForm.controls['keyword'].value;
 if (keyword === '') {
   this.longDesignDefinitionFilter = this.longDesignDefList;
 } else {
   keyword = keyword.toLowerCase();
   this.longDesignDefinitionFilter = this.longDesignDefList.filter((event) => {
     return (
       (event.designno === Number(keyword) || event.designno && event.designno.toLowerCase().includes(keyword)) ||
       (event.designpart && event.designpart.toLowerCase().includes(keyword))||
       (event.partname && event.partname.toLowerCase().includes(keyword)) ||
       (event.collection && event.collection.toLowerCase().includes(keyword))||
       (event.productname && event.productname.toLowerCase().includes(keyword)) ||
       (event.merchantname && event.merchantname.toLowerCase().includes(keyword)) ||
       (event.product_sub_type === Number(keyword))
     
     );
   });
 }
}

changeStatus(e,data: any){
 this.isChecked = e.checked;
 const dataObj = {
   id: data.id,
   isactive : this.isChecked ? 'Y' : 'N',
 };
 this.LongDesignDefinitionService.getLongDesignDefinitionUpdate(dataObj).subscribe((data: LongDesignDefinitionService) => {
   this.getLongDesignDefiniData();
   this.alertService.success('Status Updated successfully!', true);
   this.router.navigate(['longDesignDefinition/list']);
 });

}
 
 

  
}
