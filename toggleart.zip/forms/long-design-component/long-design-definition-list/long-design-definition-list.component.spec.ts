import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LongDesignDefinitionListComponent } from './long-design-definition-list.component';

describe('LongDesignDefinitionListComponent', () => {
  let component: LongDesignDefinitionListComponent;
  let fixture: ComponentFixture<LongDesignDefinitionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LongDesignDefinitionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LongDesignDefinitionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
