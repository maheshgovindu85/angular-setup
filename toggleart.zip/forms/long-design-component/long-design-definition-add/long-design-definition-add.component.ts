import { Component, OnInit, ViewChild } from "@angular/core";
import { FormGroup, FormBuilder, Validators, FormArray } from "@angular/forms";
import { Router } from "@angular/router";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs";

import { Producttype } from "@/_models/producttype";
import { producttypeAdd } from "@/_store/producttype/product.actions";

import { AlertService, AuthenticationService, MetalService, VendorAuthenticationService } from "@/_services";
import { ProductTypeService } from "@/_services/product-type.service";
import { AddFamilyService } from "@/_services/add-family.service";
import { AddFamily } from "@/_models/add-family";
import {
  colorList,
  designPartList,
  diamondType,
  goldCalculate,
} from "@/masters/common.master";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { DiamondShapeService } from "@/_services/diamondshape.service";
import { GemstoneService } from "@/_services/gemstone.service";
import { DiamondCaratService } from "@/_services/diamondcarat.service";
import { GlobalColorPreferenceService } from "@/_services/global-color-preference.service";
import {
  LongDesignDefinition,
  LongDesignDefinitionDiamond,
  LongDesignDefinitionGemStones,
} from "@/_models/long-design-defifnition";
import { LongDesignDefinitionService } from "@/_services/long-design-defifnition.service";
import { CollectionService } from "@/_services/collection.service";
import { VendorService } from "@/_services/vendor.service";
import { MetalgoldcolorService } from "@/_services/metalgoldcolor.service";
import { environment } from "environments/environment";
import { MerchantCollectionService } from "@/_services/merchant-collection.service";
@Component({
  selector: "app-long-design-definition-add",
  templateUrl: "./long-design-definition-add.component.html",
  styleUrls: ["./long-design-definition-add.component.css"],
})
export class LongDesignDefinitionAddComponent implements OnInit {
  @ViewChild('myImage') myImage;

  longDesignDefinitionAddForm: FormGroup;
  addFamilyForm: FormGroup;
  loading = false;
  submitted = false;
  currencies: Observable<Producttype[]>;
  public isactive: boolean = true;
  productList: any = [];
  familyName: any = [];
  familyNameTop: any = [];
  familyNameMid: any = [];
  familyNameDrop: any = [];
  list: any = [];
  displayFamilyPop: boolean = false;
  productSubList: any = [];
  filteredProductSubList: any = [];

  designPartList = designPartList;
  diamondType = diamondType;
  diamondShapeList: any = [];
  gemstoneList: any = [];
  gemstoneColorList: any = [];
  getCollectionList: any = [];
  merchantCollectionList: any = [];
  filtermerchantCollectionList: any = [];
  merchantList: any = [];
  goldCalculate = goldCalculate;
  colorList = colorList;
  positionList: any = [{ id: "other" }];
  calcu: number;
  gold: any = {};
  // kt: any;
  calculation: any;
  wtValue: any;
  nosValue: any;
  calValue: number;
  diamondData: any = [];
  gemStonedData: any = [];
  diamond_Id: any;
  uploadedFiles: File[] = [];
  dataObj: { base64format: any; imagePath: string; };
  // kt14: any;
  // kt18: any;
  wt: number = 0;
  // wt22: any;
  // wt18: number;
  // wt14: number;

  subProduct: any = [];
  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();
  selectSubList: any = [];
  midFam: boolean = false;
  dropFam: boolean = false;
  topFam: boolean = false;
  hideHeading: boolean = false
  modelImage: any;
  partImagePath: any;
  AllImages: any = [];
  optionList: any = [];
  diamondCaratList: any = [];
  public path = `${environment.apiUrl}`;
  positionOptions: any = []
  arrayData: any = [];
  merchantData: any = [];
  merchantSetData: any = [];
  merchantListAll: any = [];
  merchantListLogin: any;
  vendor_id: number;
  merchant_id: number;
  meData: any;
  public adminId = `${environment.adminId}`;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private producttypeService: ProductTypeService,
    private AddFamilyService: AddFamilyService,
    private DiamondShapeService: DiamondShapeService,
    private ProductSubTypeService: ProductSubTypeService,
    private collectionService: CollectionService,
    private GemstoneService: GemstoneService,
    private vendorservices: VendorService,
    private LongDesignDefinitionService: LongDesignDefinitionService,
    private GlobalColorPreferenceService: GlobalColorPreferenceService,
    private authenticationService: AuthenticationService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private DiamondCaratService: DiamondCaratService,
    private vendorauthenticationService: VendorAuthenticationService,
    private merchantCollectionService: MerchantCollectionService,
    private store: Store<{ producttypes: Producttype[] }>

  ) {
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {


    this.getCollectionData();
    this.getProductList();
    // this.getFamilyName();
    this.getProductSubTypeData();
    this.diamondShapeData();
    this.genStoneData();
    this.gemStoneColor();

    this.getMerchantList();
    this.getDiamondCaratList();
    this.createForm();
    this.famForm();
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.longDesignDefinitionAddForm.controls;
  }

  createForm() {
    this.longDesignDefinitionAddForm = this.formBuilder.group({
      product_id: ["", Validators.required],
      partname: ["", Validators.required],
      merchantid: [this.merchant_id],
      designno: ["", Validators.required],
      designpart: ["", Validators.required],
      family: ["",Validators.required],
      product_sub_type: ["", Validators.required],
      collection: [""],
      merchantCollection: [""],
      gemstone: this.formBuilder.array([this.Initial_GemStones()]),
      gold: ["22"],
      wt: [""],
      diamond: this.formBuilder.array([this.Initial_Diamond()]),
      topbottomoffset: [""],
      topbottomoffsetmodel: [""],
      midupoffset: [""],
      midupoffsetmodel: [""],
      midbottomoffsetmodel: [""],
      midbottomoffset:[''],
      dropupoffset: [""],
      dropupoffsetmodel: [""],
      associateTop: [""],
      associateDrop: [""],
      associateMid: [""],
      imagecolor: [""],
      multipleImages: this.formBuilder.array([this.Initial_Multiple()]),
    });
    this.getFamilyName();
  }

  changeCalculation(e) {
    this.goldCalculation(e.value, this.wt);
  }

  valuechange(newValue) {
    this.wt = newValue;
    this.goldCalculation(this.longDesignDefinitionAddForm.value.gold, this.wt);
  }

  goldCalculation(kt, wt) {
    if (kt == 22) {
      this.gold.kt = kt;
      this.gold.wt22 = wt;
      this.gold.wt18 = wt * 0.873;
      this.gold.wt14 = this.gold.wt18 * 0.864;
    } else if (kt == 18) {
      this.gold.kt = kt;
      this.gold.wt18 = wt;
      this.gold.wt14 = this.gold.wt18 * 0.864;
    } else {
      this.gold.kt = kt;
      this.gold.wt14 = wt;
    }
  }

  // /add diamond data form
  Initial_Diamond() {
    return this.formBuilder.group({
      type: [""],
      wt: [""],
      nos: [""],
      shape: [""],
      twt: [""],
    });
  }

  get diamond(): FormArray {
    return this.longDesignDefinitionAddForm.get("diamond") as FormArray;
  }

  addDiamond() {
    this.diamond.push(this.Initial_Diamond());
  }

  removeDiamondList(index: number) {
    this.diamond.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  wtChange(e: any, i: any) {
    this.wtValue = e;
    let diaWt = this.longDesignDefinitionAddForm.value.diamond[i].wt;
    let val = diaWt * this.longDesignDefinitionAddForm.value.diamond[i].nos;
    let data = Math.round(val * 100) / 100
    this.longDesignDefinitionAddForm.controls['diamond']['controls'][i].controls['twt'].setValue(data);

  }
  nosChange(e: any, i: any) {
    var t = e.target.value;
    e.target.value = t.indexOf('.') >= 0 ? t.substr(0, t.indexOf('.')) + t.substr(t.indexOf('.'), 3) : t;
    // let result = this.diamondCaratList.filter(c => c.id === this.longDesignDefinitionAddForm.value.diamond[i].wt);
    // let val = result[0].carat_name * this.longDesignDefinitionAddForm.value.diamond[i].nos;
    let diaWt = this.longDesignDefinitionAddForm.value.diamond[i].wt;
    let val = diaWt * this.longDesignDefinitionAddForm.value.diamond[i].nos;
    let data = Math.round(val * 100) / 100
    this.longDesignDefinitionAddForm.controls['diamond']['controls'][i].controls['twt'].setValue(data);
  }

  twtChange(e: any, i: any) {
    var t = e.target.value;
    e.target.value = t.indexOf('.') >= 0 ? t.substr(0, t.indexOf('.')) + t.substr(t.indexOf('.'), 3) : t;
    // let result = this.diamondCaratList.filter(c => c.id === this.longDesignDefinitionAddForm.value.diamond[i].wt);
    let diaWt = this.longDesignDefinitionAddForm.value.diamond[i].wt;
    let val = this.longDesignDefinitionAddForm.value.diamond[i].twt / diaWt;
    let data = Math.round(val * 100) / 100
    this.longDesignDefinitionAddForm.controls['diamond']['controls'][i].controls['nos'].setValue(data);
  }

  // /add diamond data  End form


  ///gemstone add form value chnage''
  gemWtChange(e: any, i: any) {
    this.wtValue = e;
    let result = this.longDesignDefinitionAddForm.value.gemstone[i].wt;
    let val = result * this.longDesignDefinitionAddForm.value.gemstone[i].nos;
    let data = Math.round(val * 100) / 100
    this.longDesignDefinitionAddForm.controls['gemstone']['controls'][i].controls['twt'].setValue(data);
  }
  gemNosChange(e: any, i: any) {
    var t = e.target.value;
    e.target.value = t.indexOf('.') >= 0 ? t.substr(0, t.indexOf('.')) + t.substr(t.indexOf('.'), 3) : t;
    let result = this.longDesignDefinitionAddForm.value.gemstone[i].wt;
    let val = result * this.longDesignDefinitionAddForm.value.gemstone[i].nos;
    let data = Math.round(val * 100) / 100
    this.longDesignDefinitionAddForm.controls['gemstone']['controls'][i].controls['twt'].setValue(data);
  }

  gemTwtChange(e: any, i: any) {
    var t = e.target.value;
    e.target.value = t.indexOf('.') >= 0 ? t.substr(0, t.indexOf('.')) + t.substr(t.indexOf('.'), 3) : t;
    let result = this.longDesignDefinitionAddForm.value.gemstone[i].wt;
    let val = this.longDesignDefinitionAddForm.value.gemstone[i].twt / result;
    let data = Math.round(val * 100) / 100
    this.longDesignDefinitionAddForm.controls['gemstone']['controls'][i].controls['nos'].setValue(data);
  }

  // /add Gemstones data form
  Initial_GemStones() {
    return this.formBuilder.group({
      name: [""],
      size: [""],
      shape: [""],
      wt: [""],
      nos: [""],
      color: [""],
      twt: ['']
    });
  }

  get gemstone(): FormArray {
    return this.longDesignDefinitionAddForm.get("gemstone") as FormArray;
  }

  addGemStones() {
    this.gemstone.push(this.Initial_GemStones());
  }

  removeFGemStoneList(index: number) {
    this.gemstone.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  // /add Gemstones data Form End

  /// images ///


  selectedFiles(files: File[], index) {
    for (var i = 0; i < files.length; i++) {
      this.fileindexposition++;
      this.FileListMap.set(index, files[i]);
    }
  }

  Initial_Multiple() {
    return this.formBuilder.group({
      images: [''],
      displayUser: [''],
      selectColor: [''],
      secondOption: [''],
      Position: [''],
      modelImage: ['']
    });
  }

  get multipleImages() {
    return this.longDesignDefinitionAddForm.get('multipleImages') as FormArray;
  }

  removeRow(index: number) {
    this.multipleImages.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }


  onChangeShowFam(event) {
    if (event.value === 'Top') {
      this.midFam = true;
      this.dropFam = true;
      this.topFam = false;
      this.hideHeading = true;
      this.familyName = this.familyNameTop;

    } else if (event.value === 'Mid') {
      this.midFam = false;
      this.dropFam = true;
      this.topFam = true;
      this.hideHeading = true;
      this.familyName = this.familyNameMid;
    } else {
      this.midFam = true;
      this.dropFam = false;
      this.topFam = true;
      this.hideHeading = true;
      this.familyName = this.familyNameDrop;
    }

  }

  onModelImageSelect(files: File[]) {
    var base64valueModel;
    for (var element = 0; element < files.length; element++) {
      const readerModel = new FileReader();
      readerModel.readAsDataURL(files[element]);
      readerModel.onload = (event: any) => {
        if (event.target.result) {
          base64valueModel = event.target.result;
          let dataModelObj = {
            base64format: base64valueModel,
            imagePath: files[0].name,
          };
          this.ProductSubTypeService.upload(dataModelObj).subscribe((data) => {
            this.modelImage = data['data'];
            this.partImagePath = this.path + "/imagepreview/getImage?imagename=" + this.modelImage;
            this.multipleImages.push(
              this.formBuilder.group({
                images: [this.partImagePath],
                displayUser: [''],
                selectColor: [this.longDesignDefinitionAddForm.value.imagecolor],
                secondOption: [''],
                Position: [""],
                modelImage: [this.modelImage],
              })
            );

          });

        }
      };
    }
  }
  
  clearFile(){
    this.myImage.nativeElement.value = '';
  }

  onSubmit() {
    this.submitted = true;
    this.longDesignDefinitionAddForm.value.multipleImages.shift();
    if (this.longDesignDefinitionAddForm.value.merchantid == this.adminId) {
      this.longDesignDefinitionAddForm.controls["collection"].setValidators(Validators.required);
      this.longDesignDefinitionAddForm.controls["merchantCollection"]?.clearValidators();
      this.longDesignDefinitionAddForm.controls["merchantCollection"].setErrors(null);

    } else if (this.longDesignDefinitionAddForm.value.merchantid != this.adminId) {
      this.longDesignDefinitionAddForm.controls["merchantCollection"].setValidators(Validators.required);
      this.longDesignDefinitionAddForm.controls["collection"]?.clearValidators();
      this.longDesignDefinitionAddForm.controls["collection"].setErrors(null);
    }

    if (this.longDesignDefinitionAddForm.valid) {
      const dataObj = {
        product_id: this.longDesignDefinitionAddForm.value.product_id,
        partname: this.longDesignDefinitionAddForm.value.partname,
        designpart: this.longDesignDefinitionAddForm.value.designpart,
        merchantid: this.longDesignDefinitionAddForm.value.merchantid,
        designno: this.longDesignDefinitionAddForm.value.designno,
        family: this.longDesignDefinitionAddForm.value.family,
        product_sub_type: this.longDesignDefinitionAddForm.value.product_sub_type,
        collection: this.longDesignDefinitionAddForm.value.collection,
        merchantCollection: this.longDesignDefinitionAddForm.value.merchantCollection,
        topbottomoffset: this.longDesignDefinitionAddForm.value.topbottomoffset,
        topbottomoffsetmodel: this.longDesignDefinitionAddForm.value.topbottomoffsetmodel,
        midupoffset: this.longDesignDefinitionAddForm.value.midupoffset,
        midupoffsetmodel: this.longDesignDefinitionAddForm.value.midupoffsetmodel,
        midbottomoffsetmodel: this.longDesignDefinitionAddForm.value.midbottomoffsetmodel,
        midbottomoffset: this.longDesignDefinitionAddForm.value.midbottomoffset,
        dropupoffset: this.longDesignDefinitionAddForm.value.dropupoffset,
        dropupoffsetmodel: this.longDesignDefinitionAddForm.value.dropupoffsetmodel,
        gold: this.gold,
        gemstone: this.longDesignDefinitionAddForm.value.gemstone,
        diamond: this.longDesignDefinitionAddForm.value.diamond,
        image: this.longDesignDefinitionAddForm.value.multipleImages,
        topfamily: this.longDesignDefinitionAddForm.value.associateTop,
        midfamily: this.longDesignDefinitionAddForm.value.associateMid,
        dropfamily: this.longDesignDefinitionAddForm.value.associateDrop,
      };

      this.LongDesignDefinitionService.save(dataObj).subscribe((data: LongDesignDefinition) => {
        this.alertService.success('Long Design Definition saved successfully!', true);
        if (this.vendor_id) {
          this.router.navigate(["MerchantlongDesignDefinition/list"]);
        } else {
          this.router.navigate(["longDesignDefinition/list"]);
        }
      });

    }
  }




  // add family...

  famForm() {
    this.addFamilyForm = this.formBuilder.group({
      name: [""],
      merchant_id: [""],
      part_name: [""]
    });
  }

  submitFamilyPop() {
    this.addFamilyForm.get('merchant_id').setValue(this.longDesignDefinitionAddForm.value.merchantid);
    this.addFamilyForm.get('part_name').setValue(this.longDesignDefinitionAddForm.value.designpart);
    if (this.addFamilyForm.valid) {
      this.AddFamilyService.save(this.addFamilyForm.value).subscribe(
        (data: AddFamily) => {
          this.getFamilyName();
          this.alertService.success("Family Added successfully!", true);
          this.displayFamilyPop = false;
        }
      );
    }
  }

  getFamilyName() {
    this.familyName = [];
    this.merchant_id = this.longDesignDefinitionAddForm.value.merchantid;
    if (this.longDesignDefinitionAddForm.value.product_id) {
      this.subProductChange();
    }
    this.AddFamilyService.getfamily_drop_byMerchantid({ merchant_id: this.longDesignDefinitionAddForm.value.merchantid }).subscribe((data) => {
      if (data) {
        this.familyNameDrop = data['data'];
        if (this.longDesignDefinitionAddForm.value.designpart == 'Drop')
          this.familyName = this.familyNameDrop;
      }
    });
    this.AddFamilyService.getfamily_mid_byMerchantid({ merchant_id: this.longDesignDefinitionAddForm.value.merchantid }).subscribe((data) => {
      if (data) {
        this.familyNameMid = data['data'];
        if (this.longDesignDefinitionAddForm.value.designpart == 'Mid')
          this.familyName = this.familyNameMid;
      }
    });
    this.AddFamilyService.getfamily_top_byMerchantid({ merchant_id: this.longDesignDefinitionAddForm.value.merchantid }).subscribe((data) => {
      if (data) {
        this.familyNameTop = data['data'];
        if (this.longDesignDefinitionAddForm.value.designpart == 'Top')
          this.familyName = this.familyNameTop;
      }
    });
    this.filtermerchantCollection();
  }
  // add family... end

  //// product  list////

  getProductList() {
    this.producttypeService.getAll().subscribe((data) => {
      if (data) {
        //
        setTimeout(() => {
          this.productList = data;
        });
      }
    });
  }
  //// product  list end////

  //// product sub type list////

  getProductSubTypeData() {
    this.ProductSubTypeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          // this.productSubList.filter(c=>c.merchantid == this.longDesignDefinitionAddForm.value.merchantid);
          this.productSubList = this.list.data;
          this.filteredProductSubList = this.productSubList.filter(c => c.merchantid == this.merchant_id);
          if (this.longDesignDefinitionAddForm.value.product_id) {
            this.subProductChange();
          }
          this.filtermerchantCollection();
          this.filtermerchantCollectionList = this.merchantCollectionList.filter(c => c.merchantid === this.longDesignDefinitionAddForm.value.merchantid);
          

        });
      }
    });
  }

  //// product sub type list End////

  //// diamond   list////

  getDiamondCaratList() {
    this.DiamondCaratService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.diamondCaratList = data;
          this.diamondCaratList.sort((a, b) => {
            return a.carat_name - b.carat_name;
          });
        });
      }
    });
  }
  //// diamond  list end////

  //// product collection list////

  getCollectionData() {
    this.collectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.getCollectionList = data;
        });
      }
    });
    this.merchantCollectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantCollectionList = data['data'].filter(x => x.isactive == 'Y');
        });
      }
    });
  }

  filtermerchantCollection() {
    this.subProductChange();
    this.filtermerchantCollectionList = this.merchantCollectionList.filter(c => c.merchantid === this.longDesignDefinitionAddForm.value.merchantid);
    

  }
  //// product collection list End////

  ////merchant list

  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {

          this.merchantData = data;

          this.merchantSetData = this.merchantData.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });

          if (!this.vendor_id) {
            this.merchantListAll = this.merchantSetData;

          } else {
            this.merchantListLogin = this.merchantSetData.filter(e => e.id === this.vendor_id)
          }
        });
      }
    });
  }
  ////merchant list

  ////diamond shape
  diamondShapeData() {
    this.DiamondShapeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.diamondShapeList = data;
        });
      }
    });
  }

  // /gemStones List

  genStoneData() {
    this.GemstoneService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneList = data;
        });
      }
    });
  }

  // /ggemStones color List

  gemStoneColor() {
    this.GlobalColorPreferenceService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneColorList = data;
        });
      }
    });
  }

  showAddFamily() {
    this.displayFamilyPop = true;
  }

  backToList() {
    if (this.vendor_id) {
      this.router.navigate(["MerchantlongDesignDefinition/list"]);
    } else {
      this.router.navigate(["longDesignDefinition/list"]);
    }
  }

  subProductChange() {
    if (this.productSubList.length > 0) {
      if (this.longDesignDefinitionAddForm.value.product_id != '')
        this.filteredProductSubList = this.productSubList.filter(c => c.product_id === this.longDesignDefinitionAddForm.value.product_id && c.merchantid == this.longDesignDefinitionAddForm.value.merchantid);
      else
        this.filteredProductSubList = this.productSubList.filter(c => c.merchantid == this.longDesignDefinitionAddForm.value.merchantid);
    }
  }



  showListOfOptions(event) {
    this.ProductSubTypeService.getProductSubTypeById({ id: event.value }).subscribe(data => {
      if (data) {
        let result = data['data'][0];
        if (result.flat_center == 'Y')
          this.positionList.push({ 'id': 'flat_center' })
        if (result.flat_left == 'Y')
          this.positionList.push({ 'id': 'flat_left' })
        if (result.flat_right == 'Y')
          this.positionList.push({ 'id': 'flat_right' })
        if (result.model_center == 'Y')
          this.positionList.push({ 'id': 'model_center' })
        if (result.model_left == 'Y')
          this.positionList.push({ 'id': 'model_left' })
        if (result.model_right == 'Y')
          this.positionList.push({ 'id': 'model_right' })
        if (result.side == 'Y')
          this.positionList.push({ 'id': 'side' });
      }
    })
  }

  toggledisplayuser(i: number, color: string) {
    if (this.longDesignDefinitionAddForm.value.multipleImages[i].displayUser == true) {
      this.longDesignDefinitionAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["secondOption"].setValue(false);
    }
    this.checkforuniquedisplay(i, color, "displayUser");
  }

  togglesecond(i: number, color: string) {
    if (this.longDesignDefinitionAddForm.value.multipleImages[i].secondOption == true) {
      this.longDesignDefinitionAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["displayUser"].setValue(false);
    }
    this.checkforuniquedisplay(i, color, "secondOption");
  }

  checkforuniquedisplay(i, color, type) {
    let aFormArray = this.longDesignDefinitionAddForm.get("multipleImages");
    let count = 0;
    for (let c of aFormArray["controls"]) {
      if (c.controls["selectColor"].value == color && c.controls[type].value == type) {
        count++;
        if (count > 1) {
          this.longDesignDefinitionAddForm.controls["multipleImages"]["controls"][
            i
          ].controls[type].setValue(false);
          this.alertService.success("Selection already available for color", false);
          break;
        }
      }
    }
  }

  validatePosition(e: any, i: number, color: string) {
    let aFormArray = this.longDesignDefinitionAddForm.get("multipleImages");
    if (e.value !== "other") {
      this.longDesignDefinitionAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["displayUser"].setValue(false);
      this.longDesignDefinitionAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["secondOption"].setValue(false);
      let count = 0;
      for (let c of aFormArray["controls"]) {
        if (c.controls["Position"].value === e.value && c.controls["selectColor"].value == color)
          count++;
        if (count > 1) {
          this.longDesignDefinitionAddForm.controls["multipleImages"]["controls"][
            i
          ].controls["Position"].setValue("");
          this.alertService.success("Postion Already available for selected color", false);
          break;
        }
      }
    }
  }
}



