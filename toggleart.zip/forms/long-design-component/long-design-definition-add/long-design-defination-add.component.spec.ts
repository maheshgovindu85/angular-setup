import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LongDesignDefinitionAddComponent } from './long-design-definition-add.component';

describe('LongDesignDefinitionAddComponent', () => {
  let component: LongDesignDefinitionAddComponent;
  let fixture: ComponentFixture<LongDesignDefinitionAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LongDesignDefinitionAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LongDesignDefinitionAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
