import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LongDesignDefinitionEditComponent } from './long-design-definition-edit.component';

describe('LongDesignDefinitionEditComponent', () => {
  let component: LongDesignDefinitionEditComponent;
  let fixture: ComponentFixture<LongDesignDefinitionEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LongDesignDefinitionEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LongDesignDefinitionEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
