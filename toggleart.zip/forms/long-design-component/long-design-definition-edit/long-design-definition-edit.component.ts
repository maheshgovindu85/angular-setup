import { Component, OnInit, ViewChild } from "@angular/core";
import { FormGroup, FormBuilder, FormArray, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";

import { Producttype } from "@/_models/producttype";

import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { ProductTypeService } from "@/_services/product-type.service";
import { AddFamilyService } from "@/_services/add-family.service";
import { AddFamily } from "@/_models/add-family";
import {
  colorList,
  designPartList,
  diamondType,
  goldCalculate,
} from "@/masters/common.master";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { DiamondShapeService } from "@/_services/diamondshape.service";
import { GemstoneService } from "@/_services/gemstone.service";
import { GlobalColorPreferenceService } from "@/_services/global-color-preference.service";
import {
  LongDesignDefinition,
} from "@/_models/long-design-defifnition";
import { LongDesignDefinitionService } from "@/_services/long-design-defifnition.service";
import { CollectionService } from "@/_services/collection.service";
import { VendorService } from "@/_services/vendor.service";
import { environment } from "environments/environment";
import { DiamondCaratService } from "@/_services/diamondcarat.service";
import { MerchantCollectionService } from "@/_services/merchant-collection.service";

@Component({
  selector: "app-long-design-definition-edit",
  templateUrl: "./long-design-definition-edit.component.html",
  styleUrls: ["./long-design-definition-edit.component.css"],
})
export class LongDesignDefinitionEditComponent implements OnInit {
  @ViewChild('myImage') myImage;

  longDesignDefinitionEditForm: FormGroup;
  addFamilyForm: FormGroup;
  loading = false;
  submitted = false;
  currencies: Observable<Producttype[]>;
  public isactive: boolean = true;
  productList: any = [];
  familyName: any = [];
  list: any = [];
  displayFamilyPop: boolean = false;
  productSubList: any = [];

  designPartList = designPartList;
  diamondType = diamondType;
  diamondShapeList: any = [];
  gemstoneList: any = [];
  gemstoneColorList: any = [];
  getCollectionList: any = [];
  merchantList: any = [];
  goldCalculate = goldCalculate;
  colorList = colorList;
  calcu: number;
  gold: any = {};
  kt: any;
  calculation: any;
  wtValue: any;
  nosValue: any;
  calValue: number;
  diamondData: any = [];
  gemStonedData: any = [];
  diamond_Id: any;
  uploadedFiles: File[] = [];
  dataObj: { base64format: any; imagePath: string };

  definitionId: any;
  definitionData: any;
  wt: number = 0;
  subProduct: any = [];
  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();
  selectSubList: any = [];
  midFam: boolean = false;
  dropFam: boolean = false;
  topFam: boolean = false;
  hideHeading: boolean = false;
  filteredProductSubList: any = [];
  modelImage: any;
  partImagePath: any;
  AllImages: any = [];
  optionList: any = [];
  diamondCaratList: any = [];
  public path = `${environment.apiUrl}`;
  positionOptions: any = [{ id: "other" }];
  arrayData: any = [];
  vendor_id: any;
  merchantData: any = [];
  merchantSetData: any = [];
  merchantListAll: any = [];
  merchantListLogin: any;
  meData: any;
  familyNameTop: any = [];
  familyNameMid: any = [];
  familyNameDrop: any = [];
  public adminId = `${environment.adminId}`;
  merchant_id: number;
  selectedColor: string;
  merchantCollectionList: any = [];
  filtermerchantCollectionList: any = [];
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private producttypeService: ProductTypeService,
    private AddFamilyService: AddFamilyService,
    private DiamondShapeService: DiamondShapeService,
    private ProductSubTypeService: ProductSubTypeService,
    private collectionService: CollectionService,
    private GemstoneService: GemstoneService,
    private vendorservices: VendorService,
    private LongDesignDefinitionService: LongDesignDefinitionService,
    private GlobalColorPreferenceService: GlobalColorPreferenceService,
    private route: ActivatedRoute,
    private DiamondCaratService: DiamondCaratService,
    private authenticationService: AuthenticationService,
    private vendorauthenticationService: VendorAuthenticationService,
    private merchantCollectionService: MerchantCollectionService,
    private store: Store<{ producttypes: Producttype[] }>
  ) {
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id =
        this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.definitionId = this.route.snapshot.params.id;
    this.createForm();
    this.famForm();
    this.getAllProductById();
    this.getProductList();
    this.getProductSubTypeData();
    this.diamondShapeData();
    this.genStoneData();
    this.gemStoneColor();
    this.getCollectionData();
    this.getMerchantList();
    this.getDiamondCaratList();

  }

  // convenience getter for easy access to form fields
  get f() {
    return this.longDesignDefinitionEditForm.controls;
  }

  createForm() {
    this.longDesignDefinitionEditForm = this.formBuilder.group({
      isactive: [""],
      product_id: ["", Validators.required],
      partname: ["", Validators.required],
      merchantid: [this.merchant_id],
      designno: ["", Validators.required],
      designpart: ["", Validators.required],
      family: ["", Validators.required],
      product_sub_type: ["", Validators.required],
      collection: [""],
      merchantCollection: [""],
      gemstone: this.formBuilder.array([this.Initial_GemStones()]),
      gold: [""],
      wt: [""],
      diamond: this.formBuilder.array([this.Initial_Diamond()]),
      topbottomoffset: [""],
      topbottomoffsetmodel: [""],
      midupoffset: [""],
      midupoffsetmodel: [""],
      midbottomoffsetmodel: [""],
      midbottomoffset:[''],
      dropupoffset: [""],
      dropupoffsetmodel: [""],
      associateTop: [""],
      associateDrop: [""],
      associateMid: [""],
      imagecolor: [""],
      multipleImages: this.formBuilder.array([this.Initial_Multiple()]),
    });
  }

  changeCalculation(e) {
    this.goldCalculation(e.value, this.wt);
  }

  valuechange(newValue) {
    this.wt = newValue;
    this.goldCalculation(this.longDesignDefinitionEditForm.value.gold, this.wt);
  }

  goldCalculation(kt, wt) {
    if (kt == 22) {
      this.gold.kt = kt;
      this.gold.wt22 = wt;
      this.gold.wt18 = wt * 0.873;
      this.gold.wt14 = this.gold.wt18 * 0.864;
    } else if (kt == 18) {
      this.gold.kt = kt;
      this.gold.wt18 = wt;
      this.gold.wt14 = this.gold.wt18 * 0.864;
    } else {
      this.gold.kt = kt;
      this.gold.wt14 = wt;
    }
  }

  // /add diamond data form
  Initial_Diamond() {
    return this.formBuilder.group({
      type: [""],
      wt: [""],
      nos: [""],
      shape: [""],
      twt: [""],
    });
  }

  get diamond(): FormArray {
    return this.longDesignDefinitionEditForm.get("diamond") as FormArray;
  }

  addDiamond() {
    this.diamond.push(this.Initial_Diamond());
  }

  removeDiamondList(index: number) {
    this.diamond.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }
  wtChange(e: any, i: any) {
    this.wtValue = e;
    let diaWt = this.longDesignDefinitionEditForm.value.diamond[i].wt;
    let val = diaWt * this.longDesignDefinitionEditForm.value.diamond[i].nos;
    let data = Math.round(val * 100) / 100
    this.longDesignDefinitionEditForm.controls['diamond']['controls'][i].controls['twt'].setValue(data);
  }

  nosChange(e: any, i: any) {
    var t = e.target.value;
    e.target.value = t.indexOf('.') >= 0 ? t.substr(0, t.indexOf('.')) + t.substr(t.indexOf('.'), 3) : t;
    // let result = this.diamondCaratList.filter(c => c.id === this.longDesignDefinitionEditForm.value.diamond[i].wt);
    let diaWt = this.longDesignDefinitionEditForm.value.diamond[i].wt;
    let val = diaWt * this.longDesignDefinitionEditForm.value.diamond[i].nos;
    let data = Math.round(val * 100) / 100
    this.longDesignDefinitionEditForm.controls['diamond']['controls'][i].controls['twt'].setValue(data);
  }

  twtChange(e: any, i: any) {
    var t = e.target.value;
    e.target.value = t.indexOf('.') >= 0 ? t.substr(0, t.indexOf('.')) + t.substr(t.indexOf('.'), 3) : t;
    // let result = this.diamondCaratList.filter(c => c.id === this.longDesignDefinitionEditForm.value.diamond[i].wt);
    let diaWt = this.longDesignDefinitionEditForm.value.diamond[i].wt;
    let val = this.longDesignDefinitionEditForm.value.diamond[i].twt / diaWt;
    let data = Math.round(val * 100) / 100
    this.longDesignDefinitionEditForm.controls['diamond']['controls'][i].controls['nos'].setValue(data);
  }
  
  // /add diamond data  End form

  ///gemstone add form value chnage''
  gemWtChange(e: any, i: any) {
    this.wtValue = e;
    let result = this.longDesignDefinitionEditForm.value.gemstone[i].wt;
    this.longDesignDefinitionEditForm.controls["gemstone"]["controls"][
      i
    ].controls["twt"].setValue(
      result * this.longDesignDefinitionEditForm.value.gemstone[i].nos
    );
  }
  gemNosChange(e: any, i: any) {
    let result = this.longDesignDefinitionEditForm.value.gemstone[i].wt;
    this.longDesignDefinitionEditForm.controls["gemstone"]["controls"][
      i
    ].controls["twt"].setValue(
      result * this.longDesignDefinitionEditForm.value.gemstone[i].nos
    );
  }

  gemTwtChange(e: any, i: any) {
    let result = this.longDesignDefinitionEditForm.value.gemstone[i].wt;
    let val = this.longDesignDefinitionEditForm.value.gemstone[i].twt / result;
    this.longDesignDefinitionEditForm.controls["gemstone"]["controls"][
      i
    ].controls["nos"].setValue(val);
  }

  // /add Gemstones data form
  Initial_GemStones() {
    return this.formBuilder.group({
      name: [""],
      size: [""],
      shape: [""],
      wt: [""],
      nos: [""],
      color: [""],
      twt: [""],
    });
  }

  get gemstone(): FormArray {
    return this.longDesignDefinitionEditForm.get("gemstone") as FormArray;
  }

  addGemStones() {
    this.gemstone.push(this.Initial_GemStones());
  }

  removeFGemStoneList(index: number) {
    this.gemstone.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  // /add Gemstones data Form End

  /// images ///

  selectedFiles(files: File[], index) {
    for (var i = 0; i < files.length; i++) {
      this.fileindexposition++;
      this.FileListMap.set(index, files[i]);
    }
  }

  Initial_Multiple() {
    return this.formBuilder.group({
      images: [""],
      displayUser: [''],
      selectColor: [""],
      secondOption: [''],
      Position: [""],
    });
  }

  get multipleImages() {
    return this.longDesignDefinitionEditForm.get("multipleImages") as FormArray;
  }

  removeRow(index: number) {
    this.multipleImages.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  onSubmit() {
    this.submitted = true;
    if (this.longDesignDefinitionEditForm.value.merchantid == this.adminId) {
      this.longDesignDefinitionEditForm.controls["collection"].setValidators(Validators.required);
      this.longDesignDefinitionEditForm.controls["merchantCollection"]?.clearValidators();
      this.longDesignDefinitionEditForm.controls["merchantCollection"].setErrors(null);

    } else if (this.longDesignDefinitionEditForm.value.merchantid != this.adminId) {
      this.longDesignDefinitionEditForm.controls["merchantCollection"].setValidators(Validators.required);
      this.longDesignDefinitionEditForm.controls["collection"]?.clearValidators();
      this.longDesignDefinitionEditForm.controls["collection"].setErrors(null);
    }
    if (this.longDesignDefinitionEditForm.valid) {
      const dataObj = {
        id: this.definitionId,
        isactive:
          this.longDesignDefinitionEditForm.value.isactive === true ? "Y" : "N",
        product_id: this.longDesignDefinitionEditForm.value.product_id,
        partname: this.longDesignDefinitionEditForm.value.partname,
        designpart: this.longDesignDefinitionEditForm.value.designpart,
        merchantid: this.longDesignDefinitionEditForm.value.merchantid,
        designno: this.longDesignDefinitionEditForm.value.designno,
        family: this.longDesignDefinitionEditForm.value.family,
        product_sub_type:
          this.longDesignDefinitionEditForm.value.product_sub_type,
        collection: this.longDesignDefinitionEditForm.value.collection,
        merchantCollection:
          this.longDesignDefinitionEditForm.value.merchantCollection,
          topbottomoffset: this.longDesignDefinitionEditForm.value.topbottomoffset,
          topbottomoffsetmodel: this.longDesignDefinitionEditForm.value.topbottomoffsetmodel,
          midupoffset: this.longDesignDefinitionEditForm.value.midupoffset,
          midupoffsetmodel: this.longDesignDefinitionEditForm.value.midupoffsetmodel,
          midbottomoffsetmodel: this.longDesignDefinitionEditForm.value.midbottomoffsetmodel,
          midbottomoffset: this.longDesignDefinitionEditForm.value.midbottomoffset,
          dropupoffset: this.longDesignDefinitionEditForm.value.dropupoffset,
          dropupoffsetmodel: this.longDesignDefinitionEditForm.value.dropupoffsetmodel,
        gold: this.gold,
        gemstone: this.longDesignDefinitionEditForm.value.gemstone,
        diamond: this.longDesignDefinitionEditForm.value.diamond,
        image: this.longDesignDefinitionEditForm.value.multipleImages,
        topfamily: this.longDesignDefinitionEditForm.value.associateTop,
        midfamily: this.longDesignDefinitionEditForm.value.associateMid,
        dropfamily: this.longDesignDefinitionEditForm.value.associateDrop,
      };

      this.LongDesignDefinitionService.getLongDesignDefinitionUpdate(
        dataObj
      ).subscribe((data: LongDesignDefinition) => {
        this.alertService.success(
          "Long Design Definition updated successfully!",
          true
        );
        if (this.vendor_id) {
          this.router.navigate(["MerchantlongDesignDefinition/list"]);
        } else {
          this.router.navigate(["longDesignDefinition/list"]);
        }
      });
    }
  }

  getAllProductById() {
    this.LongDesignDefinitionService.getLongDesignDefinitionbyid({
      id: this.definitionId,
    }).subscribe((data) => {
      if (data) {
        this.setFormValue(data);
        this.getCollectionData();
        if (this.longDesignDefinitionEditForm.value.merchantid != this.adminId) {
          this.filtermerchantCollectionList = this.merchantCollectionList.filter(
            (c) => c.merchantid === this.longDesignDefinitionEditForm.value.merchantid
          );


        }
      }
    });
  }

  onChangeShowFam(event) {
    if (event.value === "Top") {
      this.midFam = true;
      this.dropFam = true;
      this.topFam = false;
      this.hideHeading = true;
    } else if (event.value === "Mid") {
      this.midFam = false;
      this.dropFam = true;
      this.topFam = true;
      this.hideHeading = true;
    } else {
      this.midFam = true;
      this.dropFam = false;
      this.topFam = true;
      this.hideHeading = true;
    }
  }

  setFormValue(data) {
    this.definitionData = data.data;

    this.filtermerchantCollectionList = this.merchantCollectionList.filter(
      (c) => c.merchantid === this.definitionData[0].merchantid
    );
    this.showListOfOptions(this.definitionData[0].product_sub_type);
    this.longDesignDefinitionEditForm
      .get("isactive")
      ?.setValue(this.definitionData[0].isactive === "Y" ? true : false);
    this.longDesignDefinitionEditForm
      .get("product_id")
      ?.setValue(this.definitionData[0].product_id);
    this.longDesignDefinitionEditForm
      .get("partname")
      ?.setValue(this.definitionData[0].partname);
    this.longDesignDefinitionEditForm
      .get("designpart")
      ?.setValue(this.definitionData[0].designpart);
    this.longDesignDefinitionEditForm
      .get("merchantid")
      ?.setValue(JSON.parse(this.definitionData[0].merchantid));
    this.longDesignDefinitionEditForm
      .get("designno")
      ?.setValue(this.definitionData[0].designno);
    this.longDesignDefinitionEditForm
      .get("family")
      ?.setValue(this.definitionData[0].family);
    this.longDesignDefinitionEditForm
      .get("product_sub_type")
      ?.setValue(this.definitionData[0].product_sub_type);
    this.longDesignDefinitionEditForm
      .get("collection")
      ?.setValue(this.definitionData[0].collection);
    this.longDesignDefinitionEditForm
      .get("merchantCollection")
      ?.setValue(this.definitionData[0].merchantCollection);
    this.longDesignDefinitionEditForm
      .get("topbottomoffset")
      ?.setValue(this.definitionData[0].topbottomoffset);
    this.longDesignDefinitionEditForm
      .get("topbottomoffsetmodel")
      ?.setValue(this.definitionData[0].topbottomoffsetmodel);
    this.longDesignDefinitionEditForm
      .get("midupoffset")
      ?.setValue(this.definitionData[0].midupoffset);
    this.longDesignDefinitionEditForm
      .get("midupoffsetmodel")
      ?.setValue(this.definitionData[0].midupoffsetmodel);
    this.longDesignDefinitionEditForm
      .get("midbottomoffsetmodel")
      ?.setValue(this.definitionData[0].midbottomoffsetmodel);
      this.longDesignDefinitionEditForm
      .get("midbottomoffset")
      ?.setValue(this.definitionData[0].midbottomoffset);
    this.longDesignDefinitionEditForm
      .get("dropupoffsetmodel")
      ?.setValue(this.definitionData[0].dropupoffsetmodel);
    this.longDesignDefinitionEditForm
      .get("dropupoffset")
      ?.setValue(this.definitionData[0].dropupoffset);
    this.longDesignDefinitionEditForm
      .get("associateMid")
      ?.setValue(this.definitionData[0].midfamily);
    this.longDesignDefinitionEditForm
      .get("associateTop")
      ?.setValue(this.definitionData[0].topfamily);
    this.longDesignDefinitionEditForm
      .get("associateDrop")
      ?.setValue(this.definitionData[0].dropfamily);
      if(this.definitionData[0].gold.kt)
    this.longDesignDefinitionEditForm
      .get("gold")
      ?.setValue(this.definitionData[0].gold.kt.toString());
      if(this.definitionData[0].gold != 0)
    this.gold = this.definitionData[0].gold;
    if (this.definitionData[0].gold.kt == 22) {
      this.longDesignDefinitionEditForm
        .get("wt")
        ?.setValue(this.definitionData[0].gold.wt22);
    }
    if (this.definitionData[0].gold.kt == 18) {
      this.longDesignDefinitionEditForm
        .get("wt")
        ?.setValue(this.definitionData[0].gold.wt18);
    }
    if (this.definitionData[0].gold.kt == 14) {
      this.longDesignDefinitionEditForm
        .get("wt")
        ?.setValue(this.definitionData[0].gold.wt14);
    }
    if (this.definitionData[0].designpart === "Top") {
      this.midFam = true;
      this.dropFam = true;
      this.topFam = false;
      this.hideHeading = true;
    } else if (this.definitionData[0].designpart === "Mid") {
      this.midFam = false;
      this.dropFam = true;
      this.topFam = true;
      this.hideHeading = true;
    } else if (this.definitionData[0].designpart === "Drop") {
      this.midFam = true;
      this.dropFam = false;
      this.topFam = true;
      this.hideHeading = true;
    }

    var JsonData = this.definitionData[0].diamond;
    var dataOfDiamond = JsonData;
    this.longDesignDefinitionEditForm.setControl(
      "diamond",
      this.setDiamondForm(dataOfDiamond)
    );

    var JsonData = this.definitionData[0].gemstone;
    var dataOfGemStones = JsonData;

    this.longDesignDefinitionEditForm.setControl(
      "gemstone",
      this.setGemStonesForm(dataOfGemStones)
    );
    this.getFamilyName();
  }

  setImageForm(dataOfMultipleImages): FormArray {
    const formArray = new FormArray([]);

    for (const s of dataOfMultipleImages) {
      //do something
      formArray.push(
        this.formBuilder.group({
          images: [s.images],
          displayUser: [s.displayUser],
          selectColor: [s.selectColor],
          secondOption: [s.secondOption],
          Position: [s.Position],
        })
      );
    }

    return formArray;
  }

  setDiamondForm(dataOfDiamond): FormArray {
    const formArray = new FormArray([]);
    dataOfDiamond.forEach((s) => {
      formArray.push(
        this.formBuilder.group({
          type: [s.type],
          wt: [s.wt],
          nos: [s.nos],
          shape: [s.shape],
          twt: [s.twt],
        })
      );
    });
    return formArray;
  }

  setGemStonesForm(dataOfGemStones): FormArray {
    const formArray = new FormArray([]);
    dataOfGemStones.forEach((s) => {
      formArray.push(
        this.formBuilder.group({
          name: [s.name],
          size: [s.size],
          shape: [s.shape],
          wt: [s.wt],
          nos: [s.nos],
          twt: [s.twt],
          color: [s.color],
        })
      );
    });
    return formArray;
  }
  // add family...

  famForm() {
    this.addFamilyForm = this.formBuilder.group({
      name: [""],
      merchant_id: [""],
      part_name: [""],
    });
  }

  submitFamilyPop() {
    this.addFamilyForm
      .get("merchant_id")
      .setValue(this.longDesignDefinitionEditForm.value.merchantid);
    this.addFamilyForm
      .get("part_name")
      .setValue(this.longDesignDefinitionEditForm.value.designpart);
    if (this.addFamilyForm.valid) {
      this.AddFamilyService.save(this.addFamilyForm.value).subscribe(
        (data: AddFamily) => {
          this.getFamilyName();
          this.alertService.success("Family Added successfully!", true);
          this.displayFamilyPop = false;
        }
      );
    }
  }

  getFamilyName() {
    this.familyName = [];
    if (this.longDesignDefinitionEditForm.value.product_id) {
      this.subProductChange();
    }
    this.AddFamilyService.getfamily_drop_byMerchantid({
      merchant_id: this.longDesignDefinitionEditForm.value.merchantid,
    }).subscribe((data) => {
      if (data) {
        this.familyNameDrop = data["data"];
        if (this.longDesignDefinitionEditForm.value.designpart == "Drop")
          this.familyName = this.familyNameDrop;
      }
    });
    this.AddFamilyService.getfamily_mid_byMerchantid({
      merchant_id: this.longDesignDefinitionEditForm.value.merchantid,
    }).subscribe((data) => {
      if (data) {
        this.familyNameMid = data["data"];
        if (this.longDesignDefinitionEditForm.value.designpart == "Mid")
          this.familyName = this.familyNameMid;
      }
    });
    this.AddFamilyService.getfamily_top_byMerchantid({
      merchant_id: this.longDesignDefinitionEditForm.value.merchantid,
    }).subscribe((data) => {
      if (data) {
        this.familyNameTop = data["data"];
        if (this.longDesignDefinitionEditForm.value.designpart == "Top")
          this.familyName = this.familyNameTop;
      }
    });
  }
  // add family... end

  //// product  list////

  getProductList() {
    this.producttypeService.getAll().subscribe((data) => {
      if (data) {
        //
        setTimeout(() => {
          this.productList = data;
        });
      }
    });
  }
  //// product  list end////

  //// product sub type list////

  getProductSubTypeData() {
    this.ProductSubTypeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          // this.productSubList.filter(c=>c.merchantid == this.longDesignDefinitionEditForm.value.merchantid);
          this.productSubList = this.list.data.filter(
            (c) =>
              c.merchantid == this.longDesignDefinitionEditForm.value.merchantid
          );
          this.filteredProductSubList = this.productSubList.filter(c => c.merchantid == this.longDesignDefinitionEditForm.value.merchantid);
          if (this.longDesignDefinitionEditForm.value.product_id) {
            this.subProductChange();
          }
          this.filtermerchantCollection();
        });
      }
    });
  }
  //// product sub type list End////

  //// product collection list////

  getCollectionData() {
    this.collectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.getCollectionList = data;
        });
      }
    });
    this.merchantCollectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantCollectionList = data["data"];
        });
      }
    });

  }

  filtermerchantCollection() {
    this.subProductChange();
    this.filtermerchantCollectionList = this.merchantCollectionList.filter(c => c.merchantid === this.longDesignDefinitionEditForm.value.merchantid);
    console.log('this.filtermerchantCollectionList:', this.filtermerchantCollectionList);
  }
  //// product collection list End////

  ////merchant list

  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantData = data;

          this.merchantSetData = this.merchantData.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });

          if (!this.vendor_id) {
            this.merchantListAll = this.merchantSetData;
          } else {
            this.merchantListLogin = this.merchantSetData.filter(e => e.id === this.vendor_id)
          }
        });
      }
    });
  }

  getDiamondCaratList() {
    this.DiamondCaratService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.diamondCaratList = data;
          this.diamondCaratList.sort((a, b) => {
            return a.carat_name - b.carat_name;
          });
        });
      }
    });
  }

  ////diamond shape
  diamondShapeData() {
    this.DiamondShapeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.diamondShapeList = data;
        });
      }
    });
  }

  // /gemStones List

  genStoneData() {
    this.GemstoneService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneList = data;
        });
      }
    });
  }

  // /ggemStones color List

  gemStoneColor() {
    this.GlobalColorPreferenceService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneColorList = data;
        });
      }
    });
  }

  showAddFamily() {
    this.displayFamilyPop = true;
  }
  selectcolor(e: any) {
    this.selectcolor = e.value;
  }

  subProductChange() {
    if (this.productSubList.length > 0) {
      if (this.longDesignDefinitionEditForm.value.product_id != "")
        this.filteredProductSubList = this.productSubList.filter(
          (c) =>
            c.product_id ===
            this.longDesignDefinitionEditForm.value.product_id &&
            c.merchantid == this.longDesignDefinitionEditForm.value.merchantid
        );
      else
        this.filteredProductSubList = this.productSubList.filter(
          (c) =>
            c.merchantid == this.longDesignDefinitionEditForm.value.merchantid
        );
    }

  }
  onModelImageSelect(files: File[]) {
    var base64valueModel;
    for (var element = 0; element < files.length; element++) {
      const readerModel = new FileReader();
      readerModel.readAsDataURL(files[element]);
      readerModel.onload = (event: any) => {
        if (event.target.result) {
          base64valueModel = event.target.result;
          let dataModelObj = {
            base64format: base64valueModel,
            imagePath: files[0].name,
          };
          this.ProductSubTypeService.upload(dataModelObj).subscribe((data) => {
            this.modelImage = data['data'];
            this.partImagePath = this.path + "/imagepreview/getImage?imagename=" + this.modelImage;
            this.multipleImages.push(
              this.formBuilder.group({
                images: [this.partImagePath],
                displayUser: [''],
                selectColor: [this.longDesignDefinitionEditForm.value.imagecolor],
                secondOption: [''],
                Position: [""],
                modelImage: [this.modelImage],
              })
            );

          });

        }
      };
    }
  }
  
  clearFile(){
    this.myImage.nativeElement.value = '';
  }

  backToList() {
    if (this.vendor_id) {
      this.router.navigate(["MerchantlongDesignDefinition/list"]);
    } else {
      this.router.navigate(["longDesignDefinition/list"]);
    }
  }

  showListOfOptions(data) {
    this.ProductSubTypeService.getProductSubTypeById({ id: data }).subscribe(
      (data) => {
        if (data) {
          let result = data["data"][0];
          if (result.flat_center == "Y")
            this.positionOptions.push({ id: "flat_center" });
          if (result.flat_left == "Y")
            this.positionOptions.push({ id: "flat_left" });
          if (result.flat_right == "Y")
            this.positionOptions.push({ id: "flat_right" });
          if (result.model_center == "Y")
            this.positionOptions.push({ id: "model_center" });
          if (result.model_left == "Y")
            this.positionOptions.push({ id: "model_left" });
          if (result.model_right == "Y")
            this.positionOptions.push({ id: "model_right" });
          if (result.side == "Y") this.positionOptions.push({ id: "side" });
          var JsonImgData = this.definitionData[0].image;
          var dataOfMultipleImages = JsonImgData;
          this.longDesignDefinitionEditForm.setControl(
            "multipleImages",
            this.setImageForm(dataOfMultipleImages)
          );
        }
      }
    );
  }
  toggledisplayuser(i: number, color: string) {
    if (this.longDesignDefinitionEditForm.value.multipleImages[i].displayUser == true) {
      this.longDesignDefinitionEditForm.controls["multipleImages"]["controls"][
        i
      ].controls["secondOption"].setValue(false);
    }
    this.checkforuniquedisplay(i, color, "displayUser");
  }

  togglesecond(i: number, color: string) {
    if (this.longDesignDefinitionEditForm.value.multipleImages[i].secondOption == true) {
      this.longDesignDefinitionEditForm.controls["multipleImages"]["controls"][
        i
      ].controls["displayUser"].setValue(false);
    }
    this.checkforuniquedisplay(i, color, "secondOption");
  }

  checkforuniquedisplay(i, color, type) {
    let aFormArray = this.longDesignDefinitionEditForm.get("multipleImages");
    let count = 0;
    for (let c of aFormArray["controls"]) {
      if (c.controls["selectColor"].value == color && c.controls[type].value == type) {
        count++;
        if (count > 1) {
          this.longDesignDefinitionEditForm.controls["multipleImages"]["controls"][
            i
          ].controls[type].setValue(false);
          this.alertService.success("Selection already available for color", false);
          break;
        }
      }
    }
  }

  validatePosition(e: any, i: number, color: string) {
    let aFormArray = this.longDesignDefinitionEditForm.get("multipleImages");
    if (e.value !== "other") {
      this.longDesignDefinitionEditForm.controls["multipleImages"]["controls"][
        i
      ].controls["displayUser"].setValue(false);
      this.longDesignDefinitionEditForm.controls["multipleImages"]["controls"][
        i
      ].controls["secondOption"].setValue(false);
      let count = 0;
      for (let c of aFormArray["controls"]) {
        if (c.controls["Position"].value === e.value && c.controls["selectColor"].value == color)
          count++;
        if (count > 1) {
          this.longDesignDefinitionEditForm.controls["multipleImages"]["controls"][
            i
          ].controls["Position"].setValue("");
          this.alertService.success("Postion Already available for selected color", false);
          break;
        }
      }
    }
  }
}
