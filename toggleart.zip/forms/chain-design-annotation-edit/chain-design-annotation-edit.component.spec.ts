import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChainDesignAnnotationEditComponent } from './chain-design-annotation-edit.component';

describe('ChainDesignAnnotationEditComponent', () => {
  let component: ChainDesignAnnotationEditComponent;
  let fixture: ComponentFixture<ChainDesignAnnotationEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChainDesignAnnotationEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChainDesignAnnotationEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
