import {
  Component,
  OnInit,
  Input,
  OnDestroy,
  ViewChild,
  ViewContainerRef,
  Output,
  HostListener,
  EventEmitter,
  ComponentRef,
  ComponentFactory,
  ElementRef,
  ComponentFactoryResolver,
  ViewChildren,
  QueryList,
  Renderer2,
  ChangeDetectorRef,
  Inject
} from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { interval, Observable } from 'rxjs';
import { startWith, map, filter } from 'rxjs/operators';
// import { CdkDragDrop, moveItemInArray, transferArrayItem, copyArrayItem } from '@angular/cdk/drag-drop';

import { AlertService, AuthenticationService, VendorAuthenticationService, VendorCollectionService } from '@/_services';

import { async, resetFakeAsyncZone } from '@angular/core/testing';
import { ChaindesignannotationService } from '@/_services/chaindesignannotation.service';
import { threadId } from 'worker_threads';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { Loosebraceletpattern } from '@/_models/loosebraceletpattern';
import { JewelleryDeleteBtnComponent } from '@/_components/jewellery-delete-btn/jewellery-delete-btn.component';
import { MatTabChangeEvent, MatTabGroup } from '@angular/material/tabs';
import { promises, resolve } from 'dns';
import { rejects } from 'assert';
import { NavbarservicesService } from '@/_services/navbarservices.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CustomerAuthenticationService } from '@/_services/customer-authentication.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import domtoimage from 'dom-to-image-chrome-fix';
import { VendorAddComponent } from '@/forms/vendormaster/vendor-add/vendor-add.component';
import { DOCUMENT } from '@angular/common';
import { CollectionImageReducer } from '@/_store/collectionimage/collectionimage.reducer';
import { VendorService } from '@/_services/vendor.service';
import { DialogData } from '../vendor/collection/v-collection-view/v-collection-view.component';
import { CustomerOrdersService } from '../Client_Pages/customer-orders.service';
import { ViewclientchainrelatedimagesPopupComponent } from '../Client_Pages/client-design-annoation/viewclientchainrelatedimages-popup/viewclientchainrelatedimages-popup.component';
import { ViewCustomeraddonRateInfoComponent } from '../Client_Pages/view-customeraddon-rate-info/view-customeraddon-rate-info.component';
declare let html2canvas: any;
@Component({
  selector: 'app-setting-up-charm-coordinate',
  templateUrl: './setting-up-charm-coordinate.component.html',
  styleUrls: ['./setting-up-charm-coordinate.component.css']
})
export class SettingUpCharmCoordinateComponent implements OnInit {

  @ViewChild('divToScroll') divToScroll: ElementRef;
  @ViewChild('AddonToScroll') AddonToScroll: ElementRef;
  @ViewChild('supportimgelement') supportimgelement: ElementRef;

  isLoading = false;
  predefinestructureCtrl = new FormControl();
  predefineBracelet: any[];
  filteredPredefineBaracelet: Observable<any[]>;

  public chain_images;
  public addon_images;
  public charm_images;
  ring_images;
  lock_images;
  public alltypeofchains;
  IsContaintSinglestud: boolean = false;

  public chain_images_filters;
  public addon_images_filters;
  public addon_images_filters_SupportArray;
  public charm_images_filters;
  public charm_images_filters_SupportArray;
  ring_images_filters;
  lock_images_filters;
  public chainlist_filters;
  public alltypeofchains_filters;

  public predefinedbracelettype;

  public loosepattern_dtl: Loosebraceletpattern;

  public has_predefinesPattern: boolean = true;
  public flatImageHidenComp = 0;
  public ModelImagesHidComp = 0;

  public chain_details;
  public chain_flat_details: any[] = [];
  public chain_model_details;

  loading = false;
  submitted = false;
  public topaxisIndex: number = 0;
  public topaxisIndexModel: number = 0;
  public delete_flatIds = 1;
  public activetab = 0;


  public topaxisPixel_flat = 100;
  public topaxisPixel_model = 100;
  public columnCount_flat = 1;
  public columnCount_model = 1;

  public looseBracelettype;
  public chaingoldcolorid;
  public braceletchaintypeid;

  public ServerURL;
  designForm: FormGroup;
  left: number = 0;
  cmpt = this;

  showpricebreakup: boolean = false;
  NumberOfImageShowInList: number = 10;
  NumberOfAddonShowInList: number = 10;
  CharmIndexvalue: number = 0;

  HTMLlockelemet: boolean = false;
  HTMLringelemet: boolean = false;
  HTMLcharmelemet: boolean = false;
  HTMLaddonelemet: boolean = false;

  @ViewChildren('capa', { read: ViewContainerRef }) capa1: ViewContainerRef;
  @ViewChildren('capa') capaElementRef1: ElementRef;

  @ViewChild('capa2', { read: ViewContainerRef }) capa2: ViewContainerRef;
  @ViewChild('capa2') capaElementRef2: ElementRef;


  items1: any = [];

  public SetInitialImages_model: number = 0;
  items2: any = [];

  Stub: any[] = [];
  NumberOfStub: number = 0;

  Stub_model: any[] = [];
  NumberOfStub_model: number = 0;

  changecoordinates_flat: any[] = [];
  changecoordinates_model: any[] = [];

  flat_chain_charm_relarionDetails: any;
  model_chain_charm_relationDetails: any;

  identify_number_attached = 0;
  identify_number_hanging = 0;

  pre_click_charmId = 0;

  FLAT_Hanging_value_times = 0;
  MODEL_Hanging_value_times = 0;

  model_details_update = 0;

  public flatimagesPreview;
  public modelimagePreview;

  goldColorCtrl1 = new FormControl();
  goldcolors1: any[];
  filteredGoldColor1: Observable<any[]>;

  viewentirechainlist: any[];
  public chainwidths;
  flat_on: boolean = true;

  numberofcharm: number = 0;
  numberofaddon: number = 0;

  goldcolour = new FormControl();
  studdedtype = new FormControl();
  // studdedtypeList: any[] = [{ name: 'None', value: null }, { name: 'Diamond', value: 'diamond' }, { name: 'Gemstone', value: 'gemstone' }, { name: 'Diamond + Gemstone', value: 'combination' }];
  studdedtypeList: any[] = [];
  gemstonecolor = new FormControl();
  colorpreferances: any[];
  sessionUser: any;

  isspeciallock: boolean = true;

  isbraceletcontainAddon: boolean = false;

  targetimage;

  filtered_braceletid: any;
  filtered_collectionid: any;

  predefinedratedetails;

  DiamodColorcombo;
  Gemstonedetailslist;
  diamondcolorcombinationName;

  gemstonelengthCtrl = new FormControl();
  gemstonelengths: any[];
  filteredgemstonelength: Observable<any[]>;

  selectedKT = "18";
  selectedcolor = '1';
  selectedpurity = '1';
  selectCombocolorpurity = 1 + ',' + 1;
  pdbs_id;
  diamondComboination: any;


  selectedgemstonetype = 1;
  activeclass = 1;

  goldkaratlist;
  ktactiveclass = 18;

  flatbase64Image: any;

  vendorCompanyname;
  vendorquniquekey;
  vendor_id;

  vendorcompanyname;

  disablecalculationsection: boolean = false;
  capturedImage;
  campareurlobjectdata;

  charmform: FormGroup;

  finalcharmoffsetValue = 0;
  finaladdonoffsetValue = 0;


  AddonTopCalculation: number = 0;
  addonchangingValue = 0;

  charmchangingvalue = 0;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private ChaindesignannotationService: ChaindesignannotationService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private vendorCollectionService: VendorCollectionService,
    private _snackBar: MatSnackBar,
    private CustomerAuthenticationService: CustomerAuthenticationService,
    private NavbarservicesService: NavbarservicesService,
    private vendorauthenticationService: VendorAuthenticationService,
    private CustomerOrdersService: CustomerOrdersService,
    private cdRef: ChangeDetectorRef,
    public dialog: MatDialog,
    private renderer: Renderer2,
    private vendorservice: VendorService,
    @Inject(DOCUMENT) private document: Document,
    private resolver: ComponentFactoryResolver,
    public dialogRef: MatDialogRef<SettingUpCharmCoordinateComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    this.charmform = this.data.charmform;
  }

  setFLatDetails(Product_details, up): FormArray {
    const formArray = new FormArray([]);
    Product_details.forEach((s, index) => {
      formArray.push(this.formBuilder.group({
        id: [s.id, Validators.required],
        chaindesign_id: [s.chaindesign_id, Validators.required],
        compontIndex: [s.compontindex],
        flatIndex: [s.flat_index, Validators.required],
        IDNumber: [s.id, Validators.required],
        addFrom: [s.addfrom, Validators.required],
        tooltype: [s.tooltype, Validators.required],
        tool_id: [s.tool_id, Validators.required],
        offsetX: [s.offsetX, Validators.required],
        offsetY: [s.offsetY, Validators.required],
        img_path: [s.img_path, Validators.required],
        isdelete: [s.isdelete, Validators.required]
      }));
      if (s.isdelete === 'N') {
        this.Stub.push(
          { 'id': index, 'flatIndex': s.flat_index, 'addFrom': s.addfrom, 'compontIndex': s.compontindex, 'tooltype': s.tooltype, 'tool_id': s.tool_id, 'offsetX': s.offsetX, 'offsetY': s.offsetY, 'img_path': s.img_path, 'IDNumber': s.id, 'chaindesign_id': s.chaindesign_id, 'charmlength': 65, 'asymetricvalue': s.charmassymetricvalue ? s.charmassymetricvalue : 0 }
        );
      }
      var capa1_load_set = setInterval(() => {
        var cls = '#stubNumber_' + index;
        var cls2 = 'stubNumber_' + index;

        var x = s.offsetX;
        var y = s.offsetY;
        if (document.querySelector(cls)) {

          var parents_elm = document.getElementById(cls2);
          parents_elm.style.position = "absolute";
          parents_elm.style.left = x + 'px';
          parents_elm.style.top = y + 'px';
          if (s.tooltype === 'addon') { parents_elm.style.height = 45 + 'px'; }

          const addonid = "images_of_tools_flat_" + s.tooltype + '_' + s.tool_id + "_" + index;
          var itm = document.getElementById(addonid);
          itm.style.height = s.tooltype == 'charm' ? '65' : s.charmlength + 'px';
          itm.style.width = s.tooltype == 'charm' ? '65' : s.charmlength + 'px';
          var cln = itm.cloneNode(true);
          parents_elm.appendChild(cln);
          this.NumberOfStub++;

          this.WithCurrentFlatPage();
          clearInterval(capa1_load_set)
        }
      }, 0);
    });
    return formArray;
  }

  setModelDetails(Product_details, up): FormArray {
    const formArray = new FormArray([]);
    Product_details.forEach((s, index) => {
      formArray.push(this.formBuilder.group({
        id: [s.id, Validators.required],
        chaindesign_id: [s.chaindesign_id, Validators.required],
        compontIndex: [s.compontindex],
        IDNumber: [s.id, Validators.required],
        addFrom: [s.addfrom, Validators.required],
        tooltype: [s.tooltype, Validators.required],
        tool_id: [s.tool_id, Validators.required],
        toolsLink: [s.tools_link],
        tools_position: [s.tools_position, Validators.required],
        offsetX: [s.offsetX, Validators.required],
        offsetY: [s.offsetY, Validators.required],
        img_path: [s.img_path, Validators.required],
        isdelete: [s.isdelete, Validators.required]
      }));

      if (s.isdelete === 'N') {
        this.Stub_model.push(
          { 'id': index, 'toolsLink': s.tools_link, 'Position': s.tools_position, 'addFrom': s.addfrom, 'compontIndex': s.compontindex, 'tooltype': s.tooltype, 'tool_id': s.tool_id, 'offsetX': s.offsetX, 'offsetY': s.offsetY, 'img_path': s.img_path, 'IDNumber': s.id, 'chaindesign_id': s.chaindesign_id, 'charmlength': 65, 'asymetricvalue': s.charmassymetricvalue ? s.charmassymetricvalue : 0 }
          // { 'id': index, 'toolsLink': s.tools_link, 'Position': s.tools_position, 'addFrom': s.addfrom, 'compontIndex': s.compontindex, 'tooltype': s.tooltype, 'tool_id': s.tool_id, 'offsetX': s.offsetX, 'offsetY': s.offsetY, 'img_path': s.img_path, 'IDNumber': s.id, 'chaindesign_id': s.chaindesign_id, 'charmlength': s.charmlength ? s.charmlength : 65, 'asymetricvalue': 0 }
        );
      }
      var capa1_load = setInterval(() => {
        var cls = '#stubNumber_model_' + s.compontindex;
        var cls2 = 'stubNumber_model_' + s.compontindex;

        var x = s.offsetX;
        var y = s.offsetY;

        if (document.querySelector(cls)) {
          var parents_elm = document.getElementById(cls2);
          parents_elm.style.position = "absolute";
          parents_elm.style.left = x + 'px';
          parents_elm.style.top = y + 'px';
          if (s.tooltype === 'addon') { parents_elm.style.height = 45 + 'px'; }

          const addonid = "images_of_tools_model_" + s.tooltype + "_" + s.tool_id + "_" + index;
          var itm = document.getElementById(addonid);
          itm.style.height = s.tooltype == 'charm' ? '65' : s.charmlength + 'px';
          itm.style.width = s.tooltype == 'charm' ? '65' : s.charmlength + 'px';
          var cln = itm.cloneNode(true);
          parents_elm.appendChild(cln);
          this.NumberOfStub_model++;
          itm.style.height = 65 + 'px';
          itm.style.width = 65 + 'px';

          this.WithCurrentModelPage();
          clearInterval(capa1_load)
        }
      }, 0);
    });
    return formArray;
  }

  public test_map_flat: any[] = [];
  public test_map_model: any[] = [];
  public vendorlogo;
  public selectedreplcementtool = 'chain';

  ngAfterViewInit() {
    // console.log(this.data);
  }

  ModifyCharmYcoordinates = 0;
  InitialCharmYcoordinates = 0;
  CharmTopposition = 0;

  setCharmPerect(movedirection) {
    var attcdcurrentcharm = setInterval(() => {
      var cls = '#stubNumber_' + 0;
      var cls2 = 'stubNumber_' + 0;

      if (document.querySelector(cls)) {
        clearInterval(attcdcurrentcharm)
        var parents_elm = document.getElementById(cls2);

        switch (movedirection) {
          case 'up':
            var incrementcoord = (parseFloat(parents_elm.style.top) + 0.5);
            parents_elm.style.top = incrementcoord + "px";
            this.ModifyCharmYcoordinates = parseFloat(parents_elm.style.top);
            // this.finalcharmoffsetValue = this.ModifyCharmYcoordinates - this.InitialCharmYcoordinates;
            this.charmchangingvalue = this.charmchangingvalue + 0.5;
            break;
          case 'down':
            var incrementcoord = (parseFloat(parents_elm.style.top) - 0.5);
            parents_elm.style.top = incrementcoord + "px";
            this.ModifyCharmYcoordinates = parseFloat(parents_elm.style.top);
            // this.finalcharmoffsetValue = this.ModifyCharmYcoordinates - this.InitialCharmYcoordinates;
            this.charmchangingvalue = this.charmchangingvalue - 0.5;
            break;
        }
      }
    })
  }

  InitialAddonYcoordinates = 0;
  ModifyAddonYcoordinates = 0;
  setAddonPerect(movedirection) {
    var attcdcurrentAddon = setInterval(() => {
      var cls = '#stubNumber_' + 3;
      var cls2 = 'stubNumber_' + 3;

      if (document.querySelector(cls)) {
        clearInterval(attcdcurrentAddon)
        var parents_elm = document.getElementById(cls2);

        switch (movedirection) {
          case 'up':
            var incrementcoord = (parseFloat(parents_elm.style.top) + 0.5);
            parents_elm.style.top = incrementcoord + "px";
            this.ModifyAddonYcoordinates = parseFloat(parents_elm.style.top);
            //this.finaladdonoffsetValue = this.ModifyAddonYcoordinates - this.InitialAddonYcoordinates;
            this.addonchangingValue = this.addonchangingValue + 0.5;
            break;
          case 'down':
            var incrementcoord = (parseFloat(parents_elm.style.top) - 0.5);
            parents_elm.style.top = incrementcoord + "px";
            this.ModifyAddonYcoordinates = parseFloat(parents_elm.style.top);
            // this.finaladdonoffsetValue = this.InitialAddonYcoordinates - this.ModifyAddonYcoordinates;
            this.addonchangingValue = this.addonchangingValue - 0.5;
            break;
        }
      }
    })
  }

  WithCurrentFlatPage() {
    var flatCharmdunamicid;
    this.charmform = this.data.charmform;

    var imageslist = ((this.charmform.get('GoldVariation') as FormArray).controls[0].get('image_position') as FormArray);

    if (imageslist.length > 0) {
      if (imageslist.value.filter((f: any) => f.type == 'flat').length > 0) {
        var filterimage = imageslist.value.filter((f: any) => f.type == 'flat')[0];
        var imagebase64 = filterimage.base64;
        flatCharmdunamicid = "chm_" + (filterimage.name + "_id").replace('.', '_').replace(/\s/g, "");

        this.CreateDynamicHTMLElement(imagebase64, flatCharmdunamicid, this.charmform.get('charmlength').value + "px", this.charmform.get('charmlength').value + "px");

        var attcdcurrentcharm = setInterval(() => {
          var cls = '#stubNumber_' + 0;
          var cls2 = 'stubNumber_' + 0;

          var charmid: string = '#' + flatCharmdunamicid;
          var charmid2 = flatCharmdunamicid;

          if (document.querySelector(cls) && document.querySelector(charmid)) {
            clearInterval(attcdcurrentcharm)
            var parents_elm = document.getElementById(cls2);

            parents_elm.removeChild(parents_elm.lastElementChild);
            const constinitialvlalue = parseFloat(parents_elm.style.top);
            const constinitialLeftvlalue = parseFloat(parents_elm.style.left);
            this.InitialCharmYcoordinates = constinitialvlalue;
            var itm = document.getElementById(charmid2);
            var cln = itm.cloneNode(true);
            parents_elm.appendChild(cln);


            var addontopcoordinates = this.InitialCharmYcoordinates + ((parseFloat(this.charmform.get('charmlength').value) / 4) * 3)
            var attched_lstpstn_top = ((addontopcoordinates - parseFloat(this.charmform.get('charmsyoffset').value)) * (1));

            this.charmchangingvalue = parseFloat(this.charmform.get('asymmetric_position_value').value);
            this.addonchangingValue = parseFloat(this.charmform.get('charmsyoffset').value);
            var addonleftcoordinates = constinitialLeftvlalue + ((parseFloat(this.charmform.get('charmlength').value) - 45) / 2)
            this.AddonTopCalculation = attched_lstpstn_top;
            this.setInitialAddonPosition(attched_lstpstn_top, addonleftcoordinates);

          }
        })
      }
    }
  }

  setInitialAddonPosition(parent_charm_top_coordinate, addonleftcoordinates) {
    var attcdcurrentaddon = setInterval(() => {
      var cls = '#stubNumber_' + 3;
      var cls2 = 'stubNumber_' + 3;

      if (document.querySelector(cls)) {
        clearInterval(attcdcurrentaddon)
        var parents_elm = document.getElementById(cls2);
        parents_elm.style.top = parent_charm_top_coordinate + "px";
        parents_elm.style.left = addonleftcoordinates + "px";
        this.InitialAddonYcoordinates = parent_charm_top_coordinate;
      }
    })
  }

  WithCurrentModelPage() {
    var ModelCharmdunamicid;
    this.charmform = this.data.charmform;

    var imageslist = ((this.charmform.get('GoldVariation') as FormArray).controls[0].get('image_position') as FormArray);

    if (imageslist.length > 0) {
      if (imageslist.value.filter((f: any) => f.type == 'model' && f.position == 'central').length > 0) {
        var filterimage = imageslist.value.filter((f: any) => f.type == 'model' && f.position == 'central')[0];
        var imagebase64 = filterimage.base64;
        ModelCharmdunamicid = "chmodl_" + (filterimage.name + "_id").replace('.', '_').replace(/\s/g, "");

        this.CreateDynamicHTMLElement(imagebase64, ModelCharmdunamicid, this.charmform.get('charmlength').value + "px", this.charmform.get('charmlength').value + "px");

        var attcdcurrentcharm = setInterval(() => {
          var cls = '#stubNumber_model_' + 0;
          var cls2 = 'stubNumber_model_' + 0;

          var charmid: string = '#' + ModelCharmdunamicid;
          var charmid2 = ModelCharmdunamicid;

          if (document.querySelector(cls) && document.querySelector(charmid)) {
            clearInterval(attcdcurrentcharm)
            var parents_elm = document.getElementById(cls2);

            parents_elm.removeChild(parents_elm.lastElementChild);

            var itm = document.getElementById(charmid2);
            var cln = itm.cloneNode(true);
            parents_elm.appendChild(cln);
          }
        })
      }
    }
  }

  async ngOnInit() {

    this.test_map_flat = [
      { id: 0, name: 'Tab1', status: false }
    ];

    this.test_map_model = [
      { id: 0, name: 'Tab1', status: true }
    ];

    const id = 65;

    this.ChaindesignannotationService.getBraceletAnnotationDetails(id).then(
      data => {
        this.isLoading = false;
        var JsonData = JSON.parse(JSON.stringify(data));
        var desingAnnotation = JsonData.desingAnnotation;
        var desingAnnotation_flat = JsonData.desingAnnotation_flat;
        var desingAnnotation_model = JsonData.desingAnnotation_model;
        var chain_Design_flat_relation = JsonData.chain_Design_flat_relation;
        var chain_design_model_relation = JsonData.chain_design_model_relation;

        this.chain_details = desingAnnotation;
        this.chain_flat_details = desingAnnotation_flat;
        this.chain_model_details = desingAnnotation_model;

        // for ralation maintained
        this.flat_chain_charm_relarionDetails = chain_Design_flat_relation;
        this.model_chain_charm_relationDetails = chain_design_model_relation;

        this.chain_flat_details.forEach(element => {
          switch (element.tooltype) {
            case 'charm':
              this.numberofcharm++;
              break;
            case 'addon':
              this.numberofaddon++;
              break;
          }
        });

        this.predefinedbracelettype = desingAnnotation[0].linkballpearl

        switch (desingAnnotation[0].linkballpearl) {
          case 'chain':
            this.ChaindesignannotationService.Chaindesignimages(id).subscribe(data => {
              // this.flatimagesPreview = this.ServerURL + '/images/' + data.flatfileName;
              this.flatimagesPreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.flatfileName;

              this.modelimagePreview = this.ServerURL + '/images/' + data.modelfilename;
              this.chaingoldcolorid = data.goldcolorid;
              this.braceletchaintypeid = data.chain_type_id;

              if (this.chaingoldcolorid > 0 && this.lock_images !== undefined) {
                this.lock_images_filters = this.lock_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
              }
              if (this.chaingoldcolorid > 0 && this.ring_images !== undefined)
                this.ring_images_filters = this.ring_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
            })
            break;
          case 'link':
            this.ChaindesignannotationService.LinkChaindesignimages(id).subscribe(data => {
              // this.flatimagesPreview = this.ServerURL + '/images/' + data.flatfileName;
              this.flatimagesPreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.flatfileName;

              this.modelimagePreview = this.ServerURL + '/images/' + data.modelfilename;
              this.chaingoldcolorid = data.goldcolorid;

              this.braceletchaintypeid = data.chain_type_id;

              if (this.chaingoldcolorid > 0 && this.lock_images !== undefined) {
                this.lock_images_filters = this.lock_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
              }
              if (this.chaingoldcolorid > 0 && this.ring_images !== undefined)
                this.ring_images_filters = this.ring_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
            })
            break;
          case 'ball-pearl':
            this.ChaindesignannotationService.ballpearlChaindesignimages(id).subscribe(data => {
              // this.flatimagesPreview = this.ServerURL + '/images/' + data.flatfileName;
              this.flatimagesPreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.flatfileName;

              this.modelimagePreview = this.ServerURL + '/images/' + data.modelfilename;
              this.chaingoldcolorid = data.goldcolorid;
              this.braceletchaintypeid = data.chain_type_id;


              if (this.chaingoldcolorid > 0 && this.lock_images !== undefined) {
                this.lock_images_filters = this.lock_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
              }
              if (this.chaingoldcolorid > 0 && this.ring_images !== undefined)
                this.ring_images_filters = this.ring_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
            })
            break;
        }

        this.ChaindesignannotationService.loosebraceletpattern(desingAnnotation[0].pre_braceletpattern).subscribe(data => {
          if (data[0]) {
            this.looseBracelettype = (data[0].charm_type).toLowerCase();

            var loosebracelet = setInterval(() => {
              if (this.charm_images_filters_SupportArray) {
                // f.img_view_type == 'flat' &&
                this.charm_images_filters_SupportArray = this.charm_images_filters_SupportArray.filter(f => f.charm_position == this.looseBracelettype)
                clearInterval(loosebracelet);
              }
            }, 0)

            var loosebraceletAddon = setInterval(() => {
              if (this.addon_images_filters_SupportArray) {
                this.addon_images_filters_SupportArray = this.addon_images_filters_SupportArray.filter(f => f.img_view_type == 'flat')
                clearInterval(loosebraceletAddon);
              }
            }, 0)
          }
        })

        this.predefinestructureCtrl.setValue(desingAnnotation[0].pre_braceletpattern);
        this.pdbs_id = desingAnnotation[0].pre_braceletpattern;

        this.targetimage = this.ServerURL + '/images/target_image.jpg';

        this.designForm = this.formBuilder.group({
          id: [desingAnnotation[0].id, Validators.required],
          name: [desingAnnotation[0].predefinedbraceletname, Validators.required],
          pre_braceletpattern: [desingAnnotation[0].pre_braceletpattern, Validators.required],
          loosebraceletPatternid: [desingAnnotation[0].loosebraceletpatternid, Validators.required],
          braceletchain_id: [desingAnnotation[0].braceletchain_id, Validators.required],
          braceletchaintype: [''],
          isdelete: [false, Validators.required],

          delete_flat_images: this.formBuilder.array([]),
          delete_model_images: this.formBuilder.array([]),
          design_tools_charm: [''],
          design_tools_addon: [''],
          design_tools_lock: [''],
          design_tools_ring: [''],
          linkchainlockid: [desingAnnotation[0].lock_id],

          totalprice: [0, Validators.required],
          subtotal: [],
          taxvalue: [],
          gold: [0, Validators.required],
          gemstone: [0, Validators.required],
          diamond: [0, Validators.required],
          margin: [0, Validators.required],
          quantity: [1, Validators.required],
          image: ['', Validators.required],
          image_model: [''],
          producttype: ['collection', Validators.required],
          braceletwidth_id: [1],
          charmstuddedtype: [''],
          //End New Fields
          customerid: [0, Validators.required],
          chainflatImages_id: [desingAnnotation[0].chainflatimages_id, Validators.required],
          chainmodelImages_id: [desingAnnotation[0].chainmodelimages_id, Validators.required],
          clickfromproduct: ['', Validators.required],
          // some additional form fields
          pricerange: [''],
          //end addition fields
          vendorid: [this.vendor_id, Validators.required],

          flat_chain_designAnnotation: this.formBuilder.array([]),
          model_chain_designAnnotation: this.formBuilder.array([]),
          flat_relation_details: this.formBuilder.array([]),
          model_relation_details: this.formBuilder.array([]),

          braceletgoldkt: ['18', Validators.required],
          diamondcolorpuritycombo: ['', Validators.required],
          braceletgemstonetype: ['2'],
          color: ['1'],
          purity: ['1'],
          braceletsize: ['6', Validators.required],

        });

        this.gemstonelengthCtrl.setValue(1)
        var Flat_also_update = 0
        var Model_also_update = 0
        desingAnnotation_flat.forEach(element => {
          if (element.addfrom === 'update')
            Flat_also_update = 1
        });

        desingAnnotation_model.forEach(element => {
          if (element.addfrom === 'update')
            Model_also_update = 1;
          this.model_details_update = 1;
        });

        var capa1_load_onload = setInterval(() => {
          if (this.capa1) {
            clearInterval(capa1_load_onload)
            this.designForm.setControl('flat_chain_designAnnotation', this.setFLatDetails(desingAnnotation_flat, Flat_also_update));
          }
        }, 1000);

        var capa2_load_onload = setInterval(() => {
          if (this.capa2) {
            clearInterval(capa2_load_onload)
            this.designForm.setControl('model_chain_designAnnotation', this.setModelDetails(desingAnnotation_model, Model_also_update));
          }
        }, 1000);
        this.selectedreplcementtool = 'chain';
      }
    );

    this.designForm = this.formBuilder.group({
      id: [0, Validators.required],
      name: ['Bracelet_Design', Validators.required],
      pre_braceletpattern: [0, Validators.required],
      loosebraceletPatternid: [0, Validators.required],
      braceletchain_id: [0, Validators.required],
      braceletchaintype: [''],
      isdelete: [false, Validators.required],

      flat_chain_designAnnotation: this.formBuilder.array([]),
      model_chain_designAnnotation: this.formBuilder.array([]),
      delete_flat_images: this.formBuilder.array([]),
      delete_model_images: this.formBuilder.array([]),

      flat_relation_details: this.formBuilder.array([]),
      model_relation_details: this.formBuilder.array([]),

      design_tools_charm: [''],
      design_tools_addon: [''],
      design_tools_lock: [''],
      design_tools_ring: [''],
      linkchainlockid: [''],
    });
    this.ServerURL = this.metalgoldcolorservice.path;
    window.scroll(0, 0);

  }


  scrollToTop() {
    (function smoothscroll() {
      var currentScroll = document.documentElement.scrollTop || document.body.scrollTop;
      if (currentScroll > 0) {
        window.requestAnimationFrame(smoothscroll);
        window.scrollTo(0, currentScroll - (currentScroll / 8));
      }
    })();
  }

  clickFlat() {
    this.flat_on = true;
    this.test_map_model.forEach(e => {
      e.status = true;
    })
    this.test_map_flat.forEach(e => {
      e.status = true;
      if (e.id === 0) {
        e.status = false
      }
    })

    this.scrollToTop()

  }
  clickmodel() {
    console.log(window.screenTop)

    this.flat_on = false;
    this.test_map_flat.forEach(e => {
      e.status = true;
    })
    this.test_map_model.forEach(e => {
      e.status = true;
      if (e.id === 0) {
        e.status = false
      }
    })
    this.scrollToTop()
  }
  tabChanged(tabChangeEvent: MatTabChangeEvent): void {
    this.activetab = tabChangeEvent.index;
  }

  imagesPreview(image_path: string) {
    // return (this.ServerURL + '/images/' + image_path);
    return this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + image_path
  }

  get Getchain_designAnnotationArray() {
    return this.designForm.get('flat_chain_designAnnotation') as FormArray;
  }

  get GetModel_designAnnotationArray() {
    return this.designForm.get('model_chain_designAnnotation') as FormArray;
  }

  get Delete_flat_fromgroup() {
    return this.designForm.get('delete_flat_images') as FormArray;
  }

  get Delete_model_fromgroup() {
    return this.designForm.get('delete_model_images') as FormArray;
  }

  onSubmit() {

  }


  get f() { return this.designForm.controls; }

  getPosition(el) {
    let x = 0;
    let y = 0;
    while (el && !isNaN(el.offsetLeft) && !isNaN(el.offsetTop)) {
      x += el.offsetLeft - el.scrollLeft;
      y += el.offsetTop - el.scrollTop;
      el = el.offsetParent;
    }
    return { top: y, left: x };
  }

  async CreateDynamicHTMLElement(imgpath, id, width, height): Promise<boolean> {
    var boolean: boolean = true;
    //create the DOM element 
    let img = this.renderer.createElement('img');
    // img.src = this.imagesPreview(imgpath);
    img.src = imgpath;
    img.id = id;
    img.alt = "image";
    img.class = "toolsimages";
    img.style.width = width;
    img.style.height = height;
    img.style.border = 'none';
    await this.renderer.appendChild(this.supportimgelement.nativeElement, img);
    return boolean;
  }

  closepopup() {
    var charmtype = this.charmform.get('charm_type').value;
    this.dialogRef.close({ charm: charmtype == 'asymmetric' ? this.charmchangingvalue : 0, addon: this.addonchangingValue })
  }
}
