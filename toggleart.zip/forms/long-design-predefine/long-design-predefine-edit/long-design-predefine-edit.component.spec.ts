import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LongDesignPredefineEditComponent } from './long-design-predefine-edit.component';

describe('LongDesignPredefineEditComponent', () => {
  let component: LongDesignPredefineEditComponent;
  let fixture: ComponentFixture<LongDesignPredefineEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LongDesignPredefineEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LongDesignPredefineEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
