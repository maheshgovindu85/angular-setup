import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators, FormArray } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs";

import { Producttype } from "@/_models/producttype";
import { producttypeAdd } from "@/_store/producttype/product.actions";

import { AlertService, AuthenticationService, MetalService, VendorAuthenticationService } from "@/_services";
import { ProductTypeService } from "@/_services/product-type.service";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { LongDesignDefinitionService } from "@/_services/long-design-defifnition.service";
import { LongDesignPredefineService } from '@/_services/long-design-predefine.service';
import { environment } from "environments/environment";
import { longDesignPredefine } from "@/_models/longDesignPredefine";
import { CollectionService } from "@/_services/collection.service";
import { VendorService } from "@/_services/vendor.service";
import { MerchantCollectionService } from "@/_services/merchant-collection.service";
@Component({
  selector: "app-long-design-predefine-edit",
  templateUrl: "./long-design-predefine-edit.component.html",
  styleUrls: ["./long-design-predefine-edit.component.css"],
})
export class LongDesignPredefineEditComponent implements OnInit {
  longDesignPredefineEditForm: FormGroup;
  loading = false;
  submitted = false;
  currencies: Observable<Producttype[]>;
  
  productList: any=[];
  list:any=[];
  productSubList:any=[];
  subTypeOptions:any=[]
  selectSubList:any =[];
  longDesignDefinitionFilter: any =[];
  longDesignDefList:any=[];
  dataList:any=[];
  showSubListData: any=[];
  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();
  predefineId:any;
  predefineSetData: any=[];
  modelImage: any;
  partImagePath: any;
  public path = `${environment.apiUrl}`;
  midArray: any = [];
  topArray: any = [];
  dropArray: any = [];
  vendor_id:any;
  getCollectionList: any=[];
  merchant_id:number;
  public adminId=`${environment.adminId}`;
  merchantData: any =[];
  merchantSetData: any =[];
  merchantListAll:any=[];
  merchantListLogin:any;
  merchantCollectionList: any = [];
  filtermerchantCollectionList: any = [];
  filteredProductSubList: any = [];
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private producttypeService: ProductTypeService,
    private LongDesignDefinitionService: LongDesignDefinitionService,
    private LongDesignPredefineService: LongDesignPredefineService,
    private vendorauthenticationService:VendorAuthenticationService,
    private ProductSubTypeService: ProductSubTypeService,
    private collectionService: CollectionService,
    private vendorservices: VendorService,
    private merchantCollectionService: MerchantCollectionService,
    private store: Store<{ producttypes: Producttype[] }>
  ) {
    this.getLongDesignDefiniData();
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id; 
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.predefineId = this.route.snapshot.params.id;    
    this.getCollectionData();
    this.createForm();
    this.getAllPredefineDataByID();
    this.getProductList();    
    this.getMerchantList();
    
    
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.longDesignPredefineEditForm.controls;
  }

  createForm() {
    this.longDesignPredefineEditForm = this.formBuilder.group({
      isactive: [''],
      product_id: ['', Validators.required],
      merchantid: [this.merchant_id],
      product_sub_type: ['', Validators.required],
      collection_id: [''],      
      merchantCollection: [''],
      name: ['', Validators.required],
      description:[''],
      top_part: [''],
      mid_part: [''],
      drop_part: [''],
      designNo: [''],
      multipleImages: this.formBuilder.array([this.Initial_Multiple()]),
    });
  }

  onSubmit() {
    this.submitted = true;
    if (this.longDesignPredefineEditForm.value.merchantid === this.adminId) {
      this.longDesignPredefineEditForm.controls["collection_id"].setValidators(Validators.required);
      this.longDesignPredefineEditForm.controls["merchantCollection"]?.clearValidators();
      this.longDesignPredefineEditForm.controls["merchantCollection"].setErrors(null);
      
    }  else if(this.longDesignPredefineEditForm.value.merchantid !== this.adminId) {
      this.longDesignPredefineEditForm.controls["merchantCollection"].setValidators(Validators.required);
      this.longDesignPredefineEditForm.controls["collection_id"]?.clearValidators();
      this.longDesignPredefineEditForm.controls["collection_id"].setErrors(null);
    }
    if(this.longDesignPredefineEditForm.valid){
      const dataObj = {
        id: this.predefineId,
        merchantid: this.longDesignPredefineEditForm.value.merchantid,
        isactive: this.longDesignPredefineEditForm.value.isactive  === true ? 'Y' :  'N',
        product_id: this.longDesignPredefineEditForm.value.product_id,
        product_subtype_id: this.longDesignPredefineEditForm.value.product_sub_type,
        collection_id: this.longDesignPredefineEditForm.value.collection_id,
        merchantCollection: this.longDesignPredefineEditForm.value.merchantCollection,
        name: this.longDesignPredefineEditForm.value.name,
        description:this.longDesignPredefineEditForm.value.description,
        topval: this.longDesignPredefineEditForm.value.top_part,
        midval: this.longDesignPredefineEditForm.value.mid_part,
        dropval: this.longDesignPredefineEditForm.value.drop_part,
        designno: this.longDesignPredefineEditForm.value.designNo,
        image: this.longDesignPredefineEditForm.value.multipleImages,
      }
      
      this.LongDesignPredefineService.getLongDesignPredefineUpdate(dataObj).subscribe((data: longDesignPredefine) => {
        this.alertService.success('Long Design Predefine updated successfully!', true);
        if(this.vendor_id){
          this.router.navigate(["MerchantlongDesignPredefine/list"]);
        } else{
          this.router.navigate(["longDesignPredefine/list"]);
        }
      });
    }
  }

  //// product  list////

  getProductList() {
    this.producttypeService.getAll().subscribe((data) => {
      if (data) {
        //
        setTimeout(() => {
          this.productList = data;
        });
      }
    });
  }
  //// product  list end////

  
  //// product collection list////

  getCollectionData() {
    this.collectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.getCollectionList = data;
          });
      }
    });
    this.merchantCollectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantCollectionList = data['data'].filter(x => x.isactive == 'Y');
        });
      }
    });
    
  }

  filtermerchantCollection(e:any) {
    let merchantCId = e.value;
    this.longDesignPredefineEditForm.get("merchantCollection")?.setValue("");
    this.filtermerchantCollectionList = this.merchantCollectionList.filter(c => c.merchantid === merchantCId);

  }
  //// product collection list End////

  //// product sub type list////

  getProductSubTypeData() {
    this.ProductSubTypeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.productSubList = this.list.data;
          this.filteredProductSubList = this.productSubList.filter(c=>c.merchantid == this.merchant_id);
          if(this.longDesignPredefineEditForm.value.product_id) {
            this.productOnChange();
          }
          this.subProductOnChange();
          // this.filtermerchantCollection();
        });
      }
    });
  }
  //// product sub type list End////

  ////merchant list

  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          
          this.merchantData = data;

          this.merchantSetData = this.merchantData.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });
          this.merchantListAll = this.merchantSetData;
        });
      }
    });
  }
  ////merchant list
  
  getLongDesignDefiniData(){
    this.LongDesignDefinitionService.getAll()
     .subscribe(data => {
       if (data) {         
        this.dataList = data;
        this.longDesignDefList = this.dataList.data;
        this.longDesignDefinitionFilter = this.longDesignDefList;  
       }
     });
 }

 getAllPredefineDataByID(){
  this.LongDesignPredefineService.getAllPredefineDataById({id: this.predefineId}).subscribe(data => {
    if(data){
      setTimeout(() => {
      this.setFormValue(data);
      this.getProductSubTypeData();    
      });

    }
  })
}

setFormValue(data){
  this.predefineSetData = data.data;  
  this.filtermerchantCollectionList = this.merchantCollectionList.filter(c => c.merchantid === this.predefineSetData[0].merchantid);
  
  this.longDesignPredefineEditForm.get('isactive')?.setValue(this.predefineSetData[0].isactive === 'Y' ? true : false);
  this.longDesignPredefineEditForm.get('product_id')?.setValue(this.predefineSetData[0].product_id);
  this.longDesignPredefineEditForm.get('product_sub_type')?.setValue(this.predefineSetData[0].product_subtype_id);
  this.longDesignPredefineEditForm.get('name')?.setValue(this.predefineSetData[0].name);
  this.longDesignPredefineEditForm.get('description')?.setValue(this.predefineSetData[0].description);
  this.longDesignPredefineEditForm.get('collection_id')?.setValue(this.predefineSetData[0].collection_id);
  this.longDesignPredefineEditForm.get('merchantCollection')?.setValue(this.predefineSetData[0].merchantCollection);
  this.longDesignPredefineEditForm.get('merchantid')?.setValue(this.predefineSetData[0].merchantid);
  this.longDesignPredefineEditForm.get('designNo')?.setValue(this.predefineSetData[0].designno);
  this.longDesignPredefineEditForm.get('top_part')?.setValue(this.predefineSetData[0].topval);
  this.longDesignPredefineEditForm.get('mid_part')?.setValue(this.predefineSetData[0].midval);
  this.longDesignPredefineEditForm.get('drop_part')?.setValue(this.predefineSetData[0].dropval);
  var JsonImgData = this.predefineSetData[0].image;
  var dataOfMultipleImages = JsonImgData;
    this.longDesignPredefineEditForm.setControl(
      "multipleImages",
      this.setImageForm(dataOfMultipleImages)
    );
    
    
}
setImageForm(dataOfMultipleImages): FormArray {
  const formArray = new FormArray([]);
  dataOfMultipleImages.forEach((s) => {
    formArray.push(
      this.formBuilder.group({
        images: [s.images],
        displayUser: [s.displayUser],
        secondOption: [s.secondOption],
      })
    );
  });
  return formArray;
}
  productOnChange(){
    if (this.productSubList.length > 0){
      if(this.longDesignPredefineEditForm.value.product_id != '')
      this.filteredProductSubList = this.productSubList.filter(c=>c.product_id===this.longDesignPredefineEditForm.value.product_id && c.merchantid == this.longDesignPredefineEditForm.value.merchantid);
      else
      this.filteredProductSubList = this.productSubList.filter(c=>c.merchantid == this.longDesignPredefineEditForm.value.merchantid);
    }

  }

 ////
 subProductOnChange() {
  this.showSubListData = this.longDesignDefinitionFilter.filter(c => c.product_sub_type_id === this.longDesignPredefineEditForm.value.product_sub_type);
  // 
  
  for (let i = 0; i <= this.showSubListData.length; i++) {
    if (this.showSubListData[i]?.designpart == "Mid") {
      this.midArray.push({
        label: this.showSubListData[i].partname,
        id: this.showSubListData[i].id
      });

    } else if (this.showSubListData[i]?.designpart == "Top") {
      this.topArray.push({
        label: this.showSubListData[i].partname,
        id: this.showSubListData[i].id
      });
    } else if (this.showSubListData[i]?.designpart == "Drop") {
      this.dropArray.push({
        label: this.showSubListData[i].partname,
        id: this.showSubListData[i].id
      });
    }
  } 
  if(this.predefineSetData[0]) {
  this.longDesignPredefineEditForm.get('top_part')?.setValue(this.predefineSetData[0].topval);
  this.longDesignPredefineEditForm.get('mid_part')?.setValue(this.predefineSetData[0].midval);
  this.longDesignPredefineEditForm.get('drop_part')?.setValue(this.predefineSetData[0].dropval);
  }
}

   /// images ///

   topChange(e: any) {
      
      
    
   }
   selectedFiles(files: File[], index) {
    for (var i = 0; i < files.length; i++) {
      this.fileindexposition++;
      this.FileListMap.set(index, files[i]);
    }
  }

  Initial_Multiple() {
    return this.formBuilder.group({
      images: [''],
      displayUser: [''],
      secondOption: [''],
    });
  }

  get multipleImages() {
    return this.longDesignPredefineEditForm.get('multipleImages') as FormArray;
  }

  removeRow(index: number) {
    this.multipleImages.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  

  onModelImageSelect(files: File[]) {
    var base64valueModel;
    for (var element = 0; element < files.length; element++) {
      const readerModel = new FileReader();
      readerModel.readAsDataURL(files[element]);
      readerModel.onload = (event: any) => {
        if (event.target.result) {
          base64valueModel = event.target.result;
          let dataModelObj = {
            base64format: base64valueModel,
            imagePath: files[0].name,
          };
          this.ProductSubTypeService.upload(dataModelObj).subscribe((data) => {
            this.modelImage = data['data'];
            this.partImagePath = this.path + "/imagepreview/getImage?imagename=" + this.modelImage;
            this.multipleImages.push(
              this.formBuilder.group({
                images: [this.partImagePath],
                displayUser: [''],
                secondOption: [''],
                modelImage: [this.modelImage],
              })
            );

          });


        }
      };
    }
  }



  backToList(){
    if(this.vendor_id){
      this.router.navigate(["MerchantlongDesignPredefine/list"]);
    } else{
      this.router.navigate(["longDesignPredefine/list"]);
    }
  }

  toggledisplayuser(i: number) {
    if(this.longDesignPredefineEditForm.value.multipleImages[i].displayUser == true){
      this.longDesignPredefineEditForm.controls["multipleImages"]["controls"][i].controls["secondOption"].setValue(false);
    }
  }

  togglesecond(i: number) {
    if(this.longDesignPredefineEditForm.value.multipleImages[i].secondOption == true){
      this.longDesignPredefineEditForm.controls["multipleImages"]["controls"][i].controls["displayUser"].setValue(false);
    }
  }

}
