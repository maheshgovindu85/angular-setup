import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LongDesignPredefineListComponent } from './long-design-predefine-list.component';

describe('LongDesignPredefineListComponent', () => {
  let component: LongDesignPredefineListComponent;
  let fixture: ComponentFixture<LongDesignPredefineListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LongDesignPredefineListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LongDesignPredefineListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
