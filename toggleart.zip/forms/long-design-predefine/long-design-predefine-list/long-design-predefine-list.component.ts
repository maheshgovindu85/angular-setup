import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs";

import { Producttype } from "@/_models/producttype";
import { producttypeAdd } from "@/_store/producttype/product.actions";

import { AlertService, AuthenticationService, MetalService } from "@/_services";
import { LongDesignPredefineService } from "@/_services/long-design-predefine.service";
import { LongDesignPredefine } from "@/_models/long-design-predefine";

@Component({
  selector: "app-long-design-predefine-list",
  templateUrl: "./long-design-predefine-list.component.html",
  styleUrls: ["./long-design-predefine-list.component.css"],
})
export class LongDesignPredefineListComponent implements OnInit {
  loading = false;
  submitted = false;
  currencies: Observable<Producttype[]>;
  public isactive: boolean = true;
  longPreDefineList: any = [];
  list: any=[];
  searchForm: FormGroup;
  predefineData:any =[];
  isChecked:boolean;
  activeStatus: any;
  predefineList:  any =[];


  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private LongDesignPredefineService: LongDesignPredefineService ,
    private store: Store<{ producttypes: Producttype[] }>
  ) {
    if (!this.authenticationService.currentUserValue) {
    }
  }

  ngOnInit() {
    this.getPredefineData();
    this.createSearchForm();
   }
 
   getPredefineData(){
      this.LongDesignPredefineService.getAll()
       .subscribe(data => {
         if (data) {
           
           setTimeout(() => {
             this.list = data;
            this.predefineData = this.list.data;
            // console.log("all data..",this.predefineData)
            for(let i =0; i <this.predefineData.length;i++){
             this.predefineData[i].isactive = this.predefineData[i].isactive === 'N' ? false : true;
             this.predefineData[i].SrNo= i+1;
           }
 
            this.predefineList = this.predefineData;
            // console.log("predefine list.....",this.predefineList)
           });
         }
       });
   }
  
 // Search button function start
 createSearchForm() {
   this.searchForm = this.formBuilder.group({
     keyword: [''],
   });
 }
 clear() {
   this.searchForm.get('keyword')?.setValue('');
   this.searchGrid();
 }
 searchGrid() {
   let keyword = this.searchForm.controls['keyword'].value;
   if (keyword === '') {
     this.predefineList = this.predefineData;
   } else {
     keyword = keyword.toLowerCase();
     this.predefineList = this.predefineData.filter((event) => {
       return (
        
          (event.designno === Number(keyword) || event.designno && event.designno.toLowerCase().includes(keyword)) ||
          (event.name && event.name.toLowerCase().includes(keyword))||
          (event.productname && event.productname.toLowerCase().includes(keyword))||
          (event.product_sub_type && event.product_sub_type.toLowerCase().includes(keyword))||
          (event.productname && event.productname.toLowerCase().includes(keyword))||
          (event.collectionName && event.collectionName.toLowerCase().includes(keyword))
         
         
       );
     });
   }
 }
 
 
  
 
 changeStatus(e,data: any){
   this.isChecked = e.checked;
   const dataObj = {
     id: data.id,
     isactive : this.isChecked ? 'Y' : 'N',
   };
   this.LongDesignPredefineService.getLongDesignPredefineUpdate(dataObj).subscribe((data: LongDesignPredefine) => {
     this.getPredefineData();
     this.alertService.success('Status Updated successfully!', true);
   });
 
 }
  
 

 
 

  
}
