import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LongDesignPredefineAddComponent } from './long-design-predefine-add.component';

describe('LongDesignPredefineAddComponent', () => {
  let component: LongDesignPredefineAddComponent;
  let fixture: ComponentFixture<LongDesignPredefineAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LongDesignPredefineAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LongDesignPredefineAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
