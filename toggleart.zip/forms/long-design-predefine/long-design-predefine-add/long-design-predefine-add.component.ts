import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators, FormArray } from "@angular/forms";
import { Router } from "@angular/router";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs";

import { Producttype } from "@/_models/producttype";
import { producttypeAdd } from "@/_store/producttype/product.actions";

import { AlertService, AuthenticationService, MetalService, VendorAuthenticationService } from "@/_services";
import { ProductTypeService } from "@/_services/product-type.service";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { LongDesignDefinitionService } from "@/_services/long-design-defifnition.service";
import { environment } from "environments/environment";
import { longDesignPredefine } from "@/_models/longDesignPredefine";
import { LongDesignPredefineService } from "@/_services/long-design-predefine.service"
import { CollectionService } from "@/_services/collection.service";
import { VendorService } from "@/_services/vendor.service";
import { MerchantCollectionService } from "@/_services/merchant-collection.service";

@Component({
  selector: "app-long-design-predefine-add",
  templateUrl: "./long-design-predefine-add.component.html",
  styleUrls: ["./long-design-predefine-add.component.css"],
})
export class LongDesignPredefineAddComponent implements OnInit {
  longDesignPredefineAddForm: FormGroup;
  loading = false;
  submitted = false;
  currencies: Observable<Producttype[]>;
  public isactive: boolean = true;
  productList: any = [];
  list: any = [];
  productSubList: any = [];
  subTypeOptions: any = []
  selectSubList: any = [];
  longDesignDefinitionFilter: any = [];
  longDesignDefList: any = [];
  dataList: any = [];
  showSubListData: any = [];
  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();

  modelImage: any;
  partImagePath: any;
  public path = `${environment.apiUrl}`;
  midArray: any = [];
  topArray: any = [];
  dropArray: any = [];
  vendor_id: any;
  getCollectionList: any = [];
  merchant_id: number;
  public adminId = `${environment.adminId}`;
  merchantData: any = [];
  merchantSetData: any = [];
  merchantListAll: any = [];
  merchantListLogin: any;
  merchantCollectionList: any = [];
  filtermerchantCollectionList: any = [];
  filteredProductSubList: any = [];
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private producttypeService: ProductTypeService,
    private LongDesignDefinitionService: LongDesignDefinitionService,
    private ProductSubTypeService: ProductSubTypeService,
    private LongDesignPredefineService: LongDesignPredefineService,
    private vendorauthenticationService: VendorAuthenticationService,
    private collectionService: CollectionService,
    private vendorservices: VendorService,
    private merchantCollectionService: MerchantCollectionService,
    private store: Store<{ producttypes: Producttype[] }>
  ) {
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.createForm();
    this.getProductList();
    this.getMerchantList();
    this.getCollectionData();
    this.getProductSubTypeData();
    this.getLongDesignDefiniData();
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.longDesignPredefineAddForm.controls;
  }

  createForm() {
    this.longDesignPredefineAddForm = this.formBuilder.group({
      product_id: ['', Validators.required],
      merchantid: [this.merchant_id],
      product_sub_type: ['', Validators.required],
      collection_id: [''],
      merchantCollection: [''],
      name: ['', Validators.required],
      description: [''],
      top_part: [''],
      mid_part: ['',],
      drop_part: ['',],
      designNo: ['', Validators.required],
      multipleImages: this.formBuilder.array([this.Initial_Multiple()]),
    });
  }

  onSubmit() {
    this.submitted = true;
    this.longDesignPredefineAddForm.value.multipleImages.shift();
    if (this.longDesignPredefineAddForm.value.merchantid === this.adminId) {
      this.longDesignPredefineAddForm.controls["collection_id"].setValidators(Validators.required);
      this.longDesignPredefineAddForm.controls["merchantCollection"]?.clearValidators();
      this.longDesignPredefineAddForm.controls["merchantCollection"].setErrors(null);
      
    }  else if(this.longDesignPredefineAddForm.value.merchantid !== this.adminId) {
      this.longDesignPredefineAddForm.controls["merchantCollection"].setValidators(Validators.required);
      this.longDesignPredefineAddForm.controls["collection_id"]?.clearValidators();
      this.longDesignPredefineAddForm.controls["collection_id"].setErrors(null);
    }
    if (this.longDesignPredefineAddForm.valid) {
      const dataObj = {
        product_id: this.longDesignPredefineAddForm.value.product_id,
        merchantid: this.longDesignPredefineAddForm.value.merchantid,
        product_subtype_id: this.longDesignPredefineAddForm.value.product_sub_type,
        collection_id: this.longDesignPredefineAddForm.value.collection_id,
        merchantCollection: this.longDesignPredefineAddForm.value.merchantCollection,
        name: this.longDesignPredefineAddForm.value.name,
        description: this.longDesignPredefineAddForm.value.description,
        topval: this.longDesignPredefineAddForm.value.top_part,
        midval: this.longDesignPredefineAddForm.value.mid_part,
        dropval: this.longDesignPredefineAddForm.value.drop_part,
        designno: this.longDesignPredefineAddForm.value.designNo,
        image: this.longDesignPredefineAddForm.value.multipleImages,
      }
      this.LongDesignPredefineService.save(dataObj).subscribe((data: longDesignPredefine) => {
        this.alertService.success('Long Design Predefine saved successfully!', true);
        if (this.vendor_id) {
          this.router.navigate(["MerchantlongDesignPredefine/list"]);
        } else {
          this.router.navigate(["longDesignPredefine/list"]);
        }
      });

    }

  }

  //// product  list////

  getProductList() {
    this.producttypeService.getAll().subscribe((data) => {
      if (data) {
        //
        setTimeout(() => {
          this.productList = data;
        });
      }
    });
  }
  //// product  list end////

  //// product collection list////

  getCollectionData() {
    this.collectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.getCollectionList = data;
        });
      }
    });
    this.merchantCollectionService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantCollectionList = data['data'].filter(x => x.isactive == 'Y');
          this.filtermerchantCollectionList = this.merchantCollectionList.filter(c => c.merchantid === this.merchant_id);
        });
      }
    });
  }

  filtermerchantCollection() {
    this.productOnChange();
    this.filtermerchantCollectionList = this.merchantCollectionList.filter(c => c.merchantid === this.longDesignPredefineAddForm.value.merchantid);
  }

  //// product collection list End////

  //// product sub type list////

  getProductSubTypeData() {
    this.ProductSubTypeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.productSubList = this.list.data;
          this.filteredProductSubList = this.productSubList.filter(c => c.merchantid == this.merchant_id);
          if (this.longDesignPredefineAddForm.value.product_id) {
            this.productOnChange();
          }
          this.filtermerchantCollection();
        });
      }
    });
  }
  //// product sub type list End////

  ////merchant list

  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {

          this.merchantData = data;

          this.merchantSetData = this.merchantData.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });
          this.merchantListAll = this.merchantSetData;
        });
      }
    });
  }
  ////merchant list


  getLongDesignDefiniData() {
    this.LongDesignDefinitionService.getAll()
      .subscribe(data => {
        if (data) {
          setTimeout(() => {
            this.dataList = data;
            this.longDesignDefList = this.dataList.data;
            this.longDesignDefinitionFilter = this.longDesignDefList;
          });
        }
      });
  }

  productOnChange() {
    // let produdtId = event.value
    // this.selectSubList = this.productSubList.filter(c => c.product_id === produdtId);
    // let itm = this.selectSubList[0];
    // this.longDesignPredefineAddForm.controls['product_sub_type'].setValue(itm.product_id);
    if (this.productSubList.length > 0) {
      if (this.longDesignPredefineAddForm.value.product_id != '')
        this.filteredProductSubList = this.productSubList.filter(c => c.product_id === this.longDesignPredefineAddForm.value.product_id && c.merchantid == this.longDesignPredefineAddForm.value.merchantid);
      else
        this.filteredProductSubList = this.productSubList.filter(c => c.merchantid == this.longDesignPredefineAddForm.value.merchantid);
    }


  }

  ////
  subProductOnChange(event) {
    let subProductId = event.value
    console.log(subProductId);

    this.showSubListData = this.longDesignDefinitionFilter.filter(c => c.product_sub_type_id == subProductId);
    console.log(this.showSubListData);
    this.showSubListData.map(val => {
      if (val.designpart == "Mid") {
        this.midArray.push({
          label: val.partname,
          id: val.id
        })
        console.log(this.midArray);
        
      } else if (val.designpart == "Top") {
        this.topArray.push({
          label: val.partname,
          id: val.id
        });
      } else if (val.designpart == "Drop") {
        this.dropArray.push({
          label: val.partname,
          id: val.id
        });
      }
    })
  }

  /// images ///

  selectedFiles(files: File[], index) {
    for (var i = 0; i < files.length; i++) {
      this.fileindexposition++;
      this.FileListMap.set(index, files[i]);
    }
  }

  Initial_Multiple() {
    return this.formBuilder.group({
      images: [''],
      displayUser: [''],
      secondOption: [''],
    });
  }

  get multipleImages() {
    return this.longDesignPredefineAddForm.get('multipleImages') as FormArray;
  }

  removeRow(index: number) {
    this.multipleImages.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }


  onModelImageSelect(files: File[]) {
    var base64valueModel;
    for (var element = 0; element < files.length; element++) {
      const readerModel = new FileReader();
      readerModel.readAsDataURL(files[element]);
      readerModel.onload = (event: any) => {
        if (event.target.result) {
          base64valueModel = event.target.result;
          let dataModelObj = {
            base64format: base64valueModel,
            imagePath: files[0].name,
          };
          this.ProductSubTypeService.upload(dataModelObj).subscribe((data) => {
            this.modelImage = data['data'];
            this.partImagePath = this.path + "/imagepreview/getImage?imagename=" + this.modelImage;
            this.multipleImages.push(
              this.formBuilder.group({
                images: [this.partImagePath],
                displayUser: [''],
                secondOption: [''],
                modelImage: [this.modelImage],
              })
            );

          });



        }
      };
    }
  }

  toggledisplayuser(i: number) {
    if (this.longDesignPredefineAddForm.value.multipleImages[i].displayUser == true) {
      this.longDesignPredefineAddForm.controls["multipleImages"]["controls"][i].controls["secondOption"].setValue(false);
    }
  }

  togglesecond(i: number) {
    if (this.longDesignPredefineAddForm.value.multipleImages[i].secondOption == true) {
      this.longDesignPredefineAddForm.controls["multipleImages"]["controls"][i].controls["displayUser"].setValue(false);
    }
  }

  backToList() {
    if (this.vendor_id) {
      this.router.navigate(["MerchantlongDesignPredefine/list"]);
    } else {
      this.router.navigate(["longDesignPredefine/list"]);
    }
  }



}
