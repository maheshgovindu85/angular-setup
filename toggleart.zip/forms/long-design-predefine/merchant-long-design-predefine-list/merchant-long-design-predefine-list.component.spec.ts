import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantLongDesignPredefineListComponent } from './merchant-long-design-predefine-list.component';

describe('MerchantLongDesignPredefineListComponent', () => {
  let component: MerchantLongDesignPredefineListComponent;
  let fixture: ComponentFixture<MerchantLongDesignPredefineListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantLongDesignPredefineListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantLongDesignPredefineListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
