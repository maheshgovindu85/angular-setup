import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs";

import { Producttype } from "@/_models/producttype";
import { producttypeAdd } from "@/_store/producttype/product.actions";

import { AlertService, AuthenticationService, MetalService, VendorAuthenticationService } from "@/_services";
import { LongDesignPredefineService } from "@/_services/long-design-predefine.service";
import { LongDesignPredefine } from "@/_models/long-design-predefine";

@Component({
  selector: "app-merchant-long-design-predefine-list",
  templateUrl: "./merchant-long-design-predefine-list.component.html",
  styleUrls: ["./merchant-long-design-predefine-list.component.css"],
})
export class MerchantLongDesignPredefineListComponent implements OnInit {
  loading = false;
  submitted = false;
  currencies: Observable<Producttype[]>;
  public isactive: boolean = true;
  longPreDefineList: any = [];
  list: any=[];
  searchForm: FormGroup;
  merchantPredefineData:any =[];
  isChecked:boolean;
  activeStatus: any;
  filterMerchantPredefineList:  any =[];
  vendor_id: number;


  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private LongDesignPredefineService: LongDesignPredefineService ,
    private vendorauthenticationService: VendorAuthenticationService,

  ) {
    if (!this.vendorauthenticationService.vendorcurrentUserValue) {
      this.router.navigate(['merchant']);
    }
  }

  ngOnInit() {
    this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id;

    this.getPredefineData();
    this.createSearchForm();
   }
 
   getPredefineData(){
    const dataObj = {
      merchantid : this.vendor_id
    }
      this.LongDesignPredefineService.getMerchantPredefineDataById(dataObj)
       .subscribe(data => {
         if (data) {
           setTimeout(() => {
             this.list = data;
            this.merchantPredefineData = this.list.data;
            for(let i =0; i <this.merchantPredefineData.length;i++){
             this.merchantPredefineData[i].isactive = this.merchantPredefineData[i].isactive === 'N' ? false : true;
             this.merchantPredefineData[i].SrNo= i+1;
           }
 
            this.filterMerchantPredefineList = this.merchantPredefineData;
            
           });
         }
       });
   }
  
 // Search button function start
 createSearchForm() {
   this.searchForm = this.formBuilder.group({
     keyword: [''],
   });
 }
 clear() {
   this.searchForm.get('keyword')?.setValue('');
   this.searchGrid();
 }
 searchGrid() {
   let keyword = this.searchForm.controls['keyword'].value;
   if (keyword === '') {
     this.filterMerchantPredefineList = this.merchantPredefineData;
   } else {
     keyword = keyword.toLowerCase();
     this.filterMerchantPredefineList = this.merchantPredefineData.filter((event) => {
       return (
        (event.designno && event.designno.toLowerCase().includes(keyword)) ||
         (event.name && event.name.toLowerCase().includes(keyword)) ||
         (event.product_name && event.product_name.toLowerCase().includes(keyword))||
         (event.product_sub_type && event.product_sub_type.toLowerCase().includes(keyword)) ||
         (event.collectionName && event.collectionName.toLowerCase().includes(keyword))
       );
     });
   }
 }
 
 
  
 
 changeStatus(e,data: any){
   this.isChecked = e.checked;
   const dataObj = {
     id: data.id,
     isactive : this.isChecked ? 'Y' : 'N',
   };
   this.LongDesignPredefineService.getLongDesignPredefineUpdate(dataObj).subscribe((data: LongDesignPredefine) => {
     this.getPredefineData();
     this.alertService.success('Status Updated successfully!', true);
   });
 
 }
  
 

 
 

  
}
