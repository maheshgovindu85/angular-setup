import { ChaindesignannotationService } from '@/_services/chaindesignannotation.service';
import { CustomerAuthenticationService } from '@/_services/customer-authentication.service';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { CustomerOrdersService } from '../customer-orders.service';

import { Component, OnInit, ViewChild } from '@angular/core';

import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

import { AlertService, AuthenticationService, EncryptDecryptService, AddonService } from '@/_services';
import * as moment from 'moment';

@Component({
  selector: 'app-clientorders',
  templateUrl: './clientorders.component.html',
  styleUrls: ['./clientorders.component.css']
})
export class ClientordersComponent implements OnInit {


  AddonFilterForm: FormGroup;
  searchForm: FormGroup;
  dataSource: MatTableDataSource<any>;
  closeResult: string;
  search_text = "";
  merchantCustOrder:any= [];
  filterCustomerOrderList:any=[];

  displayedColumns: string[] = ['orderid', 'customer', 'date', 'amount', 'status', 'actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private CustomerAuthenticationService: CustomerAuthenticationService,
    private CustomerOrdersService: CustomerOrdersService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private ChaindesignannotationService: ChaindesignannotationService,

    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private addonService: AddonService,
  ) {
    // if (!this.authenticationService.currentUserValue) {
    //   this.router.navigate(['login']);
    // }

    this.AddonFilterForm = formBuilder.group({
      search_text: ''
    });

    this.AddonFilterForm.valueChanges.subscribe(value => {
      
      const filter = {
        ...value,
        search_text: value.search_text.trim().toLowerCase()
      } as string;
      
      this.dataSource.filter = filter;
    });
  }

  ngOnInit(): void {
    this.createSearchForm();
  }

  showorderdtl(orderid, orderdtid) {
    this.router.navigate(['customerorders/view/', orderid, orderdtid]);
  }

  ngAfterViewInit() {
    this.ChaindesignannotationService.customerorderlist()
      .subscribe(data => {
        if (data) {
          // 
          setTimeout(() => {
            this.dataSource = new MatTableDataSource(data);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
            this.merchantCustOrder = data;
            this.filterCustomerOrderList= this.merchantCustOrder;
            
            for(let i =0; i <this.merchantCustOrder.length;i++){
              const date = moment(this.merchantCustOrder[i].odrerdate).format('MM/DD/YYYY HH:mm');
              this.merchantCustOrder[i].odrerdate = date;
              
            }
            this.dataSource.filterPredicate = ((data, filter) => {
              const a = !filter.search_text
                || data.orderid.toString().trim().toLowerCase().includes(filter.search_text)
                || data.status.toString().trim().toLowerCase().includes(filter.search_text)
                || data.odrerdate.toString().trim().toLowerCase().includes(filter.search_text)
                || data.totalprice.toString().trim().toLowerCase().includes(filter.search_text)
                || data.customername.toString().trim().toLowerCase().includes(filter.search_text)
                ;
              return a;
            }) as (PeriodicElement, string) => boolean;
          });
        }
      });
  }

  // Search button function start
  createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [''],
    });
  }
  clear() {
    this.searchForm.get('keyword')?.setValue('');
    this.searchGrid();
  }
  searchGrid() {
    let keyword = this.searchForm.controls['keyword'].value;
    if (keyword === '') {
      this.filterCustomerOrderList = this.merchantCustOrder;
    } else {
      keyword = keyword.toLowerCase();
      this.filterCustomerOrderList = this.merchantCustOrder.filter((event) => {
        return (
          (event.orderid ===Number(keyword))
          ||(event.customername && event.customername.toLowerCase().includes(keyword)) ||
          (event.odrerdate === Number(keyword) || event.odrerdate && event.odrerdate.toLowerCase().includes(keyword) ) ||
          (event.totalprice && event.totalprice.toLowerCase().includes(keyword)) ||
          (event.status && event.status.toLowerCase().includes(keyword))
        );
      });
    }
  }
}
