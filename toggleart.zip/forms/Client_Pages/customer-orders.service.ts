import { CustomerOrder } from '@/_models/customer-order';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';


const state = {
  wishlist: JSON.parse(localStorage['wishlistItems'] || '[]'),
  compare: JSON.parse(localStorage['compareItems'] || '[]'),
  cart: JSON.parse(localStorage['cartItems'] || '[]')
}

@Injectable({
  providedIn: 'root'
})
export class CustomerOrdersService {

  constructor(private http: HttpClient) { }

  addtocart(product: any) {
    let localCartItems =localStorage.getItem('cartItems');
    if(!localCartItems){
    localStorage.setItem("cartItems", JSON.stringify([product]));
    
    } else{
      state.cart = JSON.parse(localCartItems);
      state.cart.push(product);
      localStorage.setItem("cartItems", JSON.stringify(state.cart));
      
    }
    return true;
  }

  public get getcartproduct() {
    
    const itemsStream = state.cart;
    return itemsStream;
  }

  cartlistlength() {
    var list: any = JSON.parse(localStorage.getItem("cartItems"));
    return list ? list.length : 0;
  }
  comparelistlength() {
    var list: any = JSON.parse(localStorage.getItem("compareItems"));
    return list ? list.length : 0;
  }
 
  // Remove Compare items
  public removeCartItem(product: any): any {
    state.cart.forEach((element, index) => {
      if (product.predefinedata.id == element.predefinedata.id) {
        state.cart.splice(index, 1);
      }
    });
    localStorage.setItem("cartItems", JSON.stringify(state.cart));
    return true
  }

  addtocompare(product: any) {
    let localCompareItems =localStorage.getItem('compareItems');
    if(!localCompareItems){
    localStorage.setItem("compareItems", JSON.stringify([product]));
    } else{
      state.compare = JSON.parse(localCompareItems);
      state.compare.push(product);
      localStorage.setItem("compareItems", JSON.stringify(state.compare));
    }
    return true
    
  }

  // Remove Compare items
  public removeCompareItem(product: any): any {
    state.compare.forEach((element, index) => {
      if (product.predefinedata.id == element.predefinedata.id) {
        state.compare.splice(index, 1);
        localStorage.setItem("compareItems", JSON.stringify(state.compare));
      }
    });
    return true
  }

  public get getcompareproduct() {
    const itemsStream = state.compare
    return itemsStream;
  }

  compareList() {
    var list: any = JSON.parse(localStorage.getItem("compareItems"));
    return list;
  }

  cartList() {
    var list: any = JSON.parse(localStorage.getItem("cartItems"));
    return list;
  }

  // public get getcompareproduct(): Observable<any[]> {
  //   const itemsStream = new Observable(observer => {
  //     observer.next(state.compare);
  //     observer.complete();
  //   });
  //   return <Observable<any[]>>itemsStream;
  // }

  addtowishlist(product: any) {
    if (Number(product.id)) {
      const wishlistItem = state.wishlist.find(item => ((item.id === product.id) && (item.producttype == product.producttype)))
      if (!wishlistItem) {
        state.wishlist.push({
          ...product
        })
      }
      // this.toastrService.success('Product has been added in wishlist.');
      localStorage.setItem("wishlistItems", JSON.stringify(state.wishlist));
      return true
    }
  }

  public get wishlist() {
    // const itemsStream = new Observable(observer => {
    //   observer.next(state.wishlist);
    //   observer.complete();
    // });
    // return <Observable<any[]>>itemsStream;
    const itemsStream = state.wishlist;
    return itemsStream;
  }

  // Remove Wishlist items
  public removeWishlistItem(product: any): any {
    const index = state.wishlist.indexOf(product);
    state.wishlist.splice(index, 1);
    localStorage.setItem("wishlistItems", JSON.stringify(state.wishlist));
    return true
  }

  checkoutOrder(CustomerOrder: CustomerOrder) {
    return this.http.post(`${environment.newapiUrl}/addCustomerOrder`, CustomerOrder);
  }

  getCustomerOrderDetail(merchant_id) {
    return this.http.post<any[]>(`${environment.newapiUrl}/getCustomerOrderDetail`, merchant_id);
  }
  getCustomerOrder(merchant_id) {
    return this.http.post<any[]>(`${environment.newapiUrl}/getCustomerOrder`, merchant_id);
  }

  getCustomerOrderDetailbyid(id) {
    return this.http.post<any[]>(`${environment.newapiUrl}/getCustomerOrderDetailbyid`, id);
  }


}
