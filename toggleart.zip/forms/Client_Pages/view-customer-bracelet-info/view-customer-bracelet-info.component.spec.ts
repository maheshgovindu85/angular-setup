import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCustomerBraceletInfoComponent } from './view-customer-bracelet-info.component';

describe('ViewCustomerBraceletInfoComponent', () => {
  let component: ViewCustomerBraceletInfoComponent;
  let fixture: ComponentFixture<ViewCustomerBraceletInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewCustomerBraceletInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCustomerBraceletInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
