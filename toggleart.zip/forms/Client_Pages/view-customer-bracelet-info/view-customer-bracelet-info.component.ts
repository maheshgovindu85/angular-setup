import { VendorAuthenticationService, VendorCollectionService } from '@/_services';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { Component, ElementRef, Inject, OnInit, Output, ViewChild } from '@angular/core';
import { ProductDetailsMainSlider, ProductDetailsThumbSlider } from '@/_models/collection';

// 
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';
import { EventEmitter } from 'events';
import { ChaindesignannotationService } from '@/_services/chaindesignannotation.service';
import { CustomerAuthenticationService } from '@/_services/customer-authentication.service';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

export interface DialogData {
  gold: string;
  goldkt: string;
  id: string;
  diamond: string;
  gemstone: string;
  design: any;
  vendor_id: any;
}
@Component({
  selector: 'app-view-customer-bracelet-info',
  templateUrl: './view-customer-bracelet-info.component.html',
  styleUrls: ['./view-customer-bracelet-info.component.css']
})
export class ViewCustomerBraceletInfoComponent implements OnInit {

  disablecalculationsection: boolean = false;
  designForm: FormGroup;
  collection: any;
  @ViewChild('videoPlayer') videoplayer: ElementRef;
  public serviceurl;
  public collectiondiamonddetails;

  public Product_images: any[];
  public product: any[] = [];
  public counter: number = 1;
  public activeSlide: any = 0;
  public selectedSize: any;
  public mobileSidebar: boolean = false;
  pictures: any[] = [];
  currentPicture;
  sessionUser: any;

  //Gold
  netgoldkt: any = 0;
  netgoldweight: any = 0;
  ratepergm: any;
  goldprice: any;
  //Diamond
  colorpurity: any;
  diamondwt: any;
  diamondprice: any;
  //Gemstone
  gemstonetype: any;
  gemstoneieces: any = 0;
  gemstoneprice: any = 0;
  //Makingcharges
  makingchargesprice: any;
  diamondComboination: any;

  goldratesdetails: any;
  totalgoldweight = 0;
  ratepergramgold = 0;

  diamondratesdetails: any;
  totaldiamondwt: any = 0;
  totaldiamonrate: any = 0;

  gemstoneratesdetails: any;
  gemstonepieces: any = 0;
  gemstonetotaleates: any = 0;
  public BraceletPrices: any[] = [{ diamondwt: 0 }, { gemstonewt: 0 }, { goldwt: 0 }];
  public braceletgoldktlist: any;
  public totalpriceofbracelet = 0.00;
  public braceletgoldperoperties;

  predefinedratedetails;

  DiamodColorcombo;
  Gemstonedetailslist;
  diamondcolorcombinationName;

  gemstonelengthCtrl = new FormControl();
  gemstonelengths: any[];
  filteredgemstonelength: Observable<any[]>;

  public ProductDetailsMainSliderConfig: any = ProductDetailsMainSlider;
  public ProductDetailsThumbConfig: any = ProductDetailsThumbSlider;

  selectedKT = "18";
  selectedcolor = '1';
  selectedpurity = '1';
  selectCombocolorpurity = '1' + ',' + '1';
  selectedgemstonetype = 1;
  pdbs_id;
  activeclass = 1;

  goldkaratlist;
  ktactiveclass = 18;

  showpricebreakup: boolean = false;
  vendor_id;


  constructor(
    public dialogRef: MatDialogRef<ViewCustomerBraceletInfoComponent>,
    private metalgoldcolorservice: MetalgoldcolorService,
    private vendorCollectionService: VendorCollectionService,
    private ChaindesignannotationService: ChaindesignannotationService,
    private CustomerAuthenticationService: CustomerAuthenticationService,
    private vendorauthenticationService: VendorAuthenticationService,
    private route: ActivatedRoute,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) {
    this.currentPicture = 0;
    this.serviceurl = metalgoldcolorservice.path;
    this.designForm = data.design;
    this.vendor_id = data.vendor_id

    // if (CustomerAuthenticationService.customercurrentUserValue)
    //   this.sessionUser = CustomerAuthenticationService.customercurrentUserValue;

    // if (this.vendorauthenticationService.vendorcurrentUserValue)
    //   this.sessionUser = this.vendorauthenticationService.vendorcurrentUserValue;

    // ChaindesignannotationService.getbraceleteLength().subscribe(
    //   (data) => {
    //     this.gemstonelengths = data;
    //     this.filteredgemstonelength = this.gemstonelengthCtrl.valueChanges
    //       .pipe(
    //         startWith(''),
    //         map(coll => coll ? this.filterGemstonelength(coll) : this.gemstonelengths.slice()),
    //       );
    //   });

    ChaindesignannotationService.predefinedkaratlist(data.id).subscribe(data => {
      this.goldkaratlist = data;
    })

    ChaindesignannotationService.GetDiamondColorPurityCombo(this.vendor_id).subscribe(data => {
      this.DiamodColorcombo = data;
    })

    ChaindesignannotationService.getgemstonetypedetails().subscribe(data => {
      this.Gemstonedetailslist = data;
    })

    vendorCollectionService.getVendorCollectionDiamond(data.id).subscribe(data => {
      this.collectiondiamonddetails = data;
    })

    this.serviceurl = metalgoldcolorservice.path;
    // if (CustomerAuthenticationService.customercurrentUserValue)
    //   this.sessionUser = CustomerAuthenticationService.customercurrentUserValue;

    // if (this.vendorauthenticationService.vendorcurrentUserValue)
    //   this.sessionUser = this.vendorauthenticationService.vendorcurrentUserValue;

    this.MakeCalculation(data.id, this.vendor_id, "18", "6", "1", "1", "1");
    this.pdbs_id = data.id;

    this.gemstonelengthCtrl.setValue(1)

    vendorCollectionService.getpredefinedentireimages(data.id).subscribe(
      data => {
        this.Product_images = data;
        this.Product_images.forEach((element, index) => {
          // this.product.push(
          //   { 'src': this.serviceurl + '/images/' + element.img_path, 'content_type': this.extension(element.img_path), 'active': (index === 0) ? true : false }
          // )
          this.pictures.push({ 'id': index, 'src': this.serviceurl + '/images/' + element.img_path, 'media_type': this.extension(element.img_path), 'activethm': index <= 3 ? true : false });
        });
      }
    )


    this.gemstonelengthCtrl.valueChanges.subscribe(data => {
      this.MakeCalculation(this.pdbs_id, this.vendor_id, this.selectedKT, data, this.selectedcolor, this.selectedpurity, this.selectedgemstonetype)
    })

  }

  chooseBraceletsize(id) {
    this.activeclass = id;
    this.gemstonelengthCtrl.setValue(id);
  }

  getGemstonetypeName(id: any) {
    return this.Gemstonedetailslist.filter(f => f.id == id)[0].type_name;
  }

  changeGoldCarat(kt) {
    this.selectedKT = kt;
    this.ktactiveclass = kt;
    this.MakeCalculation(this.pdbs_id, this.vendor_id, this.selectedKT, this.gemstonelengthCtrl.value, this.selectedcolor, this.selectedpurity, this.selectedgemstonetype)
  }

  changecolorpurity(id) {
    var a: any = this.DiamodColorcombo.filter(f => f.comboid == id)[0];
    a.colorname + " - " + a.purityname;

    this.selectedcolor = a.colorid;
    this.selectedpurity = a.purityid;

    this.selectCombocolorpurity = id;

    this.MakeCalculation(this.pdbs_id, this.vendor_id, this.selectedKT, this.gemstonelengthCtrl.value, this.selectedcolor, this.selectedpurity, this.selectedgemstonetype)
  }

  changeGemstonetype(id) {
    this.selectedgemstonetype = id;

    this.MakeCalculation(this.pdbs_id, this.vendor_id, this.selectedKT, this.gemstonelengthCtrl.value, this.selectedcolor, this.selectedpurity, this.selectedgemstonetype)
  }
  finalvalue = 0;
  MakeCalculation(pdbs_id, vendor_id, kt, braceletsize, color, purity, type) {
    this.disablecalculationsection = true;
    if (this.gemstonelengths) {
      braceletsize = this.gemstonelengths.filter(f => f.id == braceletsize)[0].length
    }
    this.vendorCollectionService.getpredefinedentireRates(pdbs_id, vendor_id, kt, braceletsize, color, purity, type).then(data => {
      this.disablecalculationsection = false;
      this.predefinedratedetails = data;

      var fianl = this.predefinedratedetails.price + (this.predefinedratedetails.price / 100) * 3
      this.finalvalue = Math.round(fianl);
      this.gemstonelengths = this.predefinedratedetails.braceletelength;
    }, error => this.disablecalculationsection = false)
  }

  getDimondcolor(colorid: any, purityid: any) {
    var a: any = this.DiamodColorcombo.filter(f => f.colorid == colorid && f.purityid == purityid)[0];
    return a.colorname + " - " + a.purityname;
  }

  Changecolorpurity() {

    var checkcolorcombo = setInterval(() => {
      if (this.designForm.get('diamondcolorpuritycombo').value != '') {
        clearInterval(checkcolorcombo)
        this.diamondComboination.forEach(element => {
          if (element.comboid == this.designForm.get('diamondcolorpuritycombo').value) {
            this.diamondcolorcombinationName = element.colorname + "/" + element.purityname
          }
        });
      }
    }, 0);
    return this.diamondcolorcombinationName;
  }

  extension(str: string) {
    if (str.includes('png') || str.includes('jpeg') || str.includes('raw') || str.includes('jpg'))
      return 'Image';
    else
      return 'Video';
  }

  closemodal(): void {
    this.dialogRef.close(this.designForm);
  }

  toggleVideo(event: any) {
    this.videoplayer.nativeElement.play();
  }
  getvedioBute(filename) {
    return this.serviceurl + '/images/' + filename;
  }

  ngOnInit(): void {
  }

  ChangeImages(ind) {
    this.product[ind].active = true;

    this.product.forEach((elenemt, index) => {
      if (index === ind) {
        this.product[ind].active = true;
      } else {
        this.product[index].active = false;
      }
    })
  }

  customOptions2: any = {
    items: 1,
    nav: false,
    dots: false,
    autoplay: false,
    slideSpeed: 300,
    loop: true
  }

  select(index) {
    this.currentPicture = index;
  }


  selectArrow() {
    if (this.currentPicture < this.pictures.length - 1) {
      this.currentPicture++;
    } else {
      this.currentPicture = 0;
    }
  }

  selectLeftArrow() {
    if (this.currentPicture > 0) {
      this.currentPicture--;
    } else {
      this.currentPicture = this.pictures.length - 1;
    }
  }

  clickprevious() {
    var thumbactiveimage: any[] = this.pictures.filter(f => f.activethm == true)
    if (thumbactiveimage.length > 3) {
      this.pictures[thumbactiveimage[0].id - 1].activethm = true;
      this.pictures[thumbactiveimage[3].id].activethm = false;
    }
  }

  clicknext() {
    var thumbactiveimage: any[] = this.pictures.filter(f => f.activethm == true)
    if (thumbactiveimage.length > 3) {
      this.pictures[thumbactiveimage[3].id + 1].activethm = true;
      this.pictures[thumbactiveimage[0].id].activethm = false;
    }
  }


  //For Collcetion 
  filterGemstonelength(name: string) {
    if (!this.isNumber(name))
      return this.gemstonelengths.filter(m => m.length.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getgemstonelengthName(typeId: number) {
    if (this.gemstonelengths != null && typeId != null && typeId != 0) {
      return this.gemstonelengths.filter(s => s.id == typeId)[0].length;
    }
  }
  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }
}
