import { ChaindesignannotationService } from "@/_services/chaindesignannotation.service";
import { CustomerAuthenticationService } from "@/_services/customer-authentication.service";
import { MetalgoldcolorService } from "@/_services/metalgoldcolor.service";
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { CustomerOrdersService } from "../customer-orders.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { VendordiamondrateService } from "@/_services/vendordiamondrate.service";
import { CommonalertpopupComponent } from "@/forms/CommonPopup/commonalertpopup/commonalertpopup.component";
import { MatDialog } from "@angular/material/dialog";
import {AlertService} from "@/_services";
@Component({
  selector: "app-thankyou",
  templateUrl: "./thankyou.component.html",
  styleUrls: ["./thankyou.component.css"],
})
export class ThankyouComponent implements OnInit {
  checkOutForm: FormGroup;
  public productlist: any[] = [];
  public serviceurl;
  public isempty: boolean = true;
  public netamount: number = 0;
  public disable: boolean = false;
  modalRef: any;
  modalService: any;
 
  displayThankuStyle= 'block';


  constructor(
    private router: Router,
    public CustomerOrdersService: CustomerOrdersService,
    
    public dialog: MatDialog,
    private alertService: AlertService,


  ) {
  }

 

  ngOnInit() {
   
  }
 
  cancel() {
    
  }
 
  goToHome(){
    this.router.navigate(['', localStorage.getItem('vendorcompany'), localStorage.getItem('vendorkey')])
  }
}
