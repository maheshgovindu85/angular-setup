import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomizationViewPopupCsComponent } from './customization-view-popup-cs.component';

describe('CustomizationViewPopupCsComponent', () => {
  let component: CustomizationViewPopupCsComponent;
  let fixture: ComponentFixture<CustomizationViewPopupCsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomizationViewPopupCsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomizationViewPopupCsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
