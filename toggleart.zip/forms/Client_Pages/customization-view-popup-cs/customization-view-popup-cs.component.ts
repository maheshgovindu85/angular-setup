import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { OwlOptions } from "ngx-owl-carousel-o";
import { DiamondShapeService } from "@/_services";
import { GemstoneService } from "@/_services";
import { CenterStoneSizeService } from "@/_services/cs_size.service";
export interface DialogData {
  illusion: any;
  design1: any;
  Image: any;
  image: any;
  gold: string;
  goldkt: string;
  id: string;
  diamond: string;
  gemstone: string;
  design: any;
  vendor_id: any;
  solitaire: string;
  cs_image_comm: any;
  cs_frameband: any;
  partname: string;
  name: string;
  designpart: string;
}

@Component({
  selector: "app-customization-view-popup-cs",
  templateUrl: "./customization-view-popup-cs.component.html",
  styleUrls: ["./customization-view-popup-cs.component.css"],
})
export class CustomizationViewPopupCsComponent implements OnInit {
  isDiamond: boolean = false;
  isGemstone: boolean = false;
  isSolitaire: boolean = false;
  isGold: boolean = false;
  diamond12: any;

  bannerOptions: OwlOptions = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 500,
    margin: 15,
    center: true,
    autoplay: false,
    autoplayTimeout: 5000,
    navText: [
      '<i class="fa fa-angle-left"></i>',
      '<i class="fa fa-angle-right"></i>',
    ],
    responsive: {
      0: {
        items: 1,
        nav: false,
      },
      400: {
        items: 1,
        nav: false,
      },
      740: {
        items: 1,
        nav: true,
      },
      940: {
        items: 1,
        nav: true,
      },
      1200: {
        items: 1,
        nav: true,
      },
    },
  };

  getBannerData = [
    {
      src: "../../../../assets/images/Dropuneven.jpg",
      name: "Peppa pig",
    },
    {
      src: "../../../../assets/images/Dropuneven.jpg",
      name: "Peppa pig",
    },
  ];
  popData: DialogData;
  predeifnedImagesv: any = [];
  diamondData: any = [];
  gemstoneData: any = [];
  goldData: any = [];
  solitaireData: any = [];
  framebanddata: any = [];
  design1Data: any = [];
  diamondShapeList: any;
  filteredDiamondShapeList: any;
  gemstoneName: any;
  gemstone12: any;
  DesignData: any = [];
  centerStoneSizeList: any = [];
  list: any = [];
  constructor(
    public dialogRef: MatDialogRef<CustomizationViewPopupCsComponent>,
    private DiamondShapeService: DiamondShapeService,
    private Gemstoneservice: GemstoneService,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private centerstonsizeService: CenterStoneSizeService
  ) {
    this.popData = data["data"];
    console.log(" this.popData:", this.popData);

    this.predeifnedImagesv =
      this.popData?.cs_image_comm ?? this.popData?.Image ?? [];

    this.DesignData =
      this.popData?.design ||
      this.popData?.diamond ||
      this.popData?.gemstone ||
      this.popData?.illusion ||
      this.popData?.cs_frameband ||
      [];
    console.log("this.DesignData:", this.DesignData);

    if (this.popData?.cs_frameband?.length > 0) {
      this.goldData = this.DesignData[0].calcgold || [];
    } else {
      this.goldData = this.DesignData || [];
      console.log("this.goldData:", this.goldData);
    }

    if (this.popData.diamond?.length > 0) {
      this.diamondData = this.DesignData || [];
      console.log(" this.diamondData:", this.diamondData);
    } else {
      this.diamondData =
        this.framebanddata[0]?.diamond || this.DesignData[0].diamond || [];
      console.log("this.diamondData:", this.diamondData);
    }

    if (this.popData.gemstone?.length > 0) {
      this.centerstonsizeService.getAll().subscribe((data) => {
        if (data) {
          this.list = data;
          this.centerStoneSizeList = this.list.data.filter(
            (x) => x.isactive == "Y"
          );
          this.centerStoneSizeList.map((data) => {
            data.csSize = data.cs_length + " * " + data.cs_width;
            return data;
          });
          if (this.DesignData[0].diawt != 0) {
            for (const element of this.DesignData) {
              let res = this.centerStoneSizeList.filter(x=>x.id == element.csSize);
              let data = {
                name: element.name,
                size: this.centerStoneSizeList.filter(x=>x.id = element.csSize)[0].csSize ,
                nos: 1,
                wt: element.diaWt,
                twt: element.diaWt,
              };
              this.gemstoneData.push(data);
            }
          } else {
            this.gemstoneData = this.DesignData || [];
          }
        }
      });
      
    } else {
      this.gemstoneData =
        this.framebanddata[0]?.gemstone || this.DesignData[0].gemstone || [];
      console.log(" this.gemstoneData:", this.gemstoneData);
    }

    this.framebanddata = this.popData?.cs_frameband ?? [];

    if (
      this.goldData[0]?.gold !== null &&
      this.goldData[0]?.wt !== null &&
      this.goldData[0]?.gold !== "" &&
      this.goldData[0]?.wt !== ""
    ) {
      this.isGold = true;
    } else {
      this.isGold = false;
    }

    if (
      this.diamondData[0]?.nos !== "" &&
      this.diamondData[0]?.shape !== "" &&
      this.diamondData[0]?.twt !== "" &&
      this.diamondData[0]?.wt !== ""
    ) {
      this.isDiamond = true;
    } else {
      this.isDiamond = false;
    }

    if (
      this.gemstoneData[0]?.nos !== "" &&
      this.gemstoneData[0]?.name !== "" &&
      this.gemstoneData[0]?.shape !== "" &&
      this.gemstoneData[0]?.twt !== "" &&
      this.gemstoneData[0]?.color !== "" &&
      this.gemstoneData[0]?.size !== "" &&
      this.gemstoneData[0]?.wt !== ""
    ) {
      this.isGemstone = true;
    } else {
      this.isGemstone = false;
    }

    this.DiamondShapeService.getAll().subscribe((data) => {
      if (data) {
        this.diamondShapeList = data;

        for (let i = 0; i < this.diamondData.length; i++) {
          this.diamond12 = this.diamondData[i];
          const filteredList = this.diamondShapeList.filter(
            (c) => c.id == this.diamond12.shape
          );
          if (filteredList.length > 0)
            this.diamond12.shape = filteredList[0]?.shape;
        }
      }
    });

    this.Gemstoneservice.getAll().subscribe((data) => {
      if (data) {
        this.gemstoneName = data;

        for (let i = 0; i < this.gemstoneData.length; i++) {
          this.gemstone12 = this.gemstoneData[i];
          const filteredList = this.gemstoneName.filter(
            (c) => c.id == this.gemstone12.name
          );
          if (filteredList.length > 0) {
            this.gemstone12.name = filteredList[0]?.name;
          }
        }
      }
    });

    this.solitaireData = this.popData.solitaire;
  }

  ngOnInit(): void {}

  closePopup() {
    this.dialogRef.close();
  }
}
