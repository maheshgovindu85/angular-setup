import { AlertService } from '@/_services';
import { ChaindesignannotationService } from '@/_services/chaindesignannotation.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewclientorderstructure-cartpopup',
  templateUrl: './viewclientorderstructure-cartpopup.component.html',
  styleUrls: ['./viewclientorderstructure-cartpopup.component.css']
})
export class ViewclientorderstructureCartpopupComponent implements OnInit {

  listofCustomerOrder: any;
  constructor(
    private alertService: AlertService,
    private chaindesignannotationService: ChaindesignannotationService,
  ) {
    if (localStorage.getItem("vendorcustomerorder")) {
      this.listofCustomerOrder = JSON.parse(localStorage.getItem("vendorcustomerorder"));
    }
  }

  ngOnInit(): void {
  }

  deleteFromlist(id: number) {
    this.listofCustomerOrder.forEach((element, index) => {
      if (element.orderid * 1 == id * 1) {
        this.listofCustomerOrder.splice(index, 1);
        localStorage.setItem("vendorcustomerorder", JSON.stringify(this.listofCustomerOrder))
      }
    });
  }

  ProccessorderToToggleArt() {
    this.chaindesignannotationService.ProcesstoToggleArt(this.listofCustomerOrder).subscribe(data => {
      this.listofCustomerOrder.forEach((element, index) => {
        this.listofCustomerOrder.splice(index, 1);
      });
      localStorage.setItem("vendorcustomerorder", JSON.stringify(this.listofCustomerOrder))
      this.alertService.success("Order Transfer To ToggleArt Successfully", true);
    })
  }
}
