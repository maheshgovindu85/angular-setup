import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewclientorderstructureCartpopupComponent } from './viewclientorderstructure-cartpopup.component';

describe('ViewclientorderstructureCartpopupComponent', () => {
  let component: ViewclientorderstructureCartpopupComponent;
  let fixture: ComponentFixture<ViewclientorderstructureCartpopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewclientorderstructureCartpopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewclientorderstructureCartpopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
