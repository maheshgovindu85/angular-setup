import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewClientOrderStructureComponent } from './view-client-order-structure.component';

describe('ViewClientOrderStructureComponent', () => {
  let component: ViewClientOrderStructureComponent;
  let fixture: ComponentFixture<ViewClientOrderStructureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ViewClientOrderStructureComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewClientOrderStructureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
