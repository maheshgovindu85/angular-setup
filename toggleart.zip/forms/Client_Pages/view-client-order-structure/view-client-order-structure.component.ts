import { AlertService } from '@/_services';
import { ChaindesignannotationService } from '@/_services/chaindesignannotation.service';
import { CustomerAuthenticationService } from '@/_services/customer-authentication.service';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerOrdersService } from '../customer-orders.service';
import html2canvas from 'html2canvas';
import jspdf from 'jspdf';
import { defaultIfEmpty } from 'rxjs/operators';

@Component({
  selector: 'app-view-client-order-structure',
  templateUrl: './view-client-order-structure.component.html',
  styleUrls: ['./view-client-order-structure.component.css']
})
export class ViewClientOrderStructureComponent implements OnInit {

  // @ViewChild('ordertable') pdfTable: ElementRef;
  @ViewChild('ordertable', { static: false }) pdfTable: ElementRef;

  OrderManufacture: FormGroup;
  public serviceurl;
  public isempty: boolean = true;
  public loading: boolean = false;

  public test_map_flat: any[] = [];
  public test_map_model: any[] = [];

  orderDetails: any[] = [];

  public orderid: any;
  public orderdate: any;
  public predefinedbraceletname;
  public customer: any;
  public vendor: any;
  public totalorder: any;
  public orderchaindetails: any;
  public ordercharmaddon: any;
  public ordergolddetails: any;
  public totaldiamondwt: any;
  public listofdiamonddetails: any;
  public listofgemstonedetails: any;
  globalorderid;
  predefinedcolor: any;
  braceletgoldkt: any;
  braceletlength: any;
  diamondcolor: any;
  diamondpurity: any;


  goldata2: any;

  OrderdetailDataInfo: any;
  orderchainlength: any;
  predefinedbracelettype: any = 0;
  braceletlengthdata: any = 0;

  linkbraceletcoredetails: any;
  linkbraceletnolink = 0;
  linkbraceletnoconnector = 0;

  linkbraceletnooflinkgold = 0;
  linkbraceletnoofconnectorgold = 0;

  linkbraceletnooflinkgoldwt = 0;
  linkbraceletnoofconnectorgoldwt = 0;
  linkorderlockdatalist;
  predefinedlockdata;

  constructor(private router: Router,
    private CustomerOrdersService: CustomerOrdersService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private chaindesignannotationService: ChaindesignannotationService,
    private _snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private formbuilder: FormBuilder,
    private datepipe: DatePipe,
    private alertService: AlertService
  ) {
    this.serviceurl = metalgoldcolorservice.path;



    this.OrderManufacture = formbuilder.group({
      id: [0, Validators.required],
      orderid: [this.route.snapshot.paramMap.get('id'), Validators.required],
      orderdate: [],
      merchantname: [''],
      customername: [],
      orderamount: [],

      vendorid: [this.vendor],
      braceletsize: [, Validators.required],
      braceletsize_id: [],
      chainname: [],
      braceletchainid: [],
      thickness: [, Validators.required],
      thickness_id: [],
      chaingoldcolor: ['', Validators.required],
      chaingoldcolor_id: [],
      lock: [, Validators.required],
      lock_id: [],
      ring: [, Validators.required],
      ring_id: [],
      listofCharnAddon: formbuilder.array([]),
      goldkt: [, Validators.required],
      totalgoldwt: [, Validators.required],
      totaldiamondColorPurity: ['', Validators.required],
      tatalweight: [],
      listofdiamond: formbuilder.array([]),
      listofgemstone: formbuilder.array([]),
      subtotal: ['', Validators.required],
      gst: ['', Validators.required],
      granttotal: ['', Validators.required],
      filetype: ['', Validators.required],
      selfmanufature: [false],
      isdelete: [false],
      grosswt: ['', Validators.required],
      diamondwt: ['', Validators.required],
      gemstonewt: ['', Validators.required],
      netwt: ['', Validators.required],
      makingcharges: ['', Validators.required]
    })


  }

  addOrderTocart() {
    if (localStorage.getItem("vendorcustomerorder")) {
      var orderarray = { 'orderid': this.orderid, 'orderdate': this.orderdate, 'customer': this.customer, 'totalamount': this.totalorder };

      var pre_orderarray: any[] = [];
      JSON.parse(localStorage.getItem("vendorcustomerorder")).forEach(element => {
        pre_orderarray.push(element)
      });
      pre_orderarray.push(orderarray)
      localStorage.setItem("vendorcustomerorder", JSON.stringify(pre_orderarray));
    } else {
      var freshorderarray = [{ 'orderid': this.orderid, 'orderdate': this.orderdate, 'customer': this.customer, 'totalamount': this.totalorder }];
      localStorage.setItem("vendorcustomerorder", JSON.stringify(freshorderarray));
    }
  }

  async ngOnInit() {
    this.OrderManufacture.get("filetype").valueChanges.subscribe(data => {

    });

    var id = this.route.snapshot.paramMap.get('id');
    var orddtid = this.route.snapshot.paramMap.get('orddtid');

    this.globalorderid = id;
    await this.chaindesignannotationService.displayOrderdetails(id, orddtid).then(data => {
      this.orderDetails = data;
      this.orderid = data[0].orderid;
      this.orderdate = data[0].odrerdate;
      this.predefinedbraceletname = data[0].predefinedbraceletname;
      this.customer = data[0].customer_name;
      this.vendor = data[0].vendor_name;
      this.totalorder = data[0].totalprice;

      this.ordercharmaddon = data[0].productsdetails;
      this.predefinedcolor = data[0].predefinedcolor;
      this.braceletgoldkt = data[0].braceletgoldkt;
      this.braceletlength = data[0].braceletlength;
      this.diamondcolor = data[0].diamondcolor;
      this.diamondpurity = data[0].diamondpurity;

      this.OrderdetailDataInfo = data[0];
    })


    await this.chaindesignannotationService.orderchaindetails(id, orddtid).then(data => {
      var JsonData = JSON.parse(JSON.stringify(data));

      this.predefinedbracelettype = JsonData.predefinedbracelettype;
      this.braceletlengthdata = JsonData.braceeletlendth;
      this.linkbraceletcoredetails = JsonData.linkbraceletcoredetails;
      this.linkorderlockdatalist = JsonData.orderlinkchainlock;

      // fetch link bracelet details
      if (this.linkbraceletcoredetails !== undefined && this.linkbraceletcoredetails !== "") {
        this.linkbraceletnolink = this.linkbraceletcoredetails[0].linknos;
        this.linkbraceletnoconnector = this.linkbraceletcoredetails[1].linknos;
        this.linkbraceletnooflinkgold = this.linkbraceletcoredetails[0].finalgoldwt;
        this.linkbraceletnoofconnectorgold = this.linkbraceletcoredetails[1].finalgoldwt;
        this.linkbraceletnooflinkgoldwt = this.linkbraceletcoredetails[0].gold_wt;
        this.linkbraceletnoofconnectorgoldwt = this.linkbraceletcoredetails[1].gold_wt;
      }

      if (this.linkorderlockdatalist !== undefined && this.linkorderlockdatalist !== "") {
        this.predefinedlockdata = this.linkorderlockdatalist;
      }

      this.orderchaindetails = JsonData.orderchaindetails[0];
      this.orderchainlength = JsonData.orderchainlength.ttl;

      this.ordergolddetails = JsonData.orderGolddetails;
      this.totaldiamondwt = JsonData.ordertotaldiamondweight;
      this.listofdiamonddetails = JsonData.orderDiamonddetails;
      this.listofgemstonedetails = JsonData.orderGemstonedetails;

      this.goldata2 = JsonData.golddata;

      this.OrderManufacture = this.formbuilder.group({
        id: [0, Validators.required],
        orderid: [id, Validators.required],
        orderdate: [this.datepipe.transform(this.orderdate, 'dd-MMM-yyyy hh:mm')],
        merchantname: [''],
        customername: [this.customer],
        orderamount: [this.totalorder],

        vendorid: [this.vendor],
        braceletsize: [this.orderchaindetails.braceletlength, Validators.required],
        braceletsize_id: [0],
        chainname: [this.orderchaindetails.chaindesignweigth],
        braceletchainid: [],
        thickness: [this.orderchaindetails.chainthikness, Validators.required],
        thickness_id: [0],
        chaingoldcolor: ['NA', Validators.required],
        chaingoldcolor_id: [0],
        lock: [this.orderchaindetails.lockname, Validators.required],
        lock_id: [0],
        ring: [this.orderchaindetails.ringname, Validators.required],
        ring_id: [0],
        listofCharnAddon: this.orderProductlist(this.ordercharmaddon),
        goldkt: [this.ordergolddetails.carat, Validators.required],
        totalgoldwt: [this.ordergolddetails.weight, Validators.required],
        totaldiamondColorPurity: ['NA', Validators.required],
        tatalweight: [this.totaldiamondwt],
        listofdiamond: this.orderdiamondlist(this.listofdiamonddetails),
        listofgemstone: this.ordergemstonelist(this.listofgemstonedetails),
        subtotal: ['', Validators.required],
        gst: ['', Validators.required],
        granttotal: ['', Validators.required],
        filetype: ['', Validators.required],
        selfmanufature: [false],
        isdelete: [false],
        grosswt: ['', Validators.required],
        diamondwt: ['', Validators.required],
        gemstonewt: ['', Validators.required],
        netwt: ['', Validators.required],
        makingcharges: ['', Validators.required]
      })
    })

  }
  changefiletype() {
    console.log(this.OrderManufacture.get("filetype").value);
  }
  changeselfmanucature(event) {
    this.OrderManufacture.get("selfmanufature").setValue(event.checked);
  }

  orderProductlist(Product_details): FormArray {
    const formArray = new FormArray([]);
    Product_details.forEach(s => {
      formArray.push(this.formbuilder.group({
        charmaddonid: [s.productid, Validators.required],
        type: [s.producttype, Validators.required],
        imagesid: [s.imageid],
        goldcolorvariationid: [s.colorvariationid, Validators.required],
        isdelete: ['N', Validators.required]
      }));
    });
    return formArray;
  }

  orderdiamondlist(Product_details): FormArray {
    const formArray = new FormArray([]);
    Product_details.forEach(s => {
      formArray.push(this.formbuilder.group({
        shape: [s.shape],
        shape_id: [s.shape_id],
        totalwt: [s.total_wt, Validators.required],
        nos: [s.nos],
        wt: [s.caratid, Validators.required],
        isdelete: ['N', Validators.required]
      }));
    });
    return formArray;
  }

  ordergemstonelist(Product_details): FormArray {
    const formArray = new FormArray([]);
    Product_details.forEach(s => {
      formArray.push(this.formbuilder.group({
        shape: [s.shape],
        shape_id: [s.shape_id],
        gemstone: [s.gemstone_id, Validators.required],
        color: [s.colorid],
        size: [s.size, Validators.required],
        wt: [s.caratname],
        isdelete: ['N', Validators.required]
      }));
    });
    return formArray;
  }

  printorder() {
    const printContent = document.getElementById("componentID");
    const WindowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0,scrollbars=0,status=0');

    WindowPrt.document.write('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"><html>');
    WindowPrt.document.write('<body >');
    WindowPrt.document.write(printContent.innerHTML);
    WindowPrt.document.write('</body></html>');

    WindowPrt.document.close();
    WindowPrt.focus();
    WindowPrt.print();
    // WindowPrt.close();
  }

  getPDF() {
    var HTML_Width = this.pdfTable.nativeElement.offsetWidth;
    var HTML_Height = 2100;
    var top_left_margin = 15;
    var PDF_Width = HTML_Width + (top_left_margin * 2);
    var PDF_Height = (PDF_Width * 1.5) + (top_left_margin * 2);
    var canvas_image_width = HTML_Width;
    var canvas_image_height = HTML_Height;

    var totalPDFPages = Math.ceil(HTML_Height / PDF_Height) - 1;

    html2canvas(document.getElementById('mainid'), { useCORS: true }).then(function (canvas) {
      canvas.getContext('2d');

      var imgData = canvas.toDataURL("image/jpeg", 1.0);
      var pdf = new jspdf('p', 'pt', [PDF_Width, PDF_Height]);
      pdf.addImage(imgData, 'JPG', top_left_margin, top_left_margin, canvas_image_width, canvas_image_height);


      for (var i = 1; i <= totalPDFPages; i++) {
        pdf.addPage(PDF_Width, PDF_Height);
        pdf.addImage(imgData, 'JPG', top_left_margin, -(PDF_Height * i) + (top_left_margin * 4), canvas_image_width, canvas_image_height);
      }
      pdf.save("BraceletDocument.pdf");
    });
  }

  public downloadAsPDF() {
    const doc = new jspdf('p', 'pt', 'a4');

    const pdfTable = this.pdfTable.nativeElement;
    var specialElementHandlers = {
      '#bypassme': function (element, renderer) {
        return true;
      }
    };

    var margin = {
      top: 0,
      left: 0,
      right: 0,
      bottom: 0
    };

    var tinymceToJSPDFHTML = document.getElementById("mainid");
    var pdfcontaint = tinymceToJSPDFHTML.innerHTML;
    var aa = '<h1>Hello Vikram<h1>';

    // var temp = document.createElement('div');
    // temp.innerHTML = pdfcontaint;

    console.log(pdfcontaint)
    console.log("2")

    doc.fromHTML(tinymceToJSPDFHTML.innerHTML, 0, 0, {
      'width': 100, // max width of content on PDF
      'elementHandlers': specialElementHandlers
    }, function (a) { console.log("3") }, margin);

    doc.save('project.pdf');

  }
  onSubmit() {
    if (this.OrderManufacture.invalid) {
      return
    }
    this.loading = true;

    this.chaindesignannotationService.saveCustomerorder(this.OrderManufacture.value).subscribe(data => {
      this.alertService.success('Charm saved successfully!', true);
      this.router.navigate(['customerorders/list']);
    })
  }

  imagesPreview(image_path: string) {
    return this.serviceurl + '/images/' + image_path;
    // return this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + image_path;
  }
  getImageByte(filename) {
    return this.serviceurl + '/images/' + filename;
    // return this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + filename;
  }

  clickFlat(id) {
    document.getElementById('appendimage_' + id).hidden = false;
    document.getElementById('append_model_image_' + id).hidden = true;
  }

  clickmodel(id) {
    document.getElementById('appendimage_' + id).hidden = true;
    document.getElementById('append_model_image_' + id).hidden = false;
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action);
  }

}

