import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clienthome',
  templateUrl: './clienthome.component.html',
  styleUrls: ['./clienthome.component.css']
})
export class ClienthomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
