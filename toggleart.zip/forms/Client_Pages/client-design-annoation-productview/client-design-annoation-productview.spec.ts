import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientDesignAnnoationProductViewComponent } from './client-design-annoation-productview';

describe('ClientDesignAnnoationProductViewComponent', () => {
  let component: ClientDesignAnnoationProductViewComponent;
  let fixture: ComponentFixture<ClientDesignAnnoationProductViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientDesignAnnoationProductViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientDesignAnnoationProductViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
