import { Component, OnInit } from "@angular/core";
import {
  FormControl,
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
} from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { VendordiamondrateService } from "@/_services/vendordiamondrate.service";
import { LongDesignPredefineService } from "@/_services/long-design-predefine.service";

import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
  VendorCollectionService,
} from "@/_services";
import { OwlOptions } from "ngx-owl-carousel-o";
import { NgxGalleryOptions } from "@kolkov/ngx-gallery";
import { NgxGalleryImage } from "@kolkov/ngx-gallery";
import { NgxGalleryAnimation } from "@kolkov/ngx-gallery";
import { CenterStonePredefineService } from "@/_services/cs_predefine.service";
import { CustomerOrdersService } from "../customer-orders.service";
import { CommonalertpopupComponent } from "@/forms/CommonPopup/commonalertpopup/commonalertpopup.component";
import { MatDialog } from "@angular/material/dialog";
import { Location } from "@angular/common";

interface allCalculationData {
  GoldPrice: number;
  DiamondPrice: number;
  MakingChargePrice: number;
  TotalValue: number;
  Gst: number;
  GrandTotal: number;
}

@Component({
  selector: "app-client-design-annoation-productview",
  templateUrl: "./client-design-annoation-productview.html",
  styleUrls: ["./client-design-annoation-productview.css"],
})
export class ClientDesignAnnoationProductViewComponent implements OnInit {
  materialSection: boolean = false;
  PriceBreakUp: boolean = false;
  displayNaturalRates: boolean = false;
  displayQuantity = "Synthetic";
  vendorcompanyname;
  merchant_id: number;
  vendoruniquekey;
  collectionList: any = [];
  bannerList: any = [];
  predefinedid: any;
  predefinedList: any = [];
  url_companyname;
  predefinedType;

  currentPicture = 0;
  predefinedData: any = [];
  productViewImages: any = [];
  predefinedBind: any;
  predefinedDetail: any;
  calculationPart: any = [];
  ktActiveClass = 18;
  ActivityStorage: any[] = [];
  brSizeValues: any = [];
  KTValues: any = [];
  DiamondValues: any = [];
  DiamondSolitaireValues: any = [];
  GemstoneNatural: any = [];
  GesmtoneSynthetic: any = [];
  selectSize: any;
  // filterGms: any=[];
  goldwt: any;
  goldprice: any;
  goldkt = 18;
  goldrate: any;
  diamondval: any;
  diamondsolitaireval: any;
  gemstoneval: any = [];
  gemstoneselected: any = [];
  calculationPartDrop: any = [];
  calculationPartTOp: any = [];
  calculationPartMId: any = [];
  KTValuesDrop: any[];
  KTValuesMid: any[];
  KTValuesTop: any[];
  allCalCulationValues: any = [];
  dropKtValueSum: any;
  topKtValuesSum: any;
  dropKtValue: any;
  goldCalculation: any = [];
  showNaturalRates: boolean;
  allData: any = [];
  totalmakingcharges: any;
  total: any;
  gsttotal: any;
  grandtotal: any;

  productID: any;
  diamondActiveClass = "IJ VVS";
  typeActive = "Synthetic";
  typeActiveNatural;
  dropCalData: any = [];
  TopGemstoneNatural: any = [];
  TopGesmtoneSynthetic: any = [];
  DropGesmtoneSynthetic: any = [];
  DropGemstoneNatural: any = [];
  topCalData: any = [];
  midCalData: any = [];
  MidGemstoneNatural: any = [];
  MidGesmtoneSynthetic: any = [];
  design1calData: any = [];
  design2calData: any = [];
  design3calData: any = [];
  dropcalData: any = [];
  framebandcalData: any = [];
  Design1GesmtoneSynthetic: any = [];
  Design1GemstoneNatural: any = [];
  Design2GesmtoneSynthetic: any = [];
  Design2GemstoneNatural: any = [];
  Design3GesmtoneSynthetic: any = [];
  Design3GemstoneNatural: any = [];
  FrameGesmtoneSynthetic: any = [];
  FrameGemstoneNatural: any = [];
  unActiveSys: number;
  activeCompo: string;
  goldData: {};
  diamondData: {};
  solitaireData: {};
  gemstoneData: {};

  galleryOptions: OwlOptions = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: true,
    dots: true,
    navSpeed: 500,
    margin: 15,
    center: true,
    autoplay: true,
    autoplayTimeout: 6000,
    navText: [
      '<i class="fa fa-angle-left"></i>',
      '<i class="fa fa-angle-right"></i>',
    ],
    responsive: {
      0: {
        items: 1,
        nav: false,
      },
      400: {
        items: 1,
        nav: false,
      },
      740: {
        items: 1,
        nav: true,
      },
      940: {
        items: 1,
        nav: true,
      },
      1200: {
        items: 1,
        nav: true,
      },
    },
  };
  allCalculationData: {
    GoldPrice: {};
    DiamondPrice: {};
    SolitairePrice: {};
    GemstonePrice: any;
    MakingChargePrice: any;
    TotalValue: any;
    Gst: any;
    GrandTotal: any;
    type: any;
    imagePath: any;
  };
  solitaireActiveClass: any;
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private VendordiamondrateService: VendordiamondrateService,
    private authenticationService: AuthenticationService,
    private LongDesignPredefineService: LongDesignPredefineService,
    private centerstonPredefinedService: CenterStonePredefineService,
    private CustomerOrdersService: CustomerOrdersService,
    private _location: Location,
    public dialog: MatDialog
  ) {
    let companyUrl: any = [];
    let data = this.router.url;
    companyUrl = data.split("/");
    this.url_companyname = companyUrl[1];
    this.vendoruniquekey = companyUrl[2];

    this.predefinedid = JSON.parse(
      this.route.snapshot.paramMap.get("predefinedid")
    );
    this.productID = JSON.parse(this.route.snapshot.paramMap.get("productid"));
    this.predefinedType = this.route.snapshot.paramMap.get("type");

    localStorage.setItem("vendorcompany", this.url_companyname);
    localStorage.setItem("vendorkey", this.vendoruniquekey);

    this.VendordiamondrateService.vendordetailwithuniquekey(
      this.vendoruniquekey
    ).subscribe((data: any) => {
      this.merchant_id = data.id;
      this.vendorcompanyname = data.company;

      if (this.predefinedType === "ld") {
        this.LongDesignPredefineService.getFrontendLongDesignPredefinebyid({
          id: this.predefinedid,
        }).subscribe((data) => {
          if (data) {
            this.allData = data["data"];
            

            this.predefinedData = data["data"]["predefinedata"];
            this.predefinedDetail = data["data"]["predefinedetail"];
            
            var JsonImgData = this.predefinedData.image;

            var sortedData = JsonImgData.sort((a, b) => {
              if (a.displayUser === b.displayUser) {
                if (a.secondOption === b.secondOption) {
                  return 0;
                } else if (a.secondOption && !b.secondOption) {
                  return -1;
                } else {
                  return 1;
                }
              } else if (a.displayUser && !b.displayUser) {
                return -1;
              } else {
                return 1;
              }
            });

            for (let index = 0; index < sortedData.length; index++) {
              const element = sortedData[index].images
              this.productViewImages.push(element)
            }

            this.calculationPart = this.predefinedDetail.totalgold;

            this.KTValues = [
              ...new Set(this.calculationPart.map((item) => item.kt)),
            ];

            for (let index = 0; index < this.KTValues.length; index++) {
              if (this.KTValues[index] == 18)
                this.goldkt = this.KTValues[index];
            }

            let res = this.calculationPart.filter(
              (x) => x.kt == this.goldkt
            )[0];

            this.goldrate = parseFloat(res.rate).toFixed(3);
            let goldprice: any = Number(res.rate) * Number(res.wt);
            this.goldprice = parseFloat(goldprice).toFixed(3);
            this.goldwt = parseFloat(res.wt).toFixed(3);

            this.DiamondValues = [
              ...new Set(
                this.predefinedDetail.totaldiamond.map((item) => item.type)
              ),
            ];

            this.diamondval = this.predefinedDetail.totaldiamond?.[0];
            this.dropCalData = this.predefinedDetail.drop.cal?.gemstoneResult;
            this.topCalData = this.predefinedDetail.top.cal?.gemstoneResult;
            this.midCalData = this.predefinedDetail.mid.cal?.gemstoneResult;

            if (this.predefinedDetail.totalgemstone.length > 0) {
              if (this.predefinedDetail.totalgemstone[0] == "NA") {
                this.gemstoneval = this.predefinedDetail.totalgemstone;
                
              } else {
                this.GemstoneNatural =
                  this.predefinedDetail.totalgemstone.filter(
                    (item) => item.type == "Natural"
                  );

                this.GesmtoneSynthetic =
                  this.predefinedDetail.totalgemstone.filter(
                    (item) => item.type == "Synthetic"
                  );
                if (this.GesmtoneSynthetic.length > 0) {
                  this.showQualityList("Synthetic");
                }
                if (
                  this.GemstoneNatural.length > 0 &&
                  this.GesmtoneSynthetic.length == 0
                ) {
                  this.showQualityList("Natural");
                }
              }
            }

            if (this.topCalData?.length > 0) {
              if (this.topCalData[0] == "NA") {
                this.gemstoneval = this.topCalData;
              } else {
                this.TopGemstoneNatural = this.topCalData.filter(
                  (item) => item.type == "Natural"
                );

                this.TopGesmtoneSynthetic = this.topCalData.filter(
                  (item) => item.type == "Synthetic"
                );
                if (this.TopGesmtoneSynthetic.length > 0) {
                  this.showQualityList("Synthetic");
                }
                if (
                  this.TopGemstoneNatural.length > 0 &&
                  this.TopGesmtoneSynthetic.length == 0
                ) {
                  this.showQualityList("Natural");
                }
              }
            }

            if (this.midCalData?.length > 0) {
              if (this.midCalData[0] == "NA") {
                this.gemstoneval = this.midCalData;
              } else {
                this.MidGemstoneNatural = this.midCalData.filter(
                  (item) => item.type == "Natural"
                );

                this.MidGesmtoneSynthetic = this.midCalData.filter(
                  (item) => item.type == "Synthetic"
                );

                if (this.MidGesmtoneSynthetic.length > 0) {
                  this.showQualityList("Synthetic");
                }
                if (
                  this.MidGemstoneNatural.length > 0 &&
                  this.MidGesmtoneSynthetic.length == 0
                ) {
                  this.showQualityList("Natural");
                }
              }
            }

            if (this.dropCalData?.length > 0) {
              if (this.dropCalData[0] == "NA") {
                this.gemstoneval = this.dropCalData;
              } else {
                this.DropGemstoneNatural = this.dropCalData.filter(
                  (item) => item.type == "Natural"
                );

                this.DropGesmtoneSynthetic = this.dropCalData.filter(
                  (item) => item.type == "Synthetic"
                );

                if (this.DropGesmtoneSynthetic.length > 0) {
                  this.showQualityList("Synthetic");
                }
                if (
                  this.DropGemstoneNatural.length > 0 &&
                  this.DropGesmtoneSynthetic.length == 0
                ) {
                  this.showQualityList("Natural");
                }
              }
            }

            this.calculateTotal();
          }
        });
      } else if (this.predefinedType === "cs") {
        this.centerstonPredefinedService
          .getFrontendCenteStonePredefineById({ id: this.predefinedid })
          .subscribe((data) => {
            if (data) {
              this.allData = data["data"];
              this.predefinedData = data["data"]["predefinedata"];
              this.predefinedDetail = data["data"]["predefinedetail"];
              
              var JsonImgData = this.predefinedData.Image;

              var sortedData = JsonImgData.sort((a, b) => {
                if (a.displayUser === b.displayUser) {
                  if (a.secondOption === b.secondOption) {
                    return 0;
                  } else if (a.secondOption && !b.secondOption) {
                    return -1;
                  } else {
                    return 1;
                  }
                } else if (a.displayUser && !b.displayUser) {
                  return -1;
                } else {
                  return 1;
                }
              });

              for (let index = 0; index < sortedData.length; index++) {
                const element = sortedData[index].images
                this.productViewImages.push(element)
              }

              this.calculationPart = this.predefinedDetail.totalgold;
              let res;
              if (this.productID == 1 || this.productID == 4) {
                this.brSizeValues = [
                  ...new Set(this.calculationPart.map((item) => item.brsize)),
                ];

                this.selectSize = this.brSizeValues.reduce((a, b) =>
                Math.min(a, b)
                ); // 1
                
                res = this.calculationPart.filter(
                  (x) => x.brsize == this.selectSize && x.kt == this.goldkt
                )[0];
              } else {
                res = this.calculationPart.filter(
                  (x) => x.kt == this.goldkt
                )[0];
              }

              this.KTValues = [
                ...new Set(this.calculationPart.map((item) => item.kt)),
              ];

              for (let index = 0; index < this.KTValues.length; index++) {
                if (this.KTValues[index] == 18)
                  this.goldkt = this.KTValues[index];
              }

              this.goldrate = parseFloat(res.rate).toFixed(3);
              let goldprice: any = Number(res.rate) * Number(res.wt);
              this.goldprice = parseFloat(goldprice).toFixed(3);
              this.goldwt = parseFloat(res.wt).toFixed(3);

              this.DiamondValues = [
                ...new Set(
                  this.predefinedDetail.totaldiamond.map((item) => item.type)
                ),
              ];
              this.DiamondSolitaireValues = [
                ...new Set(
                  this.predefinedDetail.totalsolitaire.map((item) => item.type)
                ),
              ];
              this.diamondval = this.predefinedDetail?.totaldiamond?.[0];
              let prediamondval = this.diamondval;
              if(!!this.selectSize) {
                this.diamondval = this.predefinedDetail.totaldiamond.filter(
                  (x) =>x.brsize == this.selectSize
                )[0];
              } 
              if(!this.diamondval) {
                this.diamondval = prediamondval;
              }
              this.diamondActiveClass = this.diamondval?.type;
              
              this.diamondsolitaireval =
                this.predefinedDetail.totalsolitaire?.[0];
              this.design1calData =
                this.predefinedDetail.design1?.calc[0]?.gemstoneResult;
              this.framebandcalData =
                this.predefinedDetail.framband?.calc[0]?.gemstoneResult;
              // if(this.predefinedDetail.design2 != {});
              this.design2calData =
                this.predefinedDetail.design2?.calc[0]?.gemstoneResult;
              this.design3calData =
                this.predefinedDetail.design3?.calc[0]?.gemstoneResult;
              this.dropcalData =
                this.predefinedDetail.drop?.calc[0]?.gemstoneResult;

              if (this.predefinedDetail.totalgemstone.length > 0) {
                if (this.predefinedDetail.totalgemstone[0] == "NA") {
                  this.gemstoneval = this.predefinedDetail.totalgemstone;
                } else {
                  this.GemstoneNatural =
                    this.predefinedDetail.totalgemstone.filter(
                      (item) => item.type == "Natural"
                    );

                  this.GesmtoneSynthetic =
                    this.predefinedDetail.totalgemstone.filter(
                      (item) => item.type == "Synthetic"
                    );
                  if (this.GesmtoneSynthetic.length > 0) {
                    this.showQualityList("Synthetic");
                  }
                  if (
                    this.GemstoneNatural.length > 0 &&
                    this.GesmtoneSynthetic.length == 0
                  ) {
                    this.showQualityList(data);
                  }
                }
              }

              // /center stone
              if (this.design1calData?.length > 0) {
                if (this.design1calData[0] == "NA") {
                  this.gemstoneval = this.design1calData;
                } else {
                  this.Design1GemstoneNatural = this.design1calData.filter(
                    (item) => item.type == "Natural"
                  );

                  this.Design1GesmtoneSynthetic = this.design1calData.filter(
                    (item) => item.type == "Synthetic"
                  );

                  if (this.Design1GesmtoneSynthetic.length > 0) {
                    this.showQualityList("Synthetic");
                  }
                  if (
                    this.Design1GemstoneNatural.length > 0 &&
                    this.Design1GesmtoneSynthetic.length == 0
                  ) {
                    this.showQualityList(data);
                  }
                }
              }

              // design2
              if (this.design2calData?.length > 0) {
                if (this.design2calData[0] == "NA") {
                  this.gemstoneval = this.design2calData;
                } else {
                  this.Design2GemstoneNatural = this.design2calData.filter(
                    (item) => item.type == "Natural"
                  );

                  this.Design2GesmtoneSynthetic = this.design2calData.filter(
                    (item) => item.type == "Synthetic"
                  );

                  if (this.Design2GesmtoneSynthetic.length > 0) {
                    this.showQualityList("Synthetic");
                  }
                  if (
                    this.Design2GemstoneNatural.length > 0 &&
                    this.Design2GesmtoneSynthetic.length == 0
                  ) {
                    this.showQualityList(data);
                  }
                }
              }

              // design3

              if (this.design3calData?.length > 0) {
                if (this.design3calData[0] == "NA") {
                  this.gemstoneval = this.design3calData;
                } else {
                  this.Design3GemstoneNatural = this.design3calData.filter(
                    (item) => item.type == "Natural"
                  );

                  this.Design3GesmtoneSynthetic = this.design3calData.filter(
                    (item) => item.type == "Synthetic"
                  );

                  if (this.Design3GesmtoneSynthetic.length > 0) {
                    this.showQualityList("Synthetic");
                  }
                  if (
                    this.Design3GemstoneNatural.length > 0 &&
                    this.Design3GesmtoneSynthetic.length == 0
                  ) {
                    this.showQualityList(data);
                  }
                }
              }

              ///Drop//
              if (this.dropcalData?.length > 0) {
                if (this.dropcalData[0] == "NA") {
                  this.gemstoneval = this.dropcalData;
                } else {
                  this.DropGemstoneNatural = this.dropcalData.filter(
                    (item) => item.type == "Natural"
                  );

                  this.DropGesmtoneSynthetic = this.dropcalData.filter(
                    (item) => item.type == "Synthetic"
                  );

                  if (this.DropGesmtoneSynthetic.length > 0) {
                    this.showQualityList("Synthetic");
                  }
                  if (
                    this.DropGemstoneNatural.length > 0 &&
                    this.DropGesmtoneSynthetic.length == 0
                  ) {
                    this.showQualityList(data);
                  }
                }
              }

              //frame/
              if (this.framebandcalData?.length > 0) {
                if (this.framebandcalData[0] == "NA") {
                  this.gemstoneval = this.framebandcalData;
                } else {
                  this.FrameGemstoneNatural = this.framebandcalData.filter(
                    (item) => item.type == "Natural"
                  );

                  this.FrameGesmtoneSynthetic = this.framebandcalData.filter(
                    (item) => item.type == "Synthetic"
                  );

                  if (this.FrameGesmtoneSynthetic.length > 0) {
                    this.showQualityList("Synthetic");
                  }
                  if (
                    this.FrameGemstoneNatural.length > 0 &&
                    this.FrameGesmtoneSynthetic.length == 0
                  ) {
                    this.showQualityList(data);
                  }
                }
              }

              this.calculateTotal();
              // }
            }
          });
      }
    });
  }

  calculateTotal() {
    let totalmake: any =
      this.predefinedDetail.makingcharges * Number(this.goldwt);
    this.totalmakingcharges = parseFloat(totalmake).toFixed(3);
    const gemstonesum = this.gemstoneval.reduce((accumulator, object) => {
      return accumulator + Number(object.price);
    }, 0);
    let tot: any = Number(this.goldprice) + Number(this.totalmakingcharges);

    
    if (this.diamondval?.price) tot = tot + Number(this.diamondval?.price);
    if (this.diamondsolitaireval?.price)
      tot = tot + Number(this.diamondsolitaireval?.price);
    if (gemstonesum) tot = tot + Number(gemstonesum);

    this.total = parseFloat(tot).toFixed(3);

    let gst: any = 0.03 * Number(this.total);

    this.gsttotal = parseFloat(gst).toFixed(3);
    let gt: any = Number(this.total) + Number(this.gsttotal);

    this.grandtotal = Math.round(gt);
    
    

    this.goldData = {
      goldkt: this.goldkt,
      goldwt: this.goldwt,
      goldrate: this.goldrate,
      goldprice: this.goldprice,
      brsize: this.selectSize,
    };
    this.diamondData = {
      DiaType: this.diamondval?.type,
      Diakt: this.diamondval?.kt,
      diaPrice: this.diamondval?.price,
    };

    this.solitaireData = {
      SolitaireType: this.diamondsolitaireval?.type,
      Solitairekt: this.diamondsolitaireval?.kt,
      SolitairePrice: this.diamondsolitaireval?.price,
    };

    this.allCalculationData = {
      GoldPrice: this.goldData || "",
      DiamondPrice: this.diamondData || "",
      SolitairePrice: this.solitaireData || "",
      GemstonePrice: this.gemstoneval,
      MakingChargePrice: this.totalmakingcharges || "",
      TotalValue: this.total || "",
      Gst: this.gsttotal || "",
      GrandTotal: this.grandtotal || "",
      type: this.predefinedType,
      imagePath: this.productViewImages[0],
    };
    this.allData.CalculationData = this.allCalculationData;
    
  }

  changeGoldKT(data) {
    this.ktActiveClass = data;
    this.goldkt = data;
    let res;
    if (!!this.selectSize)
      res = this.calculationPart.filter(
        (x) => x.brsize == this.selectSize && x.kt == this.goldkt
      )[0];
    else res = this.calculationPart.filter((x) => x.kt == this.goldkt)[0];
    this.goldrate = parseFloat(res.rate).toFixed(3);
    this.goldwt = parseFloat(res.wt).toFixed(3);
    let goldprice: any = Number(this.goldrate) * Number(this.goldwt);
    this.goldprice = parseFloat(goldprice).toFixed(3);

    this.calculateTotal();
  }

  changeDiamond(data) {
    console.log("🚀 ~ file: client-design-annoation-productview.ts:722 ~ changeDiamond ~ data:", data)
    this.diamondActiveClass = data;   
    if(!!this.selectSize) {
      this.diamondval = this.predefinedDetail.totaldiamond.filter(
        (x) => x.type == data && x.brsize == this.selectSize
      )[0];
    } else {
      this.diamondval = this.predefinedDetail.totaldiamond.filter(
        (x) => x.type == data
      )[0];
    }
    if(!this.diamondval) {
      this.diamondval = this.predefinedDetail.totaldiamond.filter(
        (x) => x.type == data
      )[0];
    }
    this.calculateTotal();
  }

  changeSolitaire(data){
    this.solitaireActiveClass = data;
    this.diamondsolitaireval = this.predefinedDetail.totalsolitaire.filter(
      (x) => x.type == data
      )[0];
    this.calculateTotal();

  }
  gemstoneprice(data, i) {
    this.gemstoneval.splice(this.gemstoneval.findIndex(item => item.name === data.name), 1)
    this.typeActiveNatural = i;
    if (this.displayQuantity == "Natural") {
      this.activeCompo = "";
      for (const ele of this.GemstoneNatural) {
        let data = {
          type: ele.type,
          shape: ele.shape,
          name: ele.name,
          wt: ele.wt,
          rate: ele.rate1,
          price: ele.price1,
        };
        this.gemstoneval.push(data);
      }
    }

    for (const element of this.gemstoneval) {
      if (
        element.name == data.name &&
        element.shape == data.shape &&
        element.type == data.type &&
        element.wt == data.wt
      ) {
        if (i == 1) {
          element.rate = data.rate1;
          element.price = data.price1;
        } else if (i == 2) {
          element.rate = data.rate2;
          element.price = data.price2;
        } else if (i == 3) {
          element.rate = data.rate3;
          element.price = data.price3;
        }
      }
      this.unActiveSys = 0;
    }
    this.calculateTotal();
  }

  changeSize(data) {
    this.selectSize = data;
    let res = this.calculationPart.filter(
      (x) => x.brsize == this.selectSize && x.kt == this.goldkt
    )[0];
    this.goldrate = parseFloat(res.rate).toFixed(3);
    let goldprice: any = Number(res.rate) * Number(res.wt);
    this.goldprice = parseFloat(goldprice).toFixed(3);
    this.goldwt = parseFloat(res.wt).toFixed(3);
    let prediamondval = this.diamondval;
    this.diamondval = this.predefinedDetail.totaldiamond.filter(
      (x) => x.type == this.diamondActiveClass && x.brsize == this.selectSize
    )[0];
    if(!this.diamondval) {
      this.diamondval = prediamondval;
    }
    this.calculateTotal();
  }

  naturalRates() {
    this.showNaturalRates = true;
  }

  SaveActivity(activity) {
    var act = { activity: activity, vendor: this.merchant_id };
    this.ActivityStorage.push(act);
  }

  select(index) {
    this.currentPicture = index;
  }

  selectArrow() {
    if (this.currentPicture > 0) {
      this.currentPicture--;
    }
  }

  selectLeftArrow() {
    if (this.currentPicture < this.productViewImages.length - 1) {
      this.currentPicture++;
    }
  }

  ngOnInit() {}

  Alertpopup(forwhat, productname): void {
    const dialogRef = this.dialog.open(CommonalertpopupComponent, {
      // width: '250px',
      data: { mission: forwhat, name: productname },
    });

    dialogRef.afterClosed().subscribe((result) => {});
  }

  addToCompare(data) {
    this.CustomerOrdersService.addtocompare(data);
    this.Alertpopup("Compare", data.predefinedata.name);
  }

  addToCart(data: any) {
    
    this.CustomerOrdersService.addtocart(data);
    this.Alertpopup("Cart", data.predefinedata.name);
  }

  showMaterialSection() {
    this.materialSection = !this.materialSection;
  }
  showPriceBreakUp() {
    this.PriceBreakUp = !this.PriceBreakUp;
  }

  showQualityList(data) {
    this.displayQuantity = data;
    this.typeActive = data;
    this.gemstoneval = [];
    this.typeActiveNatural = 0;

    if (this.displayQuantity == "Natural") {
      this.displayNaturalRates = true;
      this.activeCompo = "Synthetic";
      for (const ele of this.GesmtoneSynthetic) {
        let data = {
          type: ele.type,
          shape: ele.shape,
          name: ele.name,
          wt: ele.wt,
          rate: ele.rate1,
          price: ele.price1,
        };
        this.gemstoneval.push(data);
      }
    } else {
      // this.activeCompo = 'Synthetic'
      for (const ele of this.GesmtoneSynthetic) {
        let data = {
          type: ele.type,
          shape: ele.shape,
          name: ele.name,
          wt: ele.wt,
          rate: ele.rate1,
          price: ele.price1,
        };
        this.gemstoneval.push(data);
      }
    }
  }
  showSynthetic() {
    this.gemstoneval = [];
    this.typeActiveNatural = "";
    this.activeCompo = "Synthetic";
    for (const ele of this.GesmtoneSynthetic) {
      let data = {
        type: ele.type,
        shape: ele.shape,
        name: ele.name,
        wt: ele.wt,
        rate: ele.rate1,
        price: ele.price1,
      };
      this.gemstoneval.push(data);
    }
    this.calculateTotal();
  }

  showSyntheticAll() {
    this.gemstoneval = [];
    this.typeActiveNatural = "";
    this.typeActive = "Synthetic";
    this.activeCompo = "Synthetic";
    this.displayNaturalRates = false;
    for (const ele of this.GesmtoneSynthetic) {
      let data = {
        type: ele.type,
        shape: ele.shape,
        name: ele.name,
        wt: ele.wt,
        rate: ele.rate1,
        price: ele.price1,
      };
      this.gemstoneval.push(data);
    }
  }

  goToLDCustomization(data) {
    var det =
      this.url_companyname +
      "/" +
      this.vendoruniquekey +
      "/customization/" +
      this.predefinedType +
      "/" +
      data.id +
      "/" +
      data.product_subtype_id +
      "/" +
      data.product_id;

    this.router.navigate([det]);
  }
  goToCSCustomization(data) {
    var det =
      this.url_companyname +
      "/" +
      this.vendoruniquekey +
      "/customization/" +
      this.predefinedType +
      "/" +
      data.id +
      "/" +
      data.productsubtypeid +
      "/" +
      data.productid;

    this.router.navigate([det]);
  }

  goToProduct(data) {}

  goToBack() {
    this._location.back();
  }
}
