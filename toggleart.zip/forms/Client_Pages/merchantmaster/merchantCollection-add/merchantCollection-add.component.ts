import { Component, OnInit } from "@angular/core";
import {
  FormControl,
  FormGroup,
  FormBuilder,
  FormArray,
  Validators,
} from "@angular/forms";
import { Router } from "@angular/router";
import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { MerchantCollection } from "@/_models/merchant_collection";
import { MerchantCollectionService } from "@/_services/merchant-collection.service";
import { environment } from "environments/environment";
import { VendorService } from "@/_services/vendor.service";
import { uploadType } from "@/masters/common.master";

@Component({
  selector: "app-merchantcollection-add",
  templateUrl: "./merchantcollection-add.component.html",
  styleUrls: ["./merchantcollection-add.component.css"],
})
export class MerchantCollectionAddComponent implements OnInit {
  loading = false;
  submitted = false;
  public selection: string;
  merchantCollectionForm: FormGroup;
  list: any = [];
  productSubList: any = [];
  vendor_id: number;
  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();
  modelImage: any;
  partImagePath: any;
  public path = `${environment.apiUrl}`;
  merchantData: any = [];
  merchantSetData: any = [];
  merchantListAll: any = [];
  merchantListLogin: any;
  public adminId = `${environment.adminId}`;
  merchant_id: number;
  uploadType = uploadType;
  videoData: any;
  partVideoPath: any;
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private vendorauthenticationService: VendorAuthenticationService,
    private MerchantCollectionService: MerchantCollectionService,
    private ProductSubTypeService: ProductSubTypeService,
    private vendorservices: VendorService,
    private authenticationService: AuthenticationService
  ) {
    // redirect if already logged in
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id =
        this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.createForm();
    this.getProductSubTypeData();
    this.getMerchantList();
  }

  createForm() {
    this.merchantCollectionForm = this.formBuilder.group({
      collectionName: ["", Validators.required],
      description: ["", Validators.required],
      merchantid: [this.merchant_id, Validators.required],
      img_type: ['Image'],
      merchantCollectionImg: this.formBuilder.array([this.Initial_Images()]),
    });
  }

  get f() {
    return this.merchantCollectionForm.controls;
  }

  getProductSubTypeData() {
    this.ProductSubTypeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.productSubList = this.list.data;
        });
      }
    });
  }

  onSubmit() {
    this.submitted = true;
    this.merchantCollectionForm.value.merchantCollectionImg.shift();

    if (this.merchantCollectionForm.valid) {
      const dataObj = {
        name: this.merchantCollectionForm.value.collectionName,
        description: this.merchantCollectionForm.value.description,
        merchant_id: this.merchantCollectionForm.value.merchantid,
        images: this.merchantCollectionForm.value.merchantCollectionImg,
      };

      this.MerchantCollectionService.save(dataObj).subscribe(
        (data: MerchantCollection) => {
          this.alertService.success(
            "Merchant Collection saved successfully!",
            true
          );
          if (this.vendor_id) {
            this.router.navigate(["merchantCollection/list"]);
          } else {
            this.router.navigate(["AdminMerchantCollection/list"]);
          }
        }
      );
    }
  }

  Initial_Images() {
    return this.formBuilder.group({
      images: [""],
      videoPath: [""],
      preview_video: [""],
      preview_Image: [""],
      image_selection: [""],
      modelImage: [""],
    });
  }

  get merchantCollectionImg() {
    return this.merchantCollectionForm.get(
      "merchantCollectionImg"
    ) as FormArray;
  }

  removeRow(index: number) {
    this.merchantCollectionImg.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  onImageUpload(files: File[]) {
    var base64valueModel;
    for (var element = 0; element < files.length; element++) {
      const readerModel = new FileReader();
      readerModel.readAsDataURL(files[element]);
      readerModel.onload = (event: any) => {
        if (event.target.result) {
          base64valueModel = event.target.result;
          let dataModelObj = {
            base64format: base64valueModel,
            imagePath: files[0].name,
          };
          if (this.merchantCollectionForm.value.img_type === "Image") {
            this.ProductSubTypeService.upload(dataModelObj).subscribe(
              (data) => {
                this.modelImage = data["data"];
                this.partImagePath =
                  this.path +
                  "/imagepreview/getImage?imagename=" +
                  this.modelImage;
                this.merchantCollectionImg.push(
                  this.formBuilder.group({
                    image_selection: [
                      this.merchantCollectionForm.value.img_type,
                    ],
                    images: [this.partImagePath],
                    modelImage: [this.modelImage],
                    preview_video: [false],
                    preview_Image: [false],
                  })
                );
              }
            );
          } else {
            this.ProductSubTypeService.videoUpload(dataModelObj).subscribe(
              (data) => {
                this.videoData = data["data"];
                this.partVideoPath =
                  this.path +
                  "/imagepreview/getImage?imagename=" +
                  this.videoData;
                this.merchantCollectionImg.push(
                  this.formBuilder.group({
                    image_selection: [this.merchantCollectionForm.value.img_type],
                    videoPath: [this.partVideoPath],
                    videoData: [this.videoData],
                    preview_video: [false],
                  })
                );
              }
            );
          }
        }
      };
    }
  }

  ////merchant list

  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantData = data;

          this.merchantSetData = this.merchantData.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });
        });
      }
    });
  }
  ////merchant list

  backToList() {
    if (this.vendor_id) {
      this.router.navigate(["merchantCollection/list"]);
    } else {
      this.router.navigate(["AdminMerchantCollection/list"]);
    }
  }
}
