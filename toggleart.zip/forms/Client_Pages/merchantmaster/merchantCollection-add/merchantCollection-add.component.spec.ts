import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantCollectionAddComponent } from './merchantCollection-add.component';

describe('VendorgoldrateaddComponent', () => {
  let component: MerchantCollectionAddComponent;
  let fixture: ComponentFixture<MerchantCollectionAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantCollectionAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantCollectionAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
