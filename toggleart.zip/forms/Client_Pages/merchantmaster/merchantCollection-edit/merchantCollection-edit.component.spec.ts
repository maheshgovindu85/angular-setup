import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantCollectionEditComponent } from './merchantCollection-edit.component';

describe('VendorgoldrateaddComponent', () => {
  let component: MerchantCollectionEditComponent;
  let fixture: ComponentFixture<MerchantCollectionEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantCollectionEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantCollectionEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
