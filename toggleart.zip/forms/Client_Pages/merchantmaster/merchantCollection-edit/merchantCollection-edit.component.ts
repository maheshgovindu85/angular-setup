import { Component, OnInit } from "@angular/core";
import {
  FormControl,
  FormGroup,
  FormBuilder,
  FormArray,
  Validators,
} from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { MerchantCollection } from "@/_models/merchant_collection";
import { MerchantCollectionService } from "@/_services/merchant-collection.service";
import { environment } from "environments/environment";
import { VendorService } from "@/_services/vendor.service";
import { uploadType } from "@/masters/common.master";

@Component({
  selector: "app-merchantcollection-edit",
  templateUrl: "./merchantcollection-edit.component.html",
  styleUrls: ["./merchantcollection-edit.component.css"],
})
export class MerchantCollectionEditComponent implements OnInit {
  loading = false;
  submitted = false;
  public selection: string;
  merchantCollectionEditForm: FormGroup;
  list: any = [];
  productSubList: any = [];
  vendor_id: number;
  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();
  modelImage: any;
  partImagePath: any;
  videoData: any;
  partVideoPath: any;
  public path = `${environment.apiUrl}`;
  merchantData: any = [];
  merchantSetData: any = [];
  merchantListAll: any = [];
  merchantListLogin: any;
  merchantId: any;
  merchantCollectionData: any = [];
  public adminId = `${environment.adminId}`;
  merchant_id: number;
  uploadType = uploadType;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private vendorauthenticationService: VendorAuthenticationService,
    private MerchantCollectionService: MerchantCollectionService,
    private ProductSubTypeService: ProductSubTypeService,
    private vendorservices: VendorService,
    private authenticationService: AuthenticationService,
    private route: ActivatedRoute
  ) {
    // redirect if already logged in
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id =
        this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.merchantId = this.route.snapshot.params.id;
    this.createForm();
    this.getProductSubTypeData();
    this.getMerchantList();
    this.getAllProductById();
  }

  createForm() {
    this.merchantCollectionEditForm = this.formBuilder.group({
      collectionName: ["", Validators.required],
      description: ["", Validators.required],
      img_type: ['Image'],
      merchantid: [this.merchant_id, Validators.required],
      isactive: [""],
      merchantCollectionImg: this.formBuilder.array([this.Initial_Images()]),
    });
  }

  get f() {
    return this.merchantCollectionEditForm.controls;
  }

  getProductSubTypeData() {
    this.ProductSubTypeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.productSubList = this.list.data;
        });
      }
    });
  }

  getAllProductById() {
    this.MerchantCollectionService.getMerchantCollectionById({
      id: this.merchantId,
    }).subscribe((data) => {
      if (data) {
        this.setFormValue(data);
      }
    });
  }
  setFormValue(data) {
    this.merchantCollectionData = data.data;
    this.merchantCollectionEditForm
      .get("isactive")
      ?.setValue(
        this.merchantCollectionData[0].isactive === "Y" ? true : false
      );
    this.merchantCollectionEditForm
      .get("collectionName")
      ?.setValue(this.merchantCollectionData[0].name);
    // this.merchantCollectionEditForm
    //   .get("img_type")
    //   ?.setValue(
    //     this.merchantCollectionData[0].img_type
    //   );
    this.merchantCollectionEditForm
      .get("description")
      ?.setValue(this.merchantCollectionData[0].description);
    this.merchantCollectionEditForm
      .get("merchantid")
      ?.setValue(this.merchantCollectionData[0].merchant_id);
    var JsonImgData = this.merchantCollectionData[0].images;
    var dataMerchantImages = JsonImgData;
    this.merchantCollectionEditForm.setControl(
      "merchantCollectionImg",
      this.setImageForm(dataMerchantImages)
    );
  }

  setImageForm(dataMerchantImages): FormArray {
    const formArray = new FormArray([]);
    dataMerchantImages.forEach((s) => {
      formArray.push(
        this.formBuilder.group({
          images: [s.images],
          videoPath: [s.videoPath],
          modelImage: [s.modelImage],
          image_selection: [s.image_selection],
          preview_video: [s.preview_video],
          preview_Image: [s.preview_Image],
        })
      );
    });

    return formArray;
  }
  onSubmit() {
    this.submitted = true;
    if (this.merchantCollectionEditForm.valid) {
      const dataObj = {
        id: this.merchantId,
        isactive:
          this.merchantCollectionEditForm.value.isactive === true ? "Y" : "N",
        name: this.merchantCollectionEditForm.value.collectionName,
        description: this.merchantCollectionEditForm.value.description,
        merchant_id: this.merchantCollectionEditForm.value.merchantid,
        images: this.merchantCollectionEditForm.value.merchantCollectionImg,
      };
      this.MerchantCollectionService.updateMerchantCollection(
        dataObj
      ).subscribe((data: MerchantCollection) => {
        this.alertService.success(
          "Merchant Collection updated successfully",
          true
        );
        if (this.vendor_id) {
          this.router.navigate(["merchantCollection/list"]);
        } else {
          this.router.navigate(["AdminMerchantCollection/list"]);
        }
      });
    }
  }

  Initial_Images() {
    return this.formBuilder.group({
      images: [""],
      videoPath: [""],
      modelImage: [""],
      preview_video: [''],
      preview_Image: [""],
      image_selection: ['']
    });
  }


  get merchantCollectionImg() {
    return this.merchantCollectionEditForm.get(
      "merchantCollectionImg"
    ) as FormArray;
  }

  removeRow(index: number) {
    this.merchantCollectionImg.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  onImageUpload(files: File[]) {
    var base64valueModel;
    for (var element = 0; element < files.length; element++) {
      const readerModel = new FileReader();
      readerModel.readAsDataURL(files[element]);
      readerModel.onload = (event: any) => {
        if (event.target.result) {
          base64valueModel = event.target.result;
          let dataModelObj = {
            base64format: base64valueModel,
            imagePath: files[0].name,
          };
          if (this.merchantCollectionEditForm.value.img_type === "Image") {
            this.ProductSubTypeService.upload(dataModelObj).subscribe(
              (data) => {
                this.modelImage = data["data"];
                this.partImagePath =
                  this.path +
                  "/imagepreview/getImage?imagename=" +
                  this.modelImage;
                this.merchantCollectionImg.push(
                  this.formBuilder.group({
                    image_selection: [
                      this.merchantCollectionEditForm.value.img_type,
                    ],
                    images: [this.partImagePath],
                    modelImage: [this.modelImage],
                    preview_video: [false],
                    preview_Image: [false],
                  })
                );
              }
            );
          } else {
            this.ProductSubTypeService.videoUpload(dataModelObj).subscribe(
              (data) => {
                this.videoData = data["data"];
                this.partVideoPath =
                  this.path +
                  "/imagepreview/getImage?imagename=" +
                  this.videoData;
                this.merchantCollectionImg.push(
                  this.formBuilder.group({
                    image_selection: [this.merchantCollectionEditForm.value.img_type],
                    videoPath: [this.partVideoPath],
                    videoData: [this.videoData],
                    preview_video: [false],
                  })
                );
                console.log('this.merchantCollectionImg',this.merchantCollectionImg);
                
              }
            );
          }
        }
      };
    }
  }

  ////merchant list

  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantData = data;

          this.merchantSetData = this.merchantData.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });
        });
      }
    });
  }
  ////merchant list

  backToList() {
    if (this.vendor_id) {
      this.router.navigate(["merchantCollection/list"]);
    } else {
      this.router.navigate(["AdminMerchantCollection/list"]);
    }
  }
}
