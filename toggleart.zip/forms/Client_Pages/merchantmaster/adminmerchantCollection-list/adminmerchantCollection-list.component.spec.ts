import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMerchantCollectionlistComponent } from './adminmerchantCollection-list.component';

describe('AdminMerchantCollectionlistComponent', () => {
  let component: AdminMerchantCollectionlistComponent;
  let fixture: ComponentFixture<AdminMerchantCollectionlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminMerchantCollectionlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminMerchantCollectionlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
