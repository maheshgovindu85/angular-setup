import { ChaindesignannotationService } from '@/_services/chaindesignannotation.service';
import { CustomerAuthenticationService } from '@/_services/customer-authentication.service';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { CustomerOrdersService } from '../../customer-orders.service';

import { Component, OnInit, ViewChild } from '@angular/core';

import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MerchantCollectionService} from '@/_services/merchant-collection.service'
import { AlertService, AuthenticationService, EncryptDecryptService, AddonService } from '@/_services';
import { MerchantCollection } from '@/_models/merchant_collection';


@Component({
  selector: 'app-adminmerchantcollection-lists',
  templateUrl: './adminmerchantcollection-list.component.html',
  styleUrls: ['./adminmerchantcollection-list.component.css']
})
export class AdminMerchantCollectionlistComponent implements OnInit {


  AddonFilterForm: FormGroup;
  searchForm: FormGroup;
  dataSource: MatTableDataSource<any>;
  closeResult: string;
  search_text = "";
  list :any =[];
  merchantCollectionList:any= [];
  filterMerchantCollectionList:any=[];
  isChecked: boolean;

  displayedColumns: string[] = ['orderid', 'customer', 'date', 'amount', 'status', 'actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private MerchantCollectionService: MerchantCollectionService
  
  ) {
   
  }

  ngOnInit(): void {
    this.createSearchForm();
    this.getCollectionList();
  }

  getCollectionList(){
    this.MerchantCollectionService.getAll()
    .subscribe(data => {
      if (data) {
        setTimeout(() => {
          this.list = data;
         this.merchantCollectionList = this.list.data;
         for(let i =0; i <this.merchantCollectionList.length;i++){
          this.merchantCollectionList[i].isactive = this.merchantCollectionList[i].isactive === 'N' ? false : true;
          this.merchantCollectionList[i].SrNo = i+1;
        }
         this.filterMerchantCollectionList = this.merchantCollectionList;
        });
      }
    });
  }

  // Search button function start
  createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [''],
    });
  }
  clear() {
    this.searchForm.get('keyword')?.setValue('');
    this.searchGrid();
  }
  searchGrid() {
    let keyword = this.searchForm.controls['keyword'].value;
    if (keyword === '') {
      this.filterMerchantCollectionList = this.merchantCollectionList;
    } else {
      keyword = keyword.toLowerCase();
      this.filterMerchantCollectionList = this.merchantCollectionList.filter((event) => {
        return (
          (event.product_subtype_id ===Number(keyword))||
          (event.name && event.name.toLowerCase().includes(keyword)) ||
          (event.product_sub_type && event.product_sub_type.toLowerCase().includes(keyword)) ||
          (event.description && event.description.toLowerCase().includes(keyword)) ||
          (event.merchantname && event.merchantname.toLowerCase().includes(keyword))
        );
      });
    }
  }


  
changeStatus(e,data: any){
  this.isChecked = e.checked;
  const dataObj = {
    id: data.id,
    isactive : this.isChecked ? 'Y' : 'N',
  };
  this.MerchantCollectionService.updateMerchantCollection(dataObj).subscribe((data: MerchantCollection) => {
    this.getCollectionList();
    this.alertService.success('Status Updated successfully!', true);
  });

}
 
}
