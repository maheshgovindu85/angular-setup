import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantCollectionlistComponent } from './merchantCollection-list.component';

describe('MerchantCollectionlistComponent', () => {
  let component: MerchantCollectionlistComponent;
  let fixture: ComponentFixture<MerchantCollectionlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantCollectionlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantCollectionlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
