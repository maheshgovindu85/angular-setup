import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewclientchainrelatedimagesPopupComponent } from './viewclientchainrelatedimages-popup.component';

describe('ViewclientchainrelatedimagesPopupComponent', () => {
  let component: ViewclientchainrelatedimagesPopupComponent;
  let fixture: ComponentFixture<ViewclientchainrelatedimagesPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewclientchainrelatedimagesPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewclientchainrelatedimagesPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
