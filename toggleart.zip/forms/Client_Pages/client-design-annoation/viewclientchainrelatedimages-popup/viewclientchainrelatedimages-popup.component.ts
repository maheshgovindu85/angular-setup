import { VendorCollectionService } from '@/_services';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ExecFileSyncOptionsWithBufferEncoding } from 'child_process';
import { ViewCustomerBraceletInfoComponent } from '../../view-customer-bracelet-info/view-customer-bracelet-info.component';

export class DialogChaindata {
  id: string;
  type: string;
}

@Component({
  selector: 'app-viewclientchainrelatedimages-popup',
  templateUrl: './viewclientchainrelatedimages-popup.component.html',
  styleUrls: ['./viewclientchainrelatedimages-popup.component.css']
})
export class ViewclientchainrelatedimagesPopupComponent implements OnInit {

  public Product_images: any[];
  public product: any[] = [];
  public serviceurl;

  CharmGoldData: any[] = [];
  CharmGemstoneData: any[] = [];
  CharmDiamondData: any[] = [];

  pictures: any[] = [];
  constructor(
    public dialogRef: MatDialogRef<ViewCustomerBraceletInfoComponent>,
    private metalgoldcolorservice: MetalgoldcolorService,
    private vendorCollectionService: VendorCollectionService,
    private route: ActivatedRoute,
    @Inject(MAT_DIALOG_DATA) public data: DialogChaindata
  ) {
    this.serviceurl = metalgoldcolorservice.path;
    vendorCollectionService.getchianrelatedimages(data.id, data.type).subscribe(
      (data: any) => {
        this.Product_images = data;
        this.product = [];
        this.pictures = [];
        this.Product_images.forEach((element, index) => {

          this.pictures.push({ 'id': index, 'media_type': this.extension(element.encodefilename), 'src': this.serviceurl + '/images/' + element.encodefilename, 'activethm': index <= 3 ? true : false });

        });

        // if (data.type == 'ballpearl') {
        //   vendorCollectionService.getStuddedchainDetails(data.id).subscribe(data => {
        //     var JsonData = JSON.parse(JSON.stringify(data));
        //     this.CharmGoldData = JsonData.charmgold;
        //     this.CharmDiamondData = JsonData.charmdiamond;
        //     this.CharmGemstoneData = JsonData.charmgemstone;
        //   })
        // }

      }
    )
  }

  diableprebtn: boolean = true;
  diablenextbtn: boolean = false;
  // clickprevious() {
  //   var activeimageindex: number;
  //   this.product.forEach((ele, index) => {
  //     if (ele.active == true) {
  //       activeimageindex = index;
  //     }
  //   })
  //   this.product.forEach((ele, index) => {
  //     ele.active = false;
  //   })
  //   if (activeimageindex - 1 == 0) {
  //     this.diableprebtn = true;
  //   } else {
  //     this.diableprebtn = false;
  //   }
  //   if (this.product[activeimageindex - 1]) {
  //     this.product[activeimageindex - 1].active = true;
  //     this.diablenextbtn = false;
  //   }
  // }
  // clicknext() {
  //   var activeimageindex: number;
  //   this.product.forEach((ele, index) => {
  //     if (ele.active == true) {
  //       activeimageindex = index;
  //     }
  //   })
  //   this.product.forEach((ele, index) => {
  //     ele.active = false;
  //   })
  //   if (this.product[activeimageindex + 1]) {
  //     this.diablenextbtn = false;
  //     this.product[activeimageindex + 1].active = true;
  //     this.diableprebtn = false;
  //     if ((activeimageindex + 2) == this.product.length) {
  //       this.diablenextbtn = true;
  //     }
  //   }
  // }

  ngOnInit(): void {
  }
  extension(str: string) {
    if (str.includes('png') || str.includes('jpeg') || str.includes('raw') || str.includes('jpg'))
      return 'Image';
    else
      return 'Video';
  }
  closemodal(): void {
    this.dialogRef.close();
  }



  currentPicture = 0;


  select(index) {
    this.currentPicture = index;
  }

  selectArrow() {
    if (this.currentPicture < this.pictures.length - 1) {
      this.currentPicture++;
    } else {
      this.currentPicture = 0;
    }
  }

  selectLeftArrow() {
    if (this.currentPicture > 0) {
      this.currentPicture--;
    } else {
      this.currentPicture = this.pictures.length - 1;
    }
  }

  clickprevious() {
    var thumbactiveimage: any[] = this.pictures.filter(f => f.activethm == true)
    if (thumbactiveimage.length > 3) {
      this.pictures[thumbactiveimage[0].id - 1].activethm = true;
      this.pictures[thumbactiveimage[3].id].activethm = false;
    }
  }

  clicknext() {
    var thumbactiveimage: any[] = this.pictures.filter(f => f.activethm == true)
    if (thumbactiveimage.length > 3) {
      this.pictures[thumbactiveimage[3].id + 1].activethm = true;
      this.pictures[thumbactiveimage[0].id].activethm = false;
    }
  }


}
