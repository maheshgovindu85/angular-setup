import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientDesignAnnoationComponent } from './client-design-annoation.component';

describe('ClientDesignAnnoationComponent', () => {
  let component: ClientDesignAnnoationComponent;
  let fixture: ComponentFixture<ClientDesignAnnoationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientDesignAnnoationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientDesignAnnoationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
