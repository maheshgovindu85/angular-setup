import {
  Component,
  OnInit,
  Input,
  OnDestroy,
  ViewChild,
  ViewContainerRef,
  Output,
  HostListener,
  EventEmitter,
  ComponentRef,
  ComponentFactory,
  ElementRef,
  ComponentFactoryResolver,
  ViewChildren,
  QueryList,
  ChangeDetectorRef
} from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
// import { CdkDragDrop, moveItemInArray, transferArrayItem, copyArrayItem } from '@angular/cdk/drag-drop';

import { AlertService, AuthenticationService, VendorAuthenticationService, VendorCollectionService } from '@/_services';

import { async, resetFakeAsyncZone } from '@angular/core/testing';
import { ChaindesignannotationService } from '@/_services/chaindesignannotation.service';
import { threadId } from 'worker_threads';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { Loosebraceletpattern } from '@/_models/loosebraceletpattern';
import { JewelleryDeleteBtnComponent } from '@/_components/jewellery-delete-btn/jewellery-delete-btn.component';
import { MatTabChangeEvent, MatTabGroup } from '@angular/material/tabs';
import { promises, resolve } from 'dns';
import { rejects } from 'assert';
import { NavbarservicesService } from '@/_services/navbarservices.service';
import { Console } from 'console';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CustomerAuthenticationService } from '@/_services/customer-authentication.service';
import { MatDialog } from '@angular/material/dialog';
import { VCollectionViewComponent } from '@/forms/vendor/collection/v-collection-view/v-collection-view.component';
import { CustomerOrdersService } from '../customer-orders.service';

// import html2canvas from 'html2canvas';

// import * as htmlToImage from 'html-to-image';
// import { toPng, toJpeg, toBlob, toPixelData, toSvg } from 'html-to-image';

/* in ES 6 */
// import domtoimage from "dom-to-image-more";
/* in ES 5 */
// var domtoimage = require("dom-to-image-more");
import domtoimage from 'dom-to-image-chrome-fix'; //Use your normal dom to image import
import { ViewCustomerCollectionComponent } from '../view-customer-collection/view-customer-collection.component';
import { ViewCustomerBraceletInfoComponent } from '../view-customer-bracelet-info/view-customer-bracelet-info.component';
import { ViewCustomeraddonRateInfoComponent } from '../view-customeraddon-rate-info/view-customeraddon-rate-info.component';
import { element } from 'protractor';
import { ViewclientchainrelatedimagesPopupComponent } from './viewclientchainrelatedimages-popup/viewclientchainrelatedimages-popup.component';
import { VendordiamondrateService } from '@/_services/vendordiamondrate.service';
import { VendorService } from '@/_services/vendor.service';
import { CommonalertpopupComponent } from '@/forms/CommonPopup/commonalertpopup/commonalertpopup.component';
import { ProductTypeService } from '@/_services/product-type.service';
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { environment } from 'environments/environment';

@Component({
  selector: 'app-client-design-annoation',
  templateUrl: './client-design-annoation.component.html',
  styleUrls: ['./client-design-annoation.component.css']
})
export class ClientDesignAnnoationComponent implements OnInit {

  @ViewChild('screenflat') flat_screen: ElementRef;

  predefinestructureCtrl = new FormControl();
  predefineBracelet: any[];
  filteredPredefineBaracelet: Observable<any[]>;
  public vendorlogo;
  showSubMenu = false;

  goldcolour = new FormControl();
  goldcolourList: any[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];

  studdedtype = new FormControl();
  studdedtypeList: any[] = [{ name: 'None', value: null }, { name: 'Diamond', value: 'diamond' }, { name: 'Gemstone', value: 'gemstone' }, { name: 'Diamond + Gemstone', value: 'combination' }];

  gemstonecolor = new FormControl();
  gemstonecolorList: any[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];

  selecttabindex: number = 0;
  value = 0;
  public design_pattern;
  public design_pattern_mod;
  public chain_images;
  public addon_images;
  public charm_images;
  public ring_images;
  public lock_images;

  public chain_images_filters: any[];
  public addon_images_filters: any[];
  public charm_images_filters: any[];
  public ring_images_filters: any[];
  public lock_images_filters: any[];

  public loosepattern_dtl: Loosebraceletpattern;

  public hasFlatcanvasImages: boolean = false;
  public hasModelcanvasImages: boolean = false;

  public has_predefinesPattern: boolean = true;
  public flatImageHidenComp = 0;
  public ModelImagesHidComp = 0;

  public chain_details;
  public chain_flat_details;
  public chain_model_details;

  loading = false;
  submitted = false;
  public topaxisIndex: number = 0;
  public topaxisIndexModel: number = 0;
  public delete_flatIds = 1;
  public activetab = 0;

  collections: any[];

  public topaxisPixel_flat = 100;
  public topaxisPixel_model = 100;
  public columnCount_flat = 1;
  public columnCount_model = 1;

  public ServerURL;
  designForm: FormGroup;
  left: number = 0;
  cmpt = this;
  public closebigimagesection: boolean = false;

  flatbase64Image: any;
  modelbase64Image: any;

  @ViewChildren('capa', { read: ViewContainerRef }) capa1: ViewContainerRef;
  @ViewChildren('capa') capaElementRef1: ElementRef;

  @ViewChild('capa2', { read: ViewContainerRef }) capa2: ViewContainerRef;
  @ViewChild('capa2') capaElementRef2: ElementRef;

  items1: any = [];

  public SetInitialImages_model: number = 0;
  items2: any = [];

  public collection_maxrange: any = 0;

  Stub: any[] = [];
  NumberOfStub: number = 0;

  Stub_model: any[] = [];
  NumberOfStub_model: number = 0;

  changecoordinates_flat: any[] = [];
  changecoordinates_model: any[] = [];

  flat_chain_charm_relarionDetails: any;
  model_chain_charm_relationDetails: any;

  identify_number_attached = 0;
  identify_number_hanging = 0;

  pre_click_charmId = 0;

  FLAT_Hanging_value_times = 0;
  MODEL_Hanging_value_times = 0;

  model_details_update = 0;

  public flatimagesPreview;
  public modelimagePreview;

  goldColorCtrl1 = new FormControl();
  goldcolors1: any[];
  filteredGoldColor1: Observable<any[]>;

  BraceletLengthCtrl = new FormControl();
  BraceletLengths: any[];
  filteredBraceletLength: Observable<any[]>;

  BraceletPatternCtrl = new FormControl();
  BraceletPatterns: any[];
  filteredBraceletPattern: Observable<any[]>;

  BraceletTypeCtrl = new FormControl();
  BraceletTypes: any[];
  filteredBraceletType: Observable<any[]>;

  MetalCtrl = new FormControl();
  Metals: any[];
  filteredMetal: Observable<any[]>;

  CollectionTypeCtrl = new FormControl();
  CollectionTypes: any[];
  filteredCollectionType: Observable<any[]>;

  public chainwidths;

  ChainTypeCtrl = new FormControl();
  ChainTypes: any[];
  filteredChainTypes: Observable<any[]>;

  pdGoldcolorCtrl = new FormControl();
  pdGoldcolors: any[];
  filteredpdGoldcolors: Observable<any[]>;

  pdgemstonecolorCtrl = new FormControl();
  pdgemstonecolors: any[];
  filteredpdgemstonecolor: Observable<any[]>;

  DiamondshapaeidCtrl = new FormControl();
  diamondshapeids: any[];
  filterediamondshapeids: Observable<any[]>;

  GemstoneshapaeidCtrl = new FormControl();
  Gemstonedshapeids: any[];
  filtereGemstoneShapeid: Observable<any[]>;

  colorpreferanceCtrl = new FormControl();
  colorpreferances: any[];
  filteredcolorpreferacns: Observable<any[]>;

  // For addon Filters

  addongemstonecolorCtrl = new FormControl();
  addongemstonecolors: any[];
  filteredAddon_gemstonecolor: Observable<any[]>;

  addon_DiamondshapaeidCtrl = new FormControl();
  addon_Diamondshapeids: any[];
  filtereAddonDiamondshapeids: Observable<any[]>;

  AddonGemstoneshapaeidCtrl = new FormControl();
  AddonGemstonedshapeids: any[];
  filtereAddonGemstoneShapeid: Observable<any[]>;
  // End Addon filters

  // Start Charm Filters
  charmgemstoneColorCtrl = new FormControl();
  charmgemstoneids: any[];
  filterecharmgemstoneid: Observable<any[]>;
  // End Charm Filters

  public braceletwisedesign: any;
  public braceletwisedesign_mod: any;

  public braceletTypeRanges: any;
  public braceletTypeRanges_mod: any;
  public bracelettype_collections: any;

  public collectiondetails: any[] = [];
  public collectiondetails_mod: any[] = [];

  public test_map_flat: any[] = [];
  public test_map_model: any[] = [];
  sessionUser: any;
  public serviceurl;
  public totalpriceofbracelet = 0.00;

  public BraceletPrices: any[] = [{ diamondwt: 0 }, { gemstonewt: 0 }, { goldwt: 0 }];

  NonCustomizeProduct: FormGroup;

  public rangePrice;
  public maxrangeofbraceltrate: number = 0;productId: any;
  productImagePath: string;
  currentRoute: any;
  url_companyname: string;
  productName: string;
  productSubName: string;
;

  public bracelettyperangecollectionWise: any;

  @ViewChild('videoPlayer') videoplayer: ElementRef;

  gemstonelengthCtrl = new FormControl();
  gemstonelengths: any[];
  filteredgemstonelength: Observable<any[]>;

  gemstonetypelist;
  studdedtypelist: any;

  showselectpositiondesign: boolean = false;

  vendorcompanyname;
  vendor_id;
  vendoruniquekey;
  isLoading = false;
  maxlength = 0;

  selectedCollectionid;
  selectedBracelettypeid;

  collapse_show1:boolean = true;
  collapse_show2:boolean = false;
  collapse_show3:boolean = false;
  collapse_show4:boolean = false;
  showProductData:boolean=false;
  productList: any = [];
  list: any=[];
  productSubList:any =[];
  selectedProduct:any=[];
  public path=`${environment.apiUrl}`;

  

 

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private CustomerAuthenticationService: CustomerAuthenticationService,
    private ChaindesignannotationService: ChaindesignannotationService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private NavbarservicesService: NavbarservicesService,
    private vendorCollectionService: VendorCollectionService,
    public CustomerOrdersService: CustomerOrdersService,
    private cdRef: ChangeDetectorRef,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private vendorauthenticationService: VendorAuthenticationService,
    private VendordiamondrateService: VendordiamondrateService,
    private vendorservice: VendorService,
    private producttypeService: ProductTypeService,
    private ProductSubTypeService: ProductSubTypeService ,
    private resolver: ComponentFactoryResolver
    
    ) {

 
    authenticationService.logoutFromcustomer();

    // if (!this.CustomerAuthenticationService.customercurrentUser) {
    //   this.router.navigate(['customer/login']);
    // }

    

    var tabindexno: number = Number(this.route.snapshot.paramMap.get('tabindex'));
    if (Number(tabindexno)) {
      this.selecttabindex = tabindexno;
    }

    this.serviceurl = metalgoldcolorservice.path;
    if (CustomerAuthenticationService.customercurrentUserValue)
      this.sessionUser = CustomerAuthenticationService.customercurrentUserValue;

    if (this.vendorauthenticationService.vendorcurrentUserValue)
      this.sessionUser = this.vendorauthenticationService.vendorcurrentUserValue;
    const id = this.route.snapshot.params.id;

    // For Product get Details
    ChaindesignannotationService.getPredefinedBracelet().subscribe(
      (data) => {
        this.predefineBracelet = data;
        this.filteredPredefineBaracelet = this.predefinestructureCtrl.valueChanges
          .pipe(
            startWith(''),
            map(m => m ? this.filterPredefinedBaceltetStructure(m) : this.predefineBracelet.slice())
          );
      });

    this.ChaindesignannotationService.getAllgoldColors()
      .subscribe((data) => {
        this.goldcolors1 = data;
        this.filteredGoldColor1 = this.goldColorCtrl1.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterGoldColor1(color) : this.goldcolors1.slice())
          );
      });

    this.ChaindesignannotationService.getAllBraceletlenght()
      .subscribe((data) => {
        this.BraceletLengths = data;
        this.filteredBraceletLength = this.BraceletLengthCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterbraceletlength(color) : this.BraceletLengths.slice())
          );
      });

    this.ChaindesignannotationService.getAllLooseBraceletPattern()
      .subscribe((data) => {
        this.BraceletPatterns = data;
        this.filteredBraceletPattern = this.BraceletPatternCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterbraceletpattern(color) : this.BraceletPatterns.slice())
          );
      });

    this.ChaindesignannotationService.get_Bracelettype()
      .subscribe((data) => {
        this.BraceletTypes = data;
        this.filteredBraceletType = this.BraceletTypeCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterbraceletTypes(color) : this.BraceletTypes.slice())
          );
      });

    this.ChaindesignannotationService.getallMetals()
      .subscribe((data) => {
        this.Metals = data;
        this.filteredMetal = this.MetalCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filtermetals(color) : this.Metals.slice())
          );
      });

    this.ChaindesignannotationService.gelallcollectiontype()
      .subscribe((data) => {
        this.CollectionTypes = data;
        this.filteredCollectionType = this.CollectionTypeCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filtercollectiontypes(color) : this.CollectionTypes.slice())
          );
      });

    this.ChaindesignannotationService.getAllgoldColors()
      .subscribe((data) => {
        this.pdGoldcolors = data;
        this.filteredpdGoldcolors = this.pdGoldcolorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterpdgoldcolors(color) : this.pdGoldcolors.slice())
          );
      });

    this.ChaindesignannotationService.getgemstonecolour()
      .subscribe((data) => {
        this.charmgemstoneids = data;
        this.filterecharmgemstoneid = this.charmgemstoneColorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterCharmGemstonecolors(color) : this.charmgemstoneids.slice())
          );
      });

    ChaindesignannotationService.getbraceleteLength().subscribe(
      (data) => {
        this.gemstonelengths = data;
        this.filteredgemstonelength = this.gemstonelengthCtrl.valueChanges
          .pipe(
            startWith(''),
            map(coll => coll ? this.filterGemstonelength(coll) : this.gemstonelengths.slice()),
          );
      });

    this.ChaindesignannotationService.getallchainwidth()
      .subscribe((data) => {
        this.chainwidths = data;
      })



    ChaindesignannotationService.getgemstonetypelist().subscribe(
      (data) => {
        this.gemstonetypelist = data;
      });

    ChaindesignannotationService.getstuddettypelist().subscribe(data => {
      this.studdedtypelist = data;
    })

    this.ChaindesignannotationService.gelallchainType()
      .subscribe((data) => {
        this.ChainTypes = data;
        this.filteredChainTypes = this.ChainTypeCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterChainTypes(color) : this.ChainTypes.slice())
          );
      });

    this.ChaindesignannotationService.gelallchaincolorPref()
      .subscribe((data) => {
        this.colorpreferances = data;
        this.filteredcolorpreferacns = this.colorpreferanceCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterColorrefs(color) : this.colorpreferances.slice())
          );
      });

    this.ChaindesignannotationService.gelallchaincolorPref()
      .subscribe((data) => {
        this.pdgemstonecolors = data;
        this.filteredpdgemstonecolor = this.pdgemstonecolorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterPDgemstonecolrs(color) : this.pdgemstonecolors.slice())
          );
      });

    this.ChaindesignannotationService.getdiamondshapedetails()
      .subscribe((data) => {
        this.diamondshapeids = data;
        this.filterediamondshapeids = this.DiamondshapaeidCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterDiamondshape(color) : this.diamondshapeids.slice())
          );
      });

    // start Addon filters  
    this.ChaindesignannotationService.gelallchaincolorPref()
      .subscribe((data) => {
        this.addongemstonecolors = data;
        this.filteredAddon_gemstonecolor = this.addongemstonecolorCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterAddonGemstonecolor(color) : this.addongemstonecolors.slice())
          );
      });

    this.ChaindesignannotationService.getgemstoneshapedetails()
      .subscribe((data) => {
        this.AddonGemstonedshapeids = data;
        this.filtereAddonGemstoneShapeid = this.AddonGemstoneshapaeidCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterAddonGemstoneshape(color) : this.AddonGemstonedshapeids.slice())
          );
      });

    this.ChaindesignannotationService.getdiamondshapedetails()
      .subscribe((data) => {
        this.addon_Diamondshapeids = data;
        this.filtereAddonDiamondshapeids = this.addon_DiamondshapaeidCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterAddonDiamondshape(color) : this.addon_Diamondshapeids.slice())
          );
      });

    this.ChaindesignannotationService.getdiamondshapedetails()
      .subscribe((data) => {
        this.addon_Diamondshapeids = data;
        this.filtereAddonDiamondshapeids = this.addon_DiamondshapaeidCtrl.valueChanges
          .pipe(
            startWith(''),
            map(color => color ? this.filterAddonDiamondshape(color) : this.addon_Diamondshapeids.slice())
          );
      });
    //End addon Filters

    this.ChaindesignannotationService.getDesignStructure_bypatternwise().subscribe(data => {
      this.braceletwisedesign = data;
      this.braceletwisedesign_mod = data;
    })

    this.designForm = this.formBuilder.group({
      id: [0, Validators.required],
      customerid: [0, Validators.required],
      name: ['Bracelet_Design', Validators.required],
      pre_braceletpattern: [0, Validators.required],
      loosebraceletPatternid: [0, Validators.required],
      braceletchain_id: [0, Validators.required],
      braceletcartfrom: ['predefined'],
      chainflatImages_id: [0, Validators.required],
      chainmodelImages_id: [0, Validators.required],
      isdelete: [false, Validators.required],
      clickfromproduct: ['', Validators.required],
      // some additional form fields
      design_tools_charm: [''],
      design_tools_addon: [''],
      design_tools_lock: [''],
      design_tools_ring: [''],
      pricerange: [''],
      // New Fields
      totalprice: [this.totalpriceofbracelet, Validators.required],
      subtotal: [],
      taxvalue: [],
      gold: [0, Validators.required],
      gemstone: [0, Validators.required],
      diamond: [0, Validators.required],
      margin: [0, Validators.required],
      quantity: [1, Validators.required],
      image: ['no image', Validators.required],
      image_model: [''],
      producttype: ['customizedesign', Validators.required],
      braceletwidth_id: [0],
      charmstuddedtype: [''],
      //end addition fields
      vendorid: [this.vendor_id, Validators.required],
      customer_id: [0, Validators.required],

      flat_chain_designAnnotation: this.formBuilder.array([]),
      model_chain_designAnnotation: this.formBuilder.array([]),
      delete_flat_images: this.formBuilder.array([]),
      delete_model_images: this.formBuilder.array([]),

      flat_relation_details: this.formBuilder.array([]),
      model_relation_details: this.formBuilder.array([]),

      braceletgoldkt: ['', Validators.required],
      diamondcolorpuritycombo: ['', Validators.required],
      braceletgemstonetype: ['140'],
      braceletsize: ['0', Validators.required],

      colllectionid: [0, Validators.required],
      bracelettypeid: [0, Validators.required],
    });

    this.vendoruniquekey = this.route.snapshot.paramMap.get('vendoruniquekey');
     this.url_companyname = this.route.snapshot.paramMap.get('companyname');
    localStorage.setItem("vendorcompany", this.url_companyname);
    localStorage.setItem("vendorkey", this.vendoruniquekey)
    this.VendordiamondrateService.vendordetailwithuniquekey(this.vendoruniquekey).subscribe((data: any) => {
      this.vendor_id = data.id
      
      this.vendorcompanyname = data.company;
      //Getting Vendor Id
      this.vendorservice.getvendorlogo(this.vendor_id).then((data: any) => {
        this.vendorlogo = data.dynamicfilename;
        this.vendorlogo= this.path + "/imagepreview/getImage?imagename=" + this.vendorlogo;
        console.log('this.vendorlogo:', this.vendorlogo);
      })
      // Set New Vendor id here
      this.ChaindesignannotationService.get_BracelettypeRange(this.vendor_id).subscribe((data: any) => {
        this.braceletTypeRanges = data;
        // this.braceletTypeRanges_mod = data;
        // if (data.length > 0)
        // this.maxrangeofbraceltrate = Number(this.braceletTypeRanges[data.length - 1].braceletrate) + Number(100);
      })

      this.ChaindesignannotationService.get_vendorCollection(this.vendor_id).subscribe(data => {
        this.collectiondetails = data;
        this.collection_maxrange = 1000000; //data[0].price + 100;
        this.collectiondetails_mod = data;
        for(let i=0; i < this.collectiondetails_mod.length; i++){
          this.collectiondetails_mod[i].TACollectionImg = this.path + "/imagepreview/getImage?imagename=" + this.collectiondetails_mod[i].img_vid_path;
        }
      })


        //// Subproduct  list end////

        this.ProductSubTypeService.getfrontendProductSubtype({merchantid: this.vendor_id})
        .subscribe(data => {
          this.list = data;
          this.productSubList = this.list.data;
          for(let i =0; i <this.productSubList.length;i++){
            this.productSubList[i].subProdctImage =  this.productSubList[i].frontendimage
          }
        });

       //// SUbproduct  list end////

    

      this.ChaindesignannotationService.getloosebracelet_withcollection().subscribe(data => {
        this.bracelettype_collections = data;
      })

      this.selectedCollectionid = Number(this.route.snapshot.paramMap.get('collectionid'));
      this.selectedBracelettypeid = Number(this.route.snapshot.paramMap.get('bracelettype'));

      this.ChaindesignannotationService.bracelettyperangecollectionwise(this.vendor_id).subscribe(data => {
        this.bracelettyperangecollectionWise = data;
        var filtercollectionid: number = this.selectedCollectionid;

        // var collectionid: number = this.selectedBracelettypeid;

        this.braceletTypeRanges_mod = this.bracelettyperangecollectionWise.filter(rng => rng.collection_id == filtercollectionid)
      })

      this.ChaindesignannotationService.setopenlinkactivity(this.vendor_id)
        .subscribe((data) => {
        })

      // this.isLoading = true;
      // this.ChaindesignannotationService.getEntiredesigntools(this.vendor_id, 0).then(data => {
      //   var JsonData = JSON.parse(JSON.stringify(data));
      //   this.isLoading = false;
      //   var entire_Designannotation = JsonData.entire_Designannotation;
      //   var entire_chains = JsonData.entire_chains;
      //   var Braceletstructure_addon = JsonData.entire_Bracelet_addon;
      //   var Braceletstructure_charm = JsonData.entire_Bracelet_charm;
      //   var Braceletstructure_lock = JsonData.entire_Bracelet_lock;
      //   var Braceletstructure_ring = JsonData.entire_Bracelet_ring;

      //   this.chain_images = entire_chains;
      //   this.design_pattern = entire_Designannotation;
      //   this.addon_images = Braceletstructure_addon;
      //   this.charm_images = Braceletstructure_charm;
      //   this.ring_images = Braceletstructure_ring;
      //   this.lock_images = Braceletstructure_lock;

      //   this.addon_images_filters = Braceletstructure_addon;
      //   this.charm_images_filters = Braceletstructure_charm;
      //   this.ring_images_filters = Braceletstructure_ring;
      //   this.lock_images_filters = Braceletstructure_lock;
      //   this.chain_images_filters = entire_chains;


      //   var filteredbraceletid: number = this.selectedBracelettypeid;
      //   var collectionid: number = this.selectedCollectionid;

      //   this.maxlength = Math.max.apply(Math, this.design_pattern.map(function (o) { return o.price; }));

      //   this.design_pattern_mod = this.design_pattern.filter(f => (f.bracelet_type_id == filteredbraceletid && f.collection_id == collectionid))

      //   if (this.design_pattern[0].id) {
      //   } else {
      //     this.openSnackBar('Design Not Available', 'close');
      //   }
      //   this.DefaultSeletedTools(1, 'product');

      //   this.goldColorCtrl1.valueChanges.subscribe(value => {
      //     this.addon_images_filters = this.addon_images.filter(chn => Number(chn.goldcolorid) === Number(value))
      //     this.charm_images_filters = this.charm_images.filter(chn => Number(chn.goldcolorid) === Number(value))
      //     this.ring_images_filters = this.ring_images.filter(chn => Number(chn.goldcolorid) === Number(value))
      //     this.lock_images_filters = this.lock_images.filter(chn => Number(chn.goldcolorid) === Number(value))
      //     this.chain_images_filters = this.chain_images.filter(chn => Number(chn.goldcolorid) === Number(value));
      //   })
      // }, error => this.isLoading = false)

      this.designForm = this.formBuilder.group({
        id: [0, Validators.required],
        customerid: [0, Validators.required],
        name: ['Bracelet_Design', Validators.required],
        pre_braceletpattern: [0, Validators.required],
        loosebraceletPatternid: [0, Validators.required],
        braceletchain_id: [0, Validators.required],
        braceletcartfrom: ['predefined'],
        chainflatImages_id: [0, Validators.required],
        chainmodelImages_id: [0, Validators.required],
        isdelete: [false, Validators.required],
        clickfromproduct: ['', Validators.required],
        // some additional form fields
        design_tools_charm: [''],
        design_tools_addon: [''],
        design_tools_lock: [''],
        design_tools_ring: [''],
        pricerange: [''],
        // New Fields
        totalprice: [this.totalpriceofbracelet, Validators.required],
        subtotal: [],
        taxvalue: [],
        gold: [0, Validators.required],
        gemstone: [0, Validators.required],
        diamond: [0, Validators.required],
        margin: [0, Validators.required],
        quantity: [1, Validators.required],
        image: ['no image', Validators.required],
        image_model: [''],
        producttype: ['customizedesign', Validators.required],
        braceletwidth_id: [0],
        charmstuddedtype: [''],
        //end addition fields
        vendorid: [this.vendor_id, Validators.required],
        customer_id: [0, Validators.required],

        flat_chain_designAnnotation: this.formBuilder.array([]),
        model_chain_designAnnotation: this.formBuilder.array([]),
        delete_flat_images: this.formBuilder.array([]),
        delete_model_images: this.formBuilder.array([]),

        flat_relation_details: this.formBuilder.array([]),
        model_relation_details: this.formBuilder.array([]),

        braceletgoldkt: ['', Validators.required],
        diamondcolorpuritycombo: ['', Validators.required],
        braceletgemstonetype: ['140'],
        braceletsize: ['0', Validators.required],

        colllectionid: [this.selectedCollectionid, Validators.required],
        bracelettypeid: [this.selectedBracelettypeid, Validators.required],
      });
      this.ServerURL = this.metalgoldcolorservice.path;

      this.CollectionTypeCtrl.valueChanges.subscribe(value => {
        if (Number(value)) {
          this.collectiondetails_mod = this.collectiondetails.filter(cll => cll.collectiontype_id == value)
        }
      })

      this.pdGoldcolorCtrl.valueChanges.subscribe(value => { })

      this.ChainTypeCtrl.valueChanges.subscribe(value => {
        this.chain_images_filters = this.chain_images.filter(typ => typ.chain_type_id == value)
      })

      this.BraceletLengthCtrl.valueChanges.subscribe(value => {
        if (Number(value)) {
        }
      })
      this.DiamondshapaeidCtrl.valueChanges.subscribe(value => {
        this.charm_images_filters = this.charm_images.filter(chm => chm.diamond_shape_id == value)
      })
      this.AddonGemstoneshapaeidCtrl.valueChanges.subscribe(value => {
        this.charm_images_filters = this.charm_images.filter(chm => chm.gem_stoneshapeid == value)
      })

      this.addon_DiamondshapaeidCtrl.valueChanges.subscribe(value => {
        this.addon_images_filters = this.addon_images.filter(gem => gem.diamond_shape_id == value)
      })
      this.addongemstonecolorCtrl.valueChanges.subscribe(value => {
        this.addon_images_filters = this.addon_images.filter(gem => gem.color_id == value)
      })
      this.AddonGemstoneshapaeidCtrl.valueChanges.subscribe(value => {
        this.addon_images_filters = this.addon_images.filter(gem => gem.gem_stoneshapeid == value)
      })

      this.charmgemstoneColorCtrl.valueChanges.subscribe(value => {
        this.charm_images_filters = this.charm_images.filter(chm => chm.globalcolorpre == value)
      })

      this.pdgemstonecolorCtrl.valueChanges.subscribe(value => {
      })

      this.NonCustomizeProduct = this.formBuilder.group({
        id: ['', Validators.required],
        name: ['', Validators.required],
        totalprice: ['', Validators.required],
        subtotal: [],
        taxvalue: [],
        gold: ['', Validators.required],
        gemstone: ['', Validators.required],
        diamond: ['', Validators.required],
        margin: ['', Validators.required],
        quantity: ['', Validators.required],
        producttype: ['', Validators.required]
      })
      // Complete
    });


 

  }

  async ngOnInit() {
    this.getProductList();

    this.test_map_flat = [
      { id: 0, name: 'Tab1', status: false }
    ];

    this.test_map_model = [
      { id: 0, name: 'Tab1', status: true }
    ];

    // gold filters
    this.goldcolour.valueChanges.subscribe((data: any) => {
      // For Chain Filters
      this.chain_images_filters = [];
      data.forEach(element => {
        var a = this.chain_images.filter(chn => Number(chn.goldcolorid) === Number(element));
        a.forEach(element2 => {
          this.chain_images_filters.push(element2);
        });
      });

      // For Charm Filters
      this.charm_images_filters = [];
      data.forEach(element => {
        var a = this.charm_images.filter(chn => Number(chn.goldcolorid) === Number(element));
        a.forEach(element2 => {
          this.charm_images_filters.push(element2);
        });
      });

      // For Addon Filters
      this.addon_images_filters = [];
      data.forEach(element => {
        var a = this.addon_images.filter(chn => Number(chn.goldcolorid) === Number(element));
        a.forEach(element2 => {
          this.addon_images_filters.push(element2);
        });
      });

      // For Lock Filters
      this.lock_images_filters = [];
      data.forEach(element => {
        var a = this.lock_images.filter(chn => Number(chn.goldcolorid) === Number(element));
        a.forEach(element2 => {
          this.lock_images_filters.push(element2);
        });
      });

      // For Ring Filters
      this.ring_images_filters = [];
      data.forEach(element => {
        var a = this.ring_images.filter(chn => Number(chn.goldcolorid) === Number(element));
        a.forEach(element2 => {
          this.ring_images_filters.push(element2);
        });
      });

    })

    //  studdedtype filters
    this.studdedtype.valueChanges.subscribe(data => {
      this.addon_images_filters = [];
      data.forEach(element => {
        this.addon_images_filters.push(this.addon_images.filter(adn => adn.addontype == element));
      });

      this.charm_images_filters = [];
      data.forEach(element => {
        this.charm_images_filters.push(this.charm_images.filter(chm => chm.studdedtype == element));
      });
    })

    this.gemstonecolor.valueChanges.subscribe(data => {
      
    })
  }


  ngAfterViewInit() {

  }

  public pre_braceletpatterngold = 0;
  public pre_braceletpatterngemstone = 0;
  public pre_braceletpatterndiamond = 0;
  public pre_braceletpatterngoldcarat = 0;

  ViewPredefinedDetails(id, design) {

    this.designForm.get('id').setValue(design.id);
    // this.BhuildStructure_design(design.id, design.vendor_id);

    const dialogRef = this.dialog.open(ViewCustomerBraceletInfoComponent, {
      width: "100%",
      height: "700px",
      data: { id: id, vendor_id: this.vendor_id, design: this.designForm }
    });
    dialogRef.afterClosed().subscribe(result => {
      // 
      // 
    });
  }

  Viewchainorlink(id: number, chaintype: string) {
    const dialogRef = this.dialog.open(ViewclientchainrelatedimagesPopupComponent, {
      width: "45%",
      // height: "80%",
      data: { id: id, type: chaintype }
    });

    dialogRef.afterClosed().subscribe(result => {
      
    });
  }

  Changecolorpurity() {

    var checkcolorcombo = setInterval(() => {
      if (this.designForm.get('diamondcolorpuritycombo').value != '') {
        clearInterval(checkcolorcombo)
        this.diamondComboination.forEach(element => {
          if (element.comboid == this.designForm.get('diamondcolorpuritycombo').value) {
            this.diamondcolorcombinationName = element.colorname + "/" + element.purityname
          }
        });
      }
    }, 0);
    return this.diamondcolorcombinationName;
  }


  ViewcharmDetails(id) {
    this.ChaindesignannotationService.getcharmsratecalculation(id).subscribe(rate => {
      const dialogRef = this.dialog.open(ViewCustomeraddonRateInfoComponent, {
        width: "45%",
        // height: "80%",
        data: { id: id, gold: rate[0].goldwt, goldkt: rate[3].goldKT, diamond: rate[1].diamondwt, gemstone: rate[2].gemstonewt, tooltype: 'charm' }
      });

      dialogRef.afterClosed().subscribe(result => {
        // 
      });
    })
  }

  ViewAddonDetails(id) {
    const dialogRef = this.dialog.open(ViewCustomeraddonRateInfoComponent, {
      width: "45%",
      // height: "80%",
      data: { id: id, tooltype: 'addon' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // 
    });
  }

  checkcharmstuddenttype() {
    var studdedtype = this.designForm.get('charmstuddedtype').value;
    
    this.charm_images_filters = this.charm_images;
    this.charm_images_filters = this.charm_images_filters.filter(ch => ch.studdedtype == studdedtype)
    // 
  }
  changestuddedtype() {
    this.chain_images_filters = this.chain_images;
  }

  public tabIndexid;
  tabChanged(tabChangeEvent: MatTabChangeEvent): void {
    var activated_tab = tabChangeEvent.index;
    this.tabIndexid = activated_tab;
    this.collectiondetails_mod = this.collectiondetails;
    this.chain_images_filters = this.chain_images;
    this.charm_images_filters = this.charm_images;
    this.addon_images_filters = this.addon_images;
    this.lock_images_filters = this.lock_images;
    this.ring_images_filters = this.ring_images;
    // this.design_pattern_mod = this.design_pattern;

    this.selecttabindex = activated_tab;

    switch (activated_tab) {
      case 0:
        // alert('called here')
        this.designForm.get("colllectionid").setValue(0);
        this.designForm.get("bracelettypeid").setValue(0);

        this.selectedCollectionid = 0;
        this.selectedBracelettypeid = 0;

        this.design_pattern_mod = [];
        this.braceletTypeRanges_mod = [];
      case 1:
        this.closebigimagesection = false;
        this.showselectpositiondesign = false;
        break;
      case 2:
        this.closebigimagesection = false;
      case 3:
        this.closebigimagesection = false;
        this.showselectpositiondesign = false;
        break;
      case 4:
        this.closebigimagesection = true;
        this.showselectpositiondesign = false;
        break;
      case 5:
      case 6:
      case 7:
      case 8:
        this.showselectpositiondesign = true;
        this.closebigimagesection = true;
        break;
      default:
        this.closebigimagesection = false;
        break;
    }
  }
  // this.braceletTypeRanges_mod = this.braceletTypeRanges;
  // this.braceletwisedesign_mod = this.braceletwisedesign;

  clearfilters(tabname) {
    switch (tabname) {
      case 'collection':
        this.collectiondetails_mod = this.collectiondetails;
        break;
      case 'bracelettype':
        // this.braceletTypeRanges_mod = this.braceletTypeRanges;
        break;
      case 'braceletpattern':
        // this.braceletwisedesign_mod = this.braceletwisedesign;
        break;
      case 'chain':
        this.chain_images_filters = this.chain_images;
        break;
      case 'charm':
        this.charm_images_filters = this.charm_images;
        break;
      case 'addon':
        this.addon_images_filters = this.addon_images;
        break;
      case 'lock':
        this.lock_images_filters = this.lock_images;
        break;
      case 'ring':
        this.ring_images_filters = this.ring_images;
        break;
    }
  }

  change(element: any) {
    if (element.value > 0) {
      this.collectiondetails_mod = this.collectiondetails.filter(coll => coll.price <= element.value)
    }
  }

  ChangeRangePrice(element: any) {
    if (element.value > 0) {
      this.braceletTypeRanges_mod = this.braceletTypeRanges.filter(rng => rng.braceletrate <= element.value)
    }
  }

  changeBraceletrange(element: any) {
    var Collcetionvalue = this.designForm.get("colllectionid").value;
    var Braceletvalue = this.designForm.get("bracelettypeid").value;

    if (element.value > 0) {
      this.value = element.value;
      this.design_pattern_mod = this.design_pattern.filter(f => (f.price <= element.value && f.bracelet_type_id == Braceletvalue && f.collection_id == Collcetionvalue))
    }
  }

  async BhuildStructure_design(id, vendorid, object) {

    await this.ChaindesignannotationService.getBraceletAnnotationDetails(id).then(
      data => {
        var JsonData = JSON.parse(JSON.stringify(data));
        var desingAnnotation = JsonData.desingAnnotation;
        var desingAnnotation_flat = JsonData.desingAnnotation_flat;
        var desingAnnotation_model = JsonData.desingAnnotation_model;
        var chain_Design_flat_relation = JsonData.chain_Design_flat_relation;
        var chain_design_model_relation = JsonData.chain_design_model_relation;

        this.chain_details = desingAnnotation;
        this.chain_flat_details = desingAnnotation_flat;
        this.chain_model_details = desingAnnotation_model;

        // this.ChaindesignannotationService.setcustomizationlinkactivity(this.vendor_id)
        //   .subscribe((data) => {
        //   })

        // for ralation maintained
        this.flat_chain_charm_relarionDetails = chain_Design_flat_relation;
        this.model_chain_charm_relationDetails = chain_design_model_relation;

        switch (desingAnnotation[0].linkballpearl) {
          case 'chain':

            break;
          case 'link':

            break;
          case 'ball-pearl':

            break;
        }

        this.designForm = this.formBuilder.group({
          id: [desingAnnotation[0].id, Validators.required],
          name: [desingAnnotation[0].predefinedbraceletname, Validators.required],
          pre_braceletpattern: [desingAnnotation[0].pre_braceletpattern, Validators.required],
          loosebraceletPatternid: [desingAnnotation[0].loosebraceletpatternid, Validators.required],
          braceletchain_id: [desingAnnotation[0].braceletchain_id, Validators.required],
          braceletchaintype: [''],
          isdelete: [false, Validators.required],
          braceletcartfrom: ['predefined'],
          delete_flat_images: this.formBuilder.array([]),
          delete_model_images: this.formBuilder.array([]),
          design_tools_charm: [''],
          design_tools_addon: [''],
          design_tools_lock: [''],
          design_tools_ring: [''],
          linkchainlockid: [desingAnnotation[0].lock_id],

          totalprice: [0, Validators.required],
          subtotal: [],
          taxvalue: [],
          gold: [0, Validators.required],
          gemstone: [0, Validators.required],
          diamond: [0, Validators.required],
          margin: [0, Validators.required],
          quantity: [1, Validators.required],
          image: [object.img_path, Validators.required],
          image_model: [''],
          producttype: ['collection', Validators.required],
          braceletwidth_id: [1],
          charmstuddedtype: [''],
          //End New Fields
          customerid: [0, Validators.required],
          chainflatImages_id: [desingAnnotation[0].chainflatimages_id, Validators.required],
          chainmodelImages_id: [desingAnnotation[0].chainmodelimages_id, Validators.required],
          clickfromproduct: ['', Validators.required],
          // some additional form fields
          pricerange: [''],
          //end addition fields
          vendorid: [this.vendor_id, Validators.required],

          flat_chain_designAnnotation: this.formBuilder.array([]),
          model_chain_designAnnotation: this.formBuilder.array([]),
          flat_relation_details: this.formBuilder.array([]),
          model_relation_details: this.formBuilder.array([]),

          braceletgoldkt: ['18', Validators.required],
          diamondcolorpuritycombo: ['', Validators.required],
          braceletgemstonetype: ['2'],
          color: ['1'],
          purity: ['1'],
          braceletsize: ['6', Validators.required],
          braceletsizeid: ['1', Validators.required],

          colllectionid: [this.selectedCollectionid, Validators.required],
          bracelettypeid: [this.selectedBracelettypeid, Validators.required],

        });
        this.gemstonelengthCtrl.setValue(1)
        var Flat_also_update = 0
        var Model_also_update = 0
        desingAnnotation_flat.forEach(element => {
          if (element.addfrom === 'update')
            Flat_also_update = 1
        });

        desingAnnotation_model.forEach(element => {
          if (element.addfrom === 'update')
            Model_also_update = 1;
          this.model_details_update = 1;
        });

        var capa1_load_onload = setInterval(() => {
          if (this.capa1) {
            clearInterval(capa1_load_onload)
            this.designForm.setControl('flat_chain_designAnnotation', this.setFLatDetails(desingAnnotation_flat));
          }
        }, 1000);

        var capa2_load_onload = setInterval(() => {
          if (this.capa2) {
            clearInterval(capa2_load_onload)
            this.designForm.setControl('model_chain_designAnnotation', this.setModelDetails(desingAnnotation_model));
          }
        }, 1000);


      }
    );
  }

  finalvalue = 0;
  predefinedratedetails;
  campareurlobjectdata;
  async MakeCalculation(pdbs_id, vendor_id, kt, braceletsize, color, purity, type) {
    await this.vendorCollectionService.getpredefinedentireRates(pdbs_id, vendor_id, kt, braceletsize, color, purity, type).then(data => {
      this.predefinedratedetails = data;

      this.designForm.get('diamondcolorpuritycombo').setValue('1,1');
      this.designForm.get('gold').setValue(this.predefinedratedetails.goldexplain.actualgoldwt);
      this.designForm.get('gemstone').setValue(this.predefinedratedetails.gemstoneprice);
      this.designForm.get('diamond').setValue(this.predefinedratedetails.diamondprice);
      this.designForm.get('margin').setValue(this.predefinedratedetails.goldexplain.marginvalue);
      this.designForm.get('subtotal').setValue(this.predefinedratedetails.price);
      this.designForm.get('taxvalue').setValue((this.predefinedratedetails.price / 100) * 3);
      this.designForm.get('totalprice').setValue(Math.round(this.predefinedratedetails.price + (this.predefinedratedetails.price / 100) * 3));

    }, error => this.isLoading = false)
  }

  checkoutcustomer() {
    this.router.navigate(['/vendor/customer/checkout']);
  }

  getvedioBute(filename) {
    return this.serviceurl + '/images/' + filename;
  }
  compare() {

    this.campareurlobjectdata = { 'vendorCompanyname': this.vendorcompanyname, 'vendorquniquekey': this.vendoruniquekey, 'index': 2, 'collection': this.selectedCollectionid, 'braceletid': this.selectedBracelettypeid }

    this.router.navigate(['/vendor/customer/compare', JSON.stringify(this.campareurlobjectdata)])
  }

  BhuildStructure_chain_default(id, ob) {

    switch (ob.linkballpearl) {
      case 'chain':
        this.ChaindesignannotationService.Chaindesignimages(id).subscribe(data => {
          this.flatimagesPreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.flatfileName
          this.modelimagePreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.modelfilename
        })
        break;
      case 'link':
        this.ChaindesignannotationService.LinkChaindesignimages(id).subscribe(data => {
          this.flatimagesPreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.flatfileName
          this.modelimagePreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.modelfilename
        })
        break;
      case 'ball-pearl':
        this.ChaindesignannotationService.ballpearlChaindesignimages(id).subscribe(data => {
          this.flatimagesPreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.flatfileName
          this.modelimagePreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.modelfilename
        })
        break;
    }
  }

  BhuildStructure_chain_dynamic(id) {
    this.ChaindesignannotationService.SelectedChain_RelatedModel(id, 'plain', 0).subscribe(data => {
      if (data[0]) {
        this.flatimagesPreview = this.ServerURL + '/images/' + data[0].encodefilename;
        this.RemoveSeletedTools(this.designForm.get('chainflatImages_id').value, 'chain');
        this.designForm.get('chainflatImages_id').patchValue(data[0].id);
        this.designForm.get('braceletchain_id').setValue(data[0].chaindesigwtid);
        this.DefaultSeletedTools(data[0].id, 'chain');
      }

      if (data[1]) {
        this.modelimagePreview = this.ServerURL + '/images/' + data[1].encodefilename;
        this.RemoveSeletedTools(this.designForm.get('chainmodelImages_id').value, 'chain');
        this.designForm.get('chainmodelImages_id').patchValue(data[1].id);
        this.DefaultSeletedTools(data[1].id, 'chain');
      }
    })
  }

  diamondcolorcombinationName;

  ViewDetails(id): void {
    const dialogRef = this.dialog.open(ViewCustomerCollectionComponent, {
      width: "100%",
      height: "700px",
      data: this.collectiondetails.filter(m => m.id === id)[0]
    });

    dialogRef.afterClosed().subscribe(result => {
      
    });
  }

  setFLatDetails(Product_details): FormArray {
    const formArray = new FormArray([]);
    this.Stub = [];
    Product_details.forEach((s, index) => {
      formArray.push(this.formBuilder.group({
        id: [s.id, Validators.required],
        chaindesign_id: [s.chaindesign_id, Validators.required],
        compontIndex: [s.compontindex],
        flatIndex: [s.flat_index, Validators.required],
        IDNumber: [s.id, Validators.required],
        addFrom: [s.addfrom, Validators.required],
        tooltype: [s.tooltype, Validators.required],
        tool_id: [s.tool_id, Validators.required],
        offsetX: [s.offsetX, Validators.required],
        offsetY: [s.offsetY, Validators.required],
        img_path: [s.img_path, Validators.required],
        isdelete: [s.isdelete, Validators.required]
      }));
      // this.UpdateCode_Component_flat(s);
      if (s.isdelete === 'N') {
        this.Stub.push(
          { 'id': index, 'flatIndex': s.flat_index, 'addFrom': s.addfrom, 'compontIndex': 0, 'tooltype': s.tooltype, 'tool_id': s.tool_id, 'offsetX': s.offsetX, 'offsetY': s.offsetY, 'img_path': s.img_path, 'IDNumber': s.id, 'chaindesign_id': s.chaindesign_id }
        );
      }
      // this.NumberOfStub
      var capa1_load = setInterval(() => {
        var cls = '#stubNumber_' + index;
        var cls2 = 'stubNumber_' + index;
        var x = s.offsetX;
        var y = s.offsetY;

        if (document.querySelector(cls)) {
          clearInterval(capa1_load)
          var parents_elm = document.getElementById(cls2);
          parents_elm.style.position = "absolute";
          parents_elm.style.left = x + 'px';
          parents_elm.style.top = y + 'px';
          if (s.tooltype === 'addon') { parents_elm.style.height = 45 + 'px'; }

          const addonid = "images_of_tools_flat_" + s.tooltype + '_' + s.tool_id;
          var itm = document.getElementById(addonid);
          var cln = itm.cloneNode(true);
          parents_elm.appendChild(cln);
          this.NumberOfStub++;
        }
      }, 0);
      
    });
    return formArray;
  }

  setModelDetails(Product_details): FormArray {
    const formArray = new FormArray([]);
    this.Stub_model = [];
    Product_details.forEach((s, index) => {
      formArray.push(this.formBuilder.group({
        id: [s.id, Validators.required],
        chaindesign_id: [s.chaindesign_id, Validators.required],
        compontIndex: [s.compontIndex],
        IDNumber: [s.id, Validators.required],
        addFrom: [s.addfrom, Validators.required],
        tooltype: [s.tooltype, Validators.required],
        tool_id: [s.tool_id, Validators.required],
        toolsLink: [s.tools_link],
        tools_position: [s.tools_position, Validators.required],
        offsetX: [s.offsetX, Validators.required],
        offsetY: [s.offsetY, Validators.required],
        img_path: [s.img_path, Validators.required],
        isdelete: [s.isdelete, Validators.required]
      }));
      if (s.isdelete === 'N') {
        this.Stub_model.push(
          { 'id': index, 'toolsLink': s.tools_link, 'Position': s.tools_position, 'addFrom': s.addfrom, 'compontIndex': 0, 'tooltype': s.tooltype, 'tool_id': s.tool_id, 'offsetX': s.offsetX, 'offsetY': s.offsetY, 'img_path': s.img_path, 'IDNumber': s.id, 'chaindesign_id': s.chaindesign_id }
        );
      }
      var capa1_load = setInterval(() => {
        var cls = '#stubNumber_model_' + index;
        var cls2 = 'stubNumber_model_' + index;

        var x = s.offsetX;
        var y = s.offsetY;
        // switch (s.tooltype) {
        //   case 'addon':
        //     var coordinates = this.Model_ParentsCharmCoordinates(s.offsetX, s.offsetY, s.id);
        //     y = (Number(coordinates.Y) + (41 * (coordinates.index + 1)));
        //     x = (Number(coordinates.X) + (65 - 45) / 2);
        //     break;
        //   default: break;
        // }

        if (document.querySelector(cls)) {
          var parents_elm = document.getElementById(cls2);
          parents_elm.style.position = "absolute";
          parents_elm.style.left = x + 'px';
          parents_elm.style.top = y + 'px';
          if (s.tooltype === 'addon') { parents_elm.style.height = 45 + 'px'; }

          const addonid = "images_of_tools_model_" + s.tooltype + "_" + s.tool_id;
          var itm = document.getElementById(addonid);
          var cln = itm.cloneNode(true);
          parents_elm.appendChild(cln);
          this.NumberOfStub_model++;
          clearInterval(capa1_load)
        }
      }, 0);
    });
    return formArray;
  }

  Flat_ParentsCharmCoordinates(addonXCoordinates: number, addonYCoordinates: number, flatid) {
    var coordinates;
    var match_index = 0;
    this.flat_chain_charm_relarionDetails.forEach(element => {
      if ((Number(element.x_value) == Number(addonXCoordinates)) && (Number(element.y_value) == Number(addonYCoordinates))) {
        this.chain_flat_details.forEach(elm => {
          if (Number(elm.id) == Number(element.parents_charm_row_id)) {

            var filterRelation = this.flat_chain_charm_relarionDetails.filter(f => {
              return f.parents_charm == elm.tool_id
            })

            filterRelation.forEach((e2, index) => {
              if (e2.flattoolid == Number(flatid)) {
                match_index = index;
              }
            });
            coordinates = { 'X': elm.offsetX, 'Y': elm.offsetY, 'index': match_index };
          }
        });
      }
    });
    // 
    return coordinates;
  }

  Replacementindex(replaceIndex: number, tooltype: string) {
    
    switch (tooltype) {
      case 'charm':
        this.designForm.get('design_tools_charm').setValue(replaceIndex);
        this.chain_flat_details.forEach(element => {
          var removecharm_selected = setInterval(() => {
            var cls = '#replacemetcharm_' + element.compontindex;
            var cls2 = 'replacemetcharm_' + element.compontindex;

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              parents_elm.style.border = "none";
              clearInterval(removecharm_selected)
            }
          }, 0)
        });

        var rpcharm_selected = setInterval(() => {
          var cls = '#replacemetcharm_' + replaceIndex;
          var cls2 = 'replacemetcharm_' + replaceIndex;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "3px solid #DBA632";
            
            clearInterval(rpcharm_selected)
          }
        }, 0)
        break;
      case 'addon':

        this.chain_flat_details.forEach(element => {
          var removecharm_selected = setInterval(() => {
            var cls = '#replacemetaddon_' + element.compontindex;
            var cls2 = 'replacemetaddon_' + element.compontindex;

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              parents_elm.style.border = "none";
              clearInterval(removecharm_selected)
            }
          }, 0)
        });

        this.designForm.get('design_tools_addon').setValue(replaceIndex);
        var rpAddon_selected = setInterval(() => {
          var cls = '#replacemetaddon_' + replaceIndex;
          var cls2 = 'replacemetaddon_' + replaceIndex;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "3px solid #DBA632";
            clearInterval(rpAddon_selected)
          }
        }, 0)
        break;
      case 'lock':

        this.chain_flat_details.forEach(element => {
          var removecharm_selected = setInterval(() => {
            var cls = '#replacemetlock_' + element.compontindex;
            var cls2 = 'replacemetlock_' + element.compontindex;

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              parents_elm.style.border = "none";
              clearInterval(removecharm_selected)
            }
          }, 0)
        });

        this.designForm.get('design_tools_lock').setValue(replaceIndex);
        var rplock_selected = setInterval(() => {
          var cls = '#replacemetlock_' + replaceIndex;
          var cls2 = 'replacemetlock_' + replaceIndex;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "3px solid #DBA632";
            clearInterval(rplock_selected)
          }
        }, 0)
        break;
      case 'ring':
        this.chain_flat_details.forEach(element => {
          var removecharm_selected = setInterval(() => {
            var cls = '#replacemetring_' + element.compontindex;
            var cls2 = 'replacemetring_' + element.compontindex;

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              parents_elm.style.border = "none";
              clearInterval(removecharm_selected)
            }
          }, 0)
        });

        this.designForm.get('design_tools_ring').setValue(replaceIndex);
        var rpring_selected = setInterval(() => {
          var cls = '#replacemetring_' + replaceIndex;
          var cls2 = 'replacemetring_' + replaceIndex;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "3px solid #DBA632";
            clearInterval(rpring_selected)
          }
        }, 0)
        break;
    }
  }

  RedirectCustomisepage(id) {
    var cllid = this.designForm.get('colllectionid').value == 0 ? Number(this.route.snapshot.paramMap.get('collectionid')) : this.designForm.get('colllectionid').value;
    var brltid = this.designForm.get('bracelettypeid').value == 0 ? Number(this.route.snapshot.paramMap.get('bracelettype')) : this.designForm.get('bracelettypeid').value;
    this.router.navigate(['customisebraceletscreen', this.vendorcompanyname, this.vendoruniquekey, this.vendor_id, id, cllid, brltid]);
  }

  DefaultSeletedTools(toolsid: any, tooltype) {
    switch (tooltype) {

      case 'collection':
        var product_selected = setInterval(() => {
          var cls = '#listofcollection_' + toolsid;
          var cls2 = 'listofcollection_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(product_selected)
          }
        }, 0)
        break;

      case 'bracelettype':
        var product_selected = setInterval(() => {
          var cls = '#listoftyperange_' + toolsid;
          var cls2 = 'listoftyperange_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(product_selected)
          }
        }, 0)
        break;

      case 'product':

        var product_selected = setInterval(() => {
          var cls = '#product' + toolsid;
          var cls2 = 'product' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(product_selected)
          }
        }, 0)

        break;
      case 'design':
        var charm_selected = setInterval(() => {
          var cls = '#listofdesign_' + toolsid;
          var cls2 = 'listofdesign_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(charm_selected)
          }
        }, 0)

        break;
      case 'chain':
        var charm_selected = setInterval(() => {
          var cls = '#listofchain_' + toolsid;
          var cls2 = 'listofchain_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(charm_selected)
          }
        }, 0)

        break;

      case 'braceletwidth':
        var charm_selected = setInterval(() => {
          var cls = '#listofchainwidth_' + toolsid;
          var cls2 = 'listofchainwidth_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(charm_selected)
          }
        }, 0)

        break;
      case 'charm':
        var charm_selected = setInterval(() => {
          var cls = '#listofcharms_' + toolsid;
          var cls2 = 'listofcharms_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(charm_selected)
          }
        }, 0)

        break;
      case 'addon':
        var addon_selected = setInterval(() => {
          var cls = '#listofaddon_' + toolsid;
          var cls2 = 'listofaddon_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(addon_selected)
          }
        }, 0)

        break;
      case 'lock':
        var lock_selected = setInterval(() => {
          var cls = '#listoflock_' + toolsid;
          var cls2 = 'listoflock_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(lock_selected)
          }
        }, 0)
        break;
      case 'ring':
        var ring_selected = setInterval(() => {
          var cls = '#listofring_' + toolsid;
          var cls2 = 'listofring_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(ring_selected)
          }
        }, 0)
        break;
    }
  }

  RemoveSeletedTools(toolsid: any, tooltype) {
    switch (tooltype) {

      case 'collection':
        var product_selected = setInterval(() => {
          var cls = '#listofcollection_' + toolsid;
          var cls2 = 'listofcollection_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(product_selected)
          }
        }, 0)
        break;

      case 'bracelettype':
        var product_selected = setInterval(() => {
          var cls = '#listoftyperange_' + toolsid;
          var cls2 = 'listoftyperange_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(product_selected)
          }
        }, 0)
        break;

      case 'product':

        var product_selected = setInterval(() => {
          var cls = '#product' + toolsid;
          var cls2 = 'product' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(product_selected)
          }
        }, 0)

        break;
      case 'design':
        var charm_selected = setInterval(() => {
          var cls = '#listofdesign_' + toolsid;
          var cls2 = 'listofdesign_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(charm_selected)
          }
        }, 0)

        break;
      case 'chain':
        var charm_selected = setInterval(() => {
          var cls = '#listofchain_' + toolsid;
          var cls2 = 'listofchain_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(charm_selected)
          }
        }, 0)

        break;

      case 'braceletwidth':
        var charm_selected = setInterval(() => {
          var cls = '#listofchainwidth_' + toolsid;
          var cls2 = 'listofchainwidth_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(charm_selected)
          }
        }, 0)

        break;

      case 'charm':
        var charm_selected = setInterval(() => {
          var cls = '#listofcharms_' + toolsid;
          var cls2 = 'listofcharms_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            // parents_elm.style.border = "1px solid rgba(0, 0, 0, 0.1);";
            clearInterval(charm_selected)
          }
        }, 0)

        break;
      case 'addon':
        var addon_selected = setInterval(() => {
          var cls = '#listofaddon_' + toolsid;
          var cls2 = 'listofaddon_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(addon_selected)
          }
        }, 0)

        break;
      case 'lock':
        var lock_selected = setInterval(() => {
          var cls = '#listoflock_' + toolsid;
          var cls2 = 'listoflock_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(lock_selected)
          }
        }, 0)
        break;
      case 'ring':
        var ring_selected = setInterval(() => {
          var cls = '#listofring_' + toolsid;
          var cls2 = 'listofring_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(ring_selected)
          }
        }, 0)
        break;
    }
  }

  Model_ParentsCharmCoordinates(addonXCoordinates: number, addonYCoordinates: number, flatid) {
    var coordinates;
    var match_index = 0;
    this.model_chain_charm_relationDetails.forEach(element => {
      if ((Number(element.x_value) == Number(addonXCoordinates)) && (Number(element.y_value) == Number(addonYCoordinates))) {
        this.chain_model_details.forEach(elm => {
          if (Number(elm.id) == Number(element.parents_charm_row_id)) {
            
            var filterRelation = this.model_chain_charm_relationDetails.filter(f => {
              return f.parents_charm == elm.tool_id
            })
            filterRelation.forEach((e2, index) => {
              if (Number(e2.modeltool_id) == Number(flatid)) {
                match_index = index;
              }
            });
            coordinates = { 'X': elm.offsetX, 'Y': elm.offsetY, 'index': match_index };
          }
        });
      }
    });
    return coordinates;
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action);
  }

  getGoldcolorname(id) {
    return this.goldcolors1.filter(f => f.id == id)[0].color
  }
  getgemstonecolorname(id) {
    return this.colorpreferances.filter(f => f.id == id)[0].color_name
  }

  clickFlat() {
    this.test_map_model.forEach(e => {
      e.status = true;
    })
    this.test_map_flat.forEach(e => {
      e.status = true;
      if (e.id === 0) {
        e.status = false
      }
    })
  }

  clickmodel() {
    this.test_map_flat.forEach(e => {
      e.status = true;
    })
    this.test_map_model.forEach(e => {
      e.status = true;
      if (e.id === 0) {
        e.status = false
      }
    })
  }
  public braceletgoldktlist: any;
  public braceletgoldperoperties;
  //Gold
  netgoldkt: any = 0;
  netgoldweight: any = 0;
  ratepergm: any;
  goldprice: any;
  //Diamond
  colorpurity: any;
  diamondwt: any;
  diamondprice: any;
  //Gemstone
  gemstonetype: any;
  gemstoneieces: any = 0;
  gemstoneprice: any = 0;
  //Makingcharges
  makingchargesprice: any;
  diamondComboination: any;

  goldratesdetails: any;
  totalgoldweight = 0;
  ratepergramgold = 0;

  diamondratesdetails: any;
  totaldiamondwt: any = 0;
  totaldiamonrate: any = 0;

  gemstoneratesdetails: any;
  gemstonepieces: any = 0;
  gemstonetotaleates: any = 0;


  GetBraceletCoast(designform: any) {
    this.ChaindesignannotationService.defineTotalPrice(designform, this.vendor_id).subscribe((rates: any) => {

      this.totalgoldweight = 0;
      this.totaldiamondwt = 0;
      this.totaldiamonrate = 0;
      this.netgoldweight = 0;
      this.diamondwt = 0;
      this.diamondprice = 0;
      this.gemstoneprice = 0;

      this.BraceletPrices = rates;
      this.braceletgoldktlist = rates[3].goldktlist;
      this.diamondComboination = rates[4].colorcombination;

      this.goldratesdetails = rates[5].goldproperties;
      this.goldratesdetails.forEach(element => {
        this.ratepergramgold = parseFloat(element.rateprgram);
        this.totalgoldweight += parseFloat(element.gold_wt)
      });

      this.diamondratesdetails = rates[6].diamondproperties;
      this.diamondratesdetails.forEach(element => {
        this.totaldiamondwt += parseFloat(element.wt);
        this.totaldiamonrate += parseFloat(element.price);
      });


      this.gemstoneratesdetails = rates[7].gemstoneratecalculation;
      this.gemstoneratesdetails.forEach((element, index) => {
        this.gemstonepieces = Number(index + 1);
        this.gemstonetotaleates = parseFloat(element.price)
      });

      this.totalpriceofbracelet = Number(rates[1].diamondwt) + Number(rates[2].gemstonewt) + Number(rates[0].goldwt)
      this.braceletgoldperoperties = rates[8].goldproperties;
      this.braceletgoldperoperties.forEach(element => {
        this.netgoldkt = Number(element.kt);
        this.netgoldweight += Number(element.gold_wt)
        this.ratepergm = Number(element.rateprgram);
      });

      rates[7].forEach(element1 => {
        this.colorpurity = "NA";
        this.diamondwt += Number(element1.wt);
        this.diamondprice += Number(element1.price)
      });

      rates[6].forEach((element3, index) => {
        this.gemstonetype = "Synthetic";
        this.gemstoneieces = (index + 1)
        this.gemstoneprice += Number(element3.price);
      });
      var ttl = (Number(this.totalgoldweight * this.ratepergramgold) + Number(this.gemstonetotaleates) + Number(this.totaldiamonrate))
      this.designForm.get('totalprice').setValue(Number(Number(3 / 100 * ttl) + ttl) + Number(ttl));
      this.designForm.get('subtotal').setValue(ttl);
      this.designForm.get('taxvalue').setValue(Number(3 / 100 * ttl) + ttl);
      this.designForm.get('gold').setValue(Number(this.totalgoldweight * this.ratepergramgold));
      this.designForm.get('gemstone').setValue(Number(this.gemstonetotaleates));
      this.designForm.get('diamond').setValue(this.totaldiamonrate);
      this.designForm.get('margin').setValue(0);
      this.designForm.get('quantity').setValue(1);
    }
    );
  }

  // BracelettypePrice(typeid, ob) {
  //   this.ChaindesignannotationService.CostforBraceletType(typeid, this.sessionUser.id).subscribe(rates => {
  //     this.BraceletPrices = rates;
  //     this.totalpriceofbracelet = Number(rates[1].diamondwt) + Number(rates[2].gemstonewt) + Number(rates[0].goldwt);

  //     this.designForm.reset();
  //     this.designForm = this.formBuilder.group({
  //       // New Fields
  //       id: [ob.id, Validators.required],
  //       name: [ob.type_name, Validators.required],
  //       totalprice: [this.totalpriceofbracelet, Validators.required],
  //       subtotal: [],
  //       taxvalue: [],
  //       gold: [Number(rates[0].goldwt), Validators.required],
  //       gemstone: [Number(rates[2].gemstonewt), Validators.required],
  //       diamond: [Number(rates[1].diamondwt), Validators.required],
  //       margin: [0.00, Validators.required],
  //       quantity: [1, Validators.required],
  //       image: [ob.image_path, Validators.required],
  //       image_model: [''],
  //       producttype: ['bracelettype', Validators.required],
  //       braceletwidth_id: [0],
  //       charmstuddedtype: [''],
  //       //End New Fields
  //       customerid: [this.sessionUser.id, Validators.required],
  //       pre_braceletpattern: [ob.id, Validators.required],
  //       loosebraceletPatternid: [0, Validators.required],
  //       braceletchain_id: [0, Validators.required],
  //       chainflatImages_id: [0, Validators.required],
  //       chainmodelImages_id: [0, Validators.required],
  //       isdelete: [false, Validators.required],
  //       clickfromproduct: ['', Validators.required],
  //       // some additional form fields
  //       design_tools_charm: [''],
  //       design_tools_addon: [''],
  //       design_tools_lock: [''],
  //       design_tools_ring: [''],
  //       pricerange: [''],
  //       //end addition fields
  //       vendorid: [6, Validators.required],

  //       flat_chain_designAnnotation: this.formBuilder.array([]),
  //       model_chain_designAnnotation: this.formBuilder.array([]),
  //       delete_flat_images: this.formBuilder.array([]),
  //       delete_model_images: this.formBuilder.array([]),

  //       flat_relation_details: this.formBuilder.array([]),
  //       model_relation_details: this.formBuilder.array([]),

  //       braceletgoldkt: ['', Validators.required],
  //       diamondcolorpuritycombo: ['', Validators.required],
  //       braceletgemstonetype: ['140'],
  //       braceletsize: ['0', Validators.required],
  //     });
  //   })
  // }

  PredefinedStructureCoast(id, ob) {

    this.ChaindesignannotationService.CostforPredefinedStrucutr(id, this.vendor_id).subscribe(rates => {
      this.BraceletPrices = rates;
      this.totalpriceofbracelet = Number(rates[1].diamondwt) + Number(rates[2].gemstonewt) + Number(rates[0].goldwt)

      this.designForm.reset();
      this.designForm = this.formBuilder.group({
        // New Fields
        id: [ob.pdbs_id, Validators.required],
        name: [ob.lbp_name, Validators.required],
        totalprice: [this.totalpriceofbracelet, Validators.required],
        subtotal: [],
        taxvalue: [],
        gold: [Number(this.BraceletPrices[0].goldwt), Validators.required],
        gemstone: [Number(this.BraceletPrices[2].gemstonewt), Validators.required],
        diamond: [Number(this.BraceletPrices[1].diamondwt), Validators.required],
        margin: [0.00, Validators.required],
        quantity: [1, Validators.required],
        image: [this.designForm.get('image').value, Validators.required],
        image_model: [''],
        producttype: ['predefinedstructure', Validators.required],
        braceletwidth_id: [0],
        charmstuddedtype: [''],
        //End New Fields
        customerid: [0, Validators.required],
        pre_braceletpattern: [ob.pdbs_id, Validators.required],
        loosebraceletPatternid: [0, Validators.required],
        braceletchain_id: [0, Validators.required],
        braceletcartfrom: ['predefined'],
        chainflatImages_id: [0, Validators.required],
        chainmodelImages_id: [0, Validators.required],
        isdelete: [false, Validators.required],
        clickfromproduct: ['', Validators.required],
        // some additional form fields
        design_tools_charm: [''],
        design_tools_addon: [''],
        design_tools_lock: [''],
        design_tools_ring: [''],
        pricerange: [''],
        //end addition fields
        vendorid: [this.vendor_id, Validators.required],

        flat_chain_designAnnotation: this.formBuilder.array([]),
        model_chain_designAnnotation: this.formBuilder.array([]),
        delete_flat_images: this.formBuilder.array([]),
        delete_model_images: this.formBuilder.array([]),

        flat_relation_details: this.formBuilder.array([]),
        model_relation_details: this.formBuilder.array([]),

        braceletgoldkt: ['', Validators.required],
        diamondcolorpuritycombo: ['', Validators.required],
        braceletgemstonetype: ['140'],
        braceletsize: ['0', Validators.required],

        colllectionid: [this.selectedCollectionid, Validators.required],
        bracelettypeid: [this.selectedBracelettypeid, Validators.required],

      });
    })
  }

  chooseCollection(collection, ob) {
    this.selectedCollectionid = collection;
    // this.braceletTypeRanges_mod = this.braceletTypeRanges;
    var arraydt = this.bracelettyperangecollectionWise.filter(c => c.collection_id * 1 == collection * 1)
    this.braceletTypeRanges.filter(data => {
      return arraydt.filter(c => data.id * 1 == c.id * 1)
    })
    this.braceletTypeRanges_mod = arraydt;

    this.designForm.reset();
    this.designForm = this.formBuilder.group({
      // New Fields
      id: [ob.id, Validators.required],
      name: [ob.name, Validators.required],
      totalprice: [this.totalpriceofbracelet, Validators.required],
      subtotal: [],
      taxvalue: [],
      gold: [0, Validators.required],
      gemstone: [0, Validators.required],
      diamond: [0, Validators.required],
      margin: [0, Validators.required],
      quantity: [1, Validators.required],
      image: [ob.img_vid_path, Validators.required],
      image_model: [''],
      producttype: ['collection', Validators.required],
      braceletwidth_id: [0],
      charmstuddedtype: [''],
      //End New Fields
      customerid: [0, Validators.required],
      pre_braceletpattern: [ob.id, Validators.required],
      loosebraceletPatternid: [0, Validators.required],
      braceletchain_id: [0, Validators.required],
      braceletcartfrom: ['predefined'],
      chainflatImages_id: [0, Validators.required],
      chainmodelImages_id: [0, Validators.required],
      isdelete: [false, Validators.required],
      clickfromproduct: ['', Validators.required],
      // some additional form fields
      design_tools_charm: [''],
      design_tools_addon: [''],
      design_tools_lock: [''],
      design_tools_ring: [''],
      pricerange: [''],
      //end addition fields
      vendorid: [this.vendor_id, Validators.required],

      flat_chain_designAnnotation: this.formBuilder.array([]),
      model_chain_designAnnotation: this.formBuilder.array([]),
      delete_flat_images: this.formBuilder.array([]),
      delete_model_images: this.formBuilder.array([]),

      flat_relation_details: this.formBuilder.array([]),
      model_relation_details: this.formBuilder.array([]),

      braceletgoldkt: ['', Validators.required],
      diamondcolorpuritycombo: ['', Validators.required],
      braceletgemstonetype: [2],
      braceletsize: ['0', Validators.required],

      colllectionid: [collection * 1, Validators.required],
      bracelettypeid: [0, Validators.required],
    });

    // this.ChaindesignannotationService.getcollectionrates(collection, this.sessionUser.id).subscribe((data: any) => {
    //   this.BraceletPrices = [{ goldwt: 0 }, { diamondwt: 0 }, { gemstonewt: 0 },];
    //   this.totalpriceofbracelet = 0;

    //   // this.flatimagesPreview = this.ServerURL + '/images/' + ob.img_vid_path;
    //   // this.modelimagePreview = this.ServerURL + '/images/' + ob.img_vid_path;

    //   data.forEach(element => {
    //     this.totalpriceofbracelet += Number(element.price)
    //   });

    // })

    this.RemoveSeletedTools(this.designForm.get('id').value, 'collection');
    this.DefaultSeletedTools(collection, 'collection');
  }

  chooseTypeRage(rangetype, imagespath, ob) {
    this.Stub = [];
    this.Stub_model = [];
    // this.BracelettypePrice(rangetype, ob);
    // this.braceletwisedesign_mod = this.braceletwisedesign.filter(rng => rng.bracelet_type_id == rangetype)

    this.designForm.get('bracelettypeid').setValue(rangetype * 1);

    // 

    var getformcollectionid = this.designForm.get('colllectionid').value;
    var getformrangeid = this.designForm.get('bracelettypeid').value;

    this.selectedBracelettypeid = rangetype * 1;

    this.design_pattern_mod = this.design_pattern.filter(f => (f.bracelet_type_id == getformrangeid && f.collection_id == getformcollectionid * 1))
    // this.flatimagesPreview = this.ServerURL + '/images/' + imagespath;
    // this.modelimagePreview = this.ServerURL + '/images/' + imagespath;
    this.RemoveSeletedTools(this.designForm.get('id').value, 'bracelettype');
    this.DefaultSeletedTools(rangetype, 'bracelettype');
    // 
  }

  ChooseProduct(porduct_details) {
    this.openSnackBar('Product set successfully', 'close');
  }

  chooseDesign_pre(design: any, imges, ob) {
    this.RemoveSeletedTools(this.designForm.get('id').value, 'design');
    this.designForm.get('id').setValue(design);
    this.designForm.reset();
    this.Stub = [];
    this.Stub_model = [];
    this.flatimagesPreview = this.ServerURL + '/images/' + imges;
    this.modelimagePreview = this.ServerURL + '/images/' + imges;
    this.PredefinedStructureCoast(design, ob);
    this.DefaultSeletedTools(design, 'design');
    this.openSnackBar('Design Set successfully', 'close');
    this.designForm.get('clickfromproduct').setValue('predefinedstrucute');
  }

  chooseDesign(design: any, ob) {
    // this.RemoveSeletedTools(this.designForm.get('id').value, 'design');
    this.designForm.get('id').setValue(design);
    this.BhuildStructure_chain_default(design, ob);
    // this.BhuildStructure_design(design, ob.vendor_id);
    // this.DefaultSeletedTools(design, 'design');
    // this.openSnackBar('Design Set successfully', 'close');
  }

  chooseChain(chain) {
    this.BhuildStructure_chain_dynamic(chain);
    this.GetBraceletCoast(this.designForm.value);
    this.openSnackBar('Design Set successfully', 'close');
  }

  chooseChainWidth(id) {
    this.RemoveSeletedTools(this.designForm.get('braceletwidth_id').value, 'braceletwidth');
    this.designForm.get('braceletwidth_id').setValue(id);
    this.DefaultSeletedTools(id, 'braceletwidth');
    this.GetBraceletCoast(this.designForm.value);
  }

  selectedChain(chain) {
    if (chain != undefined) {
      switch (chain.type) {
        case 'flat':
          this.flatimagesPreview = this.ServerURL + '/images/' + chain.encodefilename;
          this.openSnackBar('Flat chain are set successfully..!', 'Close');
          this.has_predefinesPattern = true;
          this.hasFlatcanvasImages = true;
          this.designForm.get('chainflatImages_id').setValue(chain.id);
          break;

        case 'model':
          this.modelimagePreview = this.ServerURL + '/images/' + chain.encodefilename;
          this.openSnackBar('Model chain are set successfully..!', 'Close');
          this.has_predefinesPattern = true;
          this.hasModelcanvasImages = true;
          this.designForm.get('chainmodelImages_id').setValue(chain.id);
      }
    }
  }

  Choosecharm(currenttools, $event) {
    var index = this.designForm.get('design_tools_charm').value;
    this.Replace_Tools(currenttools, index, $event, 'charm');
  }

  chooseAddon(currenttools, $event) {
    
    var index = this.designForm.get('design_tools_addon').value;
    this.Replace_Tools(currenttools, index, $event, 'addon')
  }
  chooselock(currenttools, $event) {
    var index = this.designForm.get('design_tools_lock').value;
    this.Replace_Tools(currenttools, index, $event, 'lock')
  }
  choosering(currenttools, $event) {
    var index = this.designForm.get('design_tools_ring').value;
    this.Replace_Tools(currenttools, index, $event, 'ring')
  }

  Charm_replacement_structure(pre_charm, cur_charm, index, img, its_from) {

    // start apply replacement logic
    var position_type = cur_charm.charm_position;
    var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
    switch (position_type) {
      case 'attached':
        var parent_charm_Ycoordinate = 0;
        var parent_charm_Xcoordinate = 0;
        switch (cur_charm.charm_type) {
          case 'symmetric':
            var attachhed_new_Yvalue = 250;//260
            var attcdcapa1_load = setInterval(() => {
              var cls = '#stubNumber_' + index;
              var cls2 = 'stubNumber_' + index;

              if (document.querySelector(cls)) {
                clearInterval(attcdcapa1_load)
                var parents_elm = document.getElementById(cls2);
                parents_elm.childNodes[2].remove()

                var cln = img.target.cloneNode();
                parents_elm.appendChild(cln);

                parents_elm.style.top = attachhed_new_Yvalue + 'px';
                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
              }
            }, 0);
            parent_charm_Ycoordinate = attachhed_new_Yvalue;
            break;
          // ------------------------Asymmetric Charm-----------------------------
          case 'asymmetric':
            var attachhed_new_Yvalue = (Number(250) + Number(cur_charm.asymmetric_position_value));//264
            var attcdcapa1_load = setInterval(() => {
              var cls = '#stubNumber_' + index;
              var cls2 = 'stubNumber_' + index;

              if (document.querySelector(cls)) {
                clearInterval(attcdcapa1_load)
                var parents_elm = document.getElementById(cls2);
                parents_elm.childNodes[2].remove()

                var cln = img.target.cloneNode();
                parents_elm.appendChild(cln);

                parents_elm.style.top = attachhed_new_Yvalue + 'px';
                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
              }
            }, 0);
            parent_charm_Ycoordinate = attachhed_new_Yvalue
            break;
          // ------------------------default Charm Type-----------------------------
          default:
            var attachhed_new_Yvalue = 250;
            var attcdcapa1_load = setInterval(() => {
              var cls = '#stubNumber_' + index;
              var cls2 = 'stubNumber_' + index;

              if (document.querySelector(cls)) {
                clearInterval(attcdcapa1_load)
                var parents_elm = document.getElementById(cls2);
                parents_elm.childNodes[2].remove()
                var cln = img.target.cloneNode();
                parents_elm.appendChild(cln);
                parents_elm.style.top = attachhed_new_Yvalue + 'px';
                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
              }
            }, 0);
            parent_charm_Ycoordinate = attachhed_new_Yvalue;
            break;
        }
        this.RemoveSeletedTools(((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).value, its_from);
        ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
        ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
        this.DefaultSeletedTools(((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).value, its_from);

        var filter_relation = this.flat_chain_charm_relarionDetails.filter(e => {
          return ((e.parents_charm * 1) == (pre_charm.tool_id * 1))
        })
        var filter_relation = this.flat_chain_charm_relarionDetails.filter(e => {
          return ((e.parents_charm_row_id * 1) == (pre_charm.id * 1))
        })


        filter_relation.forEach((element, index) => {
          var _id = 'stubNumber_' + element.index_no;
          var attached_addon = document.getElementById(_id);

          var getXposition = setInterval(() => {
            if (parent_charm_Xcoordinate > 0) {
              clearInterval(getXposition);

              var central_pos = (parent_charm_Xcoordinate + (65 - 45) / 2)
              var attched_lstpstn_top = parent_charm_Ycoordinate + (41 * (index + 1));
              attached_addon.style.top = attched_lstpstn_top + 'px';
              attached_addon.style.left = central_pos + 'px';
            }
          })

          var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
          ((a.controls[(element.index_no * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
          ((a.controls[(element.index_no * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
          this.identify_number_attached++;
        });

        break;
      case 'hanging':
        this.FLAT_Hanging_value_times++;
        var parents_Y_coordinates = 0;
        var parent_charm_Xcoordinate = 0;
        // Replace Parents Charm ------------------------------------------------
        this.pre_click_charmId = cur_charm.charm_id
        var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;

        switch (cur_charm.charm_type) {
          case 'symmetric':
            var Rep11capa1_load = setInterval(() => {
              var cls = '#stubNumber_' + index;
              var cls2 = 'stubNumber_' + index;

              if (document.querySelector(cls)) {
                clearInterval(Rep11capa1_load)
                var parents_elm = document.getElementById(cls2);
                parents_elm.childNodes[2].remove()
                var cln = img.target.cloneNode();
                parents_elm.appendChild(cln);
                parents_elm.style.top = Number(276) + 'px';//290 - 8
                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
              }
            }, 0);
            parents_Y_coordinates = Number(276)//290 - 8

            // var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
            // ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
            // ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
            break;
          case 'asymmetric':
            var Y_axis_symmetric_posi_value = (Number(276) + Number(cur_charm.asymmetric_position_value))//290 - 8
            var Rep11capa1_load = setInterval(() => {
              var cls = '#stubNumber_' + index;
              var cls2 = 'stubNumber_' + index;

              if (document.querySelector(cls)) {
                clearInterval(Rep11capa1_load)
                var parents_elm = document.getElementById(cls2);
                parents_elm.childNodes[2].remove()
                var cln = img.target.cloneNode();
                parents_elm.appendChild(cln);
                parents_elm.style.top = Number(Y_axis_symmetric_posi_value) + 'px';
                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
              }
            }, 0);

            parents_Y_coordinates = Number(Y_axis_symmetric_posi_value)

            // var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
            // ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
            // ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
            break;
          default:
            var Rep11capa1_load = setInterval(() => {
              var cls = '#stubNumber_' + index;
              var cls2 = 'stubNumber_' + index;

              if (document.querySelector(cls)) {
                clearInterval(Rep11capa1_load)
                var parents_elm = document.getElementById(cls2);
                parents_elm.childNodes[2].remove()

                var cln = img.target.cloneNode();
                parents_elm.appendChild(cln);
                parents_elm.style.top = Number(276) + 'px';//290 - 8
                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
              }
            }, 0);
            parents_Y_coordinates = Number(276)//290 - 8
            break;
        }
        var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
        this.RemoveSeletedTools(((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).value, its_from);
        ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
        ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
        this.DefaultSeletedTools(((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).value, its_from);

        //replace its attached tools ------------------------------------------------------
        var filter_relation = this.flat_chain_charm_relarionDetails.filter(e => {
          return ((e.parents_charm * 1) == (pre_charm.tool_id * 1))
        })
        var filter_relation = this.flat_chain_charm_relarionDetails.filter(e => {
          return ((e.parents_charm_row_id * 1) == (pre_charm.id * 1))
        })

        filter_relation.forEach((element, index) => {
          var _id = 'stubNumber_' + element.index_no
          var attached_addon = document.getElementById(_id);
          var currentObject = attached_addon.style.top;

          var getXposition_hng = setInterval(() => {
            if (parent_charm_Xcoordinate > 0) {
              clearInterval(getXposition_hng);

              var central_pos = (parent_charm_Xcoordinate + (65 - 45) / 2)
              var lstpstn_top = parents_Y_coordinates + (65 * (index + 1));
              attached_addon.style.top = lstpstn_top + 'px';
              attached_addon.style.left = central_pos + 'px';
            }
          })

          var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
          ((a.controls[(element.index_no * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
          ((a.controls[(element.index_no * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);

        });
        this.identify_number_hanging++;
        break;
    }
    // end apply replacement logic
  }

  BuildReplacementStructure_Model(pre_charm, cur_charm, index, img, its_from) {

    var charm_model_pos;
    var model_tools_id;
    var model_tools_position;
    var modelflat_index = pre_charm.flat_index;
    var model_cur_yAxis = 0;
    var currentcharmid;
    var selectedcharmposition;
    switch (its_from) {
      case 'charm':
        this.Stub_model.forEach((e, index12) => {
          if (e.toolsLink === modelflat_index) {
            model_tools_id = e.tool_id;
            model_tools_position = e.Position;
            model_cur_yAxis = e.offsetY;
            index = index12
          }
        })

        
        

        this.charm_images.forEach(e => {
          if (Number(e.charm_id) === Number(cur_charm.charm_id)) {
            if (Number(e.color_variationid) === Number(cur_charm.color_variationid)) {
              if (e.img_view_type === 'model' && String(e.img_view_position) === String(model_tools_position)) { //&& String(e.img_view_position) === String(cur_charm.img_view_position) reMove this Condition
                charm_model_pos = "charm_images_model_position" + e.id
                currentcharmid = e.id
                selectedcharmposition = e.img_view_position;
              }
            }
          }
        });

        

        var cls = '#stubNumber_model_' + index;
        var cls2 = 'stubNumber_model_' + index;

        if (document.querySelector(cls)) {
          if (charm_model_pos) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.childNodes[2].remove()
            var itm = document.getElementById(charm_model_pos);
            var cln = itm.cloneNode(true);

            parents_elm.appendChild(cln);

            this.NumberOfStub_model++;
            this.SetModel_images_position(pre_charm, cur_charm, index, img, its_from, model_cur_yAxis, selectedcharmposition);
          } else {
            alert(model_tools_position.toUpperCase() + " side posititon images Not found for Model images");
          }
        }

        var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
        this.RemoveSeletedTools(((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).value, its_from);
        ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(currentcharmid);
        ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
        this.DefaultSeletedTools(((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).value, its_from);
        break;
    }
    this.GetBraceletCoast(this.designForm.value);
  }


  Replace_Tools(cur_charm, index, img, its_from) {
    var pre_charm: any;
    if (index != null && index != '') {
      //start get index tools Details
      this.chain_flat_details.forEach(element => {
        if (Number(element.compontindex) == Number(index)) {
          pre_charm = element;
        }
      });
      //end get index tools Details

      switch (its_from) {
        case 'charm':
          this.Charm_replacement_structure(pre_charm, cur_charm, index, img, its_from);
          this.BuildReplacementStructure_Model(pre_charm, cur_charm, index, img, its_from)
          break;
        case 'addon': case 'lock': case 'ring':
          this.Replace_Bracelte_tools(pre_charm, cur_charm, index, img, its_from);
          break;
      }
    } else {
      this.openSnackBar('PLEASE CHOOSE ELEMENT TO REPLACE FROM DROPDOWN', 'CLOSE');
    }
  }

  SetModel_images_position(pre_charm, cur_charm, index, img, its_from, model_cur_yAxis, selectedcharmposition) {
    var position_type = cur_charm.charm_position;
    var x, y;
    var Xaxis = pre_charm.offsetX;
    var Yaxis = model_cur_yAxis;
    var view_position = cur_charm.img_view_position;



    switch (position_type) {
      case 'attached':
        // Replace Parents Charm ------------------------------------------------------------------------------------
        var attched_parent_coordinate = 0;
        var parent_charm_Xcoordinate = 0;
        
        switch (cur_charm.charm_type) {
          // ------------------------symmetric Charm-----------------------------
          case 'symmetric':
            switch (selectedcharmposition) {
              case 'central': var its_static_value = 404; break;
              case 'left': var its_static_value = 398; break; case 'right': var its_static_value = 402; break;
              default: var its_static_value = 404; break;
            }
            // var its_static_value = 347;
            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            var attachhed_new_Yvalue = Yaxis;

            var cls = '#stubNumber_model_' + index;
            var cls2 = 'stubNumber_model_' + index;

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              var Current_object_coordinates = parseInt(parents_elm.style.top);

              parents_elm.style.top = Number(its_static_value) + 'px';
              parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
              attched_parent_coordinate = Number(its_static_value);
            }

            break;
          // ------------------------Asymmetric Charm-----------------------------
          case 'asymmetric':
            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;

            switch (selectedcharmposition) {
              case 'central': var its_static_value_asy = (Number(404) + Number(cur_charm.asymmetric_position_value));//347 break;
              case 'left': var its_static_value_asy = (Number(404) + Number(cur_charm.asymmetric_position_value));//347; break;
              default: var its_static_value_asy = (Number(404) + Number(cur_charm.asymmetric_position_value));//347 break;
            }
            // var its_static_value_asy = (Number(347) + Number(cur_charm.asymmetric_position_value));

            var cls = '#stubNumber_model_' + index;
            var cls2 = 'stubNumber_model_' + index;

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              var current_Object_coordinates = parseInt(parents_elm.style.top);
              parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
              parents_elm.style.top = Number(its_static_value_asy) + 'px';
              attched_parent_coordinate = Number(its_static_value_asy);
            }
            break;
          // ------------------------default Charm Type-----------------------------
          default:
            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            attachhed_new_Yvalue = Yaxis;
            var its_static_value_def = 404;//347

            var cls = '#stubNumber_model_' + index;
            var cls2 = 'stubNumber_model_' + index;

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              parent_charm_Xcoordinate = parseInt(parents_elm.style.left);

              parents_elm.style.top = (Number(its_static_value_def)) + 'px';
              attched_parent_coordinate = its_static_value_def;
            }
            break;
        }
        // ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
        // ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);

        var Y_coordinate_value = 0;
        var model_current_charm_id = 0;
        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          this.chain_model_details.forEach(e2 => {
            if (e2.tools_link === pre_charm.flat_index) {
              model_current_charm_id = e2.tool_id;
            }
          });
          return ((e.chaindesign_id * 1) == (pre_charm.chaindesign_id * 1))
        })

        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          return ((e.parents_charm * 1) == (model_current_charm_id * 1))
        })
        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          return ((e.parents_charm_row_id * 1) == (pre_charm.id * 1))
        })

        filter_relation.forEach((element, index) => {
          var _id = 'stubNumber_model_' + element.index_no
          var attached_addon = document.getElementById(_id);

          var getXposition_mdlatt = setInterval(() => {
            if (parent_charm_Xcoordinate > 0) {
              clearInterval(getXposition_mdlatt);

              var nodel_attched_lstpstn_top = attched_parent_coordinate + (41 * (index + 1));
              attached_addon.style.top = nodel_attched_lstpstn_top + 'px';

              var central_pos = (parent_charm_Xcoordinate + (65 - 45) / 2)
              attached_addon.style.left = central_pos + 'px';
            }
          })
          var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
          // ((a.controls[(element.index_no * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
          // ((a.controls[(element.index_no * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);

          this.identify_number_attached++;
        });
        break;
      case 'hanging':
        // Replace Parents Charm ------------------------------------------------
        var hanging_parents_coordinates = 0;
        var Y_coordinate_value_hanging = 0;
        this.pre_click_charmId = cur_charm.charm_id
        var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
        var parent_charm_Xcoordinate = 0;
        Yaxis = Yaxis - 13;
        this.MODEL_Hanging_value_times++;

        switch (cur_charm.charm_type) {
          case 'symmetric':
            var hanging_symcharm = 432
            var Rep1c_model1_load = setInterval(() => {
              var cls = '#stubNumber_model_' + index;
              var cls2 = 'stubNumber_model_' + index;

              if (document.querySelector(cls)) {
                clearInterval(Rep1c_model1_load)
                var parents_elm = document.getElementById(cls2);
                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                parents_elm.style.top = Number(hanging_symcharm) + 'px';
              }
            }, 0);
            hanging_parents_coordinates = hanging_symcharm;

            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            // ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
            // ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
            break;
          case 'asymmetric':

            var hanging_asyCharm = (Number(432) + Number(cur_charm.asymmetric_position_value));
            var Rep1c_model2_load = setInterval(() => {
              var cls = '#stubNumber_model_' + index;
              var cls2 = 'stubNumber_model_' + index;

              if (document.querySelector(cls)) {
                clearInterval(Rep1c_model2_load)
                var parents_elm = document.getElementById(cls2);
                var current_hangingObject = parseInt(parents_elm.style.top);
                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                parents_elm.style.top = Number(hanging_asyCharm) + 'px';
              }
            }, 0);
            hanging_parents_coordinates = hanging_asyCharm;

            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            // ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
            // ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
            break;
          default:
            var hanging_def = 432
            var Rep1c_model3_load = setInterval(() => {
              var cls = '#stubNumber_model_' + index;
              var cls2 = 'stubNumber_model_' + index;

              if (document.querySelector(cls)) {
                clearInterval(Rep1c_model3_load)
                var parents_elm = document.getElementById(cls2);
                var currentObjectCoordinates = parseInt(parents_elm.style.top);
                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                parents_elm.style.top = Number(hanging_def) + 'px';
              }
            }, 0);
            hanging_parents_coordinates = hanging_def;

            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            // ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
            // ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
            break;
        }
        var model_current_charm_id = 0;
        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          this.chain_model_details.forEach(e2 => {
            if (e2.tools_link === pre_charm.flat_index) {
              model_current_charm_id = e2.tool_id;
            }
          });
          return ((e.chaindesign_id * 1) == (pre_charm.chaindesign_id * 1))
        })

        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          return ((e.parents_charm * 1) == (model_current_charm_id * 1))
        })
        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          return ((e.parents_charm_row_id * 1) == (pre_charm.id * 1))
        })

        filter_relation.forEach((element, index) => {
          var _id = 'stubNumber_model_' + element.index_no
          var attached_addon = document.getElementById(_id);

          var getXposition_mdlhgn = setInterval(() => {
            if (parent_charm_Xcoordinate > 0) {
              clearInterval(getXposition_mdlhgn);

              var nodel_hang_lstpstn_top = hanging_parents_coordinates + (60 * (index + 1));
              attached_addon.style.top = nodel_hang_lstpstn_top + 'px';

              var central_pos = (parent_charm_Xcoordinate + (65 - 45) / 2)
              attached_addon.style.left = central_pos + 'px';
            }
          })

          var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
          // ((a.controls[(element.index_no * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
          // ((a.controls[(element.index_no * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);

        });
        break;
    }
  }

  Replace_Bracelte_tools(pre_charm, cur_charm, index, img, its_from) {
    
    var Rep11capa1_load = setInterval(() => {
      var cls = '#stubNumber_' + index;
      var cls2 = 'stubNumber_' + index;

      if (document.querySelector(cls)) {
        clearInterval(Rep11capa1_load)
        var parents_elm = document.getElementById(cls2);
        parents_elm.childNodes[2].remove()

        var cln = img.target.cloneNode();
        parents_elm.appendChild(cln);
      }
    }, 0);

    var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
    this.RemoveSeletedTools(((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).value, its_from);
    switch (its_from) {
      case 'addon': ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id); break;
      case 'ring': ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id); break;
      case 'lock': ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id); break;
      default: ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id); break;
    }
    ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
    this.DefaultSeletedTools(((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).value, its_from);
    //Replace model Charms
    var charm_model_pos;
    var addon_model_pos;
    var model_tools_id;
    var model_tools_position;
    var modelflat_index = pre_charm.flat_index;
    var current_addon_id;

    switch (its_from) {
      case 'charm':
        this.Stub_model.forEach((e, index) => {
          if (e.toolsLink === modelflat_index) {
            model_tools_id = e.tool_id;
            model_tools_position = e.Position;
          }
        })
        
        

        this.charm_images.forEach(e => {
          if (e.charm_id === model_tools_id) {
            if (e.img_view_position === model_tools_position) {
              charm_model_pos = "charm_images_model_position" + e.charm_id
            }
          }
        });
        
        var cls = '#stubNumber_model_' + index;
        var cls2 = 'stubNumber_model_' + index;

        if (document.querySelector(cls)) {
          var parents_elm = document.getElementById(cls2);

          parents_elm.childNodes[2].remove()
          var itm = document.getElementById(charm_model_pos);
          var cln = itm.cloneNode(true);
          parents_elm.appendChild(cln);
          this.NumberOfStub_model++;
        }
        break;
      case 'addon':
        this.Stub_model.forEach((e, index) => {
          if (e.toolsLink === modelflat_index) {
            model_tools_id = e.tool_id;
            model_tools_position = e.Position;
          }
        })

        this.addon_images.forEach(e => {
          if (e.addon_id === cur_charm.addon_id) {
            if (Number(e.color_variationid) === Number(cur_charm.color_variationid)) {
              if (e.img_view_type === 'model' && String(e.img_view_position) === String(model_tools_position) && model_tools_id !== e.id) {//&& String(e.img_view_position) === String(cur_charm.img_view_position) REmove this Condition
                addon_model_pos = "addon_images_model_position" + e.id
                current_addon_id = e.id
              }
            }
          }
        });

        var cls = '#stubNumber_model_' + index;
        var cls2 = 'stubNumber_model_' + index;

        if (document.querySelector(cls)) {
          if (addon_model_pos) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.childNodes[2].remove()
            var itm = document.getElementById(addon_model_pos);
            var cln = itm.cloneNode(true);
            parents_elm.appendChild(cln);
            this.NumberOfStub_model++;
          } else {
            alert(model_tools_position.toUpperCase() + " side posititon images Not found for Model images");
          }
        }
        break;
      case 'lock':

        var cls = '#stubNumber_model_' + index;
        var cls2 = 'stubNumber_model_' + index;

        if (document.querySelector(cls)) {
          var parents_elm = document.getElementById(cls2);
          parents_elm.childNodes[2].remove()
          var cln1 = img.target.cloneNode();
          parents_elm.appendChild(cln1);
        }

        break;
      case 'ring':
        var cls = '#stubNumber_model_' + index;
        var cls2 = 'stubNumber_model_' + index;

        if (document.querySelector(cls)) {
          var parents_elm = document.getElementById(cls2);
          parents_elm.childNodes[2].remove()
          var cln2 = img.target.cloneNode();
          parents_elm.appendChild(cln2);
        }
        break;
    }

    var cls = '#stubNumber_model_' + index;
    if (document.querySelector(cls)) {
      var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
      this.RemoveSeletedTools(((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).value, its_from);
      ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(current_addon_id);
      ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
      this.DefaultSeletedTools(((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).value, its_from);
    }
    
    this.GetBraceletCoast(this.designForm.value);
  }

  imagesPreview(image_path: string) {
    // return this.ServerURL + '/images/' + image_path;
    return this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + image_path
  }
  // For Gold color
  filterGoldColor1(name: string) {
    if (!this.isNumber(name))
      return this.goldcolors1.filter(m => m.color.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getGoldColorName1(goldcolorid: number) {
    if (this.goldcolors1 != null && goldcolorid != null && goldcolorid != 0)
      return this.goldcolors1.filter(m => m.id * 1 === goldcolorid * 1)[0].color;
  }
  // For Bacelet Crtl
  filterbraceletlength(name: string) {
    if (!this.isNumber(name))
      return this.BraceletLengths.filter(m => m.length.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getbraceletlengthName(goldcolorid: number) {
    if (this.BraceletLengths != null && goldcolorid != null && goldcolorid != 0)
      return this.BraceletLengths.filter(m => m.id * 1 === goldcolorid * 1)[0].length;
  }
  // For Bacelet Pattern Crtl
  filterbraceletpattern(name: string) {
    if (!this.isNumber(name))
      return this.BraceletPatterns.filter(m => m.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getbraceletPatternName(goldcolorid: number) {
    if (this.BraceletPatterns != null && goldcolorid != null && goldcolorid != 0)
      return this.BraceletPatterns.filter(m => m.id * 1 === goldcolorid * 1)[0].name;
  }
  // For Bacelet Types Crtl
  filterbraceletTypes(name: string) {
    if (!this.isNumber(name))
      return this.BraceletTypes.filter(m => m.type_name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getbraceletTypesName(goldcolorid: number) {
    if (this.BraceletTypes != null && goldcolorid != null && goldcolorid != 0)
      return this.BraceletTypes.filter(m => m.id * 1 === goldcolorid * 1)[0].type_name;
  }
  // For Bacelet Types Crtl
  filtermetals(name: string) {
    if (!this.isNumber(name))
      return this.Metals.filter(m => m.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getMetalName(goldcolorid: number) {
    if (this.Metals != null && goldcolorid != null && goldcolorid != 0)
      return this.Metals.filter(m => m.id * 1 === goldcolorid * 1)[0].name;
  }
  // For Collection Types Crtl
  filtercollectiontypes(name: string) {
    if (!this.isNumber(name))
      return this.CollectionTypes.filter(m => m.typename.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getCollectiontypeName(goldcolorid: number) {
    if (this.CollectionTypes != null && goldcolorid != null && goldcolorid != 0)
      return this.CollectionTypes.filter(m => m.id * 1 === goldcolorid * 1)[0].typename;
  }
  // For Predefined Gold Color Crtl
  filterpdgoldcolors(name: string) {
    if (!this.isNumber(name))
      return this.pdGoldcolors.filter(m => m.color.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getpdgoldcolorsName(goldcolorid: number) {
    if (this.pdGoldcolors != null && goldcolorid != null && goldcolorid != 0)
      return this.pdGoldcolors.filter(m => m.id * 1 === goldcolorid * 1)[0].color;
  }
  // For Bacelet Types Crtl
  filterChainTypes(name: string) {
    if (!this.isNumber(name))
      return this.ChainTypes.filter(m => m.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getChaintypesName(goldcolorid: number) {
    if (this.ChainTypes != null && goldcolorid != null && goldcolorid != 0)
      return this.ChainTypes.filter(m => m.id * 1 === goldcolorid * 1)[0].name;
  }

  // For Bacelet Types Crtl
  filterColorrefs(name: string) {
    if (!this.isNumber(name))
      return this.colorpreferances.filter(m => m.color_name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getColorprefrencesName(goldcolorid: number) {
    if (this.colorpreferances != null && goldcolorid != null && goldcolorid != 0)
      return this.colorpreferances.filter(m => m.id * 1 === goldcolorid * 1)[0].color_name;
  }

  // For Predefined Bracelet structure gemstone colors Crtl
  filterPDgemstonecolrs(name: string) {
    if (!this.isNumber(name))
      return this.pdgemstonecolors.filter(m => m.color_name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getpdGemstoneColorName(goldcolorid: number) {
    if (this.pdgemstonecolors != null && goldcolorid != null && goldcolorid != 0)
      return this.pdgemstonecolors.filter(m => m.id * 1 === goldcolorid * 1)[0].color_name;
  }

  // For Predefined Diamond Structure Details Crtl
  filterDiamondshape(name: string) {
    if (!this.isNumber(name))
      return this.diamondshapeids.filter(m => m.shape.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getDiamondShapeName(goldcolorid: number) {
    if (this.diamondshapeids != null && goldcolorid != null && goldcolorid != 0)
      return this.diamondshapeids.filter(m => m.id * 1 === goldcolorid * 1)[0].shape;
  }

  //Start filter for addonCtrl  
  filterAddonGemstonecolor(name: string) {
    if (!this.isNumber(name))
      return this.addongemstonecolors.filter(m => m.color_name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getAddonGemstoneColorName(goldcolorid: number) {
    if (this.addongemstonecolors != null && goldcolorid != null && goldcolorid != 0)
      return this.addongemstonecolors.filter(m => m.id * 1 === goldcolorid * 1)[0].color_name;
  }


  filterAddonGemstoneshape(name: string) {
    if (!this.isNumber(name))
      return this.AddonGemstonedshapeids.filter(m => m.shape.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getAddonGemstoneshapeName(goldcolorid: number) {
    if (this.AddonGemstonedshapeids != null && goldcolorid != null && goldcolorid != 0)
      return this.AddonGemstonedshapeids.filter(m => m.id * 1 === goldcolorid * 1)[0].shape;
  }

  filterAddonDiamondshape(name: string) {
    if (!this.isNumber(name))
      return this.addon_Diamondshapeids.filter(m => m.shape.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getAddonDiamondeshapeName(goldcolorid: number) {
    if (this.addon_Diamondshapeids != null && goldcolorid != null && goldcolorid != 0)
      return this.addon_Diamondshapeids.filter(m => m.id * 1 === goldcolorid * 1)[0].shape;
  }
  //END filter for addon Ctrl

  // For Predefined Gold Color Crtl
  filterCharmGemstonecolors(name: string) {
    if (!this.isNumber(name))
      return this.charmgemstoneids.filter(m => m.color_name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getCharmGemstonecolorsName(goldcolorid: number) {
    if (this.charmgemstoneids != null && goldcolorid != null && goldcolorid != 0)
      return this.charmgemstoneids.filter(m => m.id * 1 === goldcolorid * 1)[0].color_name;
  }

  //For Collcetion 
  filterGemstonelength(name: string) {
    if (!this.isNumber(name))
      return this.gemstonelengths.filter(m => m.length.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getgemstonelengthName(typeId: number) {
    if (this.gemstonelengths != null && typeId != null && typeId != 0) {
      return this.gemstonelengths.filter(s => s.id == typeId)[0].length;
    }
  }


  get Getchain_designAnnotationArray() {
    return this.designForm.get('flat_chain_designAnnotation') as FormArray;
  }
  get GetModel_designAnnotationArray() {
    return this.designForm.get('model_chain_designAnnotation') as FormArray;
  }

  get Delete_flat_fromgroup() {
    return this.designForm.get('delete_flat_images') as FormArray;
  }

  get Delete_model_fromgroup() {
    return this.designForm.get('delete_model_images') as FormArray;
  }


  compareproduct() {
    var ttl = (Number(this.totalgoldweight * this.ratepergramgold) + Number(this.gemstonetotaleates) + Number(this.totaldiamonrate))
    this.designForm.get('totalprice').setValue(Number(Number(3 / 100 * ttl) + ttl) + Number(ttl));
    this.designForm.get('subtotal').setValue(ttl);
    this.designForm.get('taxvalue').setValue(Number(3 / 100 * ttl) + ttl);
    this.designForm.get('gold').setValue(Number(this.totalgoldweight * this.ratepergramgold));
    this.designForm.get('gemstone').setValue(Number(this.gemstonetotaleates));
    this.designForm.get('diamond').setValue(this.totaldiamonrate);
    this.designForm.get('margin').setValue(0);
    this.designForm.get('quantity').setValue(1);
    
    // this.designForm.get('braceletsize').setValue(this.gemstonelengthCtrl.value);

    switch (this.designForm.get('producttype').value) {
      case 'bracelettype':
        break;
      case 'predefinedstructure':
        break;
      case 'collection':
        break;
      case 'customizedesign':
        var cls = 'flat_box';
        var parents_elm = document.getElementsByClassName(cls);
        this.designForm.get('image').setValue(parents_elm[0].outerHTML);

        var cls_model = 'model_box';
        var parents_elm = document.getElementsByClassName(cls_model);
        this.designForm.get('image_model').setValue(parents_elm[0].outerHTML);
        break;
    }

    //Set images for compare page 
    if (this.designForm.get('producttype').value == 'customizedesign') {
      // 
      var clearflatimag1 = setInterval(() => {
        var node = document.getElementById('flatscreen');
        domtoimage.toPng(node)
          .then((dataUrl) => {
            var img = new Image();
            img.src = dataUrl;
            this.flatbase64Image = img.src
            clearInterval(clearflatimag1);
          })
          .catch((error) => {
            
          });
      }, 80);

      var getflatbase6412 = setInterval(() => {
        if (this.flatbase64Image) {
          // 
          this.designForm.get('image').setValue(this.flatbase64Image);
          clearInterval(getflatbase6412)
        }
      }, 80)

      var modelscreen123 = setInterval(() => {
        if (this.flatbase64Image) {
          this.test_map_flat.forEach(e => {
            e.status = true;
          })
          this.test_map_model.forEach(e => {
            e.status = true;
            if (e.id === 0) {
              e.status = false
            }
          })
          var node = document.getElementById('modelscreen');
          domtoimage.toPng(node)
            .then((dataUrl) => {
              var img = new Image();
              img.src = dataUrl;
              this.modelbase64Image = img.src
              // document.body.appendChild(img);
              clearInterval(modelscreen123)
            })
            .catch(function (error) {
              
            });
        }
      }, 80);

      var getmodelbase64234 = setInterval(() => {
        if (this.modelbase64Image) {
          // 
          this.designForm.get('image_model').setValue(this.modelbase64Image);
          clearInterval(getmodelbase64234)
        }
      }, 80)

      var both2356 = setInterval(() => {
        if (this.modelbase64Image && this.flatbase64Image) {
          this.CustomerOrdersService.addtocompare(this.designForm.value);
          this.openSnackBar('Product set for compare successfully..!', 'Close');
          clearInterval(both2356)
        }
      }, 80)
    } else {
      if (this.designForm.get('producttype').value == 'customizedesign') {
        this.CustomerOrdersService.addtocompare(this.designForm.value);
        this.openSnackBar('Product set for compare successfully..!', 'Close');
      } else {
        this.openSnackBar('Product not Selected..!', 'Close');
      }
    }
    //End Here compare operation
  }


  cartproduct() {

    var ttl = (Number(this.totalgoldweight * this.ratepergramgold) + Number(this.gemstonetotaleates) + Number(this.totaldiamonrate))
    this.designForm.get('totalprice').setValue(Number(Number(3 / 100 * ttl) + ttl) + Number(ttl));
    this.designForm.get('subtotal').setValue(ttl);
    this.designForm.get('taxvalue').setValue(Number(3 / 100 * ttl) + ttl);
    this.designForm.get('gold').setValue(Number(this.totalgoldweight * this.ratepergramgold));
    this.designForm.get('gemstone').setValue(Number(this.gemstonetotaleates));
    this.designForm.get('diamond').setValue(this.totaldiamonrate);
    this.designForm.get('margin').setValue(0);
    this.designForm.get('quantity').setValue(1);
    // this.designForm.get('braceletsize').setValue(this.gemstonelengthCtrl.value);

    
    var flat_src_path;
    if (Number(this.designForm.get('id').value)) {

      if (this.designForm.get('producttype').value == 'customizedesign') {
        
        var clearflatimag = setTimeout(() => {
          var node = document.getElementById('flatscreen');
          domtoimage.toPng(node)
            .then((dataUrl) => {
              var img = new Image();
              img.src = dataUrl;
              this.flatbase64Image = img.src
              // clearInterval(clearflatimag);
            })
            .catch((error) => {
              
            });
        }, 50);

        var getflatbase64 = setInterval(() => {
          if (this.flatbase64Image) {
            // 
            this.designForm.get('image').setValue(this.flatbase64Image);
            clearInterval(getflatbase64)
          }
        }, 50)

        var modelscreen = setInterval(() => {
          if (this.flatbase64Image) {
            this.test_map_flat.forEach(e => {
              e.status = true;
            })
            this.test_map_model.forEach(e => {
              e.status = true;
              if (e.id === 0) {
                e.status = false
              }
            })
            var node = document.getElementById('modelscreen');
            domtoimage.toPng(node)
              .then((dataUrl) => {
                var img = new Image();
                img.src = dataUrl;
                this.modelbase64Image = img.src
                // document.body.appendChild(img);
                clearInterval(modelscreen)
              })
              .catch(function (error) {
                
              });
          }
        }, 50);

        var getmodelbase64 = setInterval(() => {
          if (this.modelbase64Image) {
            
            this.designForm.get('image_model').setValue(this.modelbase64Image);
            clearInterval(getmodelbase64)
          }
        }, 50)

        var both = setInterval(() => {
          if (this.modelbase64Image && this.flatbase64Image) {
            this.CustomerOrdersService.addtocart(this.designForm.value);
            this.openSnackBar('Product set for Cart successfully..!', 'Close');
            clearInterval(both)
          }
        }, 50)
      } else {
        if (this.designForm.get('producttype').value == 'customizedesign') {
          this.CustomerOrdersService.addtocart(this.designForm.value);
          this.openSnackBar('Product set for Cart successfully..!', 'Close');
        } else {
          this.openSnackBar('Product not Selected..!', 'Close');
        }
      }
    } else {
      this.openSnackBar('Product not Selected..!', 'Close');
    }
  }

  onSubmit() {

    this.designForm.get('loosebraceletPatternid').setValue(this.chain_details[0].loosebraceletpatternid);
    

    this.submitted = true;
    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.designForm.invalid) {
      this.submitted = false;
      return;
    }
    
    this.loading = true;
    this.ChaindesignannotationService
      .save_client_order(JSON.stringify(this.designForm.value))
      .subscribe((data: any) => {
        this.alertService.success('Order has been save successfully !', true);
        window.location.reload();
      });
  }

  async addtocartbracelet(object) {
    await this.BhuildStructure_design(object.id, object.vendor_id, object);
    await this.MakeCalculation(this.designForm.get("pre_braceletpattern").value, this.vendor_id, "18", "6", "1", "1", "1");

    var fillingformarray = setInterval(() => {
      if ((this.designForm.get("flat_chain_designAnnotation") as FormArray).length > 0) {
        this.designForm.get("image").setValue(object.img_path);
        this.CustomerOrdersService.addtocart(this.designForm.value);
        this.Alertpopup("Cart", this.designForm.get("name").value);
        clearInterval(fillingformarray);
      }
    }, 0)
  }

  async addtocomparebracelet(object) {
    await this.BhuildStructure_design(object.id, object.vendor_id, object);
    await this.MakeCalculation(this.designForm.get("pre_braceletpattern").value, this.vendor_id, "18", "6", "1", "1", "1");

    var refillformarray = setInterval(() => {
      if ((this.designForm.get("flat_chain_designAnnotation") as FormArray).length > 0) {
        this.designForm.get("image").setValue(object.img_path);
        this.CustomerOrdersService.addtocompare(this.designForm.value);
        this.Alertpopup("Compare", this.designForm.get("name").value);
        clearInterval(refillformarray);
      }
    }, 0)
  }

  Alertpopup(forwhat, productname): void {
    const dialogRef = this.dialog.open(CommonalertpopupComponent, {
      // width: '250px',
      data: { mission: forwhat, name: productname },
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }

  public findInvalidControls() {
    const invalid = [];
    const controls = this.designForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        invalid.push(name);
      }
    }
    return invalid;
  }

  cancel() {
    window.location.reload();
  }


  // convenience getter for easy access to form fields
  get f() { return this.designForm.controls; }


  filterPredefinedBaceltetStructure(name: string) {

    if (!this.isNumber(name))
      return this.predefineBracelet.filter(m => m.predefine_pattern.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getPredefinedBraceletName(typeId: number) {
    if (this.predefineBracelet != null && typeId != null && typeId != 0) {
      return this.predefineBracelet.filter(s => s.pdbs_id === typeId)[0].predefine_pattern;
    }
  }
  //common for All autocomplete
  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }



  collapse_open1(){
    this.collapse_show1 = !this.collapse_show1
    this.collapse_show2=false;
    this.collapse_show3=false;
    this.collapse_show4=false;
  }
  collapse_open2(){
    this.collapse_show2 = !this.collapse_show2
    this.collapse_show3=false;
    this.collapse_show1=false;
    this.collapse_show4=false;
  }
  collapse_open3(){
    this.collapse_show3 = !this.collapse_show3
    this.collapse_show2=false;
    this.collapse_show1=false;
    this.collapse_show4=false;
  }
  collapse_open4(){
    this.collapse_show4 = !this.collapse_show4
    this.collapse_show2=false;
    this.collapse_show3=false;
    this.collapse_show1=false;
  }
 
  goToProductList(data:any){
    console.log('data:', data);
    this.productName = this.replaceAll(data.typename, ' ', '');
    var det = this.url_companyname + "/" + this.vendoruniquekey + '/' +  'product' + '/' +  this.productName + "/" + data.id;
    this.router.navigate([det]);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;

  }

  showProductList(data:any){
    this.showProductData = true;
    this.productId = data.id;
    this.selectedProduct = this.productSubList.filter(c => c.product_id === this.productId);
  }
  hideSubMenu(data:any){
    this.showProductData = false;

  }

   //// product  list////

   getProductList() {
    this.producttypeService.getAll().subscribe((data) => {
      if (data) {
        this.productList = data;
      }
    });
  }
 replaceAll(input: string, find: string, replace: string): string {
    return input.replace(new RegExp(find, 'g'), replace);
 }
  

  //// product  list end////
  goToListing(subProductid){
    this.productName = this.replaceAll(subProductid.productname, ' ', '');
    this.productSubName = this.replaceAll(subProductid.name, ' ', '');
    var det = this.url_companyname + "/" + this.vendoruniquekey + '/' +  this.productName + "/" + this.productSubName + "/" + 'subproduct' + "/" + subProductid.id;
    this.router.navigate( [det]);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  goToCompare(){
    let compare = this.url_companyname + "/" + this.vendoruniquekey + '/compare/'
    this.router.navigate( [compare]);

  }

  goToCart(){
    let cart = this.url_companyname + "/" + this.vendoruniquekey + '/cart/'
    this.router.navigate( [cart]);
  }

 
  goToHome(){
    var det = this.url_companyname + "/" + this.vendoruniquekey;
    this.router.navigate([det]);

  }


}

