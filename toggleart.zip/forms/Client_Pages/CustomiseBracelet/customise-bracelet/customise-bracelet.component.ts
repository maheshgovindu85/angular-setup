import {
  Component,
  OnInit,
  Input,
  OnDestroy,
  ViewChild,
  ViewContainerRef,
  Output,
  HostListener,
  EventEmitter,
  ComponentRef,
  ComponentFactory,
  ElementRef,
  ComponentFactoryResolver,
  ViewChildren,
  QueryList,
  Renderer2,
  ChangeDetectorRef,
  Inject
} from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { interval, Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
// import { CdkDragDrop, moveItemInArray, transferArrayItem, copyArrayItem } from '@angular/cdk/drag-drop';

import { AlertService, AuthenticationService, VendorAuthenticationService, VendorCollectionService } from '@/_services';

import { async, resetFakeAsyncZone } from '@angular/core/testing';
import { ChaindesignannotationService } from '@/_services/chaindesignannotation.service';
import { threadId } from 'worker_threads';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { Loosebraceletpattern } from '@/_models/loosebraceletpattern';
import { JewelleryDeleteBtnComponent } from '@/_components/jewellery-delete-btn/jewellery-delete-btn.component';
import { MatTabChangeEvent, MatTabGroup } from '@angular/material/tabs';
import { promises, resolve } from 'dns';
import { rejects } from 'assert';
import { NavbarservicesService } from '@/_services/navbarservices.service';
import { ViewclientchainrelatedimagesPopupComponent } from '../../client-design-annoation/viewclientchainrelatedimages-popup/viewclientchainrelatedimages-popup.component';
import { ViewCustomeraddonRateInfoComponent } from '../../view-customeraddon-rate-info/view-customeraddon-rate-info.component';
import { MatDialog } from '@angular/material/dialog';
import { CustomerAuthenticationService } from '@/_services/customer-authentication.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import domtoimage from 'dom-to-image-chrome-fix';
import { CustomerOrdersService } from '../../customer-orders.service';
import { VendorAddComponent } from '@/forms/vendormaster/vendor-add/vendor-add.component';
import { DOCUMENT } from '@angular/common';
import { CollectionImageReducer } from '@/_store/collectionimage/collectionimage.reducer';
import { VendorService } from '@/_services/vendor.service';
import { CustomerUser } from '@/_models/CustomerUser';
import { CommonalertpopupComponent } from '@/forms/CommonPopup/commonalertpopup/commonalertpopup.component';
import { Console } from 'console';
declare let html2canvas: any;
// import html2canvas from 'html2canvas';


@Component({
  selector: 'app-customise-bracelet',
  templateUrl: './customise-bracelet.component.html',
  styleUrls: ['./customise-bracelet.component.css']
})
export class CustomiseBraceletComponent implements OnInit {

  @ViewChild('divToScroll') divToScroll: ElementRef;
  @ViewChild('AddonToScroll') AddonToScroll: ElementRef;
  @ViewChild('supportimgelement') supportimgelement: ElementRef;

  isLoading = false;
  predefinestructureCtrl = new FormControl();
  predefineBracelet: any[];
  filteredPredefineBaracelet: Observable<any[]>;

  public chain_images;
  public addon_images;
  public charm_images;
  ring_images;
  lock_images;
  public alltypeofchains;
  IsContaintSinglestud: boolean = false;

  public chain_images_filters;
  public addon_images_filters;
  public addon_images_filters_SupportArray;
  public charm_images_filters;
  public charm_images_filters_SupportArray;
  ring_images_filters;
  lock_images_filters;
  public chainlist_filters;
  public alltypeofchains_filters;

  public predefinedbracelettype;

  public loosepattern_dtl: Loosebraceletpattern;

  public has_predefinesPattern: boolean = true;
  public flatImageHidenComp = 0;
  public ModelImagesHidComp = 0;

  public chain_details;
  public chain_flat_details: any[] = [];
  public chain_model_details;

  loading = false;
  submitted = false;
  public topaxisIndex: number = 0;
  public topaxisIndexModel: number = 0;
  public delete_flatIds = 1;
  public activetab = 0;


  public topaxisPixel_flat = 100;
  public topaxisPixel_model = 100;
  public columnCount_flat = 1;
  public columnCount_model = 1;

  public looseBracelettype;
  public chaingoldcolorid;
  public braceletchaintypeid;

  public ServerURL;
  designForm: FormGroup;
  left: number = 0;
  cmpt = this;

  showpricebreakup: boolean = false;
  NumberOfImageShowInList: number = 10;
  NumberOfAddonShowInList: number = 10;
  CharmIndexvalue: number = 0;

  HTMLlockelemet: boolean = false;
  HTMLringelemet: boolean = false;
  HTMLcharmelemet: boolean = false;
  HTMLaddonelemet: boolean = false;

  @ViewChildren('capa', { read: ViewContainerRef }) capa1: ViewContainerRef;
  @ViewChildren('capa') capaElementRef1: ElementRef;

  @ViewChild('capa2', { read: ViewContainerRef }) capa2: ViewContainerRef;
  @ViewChild('capa2') capaElementRef2: ElementRef;


  items1: any = [];

  public SetInitialImages_model: number = 0;
  items2: any = [];

  Stub: any[] = [];
  NumberOfStub: number = 0;

  Stub_model: any[] = [];
  NumberOfStub_model: number = 0;

  changecoordinates_flat: any[] = [];
  changecoordinates_model: any[] = [];

  flat_chain_charm_relarionDetails: any;
  model_chain_charm_relationDetails: any;

  identify_number_attached = 0;
  identify_number_hanging = 0;

  pre_click_charmId = 0;

  FLAT_Hanging_value_times = 0;
  MODEL_Hanging_value_times = 0;

  model_details_update = 0;

  public flatimagesPreview;
  public modelimagePreview;

  goldColorCtrl1 = new FormControl();
  goldcolors1: any[];
  filteredGoldColor1: Observable<any[]>;

  viewentirechainlist: any[];
  public chainwidths;
  flat_on: boolean = true;

  numberofcharm: number = 0;
  numberofaddon: number = 0;

  goldcolour = new FormControl();
  studdedtype = new FormControl();
  // studdedtypeList: any[] = [{ name: 'None', value: null }, { name: 'Diamond', value: 'diamond' }, { name: 'Gemstone', value: 'gemstone' }, { name: 'Diamond + Gemstone', value: 'combination' }];
  studdedtypeList: any[] = [];
  gemstonecolor = new FormControl();
  colorpreferances: any[];
  sessionUser: any;

  isspeciallock: boolean = true;

  isbraceletcontainAddon: boolean = false;

  targetimage;

  filtered_braceletid: any;
  filtered_collectionid: any;

  predefinedratedetails;

  DiamodColorcombo;
  Gemstonedetailslist;
  diamondcolorcombinationName;

  gemstonelengthCtrl = new FormControl();
  gemstonelengths: any[];
  filteredgemstonelength: Observable<any[]>;

  selectedKT = "18";
  selectedcolor = '1';
  selectedpurity = '1';
  selectCombocolorpurity = 1 + ',' + 1;
  pdbs_id;
  diamondComboination: any;


  selectedgemstonetype = 1;
  activeclass = 1;

  goldkaratlist;
  ktactiveclass = 18;

  flatbase64Image: any;

  vendorCompanyname;
  vendorquniquekey;
  vendor_id;

  vendorcompanyname;

  disablecalculationsection: boolean = false;
  capturedImage;
  campareurlobjectdata;

  ActivityStorage: any[] = [];

  BraceletAutogenerateid = 0;


  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private ChaindesignannotationService: ChaindesignannotationService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private vendorCollectionService: VendorCollectionService,
    private _snackBar: MatSnackBar,
    private CustomerAuthenticationService: CustomerAuthenticationService,
    private NavbarservicesService: NavbarservicesService,
    private vendorauthenticationService: VendorAuthenticationService,
    public CustomerOrdersService: CustomerOrdersService,
    private cdRef: ChangeDetectorRef,
    public dialog: MatDialog,
    private renderer: Renderer2,
    private vendorservice: VendorService,
    @Inject(DOCUMENT) private document: Document,
    private resolver: ComponentFactoryResolver) {

    // if (!this.authenticationService.currentUserValue) {
    //   this.router.navigate(['login']);
    // }
    // authenticationService.logout()

    if (CustomerAuthenticationService.customercurrentUserValue)
      this.sessionUser = CustomerAuthenticationService.customercurrentUserValue;

    const id = this.route.snapshot.params.id;
    this.vendorCompanyname = this.route.snapshot.params.companyname;
    this.vendorquniquekey = this.route.snapshot.params.vendoruniquekey;
    this.vendor_id = this.route.snapshot.params.vendorid;

    this.filtered_collectionid = route.snapshot.params.collectionid;

    this.filtered_braceletid = route.snapshot.params.braceletypeid;

    this.campareurlobjectdata = { 'vendorCompanyname': this.vendorCompanyname, 'vendorquniquekey': this.vendorquniquekey, 'index': 2, 'collection': this.filtered_collectionid, 'braceletid': this.filtered_braceletid }


    this.ChaindesignannotationService.getAllgoldColors()
      .subscribe((data) => {
        this.goldcolors1 = data;
      });

    this.ChaindesignannotationService.gelallchaincolorPref()
      .subscribe((data) => {
        this.colorpreferances = data;
      });

    ChaindesignannotationService.GetDiamondColorPurityCombo(this.vendor_id).subscribe(data => {
      this.DiamodColorcombo = data;
    })

    ChaindesignannotationService.Vendorsdetails(this.vendor_id).subscribe((data: any) => {
      this.vendorcompanyname = data.company;
    })

    ChaindesignannotationService.getgemstonetypedetails().subscribe(data => {
      this.Gemstonedetailslist = data;
    })

    this.predefinestructureCtrl.valueChanges.subscribe(data => {
      this.ChaindesignannotationService.getMultipleModelDetails(data).subscribe(
        data => {
          this.has_predefinesPattern = true;
          var JsonData = JSON.parse(JSON.stringify(data));
          var Braceletstructure_chain = JsonData.Braceletstructure_chain;
          var Braceletstructure_addon = JsonData.Braceletstructure_addon;
          var Braceletstructure_charm = JsonData.Braceletstructure_charm;
          var Braceletstructure_lock = JsonData.Braceletstructure_lock;
          var Braceletstructure_ring = JsonData.Braceletstructure_ring;
          var getLooseBraceletPattern = JsonData.getLooseBraceletPattern;

          this.chain_images = Braceletstructure_chain;
          this.loosepattern_dtl = getLooseBraceletPattern;
        }
      );
    })

    this.ChaindesignannotationService.getallchainwidth()
      .subscribe((data) => {
        this.chainwidths = data;
      })

    this.ChaindesignannotationService.getEntiredesigntools(this.vendor_id, this.filtered_collectionid).then(data => {
      var JsonData = JSON.parse(JSON.stringify(data));
      var entire_Designannotation = JsonData.entire_Designannotation;
      var entire_chains = JsonData.entire_chains;
      var Braceletstructure_addon = JsonData.entire_Bracelet_addon;
      var Braceletstructure_charm = JsonData.entire_Bracelet_charm;
      var Braceletstructure_lock = JsonData.entire_Bracelet_lock;
      var Braceletstructure_ring = JsonData.entire_Bracelet_ring;
      var entiretypeofchain = JsonData.entire_typeofchain;

      this.chain_images = entire_chains;
      // this.design_pattern = entire_Designannotation;
      // this.design_pattern_mod = entire_Designannotation;
      this.addon_images = Braceletstructure_addon;
      this.charm_images = Braceletstructure_charm;
      this.ring_images = Braceletstructure_ring;
      this.lock_images = Braceletstructure_lock;
      this.alltypeofchains = entiretypeofchain;

      this.addon_images_filters = Braceletstructure_addon;
      this.addon_images_filters_SupportArray = Braceletstructure_addon;

      this.charm_images_filters = Braceletstructure_charm;
      this.charm_images_filters_SupportArray = Braceletstructure_charm;

      this.ring_images_filters = Braceletstructure_ring;
      this.lock_images_filters = Braceletstructure_lock;

      this.chain_images_filters = entire_chains;
      this.alltypeofchains_filters = entiretypeofchain;

    })

    this.ChaindesignannotationService.getBraceletAnnotationDetails(id).then(
      data => {
        var JsonData = JSON.parse(JSON.stringify(data));
        var desingAnnotation = JsonData.desingAnnotation;
        var desingAnnotation_flat = JsonData.desingAnnotation_flat;
        var desingAnnotation_model = JsonData.desingAnnotation_model;
        var chain_Design_flat_relation = JsonData.chain_Design_flat_relation;
        var chain_design_model_relation = JsonData.chain_design_model_relation;

        this.chain_details = desingAnnotation;
        this.chain_flat_details = desingAnnotation_flat;
        this.chain_model_details = desingAnnotation_model;

        this.ChaindesignannotationService.setcustomizationlinkactivity(this.vendor_id)
          .subscribe((data) => {
          })

        // for ralation maintained
        this.flat_chain_charm_relarionDetails = chain_Design_flat_relation;
        this.model_chain_charm_relationDetails = chain_design_model_relation;

        // console.log('This is Pseacial Loack '+this.chain_details[0].speciallock);
        if (this.chain_details[0].speciallock == 'true') {
          this.isspeciallock = false;
        }

        this.chain_flat_details.forEach(element => {
          switch (element.tooltype) {
            case 'charm':
              this.numberofcharm++;
              break;
            case 'addon':
              this.numberofaddon++;
              break;
          }
        });

        this.predefinedbracelettype = desingAnnotation[0].linkballpearl

        switch (desingAnnotation[0].linkballpearl) {
          case 'chain':
            ChaindesignannotationService.Chaindesignimages(id).subscribe(data => {
              // this.flatimagesPreview = this.ServerURL + '/images/' + data.flatfileName;
              this.flatimagesPreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.flatfileName;

              this.modelimagePreview = this.ServerURL + '/images/' + data.modelfilename;
              this.chaingoldcolorid = data.goldcolorid;
              this.braceletchaintypeid = data.chain_type_id;

              if (this.chaingoldcolorid > 0 && this.lock_images !== undefined) {
                this.lock_images_filters = this.lock_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
              }
              if (this.chaingoldcolorid > 0 && this.ring_images !== undefined)
                this.ring_images_filters = this.ring_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
            })
            break;
          case 'link':
            ChaindesignannotationService.LinkChaindesignimages(id).subscribe(data => {
              // this.flatimagesPreview = this.ServerURL + '/images/' + data.flatfileName;
              this.flatimagesPreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.flatfileName;

              this.modelimagePreview = this.ServerURL + '/images/' + data.modelfilename;
              this.chaingoldcolorid = data.goldcolorid;

              this.braceletchaintypeid = data.chain_type_id;

              if (this.chaingoldcolorid > 0 && this.lock_images !== undefined) {
                this.lock_images_filters = this.lock_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
              }
              if (this.chaingoldcolorid > 0 && this.ring_images !== undefined)
                this.ring_images_filters = this.ring_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
            })
            break;
          case 'ball-pearl':
            ChaindesignannotationService.ballpearlChaindesignimages(id).subscribe(data => {
              // this.flatimagesPreview = this.ServerURL + '/images/' + data.flatfileName;
              this.flatimagesPreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + data.flatfileName;

              this.modelimagePreview = this.ServerURL + '/images/' + data.modelfilename;
              this.chaingoldcolorid = data.goldcolorid;
              this.braceletchaintypeid = data.chain_type_id;


              if (this.chaingoldcolorid > 0 && this.lock_images !== undefined) {
                this.lock_images_filters = this.lock_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
              }
              if (this.chaingoldcolorid > 0 && this.ring_images !== undefined)
                this.ring_images_filters = this.ring_images.filter(f => f.goldcolorid == this.chaingoldcolorid);
            })
            break;
        }

        this.ChaindesignannotationService.loosebraceletpattern(desingAnnotation[0].pre_braceletpattern).subscribe(data => {
          if (data[0]) {
            this.looseBracelettype = (data[0].charm_type).toLowerCase();

            var loosebracelet = setInterval(() => {
              if (this.charm_images_filters_SupportArray) {
                // f.img_view_type == 'flat' &&
                this.charm_images_filters_SupportArray = this.charm_images_filters_SupportArray.filter(f => f.charm_position == this.looseBracelettype)
                clearInterval(loosebracelet);
              }
            }, 0)

            var loosebraceletAddon = setInterval(() => {
              if (this.addon_images_filters_SupportArray) {
                this.addon_images_filters_SupportArray = this.addon_images_filters_SupportArray;//.filter(f => f.img_view_type == 'flat')
                clearInterval(loosebraceletAddon);
              }
            }, 0)

          }
        })

        this.ChaindesignannotationService.predefinedraceletAddoncount(desingAnnotation[0].pre_braceletpattern).subscribe(data => {
          if (data[0]) {
            this.isbraceletcontainAddon = true;
          }
        })


        ChaindesignannotationService.predefinedkaratlist(desingAnnotation[0].pre_braceletpattern).subscribe(data => {
          this.goldkaratlist = data;
        })

        this.predefinestructureCtrl.setValue(desingAnnotation[0].pre_braceletpattern);
        this.pdbs_id = desingAnnotation[0].pre_braceletpattern;

        this.MakeCalculation(this.pdbs_id, this.vendor_id, "18", "6", "1", "1", "1");



        this.targetimage = this.ServerURL + '/images/target_image.jpg';

        this.designForm = this.formBuilder.group({
          id: [desingAnnotation[0].id, Validators.required],
          name: [desingAnnotation[0].predefinedbraceletname, Validators.required],
          pre_braceletpattern: [desingAnnotation[0].pre_braceletpattern, Validators.required],
          loosebraceletPatternid: [desingAnnotation[0].loosebraceletpatternid, Validators.required],
          braceletchain_id: [desingAnnotation[0].braceletchain_id, Validators.required],
          braceletchaintype: [''],
          isdelete: [false, Validators.required],
          braceletcartfrom: ['customization'],
          delete_flat_images: this.formBuilder.array([]),
          delete_model_images: this.formBuilder.array([]),
          design_tools_charm: [''],
          design_tools_addon: [''],
          design_tools_lock: [''],
          design_tools_ring: [''],
          linkchainlockid: [desingAnnotation[0].lock_id],

          totalprice: [0, Validators.required],
          subtotal: [],
          taxvalue: [],
          gold: [0, Validators.required],
          gemstone: [0, Validators.required],
          diamond: [0, Validators.required],
          margin: [0, Validators.required],
          quantity: [1, Validators.required],
          image: ['', Validators.required],
          image_model: [''],
          producttype: ['collection', Validators.required],
          braceletwidth_id: [1],
          charmstuddedtype: [''],
          //End New Fields
          customerid: [0, Validators.required],
          chainflatImages_id: [desingAnnotation[0].chainflatimages_id, Validators.required],
          chainmodelImages_id: [desingAnnotation[0].chainmodelimages_id, Validators.required],
          clickfromproduct: ['', Validators.required],
          // some additional form fields
          pricerange: [''],
          //end addition fields
          vendorid: [this.vendor_id, Validators.required],

          flat_chain_designAnnotation: this.formBuilder.array([]),
          model_chain_designAnnotation: this.formBuilder.array([]),
          flat_relation_details: this.formBuilder.array([]),
          model_relation_details: this.formBuilder.array([]),

          braceletgoldkt: ['18', Validators.required],
          diamondcolorpuritycombo: ['', Validators.required],
          braceletgemstonetype: ['2'],
          color: ['1'],
          purity: ['1'],
          braceletsize: ['6', Validators.required],
          braceletsizeid: ['1', Validators.required],
          BraceletAutogenerateid: [this.BraceletAutogenerateid]
        });

        this.gemstonelengthCtrl.setValue(1)
        var Flat_also_update = 0
        var Model_also_update = 0
        desingAnnotation_flat.forEach(element => {
          if (element.addfrom === 'update')
            Flat_also_update = 1
        });

        desingAnnotation_model.forEach(element => {
          if (element.addfrom === 'update')
            Model_also_update = 1;
          this.model_details_update = 1;
        });

        var capa1_load_onload = setInterval(() => {
          if (this.capa1) {
            clearInterval(capa1_load_onload)
            this.designForm.setControl('flat_chain_designAnnotation', this.setFLatDetails(desingAnnotation_flat, Flat_also_update));
          }
        }, 1000);

        var capa2_load_onload = setInterval(() => {
          if (this.capa2) {
            clearInterval(capa2_load_onload)
            this.designForm.setControl('model_chain_designAnnotation', this.setModelDetails(desingAnnotation_model, Model_also_update));
          }
        }, 1000);

        this.selectedreplcementtool = 'chain';
        this.Makeseletedtools('chaincls');

      }
    );

    this.designForm = this.formBuilder.group({
      id: [0, Validators.required],
      name: ['Bracelet_Design', Validators.required],
      pre_braceletpattern: [0, Validators.required],
      loosebraceletPatternid: [0, Validators.required],
      braceletchain_id: [0, Validators.required],
      braceletcartfrom: ['customization'],
      braceletchaintype: [''],
      isdelete: [false, Validators.required],

      flat_chain_designAnnotation: this.formBuilder.array([]),
      model_chain_designAnnotation: this.formBuilder.array([]),
      delete_flat_images: this.formBuilder.array([]),
      delete_model_images: this.formBuilder.array([]),

      flat_relation_details: this.formBuilder.array([]),
      model_relation_details: this.formBuilder.array([]),

      design_tools_charm: [''],
      design_tools_addon: [''],
      design_tools_lock: [''],
      design_tools_ring: [''],
      linkchainlockid: [''],
    });
    this.ServerURL = metalgoldcolorservice.path;

    ChaindesignannotationService.getStuddedtypeList().subscribe(data => {
      this.studdedtypeList = data;
    })

    this.goldcolour.valueChanges.subscribe(data => {
      this.somefilterChange();
      this.SaveActivity("Apply Some Gold Colour filters");
    });
    this.studdedtype.valueChanges.subscribe(data => {
      this.somefilterChange()
      this.SaveActivity("Apply Some Studded type filters");
    })
    this.gemstonecolor.valueChanges.subscribe(data => {
      this.somefilterChange()
      this.SaveActivity("Apply Some Gemstone Colour filters");
    })
    this.Makeseletedtools('chaincls');

    // this.gemstonelengthCtrl.valueChanges.subscribe(data => {
    //   this.CustomizationCalculation();
    //  })

    window.scroll(0, 0);
  }

  chooseBraceletsize(id) {

    console.log(id);
    this.activeclass = id;
    this.gemstonelengthCtrl.setValue(id);
    console.log(this.gemstonelengthCtrl.value);
    this.SaveActivity("Changed Bracelet Size in customization");
    this.CustomizationCalculation();
  }

  getGemstonetypeName(id: any) {
    return this.Gemstonedetailslist.filter(f => f.id == id)[0].type_name;
  }

  changeGoldCarat(id) {
    this.selectedKT = id;
    this.ktactiveclass = id;
    this.CustomizationCalculation();
    this.SaveActivity("Change gold KT in Customization");
    // this.MakeCalculation(this.pdbs_id, this.sessionUser.id, this.selectedKT, this.gemstonelengthCtrl.value, this.selectedcolor, this.selectedpurity, this.selectedgemstonetype)
  }

  changecolorpurity(id) {
    var a: any = this.DiamodColorcombo.filter(f => f.comboid == id)[0];
    a.colorname + " - " + a.purityname;

    this.selectedcolor = a.colorid;
    this.selectedpurity = a.purityid;
    this.selectCombocolorpurity = id;
    this.CustomizationCalculation();
    this.SaveActivity("Changed Colour And purity in customization");
    // this.MakeCalculation(this.pdbs_id, this.sessionUser.id, this.selectedKT, this.gemstonelengthCtrl.value, this.selectedcolor, this.selectedpurity, this.selectedgemstonetype)
  }

  changeGemstonetype(id) {
    this.selectedgemstonetype = id;
    this.CustomizationCalculation();
    this.SaveActivity("Changed Gemstone Type in Customization");
    // this.MakeCalculation(this.pdbs_id, this.sessionUser.id, this.selectedKT, this.gemstonelengthCtrl.value, this.selectedcolor, this.selectedpurity, this.selectedgemstonetype)
  }

  finalvalue = 0;
  MakeCalculation(pdbs_id, vendor_id, kt, braceletsize, color, purity, type) {
    this.isLoading = true;
    this.vendorCollectionService.getpredefinedentireRates(pdbs_id, vendor_id, kt, braceletsize, color, purity, type).then(data => {
      this.predefinedratedetails = data;

      this.gemstonelengths = this.predefinedratedetails.braceletelength;
      this.isLoading = false;
      this.designForm.get('diamondcolorpuritycombo').setValue('1,1');
      this.designForm.get('gold').setValue(this.predefinedratedetails.goldexplain.actualgoldwt);
      this.designForm.get('gemstone').setValue(this.predefinedratedetails.gemstoneprice);
      this.designForm.get('diamond').setValue(this.predefinedratedetails.diamondprice);
      this.designForm.get('margin').setValue(this.predefinedratedetails.goldexplain.marginvalue);
      this.designForm.get('subtotal').setValue(this.predefinedratedetails.price);
      this.designForm.get('taxvalue').setValue((this.predefinedratedetails.price / 100) * 3);
      this.designForm.get('totalprice').setValue(Math.round(this.predefinedratedetails.price + (this.predefinedratedetails.price / 100) * 3));

      var total = this.predefinedratedetails.price + (this.predefinedratedetails.price / 100) * 3;
      this.finalvalue = Math.round(total);

    }, error => this.isLoading = false)
  }

  CustomizationCalculation() {
    this.disablecalculationsection = true;
    this.designForm.get('braceletgoldkt').setValue(this.selectedKT);
    this.designForm.get('braceletgemstonetype').setValue(this.selectedgemstonetype);
    this.designForm.get('color').setValue(this.selectedcolor);
    this.designForm.get('purity').setValue(this.selectedpurity);

    var lenn = 0;
    if (this.gemstonelengths.length > 0) {
      lenn = this.gemstonelengths.filter(f => f.id == this.gemstonelengthCtrl.value * 1)[0].length
    }
    this.designForm.get('braceletsize').setValue(lenn);
    this.designForm.get('braceletsizeid').setValue(this.gemstonelengthCtrl.value * 1);

    this.vendorCollectionService.getcustomizationCalculation(this.designForm.value).subscribe(data => {
      this.predefinedratedetails = data;
      this.disablecalculationsection = false;
      this.gemstonelengths = this.predefinedratedetails.braceletelength;

      this.DefaultSeletedTools(this.designForm.get('braceletwidth_id').value, 'braceletwidth');
      var clrprtcmbo: any = this.predefinedratedetails.goldexplain.color + "," + this.predefinedratedetails.goldexplain.purity;
      this.designForm.get('diamondcolorpuritycombo').setValue(clrprtcmbo);
      this.designForm.get('gold').setValue(this.predefinedratedetails.goldexplain.actualgoldwt);
      this.designForm.get('gemstone').setValue(this.predefinedratedetails.gemstoneprice);
      this.designForm.get('diamond').setValue(this.predefinedratedetails.diamondprice);
      this.designForm.get('margin').setValue(this.predefinedratedetails.goldexplain.marginvalue);
      this.designForm.get('subtotal').setValue(this.predefinedratedetails.price);
      this.designForm.get('taxvalue').setValue((this.predefinedratedetails.price / 100) * 3);
      this.designForm.get('totalprice').setValue(Math.round(this.predefinedratedetails.price + (this.predefinedratedetails.price / 100) * 3));

      var total = this.predefinedratedetails.price + (this.predefinedratedetails.price / 100) * 3;
      this.finalvalue = Math.round(total);

    }, error => this.disablecalculationsection = false)
  }

  getDimondcolor(colorid: any, purityid: any) {
    var a: any = this.DiamodColorcombo.filter(f => f.colorid == colorid && f.purityid == purityid)[0];
    return a.colorname + " - " + a.purityname;
  }

  Changecolorpurity() {

    var checkcolorcombo = setInterval(() => {
      if (this.designForm.get('diamondcolorpuritycombo').value != '') {
        clearInterval(checkcolorcombo)
        this.diamondComboination.forEach(element => {
          if (element.comboid == this.designForm.get('diamondcolorpuritycombo').value) {
            this.diamondcolorcombinationName = element.colorname + "/" + element.purityname
          }
        });
      }
    }, 0);
    return this.diamondcolorcombinationName;
  }

  somefilterChange() {
    if (this.goldcolour.value == 0 && this.gemstonecolor.value == 0 && this.studdedtype.value == 0) {

      this.alltypeofchains_filters = this.alltypeofchains;
      this.addon_images_filters = this.addon_images;
      this.charm_images_filters = this.charm_images;
      this.charm_images_filters_SupportArray = this.charm_images;
      this.addon_images_filters_SupportArray = this.addon_images;

      var loosebracelet004 = setInterval(() => {
        if (this.charm_images_filters_SupportArray) {
          this.charm_images_filters_SupportArray = this.charm_images_filters_SupportArray.filter(f => f.img_view_type == 'other' && f.charm_position == this.looseBracelettype)
          clearInterval(loosebracelet004);
        }
      }, 0)
      var loosebraceletAddon004 = setInterval(() => {
        if (this.addon_images_filters_SupportArray) {
          this.addon_images_filters_SupportArray = this.addon_images_filters_SupportArray.filter(f => f.img_view_type == 'Other')
          clearInterval(loosebraceletAddon004);
        }
      }, 0)

    } else {
      this.alltypeofchains_filters = [];
      this.addon_images_filters = [];
      this.charm_images_filters = [];
      this.charm_images_filters_SupportArray = [];
      this.addon_images_filters_SupportArray = [];
      this.Filtersongold(this.goldcolour.value ? this.goldcolour.value : 0)
      this.Filtersonstudded(this.studdedtype.value ? this.studdedtype.value : 0)
      this.Filtersongemcolor(this.gemstonecolor.value ? this.gemstonecolor.value : 0)
    }
  }

  Filtersongold(data: any[]) {
    if (data.length > 0) {
      data.forEach(element => {
        var a = this.alltypeofchains.filter(chn => Number(chn.goldcolorid) == Number(element));
        a.forEach(element2 => {
          this.alltypeofchains_filters.push(element2);
        });
      });
    } else {
      this.alltypeofchains_filters = this.alltypeofchains;
    }

    // For Charm Filters
    if (data.length > 0) {
      data.forEach(element => {
        var a = this.charm_images.filter(chn => Number(chn.goldcolorid) === Number(element));
        a.forEach(element2 => {
          this.charm_images_filters.push(element2);
          this.charm_images_filters_SupportArray.push(element2);
        });
      });
    } else {
      this.charm_images_filters = this.charm_images;
      this.charm_images_filters_SupportArray = this.charm_images;
    }
    var loosebracelet001 = setInterval(() => {
      if (this.charm_images_filters_SupportArray) {
        this.charm_images_filters_SupportArray = this.charm_images_filters_SupportArray.filter(f => f.img_view_type == 'other' && f.charm_position == this.looseBracelettype)
        clearInterval(loosebracelet001);
      }
    }, 0)



    // For Addon Filters
    if (data.length > 0) {
      data.forEach(element => {
        var a = this.addon_images.filter(chn => Number(chn.goldcolorid) === Number(element));
        a.forEach(element2 => {
          this.addon_images_filters.push(element2);
          this.addon_images_filters_SupportArray.push(element2);
        });
      });
    } else {
      this.addon_images_filters = this.addon_images;
      this.addon_images_filters_SupportArray = this.addon_images;
    }
    var loosebraceletAddon = setInterval(() => {
      if (this.addon_images_filters_SupportArray) {
        this.addon_images_filters_SupportArray = this.addon_images_filters_SupportArray.filter(f => f.img_view_type == 'Other')
        clearInterval(loosebraceletAddon);
      }
    }, 0)

  }

  Filtersonstudded(data: any[]) {
    // alltypeofchains
    if (data.length > 0) {
      var backupChaintypes: any[] = this.alltypeofchains_filters;
      this.alltypeofchains_filters = [];
      data.forEach(element => {
        var a = backupChaintypes.filter(chn => Number(chn.linktype) == Number(element));
        a.forEach(element2 => {
          this.alltypeofchains_filters.push(element2);
        });
      });
    }

    //addon_images
    if (data.length > 0) {
      var backupAddon: any[] = this.addon_images_filters;
      this.addon_images_filters = [];
      this.addon_images_filters_SupportArray = [];
      data.forEach(element => {
        var a = backupAddon.filter(adn => adn.addontype == element);
        a.forEach(element3 => {
          this.addon_images_filters.push(element3);
          this.addon_images_filters_SupportArray.push(element3);
        });
      });
    }
    var loosebraceletAddon002 = setInterval(() => {
      if (this.addon_images_filters_SupportArray) {
        this.addon_images_filters_SupportArray = this.addon_images_filters_SupportArray.filter(f => f.img_view_type == 'Other')
        clearInterval(loosebraceletAddon002);
      }
    }, 0)

    // charm_images
    if (data.length > 0) {
      var backupCharm: any[] = this.charm_images_filters;
      this.charm_images_filters = [];
      this.charm_images_filters_SupportArray = [];
      data.forEach(element => {
        var a = backupCharm.filter(chm => chm.studdedtype == element);
        a.forEach(element3 => {
          this.charm_images_filters.push(element3);
          this.charm_images_filters_SupportArray.push(element3)
        });
      });
    }
    var loosebracelet002 = setInterval(() => {
      if (this.charm_images_filters_SupportArray) {
        this.charm_images_filters_SupportArray = this.charm_images_filters_SupportArray.filter(f => f.img_view_type == 'other' && f.charm_position == this.looseBracelettype)
        clearInterval(loosebracelet002);
      }
    }, 0)
  }

  Filtersongemcolor(data) {
    // addon_images
    if (data.length > 0) {
      var backupAddon: any[] = this.addon_images_filters;
      this.addon_images_filters = [];
      this.addon_images_filters_SupportArray = [];
      data.forEach(element => {
        var a = backupAddon.filter(adn => adn.color_id == element);
        a.forEach(element3 => {
          this.addon_images_filters.push(element3);
          this.addon_images_filters_SupportArray.push(element3);
        });
      });
    }
    var loosebraceletAddon003 = setInterval(() => {
      if (this.addon_images_filters_SupportArray) {
        this.addon_images_filters_SupportArray = this.addon_images_filters_SupportArray.filter(f => f.img_view_type == 'Other')
        clearInterval(loosebraceletAddon003);
      }
    }, 0)


    if (data.length > 0) {
      // charm_images
      var backupCharm: any[] = this.charm_images_filters;
      this.charm_images_filters = [];
      this.charm_images_filters_SupportArray = []
      data.forEach(element => {
        var a = backupCharm.filter(chm => chm.globalcolorpre == element);
        a.forEach(element3 => {
          this.charm_images_filters.push(element3);
          this.charm_images_filters_SupportArray.push(element3)
        });
      });
    }
    var loosebracelet003 = setInterval(() => {
      if (this.charm_images_filters_SupportArray) {
        this.charm_images_filters_SupportArray = this.charm_images_filters_SupportArray.filter(f => f.img_view_type == 'other' && f.charm_position == this.looseBracelettype)
        clearInterval(loosebracelet003);
      }
    }, 0)

  }

  Replace_chain(ob, chm, event) {

    // this.flatimagesPreview = this.ServerURL + '/images/' + chm.encodefilename;
    this.flatimagesPreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + chm.encodefilename;

    this.chainlist_filters.forEach(elm => {
      if (elm.section == chm.section) {
        if (elm.linkchainid == chm.linkchainid) {
          if (elm.goldcolorid == chm.goldcolorid) {
            if (elm.color_variationid == chm.color_variationid) {
              if (elm.type == 'model') {
                this.modelimagePreview = this.ServerURL + '/images/' + elm.encodefilename;
                // this.designForm.get('chainmodelImages_id').patchValue(elm.id);
              }
            }
          }
        }
      }
    });
  }

  async CheckingValidReplacement(cur_charm, index, event, tooltype) {
    var pre_charm;
    var validCharm: boolean = false;

    this.chain_flat_details.forEach(element => {
      if (Number(element.compontindex) == Number(index)) {
        pre_charm = element;
      }
    });
    console.log("flat Chain Relation ship details");
    console.log(this.flat_chain_charm_relarionDetails);
    var filter_relation = this.flat_chain_charm_relarionDetails.filter(e => {
      return ((e.parents_charm_row_id * 1) == (pre_charm.id * 1))
    })

    if (this.flat_chain_charm_relarionDetails.length > 0 && this.flat_chain_charm_relarionDetails.filter(f => f.tool_type == 'addon').length > 0) {
      await this.vendorCollectionService.addonlistreledtocharm(cur_charm.charm_id).then((data: any) => {
        filter_relation.forEach((element, index) => {
          var attachedaddon = this.chain_flat_details.filter(f => f.id == element.flattoolid)[0].tool_id;
          if (data.filter(f => f.id == attachedaddon).length > 0) {
            validCharm = true
          }
        });
      })
    } else {
      validCharm = true
    }
    return validCharm;
  }

  async Choosecharm(currenttools, $event) {

    if (this.numberofcharm == 1) {
      var Charmindex: any = this.chain_flat_details.filter(f => f.tooltype == 'charm')
      if (Charmindex.length > 0) {
        this.designForm.get('design_tools_charm').setValue(Charmindex[0].compontindex);

        await this.CheckingValidReplacement(currenttools, Charmindex[0].compontindex, $event, 'charm').then(data => {
          if (data) {
            if (currenttools.iscenterpiececharm == 'Y')
              this.ChangeCenterPieceCharm(currenttools);
            this.Replace_Tools(currenttools, Charmindex[0].compontindex, $event, 'charm');
          } else {
            alert("This Charm is not applicable to the attached Add-on & replacement will not happen.");
          }
        })

      } else {
        this.alertService.error('Charm Position Not Found', true)
      }
    } else {
      var index = this.designForm.get('design_tools_charm').value;
      await this.CheckingValidReplacement(currenttools, index, $event, 'charm').then(data => {
        if (data) {
          if (currenttools.iscenterpiececharm == 'Y')
            this.ChangeCenterPieceCharm(currenttools);
          this.Replace_Tools(currenttools, index, $event, 'charm');
        } else {
          alert("This Charm is not applicable to the attached Add-on & replacement will not happen.");
        }
      })

    }
  }

  chooseAddon(currenttools, $event) {

    if (this.numberofaddon == 1) {
      var Addonindex: any = this.chain_flat_details.filter(f => f.tooltype == 'addon')
      if (Addonindex.length > 0) {
        if (currenttools.isaddonwithchain == 'Y')
          this.ChangeAddonWithChain(currenttools);
        this.designForm.get('design_tools_addon').setValue(Addonindex[0].compontindex);
        this.Replace_Tools(currenttools, Addonindex[0].compontindex, $event, 'addon');
      } else {
        this.alertService.error('Addon Position Not Found', true)
      }
    } else {
      if (currenttools.isaddonwithchain == 'Y')
        this.ChangeAddonWithChain(currenttools);
      var index = this.designForm.get('design_tools_addon').value;
      this.Replace_Tools(currenttools, index, $event, 'addon')
    }
  }

  chooselock(currenttools, $event) {
    var lockindex: any = this.chain_flat_details.filter(f => f.tooltype == 'lock')
    if (lockindex.length > 0) {
      this.designForm.get('design_tools_lock').setValue(lockindex[0].compontindex);
      this.Replace_Tools(currenttools, lockindex[0].compontindex, $event, 'lock');
    } else {
      this.alertService.error('Lock Position Not Found', true)
    }
  }

  changelockwithchain(lockdetails: any) {
    console.log(lockdetails);
    var lockindex: any = this.chain_flat_details.filter(f => f.tooltype == 'lock')
    var its_from = 'lock';

    if (lockindex.length > 0) {
      this.designForm.get('design_tools_lock').setValue(lockindex[0].compontindex);
      var index = lockindex[0].compontindex;

      var chainlockfun = setInterval(() => {
        var fetchlock = 'chainlock_' + lockdetails.id;
        this.CreateDynamicHTMLElement(lockdetails.encodefilename, fetchlock, '213px', '178px');
        var fetchlockhtml = document.getElementById(fetchlock);
        if (fetchlockhtml) {
          var Rep11capa1_load = setInterval(() => {
            var cls = '#stubNumber_' + index;
            var cls2 = 'stubNumber_' + index;
            if (document.querySelector(cls)) {
              clearInterval(Rep11capa1_load)
              var parents_elm = document.getElementById(cls2);
              parents_elm.childNodes[2].remove()
              switch (its_from) {
                case 'lock':
                  fetchlockhtml.style.height = '80px';
                  fetchlockhtml.style.width = '80px';
                  break;
                case 'ring':
                  break;
              }
              var cln = fetchlockhtml.cloneNode();
              parents_elm.appendChild(cln);
            }
            // close Stub Details  
          }, 0);
          clearInterval(chainlockfun);
          //close stub model details
        }
      }, 0)

      var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
      ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(lockdetails.id);

    } else {
      this.alertService.error('Lock Position Not Found', true)
    }
  }

  choosering(currenttools, $event) {
    var ringindex: any = this.chain_flat_details.filter(f => f.tooltype == 'ring')
    if (ringindex.length > 0) {
      this.designForm.get('design_tools_ring').setValue(ringindex[0].compontindex);
      this.Replace_Tools(currenttools, ringindex[0].compontindex, $event, 'ring');
    } else {
      this.alertService.error('Ring Position Not Found', true)
    }
  }

  changeRingwithchain(ringdetails: any) {
    var ringindex: any = this.chain_flat_details.filter(f => f.tooltype == 'ring')
    var its_from = 'ring';

    if (ringindex.length > 0) {
      this.designForm.get('design_tools_ring').setValue(ringindex[0].compontindex);
      var index = ringindex[0].compontindex;

      var Rep11capa1_load = setInterval(() => {
        var cls = '#stubNumber_' + index;
        var cls2 = 'stubNumber_' + index;

        var chainlockfun = setInterval(() => {
          var fetchlock = 'chainring_' + ringdetails.id;
          this.CreateDynamicHTMLElement(ringdetails.encodefilename, fetchlock, '213px', '178px');
          var fetchringhtml = document.getElementById(fetchlock);
          if (fetchringhtml) {
            clearInterval(chainlockfun);
            if (document.querySelector(cls)) {
              clearInterval(Rep11capa1_load)
              var parents_elm = document.getElementById(cls2);
              parents_elm.childNodes[2].remove()
              switch (its_from) {
                case 'lock':
                  break;
                case 'ring':
                  fetchringhtml.style.height = '100px';
                  fetchringhtml.style.width = '100px';
                  break;
              }
              var cln = fetchringhtml.cloneNode();
              parents_elm.appendChild(cln);
            }
          }
          //Close model clas
        }, 0);
        // close chain 
      }, 0)

      var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
      ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(ringdetails.id);

    } else {
      this.alertService.error('Lock Position Not Found', true)
    }
  }

  ChangeMainChain(goldcolorid) {

    var flattoollist: any[] = [];
    flattoollist = this.designForm.get("flat_chain_designAnnotation").value;
    flattoollist = flattoollist.filter(f => f.tooltype == 'charm')

    flattoollist.forEach(f => {
      var pre_charm;
      var cur_charm;
      var charmid = this.charm_images_filters_SupportArray.filter(d => d.id == f.tool_id)[0].charm_id;
      this.chain_flat_details.forEach(element => {
        if (Number(element.compontindex) == Number(f.compontIndex)) {
          pre_charm = element;
          cur_charm = this.charm_images_filters_SupportArray.filter(ch => ch.charm_id == charmid && ch.goldcolorid == goldcolorid && ch.img_view_type == 'flat');
        }
      });
      // console.log("Current Charm details:");
      // console.log(cur_charm);
      if (cur_charm[0].iscenterpiececharm == 'Y') {
        cur_charm = cur_charm.filter(c => c.chaindesignwt == this.globalreplacechaindesignwtid)[0]
        this.Charm_replacement_structure(pre_charm, cur_charm, Number(f.compontIndex), null, "charm");
        this.BuildReplacementStructure_Model(pre_charm, cur_charm, Number(f.compontIndex), null, "charm");
      }
    })

    // -------------------------Start logic For Addon--------------------
    var flattoollistforAddon: any[] = this.designForm.get("flat_chain_designAnnotation").value;
    flattoollistforAddon = flattoollistforAddon.filter(r => r.tooltype == 'addon')
    var pre_charm;
    var cur_charm;
    flattoollistforAddon.forEach(g => {
      var addonid = this.addon_images_filters_SupportArray.filter(d => d.id == g.tool_id)[0].addon_id;
      this.chain_flat_details.forEach(element => {
        if (Number(element.compontindex) == Number(g.compontIndex)) {
          pre_charm = element;
          cur_charm = this.addon_images_filters_SupportArray.filter(ch => ch.addon_id == addonid && ch.goldcolorid == goldcolorid && ch.img_view_type == 'flat')[0];
        }
      });
      if (cur_charm.isaddonwithchain == 'Y')
        this.Replace_Bracelte_tools(pre_charm, cur_charm, Number(g.compontIndex), null, "addon");
    });
    // -------------------------End logic For Addon--------------------
  }

  ChangeCenterPieceCharm(cur_charm) {
    var chainid;
    var typeofchain;
    var chainbasicdtl;
    switch (this.predefinedbracelettype) {
      case 'chain':
        var chainlist: any[] = this.alltypeofchains_filters.filter(f => f.chain_type_id == this.braceletchaintypeid && f.chaintype == 'plain')
        chainlist = chainlist.filter(s => s.chaindesignid == cur_charm.chaindesignwt && s.goldcolorid == cur_charm.goldcolorid);
        if (chainlist.length > 0) {
          chainid = chainlist[0].id;
          chainbasicdtl = chainlist[0];
          typeofchain = "plain";
        }
        break;
      case 'ball-pearl':
        var ballpearllist: any[] = this.alltypeofchains_filters.filter(f => f.chain_type_id == this.braceletchaintypeid && f.chaintype == 'ballpearl')
        ballpearllist = ballpearllist.filter(s => s.chaindesignid == cur_charm.chaindesignwt && s.goldcolorid == cur_charm.goldcolorid);
        if (ballpearllist.length > 0) {
          chainid = ballpearllist[0].id;
          chainbasicdtl = ballpearllist[0];
          typeofchain = "ballpearl";
        }
        break;
      case 'link':
        var linklist: any[] = this.alltypeofchains_filters.filter(f => f.chain_type_id == this.braceletchaintypeid && f.chaintype == 'link')
        linklist = linklist.filter(s => s.chaindesignid == cur_charm.chaindesignwt && s.goldcolorid == cur_charm.goldcolorid);
        if (linklist.length > 0) {
          chainid = linklist[0].id;
          chainbasicdtl = linklist[0];
          typeofchain = "link";
        }
        break;
    }
    if (this.predefinedbracelettype == 'chain') {
      if (chainbasicdtl) {
        this.BhuildStructure_chain_dynamic(chainid, typeofchain, chainbasicdtl);
      } else {
        alert("We don't get any respected chain design and gold color combinations");
      }
    }
  }

  ChangeAddonWithChain(cur_charm) {
    console.log('piece called me also');

    var chainid;
    var typeofchain;
    var chainbasicdtl;
    switch (this.predefinedbracelettype) {
      case 'chain':
        var chainlist: any[] = this.alltypeofchains_filters.filter(f => f.chain_type_id == this.braceletchaintypeid && f.chaintype == 'plain')
        chainlist = chainlist.filter(s => s.chaindesignid == cur_charm.chaindesignwt && s.goldcolorid == cur_charm.goldcolorid);
        if (chainlist.length > 0) {
          chainid = chainlist[0].id;
          chainbasicdtl = chainlist[0];
          typeofchain = "plain";
        }
        break;
      case 'ball-pearl':
        var ballpearllist: any[] = this.alltypeofchains_filters.filter(f => f.chain_type_id == this.braceletchaintypeid && f.chaintype == 'ballpearl')
        ballpearllist = ballpearllist.filter(s => s.chaindesignid == cur_charm.chaindesignwt && s.goldcolorid == cur_charm.goldcolorid);
        if (ballpearllist.length > 0) {
          chainid = ballpearllist[0].id;
          chainbasicdtl = ballpearllist[0];
          typeofchain = "ballpearl";
        }
        break;
      case 'link':
        var linklist: any[] = this.alltypeofchains_filters.filter(f => f.chain_type_id == this.braceletchaintypeid && f.chaintype == 'link')
        linklist = linklist.filter(s => s.chaindesignid == cur_charm.chaindesignwt && s.goldcolorid == cur_charm.goldcolorid);
        if (linklist.length > 0) {
          chainid = linklist[0].id;
          chainbasicdtl = linklist[0];
          typeofchain = "link";
        }
        break;
    }
    if (this.predefinedbracelettype == 'chain') {
      if (chainbasicdtl) {
        this.BhuildStructure_chain_dynamic(chainid, typeofchain, chainbasicdtl);
      } else {
        alert("We don't get any respected chain design and gold color combinations");
      }
    }
  }

  getflatimage(tooltype, charmdt) {

    switch (tooltype) {
      case 'charm':
        var filterscharm = this.charm_images.filter(f => f.charm_id == charmdt.charm_id && f.goldcolorid == charmdt.goldcolorid && f.img_view_type == 'flat');
        if (filterscharm.length > 0) {
          if (charmdt.iscenterpiececharm == 'Y')
            filterscharm = filterscharm.filter(c => c.chaindesignwt == this.globalreplacechaindesignwtid)

          var cls2 = 'flatcharm' + charmdt.id + '' + charmdt.charm_id + '' + charmdt.goldcolorid;
          this.CreateDynamicHTMLElement(filterscharm[0].img_path, cls2, charmdt.charmlength + 'px', charmdt.charmlength + 'px');
          return cls2;
        }
        break;
      case 'addon':
        var filtersAddon = this.addon_images.filter(f => f.addon_id == charmdt.addon_id && f.goldcolorid == charmdt.goldcolorid && f.img_view_type == 'flat');
        if (filtersAddon.length > 0) {
          if (charmdt.isaddonwithchain == 'Y')
            filtersAddon = filtersAddon.filter(c => c.chaindesignwt == this.globalreplacechaindesignwtid)

          var cls2 = 'flataddon' + charmdt.id + '' + charmdt.addon_id + '' + charmdt.goldcolorid;

          this.CreateDynamicHTMLElement(filtersAddon[0].img_path, cls2, '45px', '45px');
          return cls2;
        }
        break;
      case 'lock':
        var filterslock = this.lock_images.filter(f => f.lockid == charmdt.lockid && f.goldcolorid == charmdt.goldcolorid && f.type == 'flat');
        if (filterslock.length > 0) {
          var cls2 = 'flatlock' + charmdt.id + '' + charmdt.lockid + '' + charmdt.goldcolorid;

          this.CreateDynamicHTMLElement(filterslock[0].encodefilename, cls2, '80px', '80px');
          return cls2;
        }
        break;
      case 'ring':
        var filtersring = this.ring_images.filter(f => f.rngid == charmdt.rngid && f.goldcolorid == charmdt.goldcolorid && f.type == 'flat');
        if (filtersring.length > 0) {
          var cls2 = 'flatring' + charmdt.id + '' + charmdt.rngid + '' + charmdt.goldcolorid;

          this.CreateDynamicHTMLElement(filtersring[0].encodefilename, cls2, '100px', '100px');
          return cls2;
        }
        break;
    }
  }

  getgemstonecolorname(id) {
    if (Number(id))
      return this.colorpreferances.filter(f => f.id == id)[0].color_name
  }

  Replacementindex(replaceIndex: number, tooltype: string) {
    switch (tooltype) {
      case 'charm':
        this.designForm.get('design_tools_charm').setValue(replaceIndex);
        this.chain_flat_details.forEach(element => {
          var removecharm_selected = setInterval(() => {
            var cls = '#replacemetcharm_' + element.compontindex;
            var cls2 = 'replacemetcharm_' + element.compontindex;

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              parents_elm.style.border = "none";
              clearInterval(removecharm_selected)
            }
          }, 0)
        });

        var rpcharm_selected = setInterval(() => {
          var cls = '#replacemetcharm_' + replaceIndex;
          var cls2 = 'replacemetcharm_' + replaceIndex;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "3px solid #DBA632";
            console.log(this.designForm.value)
            clearInterval(rpcharm_selected)
          }
        }, 0)
        break;
      case 'addon':

        this.designForm.get('design_tools_addon').setValue(replaceIndex);
        this.chain_flat_details.forEach(element => {
          var removeAddon_selected = setInterval(() => {
            var cls = '#replacemetaddon_' + element.compontindex;
            var cls2 = 'replacemetaddon_' + element.compontindex;

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              parents_elm.style.border = "none";
              clearInterval(removeAddon_selected)
            }
          }, 0)
        });

        var rpAddon_selected = setInterval(() => {
          var cls0 = '#replacemetaddon_' + replaceIndex;
          var cls02 = 'replacemetaddon_' + replaceIndex;

          if (document.querySelector(cls0)) {
            var parents_elm = document.getElementById(cls02);
            parents_elm.style.border = "3px solid #DBA632";
            clearInterval(rpAddon_selected)
          }
        }, 0)
        break;
      case 'lock':

        this.chain_flat_details.forEach(element => {
          var removeLock_selected = setInterval(() => {
            var cls = '#replacemetlock_' + element.compontindex;
            var cls2 = 'replacemetlock_' + element.compontindex;

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              parents_elm.style.border = "none";
              clearInterval(removeLock_selected)
            }
          }, 0)
        });

        this.designForm.get('design_tools_lock').setValue(replaceIndex);
        var rplock_selected = setInterval(() => {
          var cls = '#replacemetlock_' + replaceIndex;
          var cls2 = 'replacemetlock_' + replaceIndex;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "3px solid #DBA632";
            clearInterval(rplock_selected)
          }
        }, 0)
        break;
      case 'ring':
        this.chain_flat_details.forEach(element => {
          var removeRing_selected = setInterval(() => {
            var cls = '#replacemetring_' + element.compontindex;
            var cls2 = 'replacemetring_' + element.compontindex;

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              parents_elm.style.border = "none";
              clearInterval(removeRing_selected)
            }
          }, 0)
        });

        this.designForm.get('design_tools_ring').setValue(replaceIndex);
        var rpring_selected = setInterval(() => {
          var cls = '#replacemetring_' + replaceIndex;
          var cls2 = 'replacemetring_' + replaceIndex;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "3px solid #DBA632";
            clearInterval(rpring_selected)
          }
        }, 0)
        break;
    }

  }

  Viewchainorlink(id: number, chaintype: string) {
    const dialogRef = this.dialog.open(ViewclientchainrelatedimagesPopupComponent, {
      width: "45%",
      // height: "80%",
      data: { id: id, type: chaintype }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log("The dialog was closed");
    });
  }


  ViewcharmDetails(id, goldcolorid) {
    // this.ChaindesignannotationService.getcharmsratecalculation(id).subscribe(rate => {
    const dialogRef = this.dialog.open(ViewCustomeraddonRateInfoComponent, {
      width: "100%",
      // height: "80%",
      data: { id: id, gold: 0, goldkt: 0, diamond: 0, gemstone: 0, goldcolorid: goldcolorid, tooltype: 'charm', vendorid: this.vendor_id }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log("The dialog was closed");
    });

    // })
  }

  ViewAddonDetails(id, goldcolorid) {
    const dialogRef = this.dialog.open(ViewCustomeraddonRateInfoComponent, {
      width: "100%",
      // height: "80%",
      data: { id: id, tooltype: 'addon', goldcolorid: goldcolorid, vendorid: this.vendor_id }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log("The dialog was closed");
    });
  }

  setFLatDetails(Product_details, up): FormArray {
    const formArray = new FormArray([]);
    Product_details.forEach((s, index) => {
      formArray.push(this.formBuilder.group({
        id: [s.id, Validators.required],
        chaindesign_id: [s.chaindesign_id, Validators.required],
        compontIndex: [s.compontindex],
        flatIndex: [s.flat_index, Validators.required],
        IDNumber: [s.id, Validators.required],
        addFrom: [s.addfrom, Validators.required],
        tooltype: [s.tooltype, Validators.required],
        tool_id: [s.tool_id, Validators.required],
        offsetX: [s.offsetX, Validators.required],
        offsetY: [s.offsetY, Validators.required],
        img_path: [s.img_path, Validators.required],
        isdelete: [s.isdelete, Validators.required]
      }));
      // this.UpdateCode_Component_flat(s);
      if (s.isdelete === 'N') {
        this.Stub.push(
          { 'id': index, 'flatIndex': s.flat_index, 'addFrom': s.addfrom, 'compontIndex': s.compontindex, 'tooltype': s.tooltype, 'tool_id': s.tool_id, 'offsetX': s.offsetX, 'offsetY': s.offsetY, 'img_path': s.img_path, 'IDNumber': s.id, 'chaindesign_id': s.chaindesign_id, 'charmlength': s.charmlength ? s.charmlength : 65, 'asymetricvalue': s.charmassymetricvalue ? s.charmassymetricvalue : 0 }
          // { 'id': index, 'flatIndex': s.flat_index, 'addFrom': s.addfrom, 'compontIndex': s.compontindex, 'tooltype': s.tooltype, 'tool_id': s.tool_id, 'offsetX': s.offsetX, 'offsetY': s.offsetY, 'img_path': s.img_path, 'IDNumber': s.id, 'chaindesign_id': s.chaindesign_id, 'charmlength': s.charmlength ? s.charmlength : 65, 'asymetricvalue': 0 }
        );
      }

      // this.NumberOfStub
      var capa1_load_set = setInterval(() => {
        var cls = '#stubNumber_' + index;
        var cls2 = 'stubNumber_' + index;

        var x = s.offsetX;
        var y = s.offsetY;

        if (document.querySelector(cls)) {

          var parents_elm = document.getElementById(cls2);
          parents_elm.style.position = "absolute";
          parents_elm.style.left = x + 'px';
          parents_elm.style.top = y + 'px';
          if (s.tooltype === 'addon') { parents_elm.style.height = 45 + 'px'; }

          const addonid = "images_of_tools_flat_" + s.tooltype + '_' + s.tool_id + "_" + index;
          var itm = document.getElementById(addonid);
          itm.style.height = s.charmlength + 'px';
          itm.style.width = s.charmlength + 'px';
          var cln = itm.cloneNode(true);
          parents_elm.appendChild(cln);
          this.NumberOfStub++;
          itm.style.height = 65 + 'px';
          itm.style.width = 65 + 'px';
          clearInterval(capa1_load_set)
        }
      }, 0);
    });
    this.DefaultSeletedTools(1, 'braceletwidth');
    return formArray;
  }

  setModelDetails(Product_details, up): FormArray {
    const formArray = new FormArray([]);
    Product_details.forEach((s, index) => {
      formArray.push(this.formBuilder.group({
        id: [s.id, Validators.required],
        chaindesign_id: [s.chaindesign_id, Validators.required],
        compontIndex: [s.compontindex],
        IDNumber: [s.id, Validators.required],
        addFrom: [s.addfrom, Validators.required],
        tooltype: [s.tooltype, Validators.required],
        tool_id: [s.tool_id, Validators.required],
        toolsLink: [s.tools_link],
        tools_position: [s.tools_position, Validators.required],
        offsetX: [s.offsetX, Validators.required],
        offsetY: [s.offsetY, Validators.required],
        img_path: [s.img_path, Validators.required],
        isdelete: [s.isdelete, Validators.required]
      }));

      if (s.isdelete === 'N') {
        this.Stub_model.push(
          { 'id': index, 'toolsLink': s.tools_link, 'Position': s.tools_position, 'addFrom': s.addfrom, 'compontIndex': s.compontindex, 'tooltype': s.tooltype, 'tool_id': s.tool_id, 'offsetX': s.offsetX, 'offsetY': s.offsetY, 'img_path': s.img_path, 'IDNumber': s.id, 'chaindesign_id': s.chaindesign_id, 'charmlength': s.charmlength ? s.charmlength : 65, 'asymetricvalue': s.charmassymetricvalue ? s.charmassymetricvalue : 0 }
          // { 'id': index, 'toolsLink': s.tools_link, 'Position': s.tools_position, 'addFrom': s.addfrom, 'compontIndex': s.compontindex, 'tooltype': s.tooltype, 'tool_id': s.tool_id, 'offsetX': s.offsetX, 'offsetY': s.offsetY, 'img_path': s.img_path, 'IDNumber': s.id, 'chaindesign_id': s.chaindesign_id, 'charmlength': s.charmlength ? s.charmlength : 65, 'asymetricvalue': 0 }
        );
      }
      var capa1_load = setInterval(() => {
        var cls = '#stubNumber_model_' + s.compontindex;
        var cls2 = 'stubNumber_model_' + s.compontindex;

        var x = s.offsetX;
        var y = s.offsetY;

        if (document.querySelector(cls)) {
          var parents_elm = document.getElementById(cls2);
          parents_elm.style.position = "absolute";
          parents_elm.style.left = x + 'px';
          parents_elm.style.top = y + 'px';
          if (s.tooltype === 'addon') { parents_elm.style.height = 45 + 'px'; }

          const addonid = "images_of_tools_model_" + s.tooltype + "_" + s.tool_id + "_" + index;
          var itm = document.getElementById(addonid);
          itm.style.height = s.charmlength + 'px';
          itm.style.width = s.charmlength + 'px';
          var cln = itm.cloneNode(true);
          parents_elm.appendChild(cln);
          this.NumberOfStub_model++;
          itm.style.height = 65 + 'px';
          itm.style.width = 65 + 'px';
          clearInterval(capa1_load)
        }
      }, 0);
    });
    return formArray;
  }

  Flat_ParentsCharmCoordinates(addonXCoordinates: number, addonYCoordinates: number, flatid) {
    var coordinates;
    var match_index = 0;
    this.flat_chain_charm_relarionDetails.forEach(element => {
      if ((Number(element.x_value) == Number(addonXCoordinates)) && (Number(element.y_value) == Number(addonYCoordinates))) {
        this.chain_flat_details.forEach(elm => {
          if (Number(elm.id) == Number(element.parents_charm_row_id)) {

            var filterRelation = this.flat_chain_charm_relarionDetails.filter(f => {
              return f.parents_charm == elm.tool_id
            })

            filterRelation.forEach((e2, index) => {
              if (e2.flattoolid == Number(flatid)) {
                match_index = index;
              }
            });
            coordinates = { 'X': elm.offsetX, 'Y': elm.offsetY, 'index': match_index };
          }
        });
      }
    });
    return coordinates;
  }

  Model_ParentsCharmCoordinates(addonXCoordinates: number, addonYCoordinates: number, flatid) {
    var coordinates;
    var match_index = 0;
    this.model_chain_charm_relationDetails.forEach(element => {
      if ((Number(element.x_value) == Number(addonXCoordinates)) && (Number(element.y_value) == Number(addonYCoordinates))) {
        this.chain_model_details.forEach(elm => {
          if (Number(elm.id) == Number(element.parents_charm_row_id)) {
            console.log('in model');
            var filterRelation = this.model_chain_charm_relationDetails.filter(f => {
              return f.parents_charm == elm.tool_id
            })

            filterRelation.forEach((e2, index) => {
              if (Number(e2.modeltool_id) == Number(flatid)) {
                match_index = index;
              }
            });
            coordinates = { 'X': elm.offsetX, 'Y': elm.offsetY, 'index': match_index };
          }
        });
      }
    });
    return coordinates;
  }

  public test_map_flat: any[] = [];
  public test_map_model: any[] = [];
  public vendorlogo;

  public selectedreplcementtool = 'chain';
  async ngOnInit() {
    await this.vendorservice.getvendorlogo(this.route.snapshot.params.vendorid).then((data: any) => {
      // this.vendorlogo = data.dynamicfilename;
      if (data.dynamicfilename) {
        this.vendorlogo = data.dynamicfilename;
      } else {
        this.vendorlogo = 'logo.png';
      }
    })

    this.test_map_flat = [
      { id: 0, name: 'Tab1', status: false }
    ];

    this.test_map_model = [
      { id: 0, name: 'Tab1', status: true }
    ];

    setInterval(() => {
      this.FireActivity();
    }, 50000)
  }


  customisationToolsChange(type) {
    this.Removeeletedtools("chaincls");
    this.Removeeletedtools("charmcls");
    this.Removeeletedtools("addoncls");
    this.Removeeletedtools("lockcls");
    this.Removeeletedtools("sizeenhancercls");
    switch (type) {
      case 'chain':
        this.selectedreplcementtool = 'chain';
        this.Makeseletedtools('chaincls');
        break;
      case 'charm':
        this.selectedreplcementtool = 'charm';
        this.Makeseletedtools('charmcls');
        this.HTMLcharmelemet = true;
        break;
      case 'addon':
        this.selectedreplcementtool = 'addon';
        this.Makeseletedtools('addoncls');
        this.HTMLaddonelemet = true;
        break;
      case 'lock':
        this.selectedreplcementtool = 'lock';
        this.Makeseletedtools('lockcls');
        this.HTMLlockelemet = true;
        break;
      case 'ring':
        this.selectedreplcementtool = 'ring';
        this.Makeseletedtools('sizeenhancercls');
        this.HTMLringelemet = true;
        break;
    }
  }
  globalreplacechaindesignwtid = 0;
  chooseChain(chain, typeofchain, ob: any) {
    this.globalreplacechaindesignwtid = ob.chaindesignid;
    this.BhuildStructure_chain_dynamic(chain, typeofchain, ob);
    this.designForm.get('braceletchain_id').setValue(chain);
    this.designForm.get('braceletchaintype').setValue(typeofchain);
  }

  chooseChainWidth(id) {
    this.RemoveSeletedTools(this.designForm.get('braceletwidth_id').value, 'braceletwidth');
    this.designForm.get('braceletwidth_id').setValue(id);
    this.SaveActivity("Changed Bracelet Width");
    this.CustomizationCalculation()
    this.DefaultSeletedTools(id, 'braceletwidth');
  }

  async BhuildStructure_chain_dynamic(id, typeofchain, chainbasicDtls) {

    console.log("We have change Chain");
    console.log(chainbasicDtls);

    var flatcontaintdetails: any[] = this.designForm.get('flat_chain_designAnnotation').value;
    var listoflock = flatcontaintdetails.filter(f => f.tooltype == 'lock');
    var listofring = flatcontaintdetails.filter(f => f.tooltype == 'ring');
    var bothtoolavailable: boolean = false;

    var lockdetails: any[] = [];
    var ringdetails: any[] = [];

    if (listoflock[0])
      this.ChaindesignannotationService.checkLockGoldwise(listoflock[0].tool_id, chainbasicDtls.goldcolorid).subscribe((data: any) => {
        if (data[0]) {
          bothtoolavailable = true;
          lockdetails = data;
          this.changelockwithchain(lockdetails[0]);
        } else {
          bothtoolavailable = false;
          this.alertService.error('Lock Not Found', true)
        }
      })

    if (listofring[0])
      this.ChaindesignannotationService.checkRingGoldwise(listofring[0].tool_id, chainbasicDtls.goldcolorid).subscribe((data: any) => {
        bothtoolavailable = true;
        ringdetails = data;
        if (ringdetails[0]) {
          this.changeRingwithchain(ringdetails[0]);
        } else {
          bothtoolavailable = false;
          this.alertService.error('Ring Not Found', true);
        }
      })

    this.ChaindesignannotationService.SelectedChain_RelatedModel(id, chainbasicDtls.goldcolorid, typeofchain).subscribe(chaindata => {
      this.chaingoldcolorid = chaindata[0].goldcolorid;
      if (this.chaingoldcolorid > 0)
        this.lock_images_filters = this.lock_images.filter(f => f.goldcolorid == this.chaingoldcolorid);

      if (this.chaingoldcolorid > 0)
        this.ring_images_filters = this.ring_images.filter(f => f.goldcolorid == this.chaingoldcolorid);

      // this.flatimagesPreview = this.ServerURL + '/images/' + chaindata[0].encodefilename;
      this.ChangeMainChain(chainbasicDtls.goldcolorid);
      this.flatimagesPreview = this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + chaindata[0].encodefilename;

      this.RemoveSeletedTools(this.designForm.get('chainflatImages_id').value, 'chain');
      this.designForm.get('chainflatImages_id').patchValue(chaindata[0].id);
      // this.designForm.get('braceletchain_id').setValue(chaindata[0].chaindesigwtid);
      this.DefaultSeletedTools(chaindata[0].id, 'chain');

      if (chaindata[1]) {
        this.modelimagePreview = this.ServerURL + '/images/' + chaindata[1].encodefilename;
        this.RemoveSeletedTools(this.designForm.get('chainmodelImages_id').value, 'chain');
        this.designForm.get('chainmodelImages_id').patchValue(chaindata[1].id);
        this.DefaultSeletedTools(chaindata[1].id, 'chain');
      } else {
        this.alertService.error('Sorry, On-Hand chain not found ')
      }
      this.SaveActivity("Replaced " + typeofchain + " chain");
      this.CustomizationCalculation();
    })
  }

  Makeseletedtools(id: string) {
    var productseleted = setInterval(() => {
      var cls = '#' + id;
      var cls2 = id;
      if (document.querySelector(cls)) {
        var parents_elm = document.getElementById(cls2);
        parents_elm.style.border = "2px solid #DBA632";
        clearInterval(productseleted)
      }
    }, 0)
  }

  Removeeletedtools(id: string) {
    var removeproduct = setInterval(() => {
      var cls = '#' + id;
      var cls2 = id;
      if (document.querySelector(cls)) {
        var parents_elm = document.getElementById(cls2);
        parents_elm.style.border = "2px solid #ccc";
        clearInterval(removeproduct)
      }
    }, 0)
  }

  ngAfterViewInit() {
    this.NavbarservicesService.isvisible.next(false);
    this.NavbarservicesService.isvisible_menu.next(true);
  }

  scrollToTop() {
    (function smoothscroll() {
      var currentScroll = document.documentElement.scrollTop || document.body.scrollTop;
      if (currentScroll > 0) {
        window.requestAnimationFrame(smoothscroll);
        window.scrollTo(0, currentScroll - (currentScroll / 8));
      }
    })();
  }

  getstuddedtype(id) {
    if (Number(id) > 0) {
      return this.studdedtypeList.filter(f => f.id == id)[0].name;
    }
  }

  clickFlat() {
    this.flat_on = true;
    this.test_map_model.forEach(e => {
      e.status = true;
    })
    this.test_map_flat.forEach(e => {
      e.status = true;
      if (e.id === 0) {
        e.status = false
      }
    })

    this.scrollToTop()

  }
  clickmodel() {
    console.log(window.screenTop)

    this.flat_on = false;
    this.test_map_flat.forEach(e => {
      e.status = true;
    })
    this.test_map_model.forEach(e => {
      e.status = true;
      if (e.id === 0) {
        e.status = false
      }
    })
    this.scrollToTop()
  }
  tabChanged(tabChangeEvent: MatTabChangeEvent): void {
    this.activetab = tabChangeEvent.index;
  }



  async Charm_replacement_structure(pre_charm, cur_charm, index, img, its_from) {

    var autogenerateCls = await this.getflatimage('charm', cur_charm);
    var autogencharmload = setInterval(() => {
      if (document.querySelector('#' + autogenerateCls)) {
        clearInterval(autogencharmload);
        img = document.getElementById(autogenerateCls).cloneNode(true);

        var position_type = cur_charm.charm_position;
        var x, y;
        var Xaxis = pre_charm.offsetX;
        var Yaxis = pre_charm.offsetY;
        var first_click_hanging = 1;

        //getting charm details 
        var stub_charmlength;
        this.Stub.forEach((s, idx) => {
          if (index == idx) {
            stub_charmlength = s.charmlength;
          }
        })
        // close getting stub details
        switch (position_type) {
          case 'attached':
            // Replace Parents Charm ------------------------------------------------------------------------------------
            var parent_charm_Ycoordinate = 0;
            var parent_charm_Xcoordinate = 0;
            switch (cur_charm.charm_type) {
              // ------------------------symmetric Charm-----------------------------
              case 'symmetric':
                console.log('ITS symmetric Block')
                // var attachhed_new_Yvalue = ((a.controls[(index * 1)] as FormArray).controls['offsetY'] as FormArray).value;
                var attachhed_new_Yvalue = 251;//264
                var attcdcapa1_load = setInterval(() => {
                  var cls = '#stubNumber_' + index;
                  var cls2 = 'stubNumber_' + index;

                  if (document.querySelector(cls)) {
                    clearInterval(attcdcapa1_load)
                    var parents_elm = document.getElementById(cls2);
                    parents_elm.childNodes[2].remove();

                    // img.target.style.height = cur_charm.charmlength + 'px';
                    // img.target.style.width = cur_charm.charmlength + 'px';
                    // var cln = img.target.cloneNode();
                    var cln = img;
                    parents_elm.appendChild(cln);
                    // img.target.style.height = '200px';
                    // img.target.style.width = '200px';

                    //set coordinates value according to length of charm
                    var precharmlength = stub_charmlength > 0 ? stub_charmlength : 0;
                    var cusrrentcharmlength = cur_charm.charmlength > 0 ? cur_charm.charmlength : 0;

                    console.log("Initial Value Of Top And Asymetric");
                    console.log(parseFloat(parents_elm.style.top) + " " + parseFloat(this.Stub[index].asymetricvalue))

                    parents_elm.style.top = (parseFloat(parents_elm.style.top) - parseFloat(this.Stub[index].asymetricvalue)) + 'px';
                    if (parseFloat(precharmlength) > parseFloat(cusrrentcharmlength)) {
                      var substraction = parseFloat(precharmlength) - parseFloat(cusrrentcharmlength);
                      var divide = substraction / 2;

                      parents_elm.style.top = (parseFloat(parents_elm.style.top) + divide) + 'px';
                      parents_elm.style.left = (parseFloat(parents_elm.style.left) + divide) + 'px';
                      parent_charm_Ycoordinate = parseFloat(parents_elm.style.top);
                    } else {
                      var substraction = parseFloat(cusrrentcharmlength) - parseFloat(precharmlength);
                      var divide = substraction / 2;

                      parents_elm.style.top = (parseFloat(parents_elm.style.top) - divide) + 'px';
                      parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                      parent_charm_Ycoordinate = parseFloat(parents_elm.style.top);
                    }
                    console.log("Final Value Of Top And Asymetric");
                    console.log(parseFloat(parents_elm.style.top) + " " + parseFloat(this.Stub[index].asymetricvalue))

                    this.Stub[index].charmlength = cusrrentcharmlength;
                    this.Stub[index].asymetricvalue = cur_charm.asymmetric_position_value ? cur_charm.asymmetric_position_value : 0

                    parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                  }
                }, 0);

                break;
              // ------------------------Asymmetric Charm-----------------------------
              case 'asymmetric':

                console.log('ITS Asymmetric Block')
                // var attachhed_new_Yvalue = ((a.controls[(index * 1)] as FormArray).controls['offsetY'] as FormArray).value;
                var attachhed_new_Yvalue = (Number(251) + Number(cur_charm.asymmetric_position_value));//264
                var attcdcapa1_load = setInterval(() => {
                  var cls = '#stubNumber_' + index;
                  var cls2 = 'stubNumber_' + index;

                  if (document.querySelector(cls)) {
                    clearInterval(attcdcapa1_load)
                    var parents_elm = document.getElementById(cls2);
                    parents_elm.childNodes[2].remove()

                    // img.target.style.height = cur_charm.charmlength + 'px';
                    // img.target.style.width = cur_charm.charmlength + 'px';
                    // var cln = img.target.cloneNode();
                    var cln = img;
                    parents_elm.appendChild(cln);
                    // img.target.style.height = '200px';
                    // img.target.style.width = '200px';

                    console.log("Initial Value Of Top And Asymetric");
                    console.log(parseFloat(parents_elm.style.top) + " " + parseFloat(this.Stub[index].asymetricvalue) + " " + Math.abs(parseFloat(this.Stub[index].asymetricvalue)))

                    //set coordinates value according to length of charm
                    // debugger;
                    var precharmlength = stub_charmlength > 0 ? stub_charmlength : 0;
                    var cusrrentcharmlength = cur_charm.charmlength > 0 ? cur_charm.charmlength : 0;

                    parents_elm.style.top = (parseFloat(parents_elm.style.top) - parseFloat(this.Stub[index].asymetricvalue)) + 'px';
                    if (parseFloat(precharmlength) > parseFloat(cusrrentcharmlength)) {
                      var substraction = parseFloat(precharmlength) - parseFloat(cusrrentcharmlength);
                      var divide = (substraction / 2);

                      parents_elm.style.top = ((parseFloat(parents_elm.style.top) + Number(cur_charm.asymmetric_position_value)) + divide) + 'px';
                      parents_elm.style.left = (parseFloat(parents_elm.style.left) + divide) + 'px';
                      parent_charm_Ycoordinate = parseFloat(parents_elm.style.top);
                    } else {

                      var substraction = parseFloat(cusrrentcharmlength) - parseFloat(precharmlength);
                      var divide = (substraction / 2);

                      parents_elm.style.top = ((parseFloat(parents_elm.style.top) + Number(cur_charm.asymmetric_position_value)) - divide) + 'px';
                      parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                      parent_charm_Ycoordinate = parseFloat(parents_elm.style.top);
                    }
                    this.Stub[index].charmlength = cusrrentcharmlength;
                    this.Stub[index].asymetricvalue = cur_charm.asymmetric_position_value ? cur_charm.asymmetric_position_value : 0

                    // parents_elm.style.top = attachhed_new_Yvalue + 'px';
                    parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                  }
                }, 0);
                // parent_charm_Ycoordinate = attachhed_new_Yvalue
                break;
              // ------------------------default Charm Type-----------------------------
              default:
                // var attachhed_new_Yvalue = ((a.controls[(index * 1)] as FormArray).controls['offsetY'] as FormArray).value;
                var attachhed_new_Yvalue = 251;//264
                var attcdcapa1_load = setInterval(() => {
                  var cls = '#stubNumber_' + index;
                  var cls2 = 'stubNumber_' + index;

                  if (document.querySelector(cls)) {
                    clearInterval(attcdcapa1_load)
                    var parents_elm = document.getElementById(cls2);
                    parents_elm.childNodes[2].remove()

                    // img.target.style.height = cur_charm.charmlength + 'px';
                    // img.target.style.width = cur_charm.charmlength + 'px';
                    // var cln = img.target.cloneNode();
                    var cln = img;
                    parents_elm.appendChild(cln);
                    // img.target.style.height = '200px';
                    // img.target.style.width = '200px';


                    //set coordinates value according to length of charm
                    var precharmlength = stub_charmlength > 0 ? stub_charmlength : 0;
                    var cusrrentcharmlength = cur_charm.charmlength > 0 ? cur_charm.charmlength : 0;

                    if (parseFloat(precharmlength) > parseFloat(cusrrentcharmlength)) {
                      var substraction = parseFloat(precharmlength) - parseFloat(cusrrentcharmlength);
                      var divide = (substraction / 2) + Number(cur_charm.asymmetric_position_value);

                      parents_elm.style.top = (parseFloat(parents_elm.style.top) + divide) + 'px';
                      parents_elm.style.left = (parseFloat(parents_elm.style.left) + divide) + 'px';
                      parent_charm_Ycoordinate = parseFloat(parents_elm.style.top);
                    } else {
                      var substraction = parseFloat(cusrrentcharmlength) - parseFloat(precharmlength);
                      var divide = (substraction / 2) + Number(cur_charm.asymmetric_position_value);

                      parents_elm.style.top = (parseFloat(parents_elm.style.top) - divide) + 'px';
                      parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                      parent_charm_Ycoordinate = parseFloat(parents_elm.style.top);
                    }
                    this.Stub[index].charmlength = cusrrentcharmlength;

                    // parents_elm.style.top = attachhed_new_Yvalue + 'px';
                    parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                  }
                }, 0);
                // parent_charm_Ycoordinate = attachhed_new_Yvalue;
                break;
            }
            console.log('Department design Form :');
            console.log(this.designForm.value);

            var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
            ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
            ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
            this.CustomizationCalculation()

            console.log('Checking Addon Valud For details');
            console.log(this.flat_chain_charm_relarionDetails);
            console.log(pre_charm);
            console.log(cur_charm);

            var Y_coordinate_value = 0;
            var filter_relation = this.flat_chain_charm_relarionDetails.filter(e => {
              return ((e.parents_charm * 1) == (pre_charm.tool_id * 1))
            })
            var filter_relation = this.flat_chain_charm_relarionDetails.filter(e => {
              return ((e.parents_charm_row_id * 1) == (pre_charm.id * 1))
            })

            var filter_relation = this.flat_chain_charm_relarionDetails.filter(e => {
              return ((e.parents_charm_row_id * 1) == (pre_charm.id * 1))
            })

            console.log('Flter relation value are');
            console.log(filter_relation);
            console.log(this.chain_flat_details);

            filter_relation.forEach((element, index) => {

              // var _id = 'stubNumber_' + element.index_no;
              var _id = 'stubNumber_' + this.chain_flat_details.filter(f => f.id == element.flattoolid)[0].compontindex;

              console.log('Selected Addon');
              console.log(_id);
              var attached_addon = document.getElementById(_id);

              var getXposition = setInterval(() => {
                if (parent_charm_Xcoordinate > 0) {
                  clearInterval(getXposition);

                  var central_pos = (parent_charm_Xcoordinate + (parseFloat(cur_charm.charmlength) - 43) / 2)
                  var yoffset = Number(cur_charm.charmsyoffset) ? Number(cur_charm.charmsyoffset) + 0 : 0;

                  var addontopcoordinates;
                  var ycoordinate = setInterval(() => {
                    if (parent_charm_Ycoordinate > 0) {
                      addontopcoordinates = parent_charm_Ycoordinate + ((parseFloat(cur_charm.charmlength) / 4) * 3)
                      var attched_lstpstn_top = ((addontopcoordinates - yoffset) * (index + 1));

                      console.log('Addon Attachedment Details')
                      console.log("charm coorfinates :" + parent_charm_Ycoordinate);
                      console.log("Yoffsetvalue :" + yoffset);
                      console.log("hang addon cood :" + addontopcoordinates);
                      console.log("final addon codd :" + attched_lstpstn_top)

                      attached_addon.style.top = attched_lstpstn_top + 'px';
                      attached_addon.style.left = central_pos + 'px';
                      clearInterval(ycoordinate);
                    }
                  })
                }
              })

              console.log('Department design Form 2:');
              console.log(this.designForm.value);
              // var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
              // ((a.controls[(element.index_no * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
              // ((a.controls[(element.index_no * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
              this.identify_number_attached++;
            });

            break;
          case 'hanging':
            this.FLAT_Hanging_value_times++;
            var parents_Y_coordinates = 0;
            var parent_charm_Xcoordinate = 0;
            // Replace Parents Charm ------------------------------------------------
            this.pre_click_charmId = cur_charm.charm_id
            var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;

            switch (cur_charm.charm_type) {
              case 'symmetric':
                var Rep11capa1_load = setInterval(() => {
                  var cls = '#stubNumber_' + index;
                  var cls2 = 'stubNumber_' + index;

                  if (document.querySelector(cls)) {
                    clearInterval(Rep11capa1_load)
                    var parents_elm = document.getElementById(cls2);
                    parents_elm.childNodes[2].remove()

                    // img.target.style.height = cur_charm.charmlength + 'px';
                    // img.target.style.width = cur_charm.charmlength + 'px';
                    // var cln = img.target.cloneNode();
                    var cln = img;
                    parents_elm.appendChild(cln);
                    // img.target.style.height = '200px';
                    // img.target.style.width = '200px';

                    //set coordinates value according to length of charm
                    var precharmlength = stub_charmlength > 0 ? stub_charmlength : 0;
                    var cusrrentcharmlength = cur_charm.charmlength > 0 ? cur_charm.charmlength : 0;

                    if (parseFloat(precharmlength) > parseFloat(cusrrentcharmlength)) {
                      var substraction = parseFloat(precharmlength) - parseFloat(cusrrentcharmlength);
                      console.log('Subscription Value :')
                      console.log(substraction);
                      console.log(parents_elm.style.left);

                      var divide = (substraction / 2);
                      console.log(divide)


                      parents_elm.style.top = 282 + 'px';
                      parents_elm.style.left = (parseFloat(parents_elm.style.left) + divide) + 'px';
                      parents_Y_coordinates = 282;
                    } else {
                      var substraction = parseFloat(cusrrentcharmlength) - parseFloat(precharmlength);
                      var divide = (substraction / 2);

                      parents_elm.style.top = 282 + 'px';
                      parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                      parents_Y_coordinates = 282;
                    }
                    this.Stub[index].charmlength = cusrrentcharmlength;

                    // parents_elm.style.top = Number(282) + 'px';//276
                    parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                  }
                }, 0);
                // parents_Y_coordinates = Number(282)//276

                var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
                ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
                ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
                break;
              case 'asymmetric':
                var Y_axis_symmetric_posi_value = (Number(282) + Number(cur_charm.asymmetric_position_value))//290 - 8
                var Rep11capa1_load = setInterval(() => {
                  var cls = '#stubNumber_' + index;
                  var cls2 = 'stubNumber_' + index;

                  if (document.querySelector(cls)) {
                    clearInterval(Rep11capa1_load)
                    var parents_elm = document.getElementById(cls2);
                    parents_elm.childNodes[2].remove()

                    // img.target.style.height = cur_charm.charmlength + 'px';
                    // img.target.style.width = cur_charm.charmlength + 'px';
                    // var cln = img.target.cloneNode();
                    var cln = img;
                    parents_elm.appendChild(cln);
                    // img.target.style.height = '200px';
                    // img.target.style.width = '200px';


                    //set coordinates value according to length of charm
                    var precharmlength = stub_charmlength > 0 ? stub_charmlength : 0;
                    var cusrrentcharmlength = cur_charm.charmlength > 0 ? cur_charm.charmlength : 0;

                    if (parseFloat(precharmlength) > parseFloat(cusrrentcharmlength)) {
                      var substraction = parseFloat(precharmlength) - parseFloat(cusrrentcharmlength);
                      var divide = (substraction / 2) + Number(cur_charm.asymmetric_position_value);

                      parents_elm.style.top = 282 + Number(cur_charm.asymmetric_position_value) + 'px';
                      // parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                      parents_Y_coordinates = 282 + Number(cur_charm.asymmetric_position_value);
                    } else {
                      var substraction = parseFloat(cusrrentcharmlength) - parseFloat(precharmlength);
                      var divide = (substraction / 2) + Number(cur_charm.asymmetric_position_value);

                      parents_elm.style.top = 282 + Number(cur_charm.asymmetric_position_value) + 'px';
                      // parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                      parents_Y_coordinates = 282 + Number(cur_charm.asymmetric_position_value);
                    }
                    this.Stub[index].charmlength = cusrrentcharmlength;

                    parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                  }
                }, 0);

                // parents_Y_coordinates = Number(Y_axis_symmetric_posi_value)

                var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
                ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
                ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
                break;
              default:
                var Rep11capa1_load = setInterval(() => {
                  var cls = '#stubNumber_' + index;
                  var cls2 = 'stubNumber_' + index;

                  if (document.querySelector(cls)) {
                    clearInterval(Rep11capa1_load)
                    var parents_elm = document.getElementById(cls2);
                    parents_elm.childNodes[2].remove()

                    // img.target.style.height = cur_charm.charmlength + 'px';
                    // img.target.style.width = cur_charm.charmlength + 'px';
                    // var cln = img.target.cloneNode();
                    var cln = img;
                    parents_elm.appendChild(cln);
                    // img.target.style.height = '200px';
                    // img.target.style.width = '200px';

                    //set coordinates value according to length of charm
                    var precharmlength = stub_charmlength > 0 ? stub_charmlength : 0;
                    var cusrrentcharmlength = cur_charm.charmlength > 0 ? cur_charm.charmlength : 0;

                    if (parseFloat(precharmlength) > parseFloat(cusrrentcharmlength)) {
                      var substraction = parseFloat(precharmlength) - parseFloat(cusrrentcharmlength);
                      var divide = (substraction / 2);

                      parents_elm.style.top = (parseFloat(parents_elm.style.top) + divide) + 'px';
                      parents_elm.style.left = (parseFloat(parents_elm.style.left) + divide) + 'px';
                      parents_Y_coordinates = parseFloat(parents_elm.style.top);
                    } else {
                      var substraction = parseFloat(cusrrentcharmlength) - parseFloat(precharmlength);
                      var divide = (substraction / 2);

                      parents_elm.style.top = (parseFloat(parents_elm.style.top) - divide) + 'px';
                      parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                      parents_Y_coordinates = parseFloat(parents_elm.style.top);
                    }
                    this.Stub[index].charmlength = cusrrentcharmlength;
                    //end set coordinates value according to length of charm
                    // parents_elm.style.top = Number(282) + 'px';//276
                    parent_charm_Xcoordinate = parseInt(parents_elm.style.left);

                    // parents_elm.style.top = Number(282) + 'px';//290 - 8
                    parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                  }
                }, 0);
                // parents_Y_coordinates = Number(282)//290 - 8
                var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
                ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
                ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
                break;
            }

            //replace its attached tools ------------------------------------------------------
            var filter_relation = this.flat_chain_charm_relarionDetails.filter(e => {
              return ((e.parents_charm * 1) == (pre_charm.tool_id * 1))
            })
            var filter_relation = this.flat_chain_charm_relarionDetails.filter(e => {
              return ((e.parents_charm_row_id * 1) == (pre_charm.id * 1))
            })

            var filter_relation = this.flat_chain_charm_relarionDetails.filter(e => {
              return ((e.parents_charm_row_id * 1) == (pre_charm.id * 1))
            })

            filter_relation.forEach((element, index) => {
              var _id = 'stubNumber_' + element.index_no
              var attached_addon = document.getElementById(_id);
              var currentObject = attached_addon.style.top;

              var getXposition_hng = setInterval(() => {
                if (parent_charm_Xcoordinate > 0) {
                  clearInterval(getXposition_hng);

                  var central_pos = (parent_charm_Xcoordinate + (parseFloat(cur_charm.charmlength) - 43) / 2)
                  var yoffset = Number(cur_charm.charmsyoffset) ? Number(cur_charm.charmsyoffset) + 3 : 3;

                  var hang_addontopcoordinates;
                  var hangycoordinate = setInterval(() => {
                    if (parents_Y_coordinates > 0) {
                      hang_addontopcoordinates = parents_Y_coordinates + ((parseFloat(cur_charm.charmlength) / 4) * 3)
                      var attched_lstpstn_top = ((hang_addontopcoordinates - yoffset) * (index + 1));

                      console.log('Addon Attachedment Details')
                      console.log("charm coorfinates :" + parents_Y_coordinates);
                      console.log("Yoffsetvalue :" + yoffset);
                      console.log("hang addon cood :" + hang_addontopcoordinates);
                      console.log("final addon codd :" + attched_lstpstn_top)

                      attached_addon.style.top = attched_lstpstn_top + 'px';
                      attached_addon.style.left = central_pos + 'px';
                      clearInterval(hangycoordinate);
                    }
                  })
                }
              })

              // var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
              // ((a.controls[(element.index_no * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
              // ((a.controls[(element.index_no * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
            });
            this.CustomizationCalculation()
            this.identify_number_hanging++;
            first_click_hanging++;
            break;
        }
      }
    }, 0);
  }

  Replace_Tools(cur_charm, index, img, its_from) {

    var pre_charm: any;
    if (index !== null && index !== "") {
      //start get index tools Details
      this.chain_flat_details.forEach(element => {
        if (Number(element.compontindex) == Number(index)) {
          pre_charm = element;
        }
      });
      //end get index tools Details
      switch (its_from) {
        case 'charm':
          this.Charm_replacement_structure(pre_charm, cur_charm, index, img, its_from);
          this.BuildReplacementStructure_Model(pre_charm, cur_charm, index, img, its_from);
          this.SaveActivity("Charm Replaced with " + cur_charm.name);
          break;
        case 'addon': case 'lock': case 'ring':
          this.Replace_Bracelte_tools(pre_charm, cur_charm, index, img, its_from);
          break;
      }
    } else {
      this.alertService.error('PLEASE CHOOSE ELEMENT TO REPLACE FROM DROPDOWN', true);
    }
  }

  SetModel_images_position(pre_charm, cur_charm, index, img, its_from, model_cur_yAxis, selectedcharmposition, modelimages_index) {
    var position_type = cur_charm.charm_position;
    var x, y;
    var Xaxis = pre_charm.offsetX;
    var Yaxis = model_cur_yAxis;
    var view_position = cur_charm.img_view_position;

    var ModelStubdetails;
    this.Stub_model.forEach((s, modlidx) => {
      if (index == modlidx) {
        ModelStubdetails = s.asymetricvalue;
      }
    })

    //getting charm details 
    var stub_charmlength;
    this.Stub_model.forEach((s, idx) => {
      if (index == idx) {
        stub_charmlength = s.charmlength;
      }
    })
    // close getting stub details

    switch (position_type) {
      case 'attached':
        // Replace Parents Charm ------------------------------------------------------------------------------------
        var attched_parent_coordinate = 0;
        var parent_charm_Xcoordinate = 0;

        switch (cur_charm.charm_type) {
          // ------------------------symmetric Charm-----------------------------
          case 'symmetric':
            switch (selectedcharmposition) {
              case 'central': var its_static_value = 404; break;
              case 'left': var its_static_value = 398; break;
              case 'right': var its_static_value = 402; break;
              default: var its_static_value = 404; break;
            }
            // var its_static_value = originaltopcoordinates;
            //347
            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            var attachhed_new_Yvalue = Yaxis;

            var cls = '#stubNumber_model_' + modelimages_index;//index
            var cls2 = 'stubNumber_model_' + modelimages_index;//index

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              var Current_object_coordinates = parseInt(parents_elm.style.top);

              //set coordinates value according to length of charm
              var precharmlength = stub_charmlength > 0 ? stub_charmlength : 0;
              var cusrrentcharmlength = cur_charm.charmlength > 0 ? cur_charm.charmlength : 0;

              parents_elm.style.top = (parseFloat(parents_elm.style.top) - ModelStubdetails) + 'px';

              if (parseFloat(precharmlength) > parseFloat(cusrrentcharmlength)) {
                var substraction = parseFloat(precharmlength) - parseFloat(cusrrentcharmlength);
                var divide = (substraction / 2);

                console.log('divid value is :' + divide)

                parents_elm.style.top = (parseFloat(parents_elm.style.top) + divide) + 'px';
                parents_elm.style.left = (parseFloat(parents_elm.style.left) + divide) + 'px';
                attched_parent_coordinate = parseFloat(parents_elm.style.top);
              }
              else {
                var substraction = parseFloat(cusrrentcharmlength) - parseFloat(precharmlength);
                var divide = (substraction / 2);

                console.log('Precarm details here:');
                console.log(substraction + " and " + divide);

                console.log(parents_elm.style.top);
                console.log('divi: ' + divide)

                parents_elm.style.top = (parseFloat(parents_elm.style.top) - divide) + 'px';
                parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                attched_parent_coordinate = parseFloat(parents_elm.style.top);

                console.log('the final value of details is :' + attched_parent_coordinate)
              }
              this.Stub_model[index].charmlength = cusrrentcharmlength;
              this.Stub_model[index].asymetricvalue = cur_charm.asymmetric_position_value ? cur_charm.asymmetric_position_value : 0

              // parents_elm.style.top = Number(its_static_value) + 'px';
              parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
              // attched_parent_coordinate = Number(its_static_value);
            }

            break;
          // ------------------------Asymmetric Charm-----------------------------
          case 'asymmetric':
            // console.log('Okay  Its asymmetric Value')
            // console.log('Position is :' + selectedcharmposition);
            // console.log('asymentrical vlaue is :' + cur_charm.asymmetric_position_value);

            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            switch (selectedcharmposition) {
              case 'central': var its_static_value_asy = (Number(405) + Number(cur_charm.asymmetric_position_value)); break;
              case 'left': var its_static_value_asy = (Number(398) + Number(cur_charm.asymmetric_position_value)); break;
              case 'right': var its_static_value_asy = (Number(402) + Number(cur_charm.asymmetric_position_value)); break;
              default: var its_static_value_asy = (Number(404) + Number(cur_charm.asymmetric_position_value)); break;
            }
            // console.log(its_static_value_asy);
            // var its_static_value_asy = originaltopcoordinates;
            var cls = '#stubNumber_model_' + modelimages_index;//index
            var cls2 = 'stubNumber_model_' + modelimages_index;//index

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              var current_Object_coordinates = parseInt(parents_elm.style.top);

              //set coordinates value according to length of charm
              var precharmlength = stub_charmlength > 0 ? stub_charmlength : 0;
              var cusrrentcharmlength = cur_charm.charmlength > 0 ? cur_charm.charmlength : 0;

              console.log("The Managing of Good");
              console.log(parseFloat(parents_elm.style.top) + " " + parseFloat(this.Stub_model[index].asymetricvalue));

              parents_elm.style.top = (parseFloat(parents_elm.style.top) - parseFloat(this.Stub_model[index].asymetricvalue)) + 'px';
              if (parseFloat(precharmlength) > parseFloat(cusrrentcharmlength)) {
                var substraction = parseFloat(precharmlength) - parseFloat(cusrrentcharmlength);
                var divide = (substraction / 2);

                console.log('the Charm value symetric section :' + cur_charm.asymmetric_position_value);
                console.log('divid value ' + divide);
                console.log(parents_elm.style.top)

                parents_elm.style.top = ((parseFloat(parents_elm.style.top) + Number(cur_charm.asymmetric_position_value)) + divide) + 'px';
                parents_elm.style.left = (parseFloat(parents_elm.style.left) + divide) + 'px';
                attched_parent_coordinate = parseFloat(parents_elm.style.top);
              } else {
                var substraction = parseFloat(cusrrentcharmlength) - parseFloat(precharmlength);
                var divide = (substraction / 2);

                parents_elm.style.top = ((parseFloat(parents_elm.style.top) + Number(cur_charm.asymmetric_position_value)) - divide) + 'px';
                parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                attched_parent_coordinate = parseFloat(parents_elm.style.top);
              }
              this.Stub_model[index].charmlength = cusrrentcharmlength;
              this.Stub_model[index].asymetricvalue = cur_charm.asymmetric_position_value ? cur_charm.asymmetric_position_value : 0

              parent_charm_Xcoordinate = parseInt(parents_elm.style.left);

              console.log("The Managing of Good After");
              console.log(parseFloat(parents_elm.style.top) + " " + parseFloat(this.Stub_model[index].asymetricvalue));
              // parents_elm.style.top = Number(its_static_value_asy) + 'px';
              // attched_parent_coordinate = Number(its_static_value_asy);
            }
            break;
          // ------------------------default Charm Type-----------------------------
          default:
            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            attachhed_new_Yvalue = Yaxis;
            var its_static_value_def = 404;//347
            // var its_static_value_def = originaltopcoordinates;

            var cls = '#stubNumber_model_' + modelimages_index;//index
            var cls2 = 'stubNumber_model_' + modelimages_index;//index

            if (document.querySelector(cls)) {
              var parents_elm = document.getElementById(cls2);
              //set coordinates value according to length of charm
              var precharmlength = stub_charmlength > 0 ? stub_charmlength : 0;
              var cusrrentcharmlength = cur_charm.charmlength > 0 ? cur_charm.charmlength : 0;

              if (parseFloat(precharmlength) > parseFloat(cusrrentcharmlength)) {
                var substraction = parseFloat(precharmlength) - parseFloat(cusrrentcharmlength);
                var divide = (substraction / 2);

                parents_elm.style.top = (parseFloat(parents_elm.style.top) + divide) + 'px';
                parents_elm.style.left = (parseFloat(parents_elm.style.left) + divide) + 'px';
                attched_parent_coordinate = parseFloat(parents_elm.style.top);
              } else {
                var substraction = parseFloat(cusrrentcharmlength) - parseFloat(precharmlength);
                var divide = (substraction / 2);

                parents_elm.style.top = (parseFloat(parents_elm.style.top) - divide) + 'px';
                parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                attched_parent_coordinate = parseFloat(parents_elm.style.top);
              }
              this.Stub_model[index].charmlength = cusrrentcharmlength;

              parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
              // parents_elm.style.top = (Number(its_static_value_def)) + 'px';
              // attched_parent_coordinate = its_static_value_def;
            }
            break;
        }
        ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
        ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);

        var Y_coordinate_value = 0;
        var model_current_charm_id = 0;
        var model_current_parent_id = 0;
        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          this.chain_model_details.forEach(e2 => {
            if (e2.tools_link === pre_charm.flat_index) {
              model_current_charm_id = e2.tool_id;
              model_current_parent_id = e2.id;
            }
          });
          return ((e.chaindesign_id * 1) == (pre_charm.chaindesign_id * 1))
        })

        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          return ((e.parents_charm * 1) == (model_current_charm_id * 1))
        })
        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          return ((e.parents_charm_row_id * 1) == (model_current_parent_id * 1))
        })
        console.log("In Pre Defined Addon Catup");
        console.log(this.model_chain_charm_relationDetails);
        console.log(pre_charm);
        console.log(model_current_parent_id)

        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          return ((e.parents_charm_row_id * 1) == (model_current_parent_id * 1))
        })
        console.log(filter_relation);

        filter_relation.forEach((element, index) => {

          // var _id = 'stubNumber_model_' + element.index_no
          var _id = 'stubNumber_model_' + this.chain_model_details.filter(f => f.id == element.modeltool_id)[0].compontindex;


          var attached_addon = document.getElementById(_id);
          console.log('console readction');
          console.log(_id);

          var getXposition_mdlatt = setInterval(() => {
            if (parent_charm_Xcoordinate > 0) {
              clearInterval(getXposition_mdlatt);

              var yoffset = Number(cur_charm.charmsyoffset) ? Number(cur_charm.charmsyoffset) + 3 : 3;

              var _addontopcoordinates;
              var modlycoordinate = setInterval(() => {
                if (attched_parent_coordinate > 0) {

                  _addontopcoordinates = attched_parent_coordinate + ((parseFloat(cur_charm.charmlength) / 4) * 3)
                  var attched_lstpstn_top = ((_addontopcoordinates - yoffset) * (index + 1));
                  var central_pos = (parent_charm_Xcoordinate + (parseFloat(cur_charm.charmlength) - 43) / 2)

                  var addon21 = document.getElementById(_id);
                  addon21.style.top = attched_lstpstn_top + 'px';
                  addon21.style.left = central_pos + 'px';

                  clearInterval(modlycoordinate);
                }
              })
              // var _addontopcoordinates = Number(attched_parent_coordinate) + 65
              // var nodel_attched_lstpstn_top = (_addontopcoordinates - yoffset) * (index + 1);
            }
          })

          // var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
          // ((a.controls[(element.index_no * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
          // ((a.controls[(element.index_no * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);

          this.identify_number_attached++;
        });
        break;
      case 'hanging':
        // Replace Parents Charm ------------------------------------------------
        var hanging_parents_coordinates = 0;
        var Y_coordinate_value_hanging = 0;
        this.pre_click_charmId = cur_charm.charm_id
        var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
        var parent_charm_Xcoordinate = 0;
        Yaxis = Yaxis - 13;
        this.MODEL_Hanging_value_times++;

        switch (cur_charm.charm_type) {
          case 'symmetric':
            switch (selectedcharmposition) {
              case 'central': var hanging_symcharm = 438; break;//431
              case 'left': var hanging_symcharm = 427; break;//424
              case 'right': var hanging_symcharm = 435; break;//428
              default: var hanging_symcharm = 438; break;//432
            }
            // var hanging_symcharm = originaltopcoordinates;

            var Rep1c_model1_load = setInterval(() => {
              var cls = '#stubNumber_model_' + modelimages_index;//index
              var cls2 = 'stubNumber_model_' + modelimages_index;//index

              if (document.querySelector(cls)) {
                clearInterval(Rep1c_model1_load)
                var parents_elm = document.getElementById(cls2);

                //set coordinates value according to length of charm
                var precharmlength = stub_charmlength > 0 ? stub_charmlength : 0;
                var cusrrentcharmlength = cur_charm.charmlength > 0 ? cur_charm.charmlength : 0;

                if (parseFloat(precharmlength) > parseFloat(cusrrentcharmlength)) {
                  var substraction = parseFloat(precharmlength) - parseFloat(cusrrentcharmlength);
                  var divide = (substraction / 2);

                  parents_elm.style.top = (parseFloat(parents_elm.style.top) + 0) + 'px';
                  parents_elm.style.left = (parseFloat(parents_elm.style.left) + divide) + 'px';
                  hanging_parents_coordinates = parseFloat(parents_elm.style.top);
                } else {
                  var substraction = parseFloat(cusrrentcharmlength) - parseFloat(precharmlength);
                  var divide = (substraction / 2);

                  console.log('Precarm details here:');
                  console.log(substraction + " and " + divide);
                  console.log(parents_elm.style.top)

                  parents_elm.style.top = (parseFloat(parents_elm.style.top) - 0) + 'px';
                  parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                  hanging_parents_coordinates = parseFloat(parents_elm.style.top);
                }
                this.Stub_model[index].charmlength = cusrrentcharmlength;

                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                // parents_elm.style.top = Number(hanging_symcharm) + 'px';
              }
            }, 0);
            // hanging_parents_coordinates = hanging_symcharm;

            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
            ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
            break;
          case 'asymmetric':

            switch (selectedcharmposition) {
              case 'central': var hanging_asyCharm = (Number(438) + Number(cur_charm.asymmetric_position_value)); break;
              case 'left': var hanging_asyCharm = (Number(427) + Number(cur_charm.asymmetric_position_value)); break;
              case 'right': var hanging_asyCharm = (Number(435) + Number(cur_charm.asymmetric_position_value)); break;
              default: var hanging_asyCharm = (Number(438) + Number(cur_charm.asymmetric_position_value)); break;
            }

            // var hanging_asyCharm = (Number(originaltopcoordinates) + Number(cur_charm.asymmetric_position_value));
            var Rep1c_model2_load = setInterval(() => {
              var cls = '#stubNumber_model_' + modelimages_index;//index
              var cls2 = 'stubNumber_model_' + modelimages_index;//index

              if (document.querySelector(cls)) {
                clearInterval(Rep1c_model2_load)
                var parents_elm = document.getElementById(cls2);

                //set coordinates value according to length of charm
                var precharmlength = stub_charmlength > 0 ? stub_charmlength : 0;
                var cusrrentcharmlength = cur_charm.charmlength > 0 ? cur_charm.charmlength : 0;

                if (parseFloat(precharmlength) > parseFloat(cusrrentcharmlength)) {
                  var substraction = parseFloat(precharmlength) - parseFloat(cusrrentcharmlength);
                  var divide = (substraction / 2) + Number(cur_charm.asymmetric_position_value);

                  parents_elm.style.top = (parseFloat(parents_elm.style.top) + divide) + 'px';
                  parents_elm.style.left = (parseFloat(parents_elm.style.left) + divide) + 'px';
                  hanging_parents_coordinates = parseFloat(parents_elm.style.top);
                } else {
                  var substraction = parseFloat(cusrrentcharmlength) - parseFloat(precharmlength);
                  var divide = (substraction / 2) + Number(cur_charm.asymmetric_position_value);

                  parents_elm.style.top = (parseFloat(parents_elm.style.top) - divide) + 'px';
                  parents_elm.style.left = (parseFloat(parents_elm.style.left) - divide) + 'px';
                  hanging_parents_coordinates = parseFloat(parents_elm.style.top);
                }
                this.Stub_model[index].charmlength = cusrrentcharmlength;

                var current_hangingObject = parseInt(parents_elm.style.top);
                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                // parents_elm.style.top = Number(hanging_asyCharm) + 'px';
              }
            }, 0);
            // hanging_parents_coordinates = hanging_asyCharm;

            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
            ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
            break;
          default:
            var hanging_def = 438
            // var hanging_def = originaltopcoordinates
            var Rep1c_model3_load = setInterval(() => {
              var cls = '#stubNumber_model_' + modelimages_index;//index
              var cls2 = 'stubNumber_model_' + modelimages_index;//index

              if (document.querySelector(cls)) {
                clearInterval(Rep1c_model3_load)
                var parents_elm = document.getElementById(cls2);
                var currentObjectCoordinates = parseInt(parents_elm.style.top);
                parent_charm_Xcoordinate = parseInt(parents_elm.style.left);
                parents_elm.style.top = Number(hanging_def) + 'px';
              }
            }, 0);
            hanging_parents_coordinates = hanging_def;

            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
            ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
            break;
        }

        var model_current_charm_id = 0;
        var model_current_parent_id = 0;
        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          this.chain_model_details.forEach(e2 => {
            if (e2.tools_link === pre_charm.flat_index) {
              model_current_charm_id = e2.tool_id;
              model_current_parent_id = e2.id;
            }
          });
          return ((e.chaindesign_id * 1) == (pre_charm.chaindesign_id * 1))
        })

        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          return ((e.parents_charm * 1) == (model_current_charm_id * 1))
        })
        var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
          return ((e.parents_charm_row_id * 1) == (model_current_parent_id * 1))
        })
        // var filter_relation = this.model_chain_charm_relationDetails.filter(e => {
        //   return ((e.parents_charm_row_id * 1) == (model_current_parent_id * 1))
        // })

        filter_relation.forEach((element, index) => {
          // var _id = 'stubNumber_model_' + element.index_no//index_no
          var _id = 'stubNumber_model_' + this.chain_model_details.filter(f => f.id == element.modeltool_id)[0].compontindex;

          var attached_addon = document.getElementById(_id);

          var getXposition_mdlhgn = setInterval(() => {
            if (parent_charm_Xcoordinate > 0) {
              clearInterval(getXposition_mdlhgn);

              var central_pos = (parent_charm_Xcoordinate + (parseFloat(cur_charm.charmlength) - 43) / 2)
              var yoffset = Number(cur_charm.charmsyoffset) ? Number(cur_charm.charmsyoffset) + 3 : 3;

              var addontopcoordinates;
              var ycoordinate = setInterval(() => {
                if (hanging_parents_coordinates > 0) {
                  addontopcoordinates = hanging_parents_coordinates + ((parseFloat(cur_charm.charmlength) / 4) * 3)
                  var attched_lstpstn_top = ((addontopcoordinates - yoffset) * (index + 1));
                  attached_addon.style.top = attched_lstpstn_top + 'px';
                  attached_addon.style.left = central_pos + 'px';
                  clearInterval(ycoordinate);
                }
              })
            }
          })
          // var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
          // ((a.controls[(element.index_no * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id);
          // ((a.controls[(element.index_no * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);

        });
        break;
    }
  }

  async BuildReplacementStructure_Model(pre_charm, cur_charm, index, img, its_from) {

    //Replace model Charms
    var charm_model_pos;
    var addon_model_pos;
    var model_tools_id;
    var model_tools_position;
    var modelflat_index = pre_charm.flat_index;
    var model_cur_yAxis = 0;
    var currentcharmid;
    var selectedcharmposition;
    var modelimages_index;

    switch (its_from) {
      case 'charm':
        this.Stub_model.forEach((e, index12) => {
          if (e.toolsLink == modelflat_index) {
            model_tools_id = e.tool_id;
            model_tools_position = e.Position;
            model_cur_yAxis = e.offsetY;
            index = index12
            modelimages_index = e.compontIndex;
          }
        })

        // this.alltypeofchains_filters.filter(f=>f.chaintype=='plain' && f.id == )
        await this.charm_images.forEach(e => {
          if (Number(e.charm_id) === Number(cur_charm.charm_id)) {
            if (Number(e.color_variationid) === Number(cur_charm.color_variationid)) {
              if (e.img_view_type === 'model' && String(e.img_view_position) === String(model_tools_position)) { //cur_charm.img_view_position && model_tools_id !== e.id
                charm_model_pos = "charm_images_model_position" + e.id;

                switch (cur_charm.iscenterpiececharm) {
                  case 'Y':
                    if (e.chaindesignwt == this.globalreplacechaindesignwtid) {
                      this.CreateDynamicHTMLElement(e.img_path, charm_model_pos, "65px", "65px");
                      selectedcharmposition = e.img_view_position;
                      currentcharmid = e.id
                    }
                    break;
                  case 'N':
                    this.CreateDynamicHTMLElement(e.img_path, charm_model_pos, "65px", "65px");
                    console.log('Im calling this function for the appennd');
                    selectedcharmposition = e.img_view_position;
                    currentcharmid = e.id
                    break;
                }
              }
            }

          }
        });

        var cls = '#stubNumber_model_' + modelimages_index;
        var cls2 = 'stubNumber_model_' + modelimages_index;

        if (document.querySelector(cls)) {
          if (charm_model_pos) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.childNodes[2].remove()

            var itm = document.getElementById(charm_model_pos);
            itm.style.height = cur_charm.charmlength + 'px';
            itm.style.width = cur_charm.charmlength + 'px';
            var cln = itm.cloneNode(true);
            parents_elm.appendChild(cln);

            itm.style.height = '178px';
            itm.style.width = '213px';

            this.NumberOfStub_model++;
            this.SetModel_images_position(pre_charm, cur_charm, index, img, its_from, model_cur_yAxis, selectedcharmposition, modelimages_index);
          } else {
            alert(model_tools_position.toUpperCase() + " side posititon images Not found for Model images");
          }
        }

        var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
        ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(currentcharmid);
        ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);

        break;
    }
  }

  Replace_Bracelte_tools(pre_charm, cur_charm, index, img, its_from) {

    var Rep11capa1_load = setInterval(() => {
      var cls = '#stubNumber_' + index;
      var cls2 = 'stubNumber_' + index;
      if (document.querySelector(cls)) {

        var parents_elm = document.getElementById(cls2);
        parents_elm.childNodes[2].remove()
        switch (its_from) {
          case 'addon':
            var autogenerateCls = this.getflatimage('addon', cur_charm);
            var autogenAddonload = setInterval(() => {
              if (document.querySelector('#' + autogenerateCls)) {
                clearInterval(autogenAddonload)
                img = document.getElementById(autogenerateCls).cloneNode();

                var cln = img;
                parents_elm.appendChild(cln);
              }
            }, 0);
            this.SaveActivity("Addon Replaced with " + cur_charm.name);

            // img.target.style.height = '45px';
            // img.target.style.width = '45px';
            break;
          case 'lock':
            var autogenerateCls = this.getflatimage('lock', cur_charm);
            var autogenlockload = setInterval(() => {
              if (document.querySelector('#' + autogenerateCls)) {
                clearInterval(autogenlockload)
                img = document.getElementById(autogenerateCls).cloneNode();

                var cln = img;
                parents_elm.appendChild(cln);
              }
            }, 0);
            this.SaveActivity("Lock Replaced with " + cur_charm.name);
            // img.target.style.height = '80px';
            // img.target.style.width = '80px';
            break;
          case 'ring':

            var autogenerateCls = this.getflatimage('ring', cur_charm);
            var autogenringload = setInterval(() => {
              if (document.querySelector('#' + autogenerateCls)) {
                clearInterval(autogenringload)
                img = document.getElementById(autogenerateCls).cloneNode();
                var cln = img;
                parents_elm.appendChild(cln);
              }
            }, 0);
            // img.target.style.height = '100px';
            // img.target.style.width = '100px';
            this.SaveActivity("Ring Replaced with " + cur_charm.name);
            //Set Coordinates
            img.target.style.left = Number(img.target.style.left) + (4) + 'px';
            console.log(img.target.style.left);
            break;
        }

        if (its_from == 'ring') {
          parents_elm.style.left = cur_charm.ringoffsetvalue;
        }
        // img.target.style.height = '178px';
        // img.target.style.width = '213px';
        clearInterval(Rep11capa1_load)
      }
    }, 0);

    this.designForm.get('linkchainlockid').setValue(cur_charm.id);
    var a = this.designForm.get('flat_chain_designAnnotation') as FormArray;
    switch (its_from) {
      case 'addon': ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id); break;
      case 'ring': ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id); break;
      case 'lock': ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id); break;
      default: ((a.controls[(index * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(cur_charm.id); break;
    }
    ((a.controls[(index * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);
    this.CustomizationCalculation();

    //Replace model Charms
    var charm_model_pos;
    var addon_model_pos;
    var model_tools_id;
    var model_tools_position;
    var modelflat_index = pre_charm.flat_index;
    var current_addon_id;

    var indexforaddon = 0;
    var temindex;
    switch (its_from) {
      case 'ring':
        this.CustomizationCalculation()
        break;
      case 'lock':
        this.CustomizationCalculation()
        break;
      case 'addon':
        this.Stub_model.forEach((e, index13) => {
          if (e.toolsLink == modelflat_index) {
            model_tools_id = e.tool_id;
            model_tools_position = e.Position;
            // index = index13;
            temindex = index13;
            indexforaddon = e.compontIndex//index13
          }
        })

        this.addon_images.forEach(e => {
          if (e.addon_id === cur_charm.addon_id) {
            if (Number(e.color_variationid) === Number(cur_charm.color_variationid)) {
              if (e.img_view_type === 'model' && String(e.img_view_position) === String(model_tools_position)) {
                addon_model_pos = "addon_images_model_position" + e.id;
                this.CreateDynamicHTMLElement(e.img_path, addon_model_pos, "45px", "45px");
                current_addon_id = e.id
              }
            }
          }
        });
        var cls = '#stubNumber_model_' + indexforaddon;//index
        var cls2 = 'stubNumber_model_' + indexforaddon;//index

        if (document.querySelector(cls)) {
          if (addon_model_pos) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.childNodes[2].remove()
            var itm = document.getElementById(addon_model_pos);
            var cln = itm.cloneNode(true);
            parents_elm.appendChild(cln);
            this.NumberOfStub_model++;

            var a = this.designForm.get('model_chain_designAnnotation') as FormArray;
            ((a.controls[(temindex * 1)] as FormArray).controls['tool_id'] as FormArray).setValue(current_addon_id);
            ((a.controls[(temindex * 1)] as FormArray).controls['tooltype'] as FormArray).setValue(its_from);

            this.CustomizationCalculation()
          } else {
            alert(model_tools_position.toUpperCase() + " side posititon images Not found for Model images");
          }
        }
        break;
    }
  }

  checkoutcustomer() {
    this.router.navigate(['/vendor/customer/checkout']);
  }
  backonhomepage() {
    var answer: boolean = confirm('Discard Customization ?');
    if (answer) {
      this.router.navigate(['', this.vendorCompanyname, this.vendorquniquekey, 2, this.filtered_collectionid, this.filtered_braceletid
      ]);
    }
  }

  DefaultSeletedTools(toolsid: any, tooltype) {
    switch (tooltype) {

      case 'collection':
        var product_selected = setInterval(() => {
          var cls = '#listofcollection_' + toolsid;
          var cls2 = 'listofcollection_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(product_selected)
          }
        }, 0)
        break;

      case 'bracelettype':
        var product_selected = setInterval(() => {
          var cls = '#listoftyperange_' + toolsid;
          var cls2 = 'listoftyperange_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(product_selected)
          }
        }, 0)
        break;

      case 'product':

        var product_selected = setInterval(() => {
          var cls = '#product' + toolsid;
          var cls2 = 'product' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(product_selected)
          }
        }, 0)

        break;
      case 'design':
        var charm_selected = setInterval(() => {
          var cls = '#listofdesign_' + toolsid;
          var cls2 = 'listofdesign_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(charm_selected)
          }
        }, 0)

        break;
      case 'chain':
        var charm_selected = setInterval(() => {
          var cls = '#listofchain_' + toolsid;
          var cls2 = 'listofchain_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(charm_selected)
          }
        }, 0)

        break;

      case 'braceletwidth':
        var charm_selected = setInterval(() => {
          var cls = '#listofchainwidth_' + toolsid;
          var cls2 = 'listofchainwidth_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(charm_selected)
          }
        }, 0)

        break;
      case 'charm':
        var charm_selected = setInterval(() => {
          var cls = '#listofcharms_' + toolsid;
          var cls2 = 'listofcharms_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(charm_selected)
          }
        }, 0)

        break;
      case 'addon':
        var addon_selected = setInterval(() => {
          var cls = '#listofaddon_' + toolsid;
          var cls2 = 'listofaddon_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(addon_selected)
          }
        }, 0)

        break;
      case 'lock':
        var lock_selected = setInterval(() => {
          var cls = '#listoflock_' + toolsid;
          var cls2 = 'listoflock_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(lock_selected)
          }
        }, 0)
        break;
      case 'ring':
        var ring_selected = setInterval(() => {
          var cls = '#listofring_' + toolsid;
          var cls2 = 'listofring_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            parents_elm.style.border = "1px solid #DBA632";
            clearInterval(ring_selected)
          }
        }, 0)
        break;
    }
  }

  RemoveSeletedTools(toolsid: any, tooltype) {
    switch (tooltype) {

      case 'collection':
        var product_selected = setInterval(() => {
          var cls = '#listofcollection_' + toolsid;
          var cls2 = 'listofcollection_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(product_selected)
          }
        }, 0)
        break;

      case 'bracelettype':
        var product_selected = setInterval(() => {
          var cls = '#listoftyperange_' + toolsid;
          var cls2 = 'listoftyperange_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(product_selected)
          }
        }, 0)
        break;

      case 'product':

        var product_selected = setInterval(() => {
          var cls = '#product' + toolsid;
          var cls2 = 'product' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(product_selected)
          }
        }, 0)

        break;
      case 'design':
        var charm_selected = setInterval(() => {
          var cls = '#listofdesign_' + toolsid;
          var cls2 = 'listofdesign_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(charm_selected)
          }
        }, 0)

        break;
      case 'chain':
        var charm_selected = setInterval(() => {
          var cls = '#listofchain_' + toolsid;
          var cls2 = 'listofchain_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            console.log(parents_elm);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(charm_selected)
          }
        }, 0)

        break;

      case 'braceletwidth':
        var charm_selected = setInterval(() => {
          var cls = '#listofchainwidth_' + toolsid;
          var cls2 = 'listofchainwidth_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            console.log(parents_elm);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(charm_selected)
          }
        }, 0)

        break;

      case 'charm':
        var charm_selected = setInterval(() => {
          var cls = '#listofcharms_' + toolsid;
          var cls2 = 'listofcharms_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            // parents_elm.style.border = "1px solid rgba(0, 0, 0, 0.1);";
            clearInterval(charm_selected)
          }
        }, 0)

        break;
      case 'addon':
        var addon_selected = setInterval(() => {
          var cls = '#listofaddon_' + toolsid;
          var cls2 = 'listofaddon_' + toolsid;
          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(addon_selected)
          }
        }, 0)

        break;
      case 'lock':
        var lock_selected = setInterval(() => {
          var cls = '#listoflock_' + toolsid;
          var cls2 = 'listoflock_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(lock_selected)
          }
        }, 0)
        break;
      case 'ring':
        var ring_selected = setInterval(() => {
          var cls = '#listofring_' + toolsid;
          var cls2 = 'listofring_' + toolsid;

          if (document.querySelector(cls)) {
            var parents_elm = document.getElementById(cls2);
            (document.querySelector(cls) as HTMLElement).style.border = '1px solid rgba(0, 0, 0, 0.1)';
            clearInterval(ring_selected)
          }
        }, 0)
        break;
    }
  }

  GetScrollerEndPoint() {
    var scrollHeight = this.divToScroll.nativeElement.scrollHeight;
    var divHeight = this.divToScroll.nativeElement.height;
    var scrollerEndPoint = scrollHeight - 600;

    var divScrollerTop = this.divToScroll.nativeElement.scrollTop;
    console.log(divScrollerTop, " ", scrollerEndPoint);
    // if (divScrollerTop === scrollerEndPoint) {
    if (Math.floor(divScrollerTop) >= Math.floor(scrollerEndPoint)) {
      console.log("We got at the Bottom Position of Scroll");
      this.NumberOfImageShowInList += 10;
    }
  }

  yourFunction(e, comefrom: string) {
    let pos = (this.divToScroll.nativeElement.scrollTop) + 600;
    let max = this.divToScroll.nativeElement.scrollHeight;

    // console.log('Charm Section >>' + pos + " == " + max + "floor " + Math.floor(max));

    if (Math.floor(pos) >= Math.floor(max)) {
      this.NumberOfImageShowInList += 10;
    }
  }
  // this.AddonToScroll.nativeElement.offsetHeight

  ScrollAddonList(e, comingfrom) {
    let pos = (this.AddonToScroll.nativeElement.scrollTop) + 600;
    let max = this.AddonToScroll.nativeElement.scrollHeight;
    // console.log('Addon Section >>' + pos + " == " + max);
    if (Math.floor(pos) >= Math.floor(max)) {
      this.NumberOfAddonShowInList += 10;
    }
  }

  imagesPreview(image_path: string) {
    // return (this.ServerURL + '/images/' + image_path);
    return this.metalgoldcolorservice.path + "/imagepreview/getImage?imagename=" + image_path
  }

  filterGoldColor1(name: string) {
    if (!this.isNumber(name))
      return this.goldcolors1.filter(m => m.color.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getGoldColorName1(goldcolorid: number) {
    if (this.goldcolors1 != null && goldcolorid != null && goldcolorid != 0)
      return this.goldcolors1.filter(m => m.id * 1 === goldcolorid * 1)[0].color;
  }
  getGoldcolorname(id) {
    if (Number(id))
      return this.goldcolors1.filter(f => f.id == id)[0].color
  }

  get Getchain_designAnnotationArray() {
    return this.designForm.get('flat_chain_designAnnotation') as FormArray;
  }

  get GetModel_designAnnotationArray() {
    return this.designForm.get('model_chain_designAnnotation') as FormArray;
  }

  get Delete_flat_fromgroup() {
    return this.designForm.get('delete_flat_images') as FormArray;
  }

  get Delete_model_fromgroup() {
    return this.designForm.get('delete_model_images') as FormArray;
  }
  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }

  cartlistlength() {
    this.CustomerOrdersService.cartlistlength();
  }

  cartproduct() {
    this.BraceletAutogenerateid++;
    this.designForm.get('BraceletAutogenerateid').setValue(this.BraceletAutogenerateid);
    var weforcompleteimageforCart: any;
    this.clickFlat();

    var clearflatimag = setTimeout(() => {
      var node = document.getElementById('flatscreen');

      domtoimage.toPng(node)
        .then((dataUrl) => {
          var img = new Image();
          img.src = dataUrl;
          weforcompleteimageforCart = img.src
          clearInterval(clearflatimag);
        })
        .catch((error) => {
          console.error('oops, something went wrong!', error);
        });
    }, 0);

    var getflatbase64 = setInterval(() => {
      if (weforcompleteimageforCart) {
        this.designForm.get('image').setValue(weforcompleteimageforCart);
        clearInterval(getflatbase64)
      }
    }, 0)

    var both = setInterval(() => {
      if (weforcompleteimageforCart) {
        // console.log(this.designForm.value);
        this.SaveActivity("Add Customization Bracelet in Cart");
        this.CustomerOrdersService.addtocart(this.designForm.value);
        this.Alertpopup("Cart", this.designForm.get("name").value);
        clearInterval(both)
      }
    }, 0)
  }

  Alertpopup(forwhat, productname): void {
    const dialogRef = this.dialog.open(CommonalertpopupComponent, {
      // width: '250px',
      data: { mission: forwhat, name: productname },
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }

  async compareproduct() {
    console.log(this.designForm.value);
    this.BraceletAutogenerateid++;
    this.designForm.get('BraceletAutogenerateid').setValue(this.BraceletAutogenerateid);

    var wegotcomplateimage: any;
    this.clickFlat();

    var checklength = await this.CustomerOrdersService.comparelistlength();
    // console.log(checklength);
    // if (checklength <= 2) {
    //   var clearflatimag = setTimeout(() => {
    //     var node = document.getElementById('flatscreen');
    //     domtoimage.toPng(node)
    //       .then((dataUrl) => {
    //         var img = new Image();
    //         img.src = dataUrl;
    //         wegotcomplateimage = img.src
    //         clearInterval(clearflatimag);
    //       })
    //       .catch((error) => {
    //         console.error('oops, something went wrong!', error);
    //       });
    //   }, 0);

    //   var getflatbase64 = setInterval(() => {
    //     if (wegotcomplateimage) {
    //       this.designForm.get('image').setValue(wegotcomplateimage);
    //       clearInterval(getflatbase64)
    //     }
    //   }, 50)

    //   var both = setInterval(() => {
    //     if (wegotcomplateimage) {
    //       this.SaveActivity("Add Customization Bracelet in Compare");
    //       this.CustomerOrdersService.addtocompare(this.designForm.value);
    //       this.Alertpopup("Compare", this.designForm.get("name").value);
    //       clearInterval(both);
    //     }
    //   }, 50)
    // } else {
    //   this.openSnackBar('You can Add Only 3 Product in Campare', 'Close');
    // }
  }

  compare() {
    this.router.navigate(['/vendor/customer/compare', JSON.stringify(this.campareurlobjectdata)])
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action);
  }

  onSubmit() {
    console.log('Imcomingbhere and upldate value', this.loosepattern_dtl[0]);
    this.designForm.get('name').setValue(this.loosepattern_dtl[0].name);
    this.designForm.get('loosebraceletPatternid').setValue(this.loosepattern_dtl[0].id);
    // this.designForm.get('braceletchain_id').setValue(this.chain_images[0].linkchainid);

    this.submitted = true;
    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.designForm.invalid) {
      return;
    }

    console.log(this.designForm.value);
    this.loading = true;
    this.ChaindesignannotationService
      .save_Order(JSON.stringify(this.designForm.value))
      .subscribe((data: any) => {
        this.alertService.success('Bracelet Design Add successfully!', true);
        this.NavbarservicesService.isvisible.next(true)
        // this.NavbarservicesService.show();
        this.NavbarservicesService.isvisible_menu.next(false)
        this.router.navigate(['chaindesignannotations_list']);
      });
  }

  CountValidImages() {
    this.CharmIndexvalue++;
    console.log('Call This method And Number of count is :' + this.CharmIndexvalue);
    return null
  }

  callCancelMethod() {
    this.NavbarservicesService.isvisible.next(true)
    // this.NavbarservicesService.show();
    this.NavbarservicesService.isvisible_menu.next(false)
  }

  // convenience getter for easy access to form fields
  get f() { return this.designForm.controls; }

  getPosition(el) {
    let x = 0;
    let y = 0;
    while (el && !isNaN(el.offsetLeft) && !isNaN(el.offsetTop)) {
      x += el.offsetLeft - el.scrollLeft;
      y += el.offsetTop - el.scrollTop;
      el = el.offsetParent;
    }
    return { top: y, left: x };
  }


  //For Collcetion 
  filterGemstonelength(name: string) {
    if (!this.isNumber(name))
      return this.gemstonelengths.filter(m => m.length.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getgemstonelengthName(typeId: number) {
    if (this.gemstonelengths != null && typeId != null && typeId != 0) {
      return this.gemstonelengths.filter(s => s.id == typeId)[0].length;
    }
  }

  IsSinglestud(name: string) {
    if (name.includes('Single')) {
      this.IsContaintSinglestud = true;
    } else {
      this.IsContaintSinglestud = false;
    }
    return this.IsContaintSinglestud;
  }

  async CreateDynamicHTMLElement(imgpath, id, width, height): Promise<boolean> {
    var boolean: boolean = true;
    //create the DOM element 
    let img = this.renderer.createElement('img');
    img.src = this.imagesPreview(imgpath);
    img.id = id;
    img.alt = "image";
    img.class = "toolsimages";
    img.style.width = width;
    img.style.height = height;
    img.style.border = 'none';
    await this.renderer.appendChild(this.supportimgelement.nativeElement, img);
    return boolean;
  }

  SaveActivity(activity) {
    var act = { activity: activity, vendor: this.vendor_id };
    this.ActivityStorage.push(act);
  }

  FireActivity() {
    if (this.ActivityStorage.length > 0) {
      this.ChaindesignannotationService.FireCustomizationActivity(this.ActivityStorage).subscribe(da => {
        this.ActivityStorage = [];
      })
    }
  }
}


