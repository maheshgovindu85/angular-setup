import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomiseBraceletComponent } from './customise-bracelet.component';

describe('CustomiseBraceletComponent', () => {
  let component: CustomiseBraceletComponent;
  let fixture: ComponentFixture<CustomiseBraceletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomiseBraceletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomiseBraceletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
