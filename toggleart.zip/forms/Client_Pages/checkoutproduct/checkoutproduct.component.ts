import { ChaindesignannotationService } from "@/_services/chaindesignannotation.service";
import { CustomerAuthenticationService } from "@/_services/customer-authentication.service";
import { MetalgoldcolorService } from "@/_services/metalgoldcolor.service";
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { CustomerOrdersService } from "../customer-orders.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { VendordiamondrateService } from "@/_services/vendordiamondrate.service";
import { CommonalertpopupComponent } from "@/forms/CommonPopup/commonalertpopup/commonalertpopup.component";
import { MatDialog } from "@angular/material/dialog";
import {AlertService} from "@/_services";
@Component({
  selector: "app-checkoutproduct",
  templateUrl: "./checkoutproduct.component.html",
  styleUrls: ["./checkoutproduct.component.css"],
})
export class CheckoutproductComponent implements OnInit {
  checkOutForm: FormGroup;
  public productlist: any[] = [];
  public serviceurl;
  public isempty: boolean = true;
  public netamount: number = 0;
  public disable: boolean = false;
  modalRef: any;
  modalService: any;
  submitted: boolean = false;
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
  mobilePattern = "^((\\+91-?)|0)?[0-9]{10}$";
  cartList: any;
  merchant_id: any[];
  allProductData: any = [];
  customerOrderDetails: any=[];
  getPrimaryImage: any =[];
  primaryimage: any;
  displayStyle = "none";
  url_companyname;
  vendoruniquekey;



  constructor(
    private router: Router,
    private CustomerAuthenticationService: CustomerAuthenticationService,
    public CustomerOrdersService: CustomerOrdersService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private formBuilder: FormBuilder,
    private ChaindesignannotationService: ChaindesignannotationService,
    private VendordiamondrateService: VendordiamondrateService,
    public dialog: MatDialog,
    private alertService: AlertService,


  ) {
    let companyUrl: any = [];
    let data = this.router.url;
    companyUrl = data.split("/");
    this.url_companyname = companyUrl[1];
    this.vendoruniquekey = companyUrl[2];

    this.productlist = this.CustomerOrdersService.getcartproduct;
    this.get_NetPrice();
    this.serviceurl = metalgoldcolorservice.path;
    this.getCartList();

   
  }

 

  ngOnInit() {
    this.createForm();
    this.getCartList();
    this.get_NetPrice();
    this.getMerchantId();
    this.getMerchantData();
   
  }

  createForm() {
    this.checkOutForm = this.formBuilder.group({
      name: ["", Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
      mobileNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
    });
  }

  get formValidationState() {
    return this.checkOutForm.controls;
  }

  getMerchantData(){
    this.VendordiamondrateService.vendordetailwithuniquekey(
      this.vendoruniquekey
    ).subscribe((data: any) => {
      this.merchant_id = data.id;
      console.log('this.merchant_id:', this.merchant_id);
    });
  }
  getCartList() {
    this.cartList = this.CustomerOrdersService.cartList();
    console.log('this.cartList:', this.cartList);
    this.netamount = 0;
    this.cartList.forEach((element) => {
      this.netamount += Number(element.CalculationData.GrandTotal);
    });

  }
  getMerchantId(){
    this.merchant_id = [
      ...new Set(this.cartList.map((item) => item.predefinedata.merchantid)),
    ];
  }

  get_NetPrice() {

  }


  getImageByte(filename) {
    return this.serviceurl + "/images/" + filename;
  }

  DeletefromCart(ob: any, index) {
    if (confirm("Do you wish to delete this product from the cart list?")) {
      this.CustomerOrdersService.removeCartItem(ob);
      this.get_NetPrice();
      this.getCartList();
    }
  }
  cancel() {
    this.router.navigate([
      "",
      localStorage.getItem("vendorcompany"),
      localStorage.getItem("vendorkey"),
    ]);
  }

  formSubmit() {
    this.submitted = true;
    if(this.cartList.length > 0 && this.checkOutForm.valid){

    for (let index = 0; index < this.cartList.length; index++) {
      const cartItem = this.cartList[index];
      console.log('cartItem:', cartItem);
      const orderDetail = {
        "imagepath": cartItem.CalculationData.imagePath,
        "isdelete": "N",
        "price": cartItem.CalculationData.GrandTotal,
        "productname": cartItem.predefinedata.name,
        "top": cartItem.predefinedetail.top,
        "mid": cartItem.predefinedetail.mid,
        "dropval": cartItem.predefinedetail.drop,
        "frameband": cartItem.predefinedetail.frameband,
        "design1": cartItem.predefinedetail.design1,
        "design2": cartItem.predefinedetail.design2,
        "design3": cartItem.predefinedetail.design3,
        "gold": cartItem.CalculationData.GoldPrice,
        "diamond": cartItem.CalculationData.DiamondPrice,
        "solitaire": cartItem.CalculationData.SolitairePrice,
        "gemstone": cartItem.CalculationData.GemstonePrice,
        "makingcharges": cartItem.CalculationData.MakingChargePrice,
        "gst": cartItem.CalculationData.Gst
      };
      this.customerOrderDetails.push(orderDetail);
    }
    const dataObj = {
      customer_order: {
        status: "PENDING",
        totalprice: this.netamount,
        merchant_id: this.merchant_id,
        name: this.checkOutForm.value.name,
        email: this.checkOutForm.value.email,
        mobile: this.checkOutForm.value.mobileNumber,
      },
      customer_order_product: this.customerOrderDetails,

    };
    console.log('dataObj:', dataObj);

    localStorage.setItem("cartItems", "[]");
    localStorage.setItem("compareItems", "[]");
    this.CustomerOrdersService.checkoutOrder(dataObj).subscribe(data => {
      this.displayStyle = "none";
      let thanks = this.url_companyname + "/" + this.vendoruniquekey + '/Thankyou/'
      this.router.navigate([thanks])
      
    })
  }
  }

  openPopup() {
    this.displayStyle = "block";
    this.submitted = false;
    this.checkOutForm.reset();

  }
  closePopup() {
    this.displayStyle = "none";
    this.submitted = false;
    this.checkOutForm.reset();
  }
}
