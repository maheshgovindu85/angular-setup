import { VendorAuthenticationService, AlertService, EncryptDecryptService } from '@/_services';
import { CustomerAuthenticationService } from '@/_services/customer-authentication.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-customerlogin',
  templateUrl: './customerlogin.component.html',
  styleUrls: ['./customerlogin.component.css']
})
export class CustomerloginComponent implements OnInit {
  CustomerloginForm: FormGroup;
  loading = false;
  submitted = false;
  encryptedPassword: string;
  decryptedPassword: string;
  returnUrl: string;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private CustomerAuthenticationService: CustomerAuthenticationService,
    private alertService: AlertService,
    private encryptdecryptService: EncryptDecryptService
  ) {
    // redirect to vendor home if already logged in
    if (this.CustomerAuthenticationService.customercurrentUserValue) {

      // var checkoutid = route.snapshot.paramMap.get("_id");
      // console.log("intestesting detais");
      // console.log("Plan Id:");
      // console.log(checkoutid);
      // if (Number(checkoutid) > 0) {
      //     this.router.navigate(['/vendor/planpurchase/cart/', checkoutid]);
      // } else {
      this.router.navigateByUrl('/customer/login');
      // }
    }
  }

  ngOnInit() {
    this.CustomerloginForm = this.formBuilder.group({
      user_id: ['', Validators.required],
      password: ['', Validators.required]
    });

    // get return url from route parameters or default to '/'
    // this.returnUrl = '/vendor/home';
    // this.returnUrl = '/vendorIndex';
    this.returnUrl = '/customer/home';
  }
  CustomerSignup() {
    this.router.navigate(["customer/home"]);
  }

  // convenience getter for easy access to form fields
  get f() { return this.CustomerloginForm.controls; }

  onSubmit() {
    this.submitted = true;

    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.CustomerloginForm.invalid) {
      return;
    }

    // this.loading = true;
    // console.log('user id. -> ' + this.f.user_id.value);
    // console.log('password -> ' + this.f.password.value);

    // var key = CryptoJS.enc.Utf8.parse("abcdefgabcdefg12");
    // var srcs = CryptoJS.enc.Utf8.parse(this.f.password.value);
    // console.log('parsed password -> ' + srcs);
    // var encryptedPassword = CryptoJS.AES.encrypt(srcs, key, {mode:CryptoJS.mode.ECB,padding: CryptoJS.pad.Pkcs7});
    // console.log('encryptedPassword -> ' + encryptedPassword.toString());

    // this.authenticationService.login(this.f.user_id.value, encryptedPassword.toString())
    // console.log(this.encryptdecryptService.encrypt(this.f.password.value));
    this.CustomerAuthenticationService.login(this.f.user_id.value, this.encryptdecryptService.encrypt(this.f.password.value))
      .pipe(first())
      .subscribe(
        data => {
          console.log(data);
          // console.log('data authenticationService : ' + this.returnUrl);
          if (data === null) {
            this.alertService.error('User Id. or Password is incorrect !', true);
            this.loading = false;
          } else {
            this.router.navigate([this.returnUrl]);
          }
        },
        error => {
          // console.log('error authenticationService : ' + error);
          this.alertService.error(error);
          this.loading = false;
        });
  }
}