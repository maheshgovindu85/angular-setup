import { CustomerAuthenticationService } from '@/_services/customer-authentication.service';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RoutesRecognized } from '@angular/router';
import { CustomerOrdersService } from '../customer-orders.service';
import { filter, pairwise } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
import { CommonalertpopupComponent } from '@/forms/CommonPopup/commonalertpopup/commonalertpopup.component';


@Component({
  selector: 'app-compareproduct',
  templateUrl: './compareproduct.component.html',
  styleUrls: ['./compareproduct.component.css']
})
export class CompareproductComponent implements OnInit {

  public productList: any[] = [];
  public serviceurl;
  public isempty: boolean = true;
  public structureids: any[] = [];

  public test_map_flat: any[] = [];
  public test_map_model: any[] = [];

  public previousURL;
  public currentURL;
  compareList: any;
  primaryImage: any[];
  compareData: any = [];


  constructor(private router: Router,
    private CustomerAuthenticationService: CustomerAuthenticationService,
    public CustomerOrdersService: CustomerOrdersService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private _snackBar: MatSnackBar,
    private route: ActivatedRoute,
    public dialog: MatDialog,
  ) {
    this.productList = this.CustomerOrdersService.getcompareproduct;
    if (this.productList.length > 0) {
      this.isempty = false;
    }
    this.serviceurl = metalgoldcolorservice.path;

    this.router.events
      .pipe(filter((evt: any) => evt instanceof RoutesRecognized), pairwise())
      .subscribe((events: RoutesRecognized[]) => {

        this.previousURL = events[0].urlAfterRedirects;
        this.currentURL = events[1].urlAfterRedirects;
      });
    this.getCompareData();


    for (let index = 0; index < this.productList.length; index++) {
      const element = this.productList[index];
      if (element.CalculationData.type === 'ld') {
        this.compareData = element;

      } else if (element.CalculationData.type === 'cs') {
        this.compareData = element;
      }
    }


  }

  ngOnInit(): void {
    this.getCompareData();
  }

  getCompareData() {
    this.compareList = this.CustomerOrdersService.compareList();
  }


  goback() {
  }

  bindhtml(ob, model_img, id) {

    if (this.CheckDuplicates(id)) {
      document.getElementById('appendimage_' + id).innerHTML = ob;

      document.getElementById('append_model_image_' + id).innerHTML = model_img;
    }
  }

  clickFlat(id) {
    document.getElementById('appendimage_' + id).hidden = false;
    document.getElementById('append_model_image_' + id).hidden = true;
  }

  clickmodel(id) {
    document.getElementById('appendimage_' + id).hidden = true;
    document.getElementById('append_model_image_' + id).hidden = false;
  }
  Alertpopup(forwhat, productname): void {
    const dialogRef = this.dialog.open(CommonalertpopupComponent, {
      // width: '250px',
      data: { mission: forwhat, name: productname },
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }


  CheckDuplicates(id) {

    if (this.structureids.length == 0) {
      this.structureids.push(id);
      return true
    } else {
      var available = this.structureids.filter(ids => ids == id)
      if (Number(available)) {
        return false
      } else {
        return true;
      }
    }
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action);
  }

  addtowishproduct(ob: any) {
    this.CustomerOrdersService.addtowishlist(ob);
    this.openSnackBar('Product set for WishList successfully..!', 'Close');
  }

  addToCartProduct(ob: any) {
    this.CustomerOrdersService.addtocart(ob);
    this.Alertpopup("Cart", ob.predefinedata.name);
  }

  getImageByte(filename) {
    return this.serviceurl + '/images/' + filename;
  }

  deleteFromCompare(ob: any, index) {
    if (confirm("Do you wish to delete this product from the compare list?")) {
      this.CustomerOrdersService.removeCompareItem(ob);
      this.getCompareData();
    }
  }

}
