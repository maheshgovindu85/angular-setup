import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCustomeraddonRateInfoComponent } from './view-customeraddon-rate-info.component';

describe('ViewCustomeraddonRateInfoComponent', () => {
  let component: ViewCustomeraddonRateInfoComponent;
  let fixture: ComponentFixture<ViewCustomeraddonRateInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewCustomeraddonRateInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCustomeraddonRateInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
