import { VendorCollectionService } from '@/_services';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { Component, ElementRef, Inject, OnInit, Output, ViewChild } from '@angular/core';
import { ProductDetailsMainSlider, ProductDetailsThumbSlider } from '@/_models/collection';


import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from "@angular/material/dialog";
import { ActivatedRoute } from '@angular/router';
import { EventEmitter } from 'events';
import { element } from 'protractor';

export interface DialogData {
  descr: string;
  name: string;
  id: string;
}
@Component({
  selector: 'app-view-customer-collection',
  templateUrl: './view-customer-collection.component.html',
  styleUrls: ['./view-customer-collection.component.css']
})
export class ViewCustomerCollectionComponent implements OnInit {

  collection: any;
  @ViewChild('videoPlayer') videoplayer: ElementRef;
  public serviceurl;
  public collectiondiamonddetails;

  public Product_images: any[];
  public product: any[] = [];
  public counter: number = 1;
  public activeSlide: any = 0;
  public selectedSize: any;
  public mobileSidebar: boolean = false;
  public collectiondescription;

  myThumbnail = "https://wittlock.github.io/ngx-image-zoom/assets/thumb.jpg";
  myFullresImage = "https://wittlock.github.io/ngx-image-zoom/assets/fullres.jpg";

  public product_test: any[] = [
    { 'id': 1, 'name': 'A', 'active': true },
    { 'id': 2, 'name': 'B', 'active': false },
    { 'id': 3, 'name': 'C', 'active': false }
  ];

  public ProductDetailsMainSliderConfig: any = ProductDetailsMainSlider;
  public ProductDetailsThumbConfig: any = ProductDetailsThumbSlider;
  pictures: any[];
  constructor(
    public dialogRef: MatDialogRef<ViewCustomerCollectionComponent>,
    private metalgoldcolorservice: MetalgoldcolorService,
    private vendorCollectionService: VendorCollectionService,
    private route: ActivatedRoute,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) {

    this.serviceurl = metalgoldcolorservice.path;
    vendorCollectionService.getVendorCollectionDiamond(data.id).subscribe(data => {
      this.collectiondiamonddetails = data;
      if (data[0])
        this.collectiondescription = data[0].descr
    })

    this.pictures = [];

    vendorCollectionService.getVendorCollectionImagesVideo(data.id).subscribe(
      data => {
        this.Product_images = data;
        console.log(data);
        // this.Product_images = this.Product_images.filter(f => f.img_type == 'image')
        this.product = [];
        this.Product_images.forEach((element, index) => {
          this.pictures.push({ 'id': index, 'media_type': this.extension(element.img_vid_path), src: this.serviceurl + '/images/' + element.img_vid_path, 'activethm': index <= 3 ? true : false });
        });
      }
    )
  }

  extension(str: string) {
    if (str.includes('png') || str.includes('jpeg') || str.includes('raw') || str.includes('jpg'))
      return 'Image';
    else
      return 'Video';
  }

  closemodal(): void {
    this.dialogRef.close();
  }

  toggleVideo(event: any) {
    this.videoplayer.nativeElement.play();
  }

  getvedioBute(filename) {
    return this.serviceurl + '/images/' + filename;
  }

  ChangeImages(ind) {
    this.product[ind].active = true;

    this.product.forEach((elenemt, index) => {
      if (index === ind) {
        this.product[ind].active = true;
      } else {
        this.product[index].active = false;
      }
    })
  }

  customOptions2: any = {
    items: 1,
    nav: false,
    dots: false,
    autoplay: false,
    slideSpeed: 300,
    loop: true
  }
  // new code for images Gallery

  ngOnInit(): void {
  }



  currentPicture = 0;


  select(index) {
    this.currentPicture = index;
  }

  selectArrow() {
    if (this.currentPicture < this.pictures.length - 1) {
      this.currentPicture++;
    } else {
      this.currentPicture = 0;
    }
  }

  selectLeftArrow() {
    if (this.currentPicture > 0) {
      this.currentPicture--;
    } else {
      this.currentPicture = this.pictures.length - 1;
    }
  }

  clickprevious() {
    var thumbactiveimage: any[] = this.pictures.filter(f => f.activethm == true)
    if (thumbactiveimage.length > 3) {
      this.pictures[thumbactiveimage[0].id - 1].activethm = true;
      this.pictures[thumbactiveimage[3].id].activethm = false;
    }
  }

  clicknext() {
    var thumbactiveimage: any[] = this.pictures.filter(f => f.activethm == true)
    if (thumbactiveimage.length > 3) {
      this.pictures[thumbactiveimage[3].id + 1].activethm = true;
      this.pictures[thumbactiveimage[0].id].activethm = false;
    }
  }
}
