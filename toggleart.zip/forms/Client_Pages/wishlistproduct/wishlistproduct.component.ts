import { CustomerAuthenticationService } from '@/_services/customer-authentication.service';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { CustomerOrdersService } from '../customer-orders.service';

@Component({
  selector: 'app-wishlistproduct',
  templateUrl: './wishlistproduct.component.html',
  styleUrls: ['./wishlistproduct.component.css']
})
export class WishlistproductComponent implements OnInit {

  public productlist: any[] = [];
  public serviceurl;
  public isempty: boolean = true;
  public structureids: any[] = [];

  public test_map_flat: any[] = [];
  public test_map_model: any[] = [];

  constructor(private router: Router,
    private CustomerAuthenticationService: CustomerAuthenticationService,
    private CustomerOrdersService: CustomerOrdersService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private _snackBar: MatSnackBar
  ) {
    this.productlist = this.CustomerOrdersService.wishlist;
    if (this.productlist.length > 0) {
      this.isempty = false;
    }
    this.serviceurl = metalgoldcolorservice.path;
  }

  ngOnInit(): void {

  }

  bindhtml(ob, model_img, id) {

    if (this.CheckDuplicates(id)) {
      document.getElementById('appendimage_' + id).innerHTML = ob;

      document.getElementById('append_model_image_' + id).innerHTML = model_img;
    }
  }

  clickFlat(id) {
    document.getElementById('appendimage_' + id).hidden = false;
    document.getElementById('append_model_image_' + id).hidden = true;
  }

  clickmodel(id) {
    document.getElementById('appendimage_' + id).hidden = true;
    document.getElementById('append_model_image_' + id).hidden = false;
  }

  CheckDuplicates(id) {

    if (this.structureids.length == 0) {
      this.structureids.push(id);
      return true
    } else {
      var available = this.structureids.filter(ids => ids == id)
      if (Number(available)) {
        return false
      } else {
        return true;
      }
    }
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action);
  }

  addtocartproduct(ob: any) {
    this.CustomerOrdersService.addtocart(ob);
    this.openSnackBar('Product set for Cart successfully..!', 'Close');
  }

  addtowishproduct(ob: any) {
    this.CustomerOrdersService.addtowishlist(ob);
    this.openSnackBar('Product set for WishList successfully..!', 'Close');
  }

  getImageByte(filename) {
    return this.serviceurl + '/images/' + filename;
  }

  Deletefromcompare(ob: any) {
    this.productlist.forEach(element => {
      if ((element.id == ob.id) && (element.producttype == ob.producttype)) {
        this.CustomerOrdersService.removeCompareItem(element);
      }
    })
  }

}

