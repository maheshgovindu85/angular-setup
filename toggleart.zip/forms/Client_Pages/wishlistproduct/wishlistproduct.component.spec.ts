import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WishlistproductComponent } from './wishlistproduct.component';

describe('WishlistproductComponent', () => {
  let component: WishlistproductComponent;
  let fixture: ComponentFixture<WishlistproductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WishlistproductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WishlistproductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
