import { Component } from "@angular/core";
import { OwlOptions } from "ngx-owl-carousel-o";
import { VendordiamondrateService } from "@/_services/vendordiamondrate.service";
import { AlertService } from "@/_services";
import { FormBuilder } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { merchantBannerService } from "@/_services/merchant-banner.service";
import { ChaindesignannotationService } from '@/_services/chaindesignannotation.service';
import { environment } from "environments/environment";


@Component({
  selector: "app-client-design-home-page",
  templateUrl: "./client-design-home-page.component.html",
  styleUrls: ["./client-design-home-page.component.css"],
})
export class ClientDesignHomePageComponent {
  vendorcompanyname;
  url_companyname;

  merchant_id: number;
  vendoruniquekey;
  collectionList: any = [];
  bannerList: any = [];
  public path = `${environment.apiUrl}`;
  collectionDetails: any = [];
  collectionDetails_mod: any = [];
  merchantCollectionList: any = [];
  mCollectionData: any = []

  bannerOptions: OwlOptions = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 500,
    margin: 15,
    center: true,
    autoplay: true,
    autoplayTimeout: 6000,
    navText: [
      '<i class="fa fa-angle-left"></i>',
      '<i class="fa fa-angle-right"></i>',
    ],
    responsive: {
      0: {
        items: 1,
        nav: false,
      },
      400: {
        items: 1,
        nav: false,
      },
      740: {
        items: 1,
        nav: true,
      },
      940: {
        items: 1,
        nav: true,
      },
      1200: {
        items: 1,
        nav: true,
      },
    },
  };





  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private VendordiamondrateService: VendordiamondrateService,
    private ProductSubTypeService: ProductSubTypeService,
    private merchantBannerService: merchantBannerService,
    private ChaindesignannotationService: ChaindesignannotationService,
  ) {
    this.vendoruniquekey = this.route.snapshot.paramMap.get("vendoruniquekey");
    this.url_companyname = this.route.snapshot.paramMap.get("companyname");

    localStorage.setItem("vendorcompany", this.url_companyname);
    localStorage.setItem("vendorkey", this.vendoruniquekey);

    this.VendordiamondrateService.vendordetailwithuniquekey(this.vendoruniquekey).subscribe((data: any) => {
      this.merchant_id = data.id;

      this.vendorcompanyname = data.company;


      /////Front end Collection ////
      this.ProductSubTypeService.getfrontendCollections({ merchant_id: this.merchant_id }).subscribe(data => {
        if (data) {
          this.merchantCollectionList = data['MerchantCollection_data'];

          for (let i = 0; i < this.merchantCollectionList.length; i++) {
            var collectionid = this.merchantCollectionList[i].id
            var JsonImgData = this.merchantCollectionList[i].images;
            for (let index = 0; index < JsonImgData.length; index++) {
              const element = JsonImgData[index];
              this.mCollectionData.push( {element, collectionid} );
            }

          }
          console.log(this.mCollectionData[1]);
        }
      })

      /////Front end getMerchantBannerbyMerchantid ////

      this.merchantBannerService.getMerchantBannerbyMerchantid({ merchant_id: this.merchant_id }).subscribe((data) => {
        if (data) {
          this.bannerList = data['data'][0]?.bannerimage

        }
      });

      /////Front end get_vendorCollection ////
      this.ChaindesignannotationService.get_vendorCollection(this.merchant_id).subscribe(data => {
        this.collectionDetails = data;
        this.collectionDetails_mod = data;
        for (let i = 0; i < this.collectionDetails_mod.length; i++) {
          this.collectionDetails_mod[i].TACollectionImg = this.path + "/imagepreview/getImage?imagename=" + this.collectionDetails_mod[i].img_vid_path;
        }
        // console.log(this.collectionDetails_mod);


      })
    });

  }

  ngOnInit() {

  }

  //// product  list end////
  MgoToListing(data) {
    console.log('data:', data);
    var mCollectionId = data.collectionid;
    var det = this.url_companyname + "/" + this.vendoruniquekey + '/collection/' + mCollectionId;
    this.router.navigate([det]);
  }

  //// product  list end////
  TAgoToListing(data) {
    var TACollectionId= data.id   
    console.log('TACollectionId:', TACollectionId);
    var det = this.url_companyname + "/" + this.vendoruniquekey + '/collection/' + TACollectionId;
    this.router.navigate([det]);
  }

}
