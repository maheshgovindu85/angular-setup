import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientDesignAnnoationlistComponent } from './client-design-annoationlist.component';

describe('ClientDesignAnnoationlistComponent', () => {
  let component: ClientDesignAnnoationlistComponent;
  let fixture: ComponentFixture<ClientDesignAnnoationlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientDesignAnnoationlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientDesignAnnoationlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
