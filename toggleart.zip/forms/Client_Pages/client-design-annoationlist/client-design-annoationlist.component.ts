import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { takeUntil } from 'rxjs/operators';

import { AlertService, AuthenticationService, EncryptDecryptService } from '@/_services';

import { Ballpearweighte } from '@/_models/ballpearweighte';
import { BallpearweighteGetAll, BallpearweighteRemove } from '@/_store/ballpearweight/ballpearweight.actions';
import * as ballpearweight_selector from '@/_store/ballpearweight/ballpearweight.selector';
import { BallpearweightService } from '@/_services/ballpearweight.service';
import { ChaindesignannotationService } from '@/_services/chaindesignannotation.service';
@Component({
  selector: 'app-client-design-annoationlist',
  templateUrl: './client-design-annoationlist.component.html',
  styleUrls: ['./client-design-annoationlist.component.css']
})
export class ClientDesignAnnoationlistComponent implements OnInit {

  
  unsubscribe$: Subject<boolean> = new Subject<boolean>();
  ballpearweights: Observable<Ballpearweighte[]>;
  dataSource: MatTableDataSource<Ballpearweighte>;
  closeResult: string;
  searchForm: FormGroup;
  search_text = "";

  displayedColumns: string[] = ['position', 'name', 'actions'];
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private BallpearweightService: BallpearweightService,
    private ChaindesignannotationService: ChaindesignannotationService,
    private store: Store<{ ballpearweights: Ballpearweighte[] }>) {
    // redirect if already logged in
    if (!this.authenticationService.currentUserValue) {
      this.router.navigate(['login']);
    }

    this.searchForm = formBuilder.group({
      search_text: ''
    });

    this.searchForm.valueChanges.subscribe(value => {
      console.log(value);
      const filter = {
        ...value,
        search_text: value.search_text.trim().toLowerCase()
      } as string;
      console.log(filter);
      this.dataSource.filter = filter;
    });
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
    this.ChaindesignannotationService.getAllDesign()
      .subscribe(data => {
        if (data) {
          // console.log(data);
          setTimeout(() => {
            this.dataSource = new MatTableDataSource(data);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;

            this.dataSource.filterPredicate = ((data, filter) => {
              const a = !filter.search_text ||
                data.name.toString().trim().toLowerCase().includes(filter.search_text);
              return a;
            }) as (PeriodicElement, string) => boolean;
          });
        }
      });
  }

}
