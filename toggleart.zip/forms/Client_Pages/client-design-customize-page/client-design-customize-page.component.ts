import { Component } from "@angular/core";
import { ChaindesignannotationService } from "@/_services/chaindesignannotation.service";
import { MatDialog } from "@angular/material/dialog";
import { CustomizationViewPopupComponent } from "./customization-view-popup/customization-view-popup.component";
import { Router, ActivatedRoute } from "@angular/router";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { VendordiamondrateService } from "@/_services/vendordiamondrate.service";
import { environment } from "environments/environment";
import { CustomizationViewPopupCsComponent } from "../customization-view-popup-cs/customization-view-popup-cs.component";
import { CenterStonePredefineService } from "@/_services/cs_predefine.service";
import { LongDesignPredefineService } from "@/_services/long-design-predefine.service";
import { CustomerOrdersService } from "../customer-orders.service";
import { CommonalertpopupComponent } from "@/forms/CommonPopup/commonalertpopup/commonalertpopup.component";
import domtoimage from "dom-to-image-chrome-fix";
import { GemstoneService } from "@/_services";
import { CenterStoneVariantService } from "@/_services/cs_variant.service";
import { CenterStoneSizePositionService } from "@/_services/cs_size_position.service";
import { CenterStoneSizeService } from "@/_services/cs_size.service";

@Component({
  selector: "app-client-design-customize-page",
  templateUrl: "./client-design-customize-page.component.html",
  styleUrls: ["./client-design-customize-page.component.css"],
})
export class ClientDesignCustomizePageComponent {
  onModel: boolean = false;
  onCanvas: boolean = true;
  goldColor: any[];
  studdedTypeList: any = [];
  colorPreFerances: any = [];
  collapse_show1: boolean = false;
  collapse_show2: boolean = false;
  collapse_show3: boolean = false;
  collapse_show4: boolean = false;
  collapse_show5: boolean = false;
  collapse_show6: boolean = false;
  collapse_show7: boolean = false;
  materialSection: boolean = false;
  PriceBreakUp: boolean = false;
  displayQuantity = "Synthetic";

  vendorcompanyname;
  merchant_id: number;
  vendoruniquekey;
  collectionList: any = [];
  bannerList: any = [];
  subproductID: any;
  customizationRootImage: any = [];
  url_companyname;
  collectionid: any;
  productType: any;
  productId: any;
  predefinedId: any;
  customizationData: any = [];
  public path = `${environment.apiUrl}`;
  rootImageData: any = [];
  Stub: any[] = [];
  NumberOfStub: number = 0;
  customizationPredefinedetail: any = [];
  predefinedDetailTop: any = [];
  predefinedDetailMid: any = [];
  predefinedDetailDrop: any = [];
  topImages: any = [];
  midImages: any = [];
  dropImages: any = [];
  customizationAnnotation: any = [];
  Stub_model: any = [];
  Stub_tree: any = [];
  Original_Stub_model: any;
  Original_Stub_tree: any;
  NumberOfStub_model: number = 0;
  customizationPredefinedata: any = [];
  csDesign1: any = [];
  csDesign2: any = [];
  csDesign3: any = [];
  csDrop: any = [];
  csFrameband: any = [];
  design_show: boolean = false;
  frameBand_show: boolean = false;
  showTop: boolean = false;
  showMid: boolean = false;
  showDrop: boolean = false;
  showcentreStone: boolean = false;
  centreStonepresent: boolean = false;
  showDesign1: boolean = false;
  showDesign2: boolean = false;
  showDesign3: boolean = false;
  showFrameBand: boolean = false;
  showCsDrop: boolean = false;
  selectedsizepos = [];
  calculationPart: any = [];
  ktActiveClass = 18;
  ActivityStorage: any[] = [];
  brSizeValues: any = [];
  KTValues: any = [];
  selectSize: any;
  // filterGms: any=[];
  predefinedData: any = [];
  productViewImages: any = [];
  predefinedBind: any;
  predefinedDetail: any;
  goldCalculation: any = [];
  showNaturalRates: boolean;
  allData: any = [];
  DiamondValues: any = [];
  DiamondSolitaireValues: any = [];
  GemstoneNatural: any = [];
  GesmtoneSynthetic: any = [];
  goldwt: any;
  goldprice: any;
  goldkt = 18;
  goldrate: any;
  diamondval: any;
  diamondsolitaireval: any;
  gemstoneval: any = [];
  gemstoneselected: any = [];
  calculationPartDrop: any = [];
  calculationPartTOp: any = [];
  calculationPartMId: any = [];
  KTValuesDrop: any[];
  KTValuesMid: any[];
  KTValuesTop: any[];
  allCalCulationValues: any = [];
  dropKtValueSum: any;
  topKtValuesSum: any;
  dropKtValue: any;
  totalmakingcharges: any;
  total: any;
  gsttotal: any;
  grandtotal: any;
  allCalculationData: {
    GoldPrice: {};
    DiamondPrice: {};
    SolitairePrice: {};
    GemstonePrice: any;
    MakingChargePrice: any;
    TotalValue: any;
    Gst: any;
    GrandTotal: any;
    type: any;
    imagePath: any;
  };
  longdesigndata: {
    dropval: any;
    midval: any;
    topval: any;
    merchantid: any;
    merchantCollection: any;
    product_id: any;
  };
  centrestonedata: {
    frame_band_id: any;
    drop_name: any;
    cs_predefine1: any;
    cs_predefine2: any;
    cs_predefine3: any;
    merchantid: any;
    merchantCollection: any;
    product_id: any;
    csSize: any;
  };
  productID: any;
  diamondActiveClass;
  midbottomoffset: any = 0;
  dropupoffset: any = 0;
  topbottomoffset: any = 0;
  midupoffset: any = 0;
  midbottomoffsetmodel: any = 0;
  dropupoffsetmodel: any = 0;
  topbottomoffsetmodel: any = 0;
  midupoffsetmodel: any = 0;
  typeActive = "Synthetic";
  typeActiveNatural;
  typeActiveNaturalDrop: any = 0;
  typeActiveNaturalMid: any = 0;
  typeActiveNaturalTop: any = 0;
  dropImgPath: any;
  showRemoveDrop: boolean = true;
  shoAddDrop: boolean = false;
  textLabel: any;
  dropCalData: any = [];
  TopGemstoneNatural: any = [];
  TopGesmtoneSynthetic: any = [];
  DropGesmtoneSynthetic: any = [];
  DropGemstoneNatural: any = [];
  topCalData: any = [];
  midCalData: any = [];
  MidGemstoneNatural: any = [];
  MidGesmtoneSynthetic: any = [];
  design1calData: any = [];
  design2calData: any = [];
  design3calData: any = [];
  dropcalData: any = [];
  framebandcalData: any = [];
  Design1GesmtoneSynthetic: any = [];
  Design1GemstoneNatural: any = [];
  Design2GesmtoneSynthetic: any = [];
  Design2GemstoneNatural: any = [];
  Design3GesmtoneSynthetic: any = [];
  Design3GemstoneNatural: any = [];
  FrameGesmtoneSynthetic: any = [];
  FrameGemstoneNatural: any = [];
  replaceImage: any;
  selectedColor: any;
  design1Text: string;
  design2Text: string;
  displaywithcssize: boolean = false;
  selectedGemstone: any;
  gemstoneList: any;
  merchantCenterVariantList: any;
  selectedcssize: any = 0;
  framecssizes = [];
  displayNaturalRates: boolean = false;
  selectShape: any;
  singlecssize: boolean = false;
  shapes: any = [
    {
      id: 8,
      cs_shape: "Emerald",
      image: "../../assets/images/shapes/Emerald E.jpg",
    },
    {
      id: 5,
      cs_shape: "Marquise",
      image: "../../assets/images/shapes/Marquise M.jpg",
    },
    { id: 4, cs_shape: "Oval", image: "../../assets/images/shapes/Oval O.jpg" },
    {
      id: 10,
      cs_shape: "Pear",
      image: "../../assets/images/shapes/Pear P.jpg",
    },
    {
      id: 2,
      cs_shape: "Princess",
      image: "../../assets/images/shapes/Princess P copy.jpg",
    },
    {
      id: 1,
      cs_shape: "Round",
      image: "../../assets/images/shapes/Round R.jpg",
    },
  ];
  goldData: {
    goldkt: number;
    goldwt: any;
    goldrate: any;
    goldprice: any;
    brsize: any;
  };
  diamondData: { DiaType: any; Diakt: any; diaPrice: any };
  solitaireData: { SolitaireType: any; Solitairekt: any; SolitairePrice: any };
  predefinedType: any;
  activeCompo: string;
  captureImagePath: any;
  autosizeval: boolean = false;
  centerStoneSizePositionList: any = [];
  shapechange: boolean = false;
  domToImage: any;
  partImagePath: string;
  modelImage: string;
  centerStoneSizeList: any = [];
  FilterCsSizeList: any = [];
  framewidth: any;
  frameheigth: any;
  designwidth: any;
  designheigth: any;
  dropwidth: any;
  dropheigth: any;
  constructor(
    private ChaindesignannotationService: ChaindesignannotationService,
    public dialog: MatDialog,
    private router: Router,
    private route: ActivatedRoute,
    private VendordiamondrateService: VendordiamondrateService,
    private LongDesignPredefineService: LongDesignPredefineService,
    private ProductSubTypeService: ProductSubTypeService,
    private CustomerOrdersService: CustomerOrdersService,
    private CenterStonePredefineService: CenterStonePredefineService,
    private GemstoneService: GemstoneService,
    private centerstonvariantService: CenterStoneVariantService,
    private centerstonsizeService: CenterStoneSizeService,
    private CenterStoneSizePositionService: CenterStoneSizePositionService
  ) {
    //   this.vendoruniquekey = this.route.snapshot.paramMap.get("vendoruniquekey");
    // var this.url_companyname = this.route.snapshot.paramMap.get("companyname");
    let companyUrl: any = [];
    let data = this.router.url;
    companyUrl = data.split("/");

    this.url_companyname = companyUrl[1];
    this.vendoruniquekey = companyUrl[2];
    this.predefinedId = companyUrl[5];
    this.subproductID = companyUrl[6];
    this.productId = companyUrl[7];
    this.productType = this.route.snapshot.paramMap.get("type");
    this.productID = JSON.parse(this.route.snapshot.paramMap.get("productid"));

    if (this.productID == 2) {
      this.framewidth = 200;
      this.frameheigth = 200;
      this.designwidth = 200;
      this.designheigth = 200;
    }
    if (this.productID == 3) {
      this.framewidth = 125;
      this.frameheigth = 125;
      this.designwidth = 125;
      this.designheigth = 125;
      this.dropwidth = 125;
      this.dropheigth = 125;
    }

    localStorage.setItem("vendorcompany", this.url_companyname);
    localStorage.setItem("vendorkey", this.vendoruniquekey);

    this.VendordiamondrateService.vendordetailwithuniquekey(
      this.vendoruniquekey
    ).subscribe((data: any) => {
      this.merchant_id = data.id;
      this.vendorcompanyname = data.company;
      const dataObj = {
        merchant_id: this.merchant_id,
      };
      this.centerstonvariantService
        .getCS_VariantbyMerchantid(dataObj)
        .subscribe((data) => {
          if (data) {
            let res = data;
            this.merchantCenterVariantList = res["data"];
            this.resetDesign();
          }
        });

      this.CenterStoneSizePositionService.getCS_SizePositionbyMerchantid(
        dataObj
      ).subscribe((data) => {
        if (data) {
          this.centerStoneSizePositionList = data["data"].filter(
            (x) => x.isactive == "Y"
          );
          for (let i = 0; i < this.centerStoneSizePositionList.length; i++) {
            this.centerStoneSizePositionList[i].isactive =
              this.centerStoneSizePositionList[i].isactive === "N"
                ? false
                : true;
          }
        }
      });

      // this.centerstonsizeService.getAll()
      // .subscribe(data => {
      //   if (data) {
      //       this.centerStoneSizeList = data['data'];
      //       this.centerStoneSizeList.map(data => {
      //         data.csSize = data.cs_length + ' * ' + data.cs_width;
      //         return data;
      //       });
      //       this.FilterCsSizeList = this.centerStoneSizeList.filter( (c) => c.merchant_id == this.merchant_id);
      //   }
      // });
    });
  }

  ngOnInit() {
    this.getGoldColorData();
    this.getStuddenType();
    this.getColorPreference();
  }

  calculateTotal() {
    let totalmake: any =
      this.predefinedDetail.makingcharges * Number(this.goldwt);
    this.totalmakingcharges = parseFloat(totalmake).toFixed(3);
    const gemstonesum = this.gemstoneval.reduce((accumulator, object) => {
      return accumulator + Number(object.price);
    }, 0);
    let tot: any = Number(this.goldprice) + Number(this.totalmakingcharges);

    if (this.diamondval?.price) tot = tot + Number(this.diamondval?.price);
    if (this.diamondsolitaireval?.price)
      tot = tot + Number(this.diamondsolitaireval?.price);
    if (gemstonesum) tot = tot + Number(gemstonesum);

    this.total = parseFloat(tot).toFixed(3);

    let gst: any = 0.03 * Number(this.total);

    this.gsttotal = parseFloat(gst).toFixed(3);
    let gt: any = Number(this.total) + Number(this.gsttotal);

    this.grandtotal = Math.round(gt);

    this.goldData = {
      goldkt: this.goldkt,
      goldwt: this.goldwt,
      goldrate: this.goldrate,
      goldprice: this.goldprice,
      brsize: this.selectSize,
    };
    this.diamondData = {
      DiaType: this.diamondval?.type,
      Diakt: this.diamondval?.kt,
      diaPrice: this.diamondval?.price,
    };

    this.solitaireData = {
      SolitaireType: this.diamondsolitaireval?.type,
      Solitairekt: this.diamondsolitaireval?.kt,
      SolitairePrice: this.diamondsolitaireval?.price,
    };

    this.allCalculationData = {
      GoldPrice: this.goldData || "",
      DiamondPrice: this.diamondData || "",
      SolitairePrice: this.solitaireData || "",
      GemstonePrice: this.gemstoneval,
      MakingChargePrice: this.totalmakingcharges || "",
      TotalValue: this.total || "",
      Gst: this.gsttotal || "",
      GrandTotal: this.grandtotal || "",
      type: this.predefinedType,
      imagePath: this.captureImagePath,
    };
    this.allData.CalculationData = this.allCalculationData;
  }

  changeGoldKT(data) {
    this.ktActiveClass = data;
    this.goldkt = data;
    let res;
    if (!!this.selectSize)
      res = this.calculationPart.filter(
        (x) => x.brsize == this.selectSize && x.kt == this.goldkt
      )[0];
    else res = this.calculationPart.filter((x) => x.kt == this.goldkt)[0];
    this.goldrate = parseFloat(res.rate).toFixed(3);
    this.goldwt = parseFloat(res.wt).toFixed(3);
    let goldprice: any = Number(this.goldrate) * Number(this.goldwt);
    this.goldprice = parseFloat(goldprice).toFixed(3);

    this.calculateTotal();
  }

  changeDiamond(data) {
    this.diamondActiveClass = data;

    if(!!this.selectSize) {
      this.diamondval = this.predefinedDetail.totaldiamond.filter(
        (x) => x.type == data && x.brsize == this.selectSize
      )[0];
    } else {
      this.diamondval = this.predefinedDetail.totaldiamond.filter(
        (x) => x.type == data
      )[0];
    }
    if(!this.diamondval) {
      this.diamondval = this.predefinedDetail.totaldiamond.filter(
        (x) => x.type == data
      )[0];
    }
    this.calculateTotal();
  }

  changeSolitaire(data) {
    this.diamondsolitaireval = this.predefinedDetail.totalsolitaire.filter(
      (x) => x.type == data
    )[0];
    this.calculateTotal();
  }

  gemstoneprice(data, i, type) {
    let gsval = [];
    this.gemstoneval.forEach((element) => {
      if (
        !(element.name === data.name && element.designtype == data.designtype)
      ) {
        gsval.push(element);
      }
    });
    this.gemstoneval = gsval;
    this.typeActiveNatural = i;
    if (type == "DROP") this.typeActiveNaturalDrop = i;
    if (type == "TOP") this.typeActiveNaturalTop = i;
    if (type == "MID") this.typeActiveNaturalMid = i;
    if (this.displayQuantity == "Natural") {
      this.activeCompo = "";
      for (const ele of this.GemstoneNatural) {
        if (ele.name == data.name && ele.designtype == data.designtype) {
          let data = {
            type: ele.type,
            shape: ele.shape,
            name: ele.name,
            wt: ele.wt,
            rate: ele.rate1,
            price: ele.price1,
            designtype: ele.designtype,
          };
          this.gemstoneval.push(data);
        }
      }
    }

    for (const element of this.gemstoneval) {
      if (
        element.name == data.name &&
        element.shape == data.shape &&
        element.type == data.type &&
        element.wt == data.wt
      ) {
        if (i == 1) {
          element.rate = data.rate1;
          element.price = data.price1;
        } else if (i == 2) {
          element.rate = data.rate2;
          element.price = data.price2;
        } else if (i == 3) {
          element.rate = data.rate3;
          element.price = data.price3;
        }
      }
    }
    this.calculateTotal();
  }

  changeSize(data) {
    this.selectSize = data;
    let res = this.calculationPart.filter(
      (x) => x.brsize == this.selectSize && x.kt == this.goldkt
    )[0];
    this.goldrate = parseFloat(res.rate).toFixed(3);
    let goldprice: any = Number(res.rate) * Number(res.wt);
    this.goldprice = parseFloat(goldprice).toFixed(3);
    this.goldwt = parseFloat(res.wt).toFixed(3);
    let prediamondval = this.diamondval;
    this.diamondval = this.predefinedDetail.totaldiamond.filter(
      (x) => x.type == this.diamondActiveClass && x.brsize == this.selectSize
    )[0];
    if(!this.diamondval) {
      this.diamondval = prediamondval;
    }
    this.calculateTotal();
  }

  naturalRates() {
    this.showNaturalRates = true;
  }
  addToCompare(data) {
    this.toggleTab("onCanvas");
    setTimeout(() => {
      var node = document.getElementById("modelScreen");
      domtoimage
        .toPng(node)
        .then((dataUrl) => {
          var img = new Image();
          img.src = dataUrl;
          let dataModelObj = {
            base64format: img.src,
            imagePath: "Product.jpg",
          };

          this.ProductSubTypeService.upload(dataModelObj).subscribe((data) => {
            this.domToImage = data["data"];
            this.partImagePath =
              this.path + "/imagepreview/getImage?imagename=" + this.domToImage;
            this.allCalculationData.imagePath = this.partImagePath;
            this.allData.CalculationData = this.allCalculationData;
            this.CustomerOrdersService.addtocompare(this.allData);
          });
          this.Alertpopup("Compare", data.predefinedata.name);
        })
        .catch((error) => {});
    }, 2000);
  }

  addToCart(data: any) {
    this.toggleTab("onCanvas");
    var node = document.getElementById("modelScreen");
    domtoimage
      .toPng(node)
      .then((dataUrl) => {
        var img = new Image();
        img.src = dataUrl;
        let dataModelObj = {
          base64format: img.src,
          imagePath: "Product.jpg",
        };
        this.ProductSubTypeService.upload(dataModelObj).subscribe((data) => {
          this.domToImage = data["data"];
          this.partImagePath =
            this.path + "/imagepreview/getImage?imagename=" + this.domToImage;
          this.allCalculationData.imagePath = this.partImagePath;
          this.allData.CalculationData = this.allCalculationData;
        });
        this.CustomerOrdersService.addtocart(data);
        console.log("🚀 ~ file: client-design-customize-page.component.ts:596 ~ ClientDesignCustomizePageComponent ~ .then ~ data:", data)
        this.Alertpopup("Cart", data.predefinedata.name);
      })
      .catch((error) => {});
  }

  Alertpopup(forwhat, productname): void {
    const dialogRef = this.dialog.open(CommonalertpopupComponent, {
      // width: '250px',
      data: { mission: forwhat, name: productname },
    });

    dialogRef.afterClosed().subscribe((result) => {});
  }

  toggleTab(data) {
    if (data === "onCanvas") {
      this.onCanvas = true;
      this.onModel = false;
    } else if (data === "onModel") {
      this.onModel = true;
      this.onCanvas = false;
    }
  }

  backToDesign() {}

  showChangeImage(data, index) {
    this.showcentreStone = false;
    if (data.dragType == "TOP" && this.productType == "ld") {
      this.showTop = true;
      this.showMid = false;
      this.showDrop = false;
      this.textLabel = data.dragType;
    } else if (data.dragType == "MID" && this.productType == "ld") {
      this.showMid = true;
      this.showTop = false;
      this.showDrop = false;
      this.textLabel = data.dragType;
    } else if (data.dragType == "DROP" && this.productType == "ld") {
      this.showDrop = true;
      this.showTop = false;
      this.showMid = false;
      this.textLabel = data.dragType;
    }

    // CENTER STONE
    else if (data.dragType == "Drop" && this.productType == "cs") {
      this.showCsDrop = true;
      this.showFrameBand = false;
      this.showDesign2 = false;
      this.showDesign3 = false;
      this.showDesign1 = false;
      this.textLabel = data.dragType;
    } else if (data.dragType == "Center Design" && this.productType == "cs") {
      this.showDesign1 = true;
      this.showFrameBand = false;
      this.showDesign2 = false;
      this.showDesign3 = false;
      this.showCsDrop = false;
      this.textLabel = data.dragType;
      this.design1Text = "Center Design";
    } else if (data.dragType == "Center Stone" && this.productType == "cs") {
      this.showDesign1 = true;
      this.showFrameBand = false;
      this.showDesign2 = false;
      this.showDesign3 = false;
      this.showCsDrop = false;
      this.textLabel = data.dragType;
      this.design1Text = "Center Stone";
      this.showcentreStone = true;
    } else if (data.dragType == "Band" && this.productType == "cs") {
      this.showFrameBand = true;
      this.showDesign1 = false;
      this.showDesign2 = false;
      this.showDesign3 = false;
      this.showCsDrop = false;
      this.textLabel = data.dragType;
    } else if (data.dragType == "Frame" && this.productType == "cs") {
      this.showFrameBand = true;
      this.showDesign1 = false;
      this.showDesign2 = false;
      this.showDesign3 = false;
      this.showCsDrop = false;
      this.textLabel = data.dragType;
    } else if (data.dragType == "Stone 1" && this.productType == "cs") {
      this.showDesign1 = true;
      this.showFrameBand = false;
      this.showDesign2 = false;
      this.showDesign3 = false;
      this.showCsDrop = false;
      this.textLabel = data.dragType;
      this.design1Text = "Center Stone";
    } else if (data.dragType == "Stone 2" && this.productType == "cs") {
      this.showDesign2 = true;
      this.showFrameBand = false;
      this.showDesign1 = false;
      this.showDesign3 = false;
      this.showCsDrop = false;
      this.textLabel = data.dragType;
      this.design2Text = "Center Stone";
    } else if (data.dragType == "Design 1" && this.productType == "cs") {
      this.showDesign1 = true;
      this.showFrameBand = false;
      this.showDesign2 = false;
      this.showDesign3 = false;
      this.showCsDrop = false;
      this.textLabel = data.dragType;
      this.design1Text = "Design 1";
    } else if (data.dragType == "Design 2" && this.productType == "cs") {
      this.showDesign2 = true;
      this.showFrameBand = false;
      this.showDesign1 = false;
      this.showDesign3 = false;
      this.showCsDrop = false;
      this.textLabel = data.dragType;
      this.design2Text = "Design 2";
    }
  }

  getGoldColorData() {
    this.ChaindesignannotationService.getAllgoldColors().subscribe((data) => {
      this.goldColor = data;
      this.selectedColor = "Yellow Gold";
    });
    this.GemstoneService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneList = data;
        });
      }
    });
  }
  getStuddenType() {
    this.ChaindesignannotationService.getStuddedtypeList().subscribe((data) => {
      this.studdedTypeList = data;
    });
  }

  getColorPreference() {
    this.ChaindesignannotationService.gelallchaincolorPref().subscribe(
      (data) => {
        this.colorPreFerances = data;
      }
    );
  }

  collapse_open1() {
    this.collapse_show1 = !this.collapse_show1;
    this.collapse_show2 = false;
    this.collapse_show3 = false;
  }

  collapse_open2() {
    this.collapse_show2 = !this.collapse_show2;
    this.collapse_show1 = false;
    this.collapse_show3 = false;
  }
  collapse_open3() {
    this.collapse_show3 = !this.collapse_show3;
    this.collapse_show2 = false;
    this.collapse_show1 = false;
  }

  designOne() {
    this.design_show = !this.design_show;
    this.frameBand_show = false;
  }

  frameBand() {
    this.frameBand_show = !this.frameBand_show;
    this.design_show = false;
  }

  showMaterialSection() {
    this.materialSection = !this.materialSection;
  }

  showPriceBreakUp() {
    this.PriceBreakUp = !this.PriceBreakUp;
  }

  ViewDetails(data): void {
    const dialogRef = this.dialog.open(CustomizationViewPopupComponent, {
      width: "1000px",
      height: "450px",
      data: { data },
    });

    dialogRef.afterClosed().subscribe((result) => {});
  }
  ViewDesign1Details(data): void {
    const dialogRef = this.dialog.open(CustomizationViewPopupCsComponent, {
      width: "1000px",
      height: "450px",
      data: { data },
    });

    dialogRef.afterClosed().subscribe((result) => {});
  }

  ViewCSDetails(data): void {
    const dialogRef = this.dialog.open(CustomizationViewPopupCsComponent, {
      width: "1000px",
      height: "450px",
      data: { data },
    });

    dialogRef.afterClosed().subscribe((result) => {});
  }

  showQualityList(data) {
    this.displayQuantity = data;
    this.typeActive = data;
    this.gemstoneval = [];
    this.typeActiveNatural = 0;
    this.typeActiveNaturalTop = 0;

    this.typeActiveNaturalMid = 0;

    this.typeActiveNaturalDrop = 0;

    if (this.displayQuantity == "Natural") {
      this.displayNaturalRates = true;
      for (const ele of this.GesmtoneSynthetic) {
        let data = {
          type: ele.type,
          shape: ele.shape,
          name: ele.name,
          wt: ele.wt,
          rate: ele.rate1,
          price: ele.price1,
          designtype: ele.designtype,
        };
        this.gemstoneval.push(data);
      }
    } else {
      this.activeCompo = 'Synthetic'
      this.displayNaturalRates = false;
      for (const ele of this.GesmtoneSynthetic) {
        let data = {
          type: ele.type,
          shape: ele.shape,
          name: ele.name,
          wt: ele.wt,
          rate: ele.rate1,
          price: ele.price1,
          designtype: ele.designtype,
        };
        this.gemstoneval.push(data);
      }
    }
  }
  showSynthetic() {
    this.gemstoneval = [];
    this.typeActiveNatural = 0;
    this.typeActiveNaturalTop = 0;
    this.typeActiveNaturalMid = 0;
    this.typeActiveNaturalDrop = 0;
    this.activeCompo = "Synthetic";
    for (const ele of this.GesmtoneSynthetic) {
      let data = {
        type: ele.type,
        shape: ele.shape,
        name: ele.name,
        wt: ele.wt,
        rate: ele.rate1,
        price: ele.price1,
        designtype: ele.designtype,
      };
      this.gemstoneval.push(data);
    }
    this.calculateTotal();
  }

  showSyntheticVal(type) {
    let gsval = [];
    this.gemstoneval.forEach((element) => {
      if (!(element.designtype == type)) {
        gsval.push(element);
      }
    });
    this.gemstoneval = gsval;
    this.typeActiveNatural = 0;
    if (type == "TOP") this.typeActiveNaturalTop = 0;
    if (type == "MID") this.typeActiveNaturalMid = 0;
    if (type == "DROP") this.typeActiveNaturalDrop = 0;
    this.activeCompo = "Synthetic";
    for (const ele of this.GesmtoneSynthetic) {
      if (ele.designtype == type) {
        let data = {
          type: ele.type,
          shape: ele.shape,
          name: ele.name,
          wt: ele.wt,
          rate: ele.rate1,
          price: ele.price1,
          designtype: ele.designtype,
        };
        this.gemstoneval.push(data);
      }
    }
    this.calculateTotal();
  }

  showSyntheticAll() {
    this.gemstoneval = [];
    this.typeActiveNatural = "";
    this.typeActive = "Synthetic";
    this.activeCompo = "Synthetic";
    this.typeActiveNaturalTop = 0;
    this.typeActiveNaturalMid = 0;
    this.typeActiveNaturalDrop = 0;
    this.displayNaturalRates = false;
    for (const ele of this.GesmtoneSynthetic) {
      let data = {
        type: ele.type,
        shape: ele.shape,
        name: ele.name,
        wt: ele.wt,
        rate: ele.rate1,
        price: ele.price1,
        designtype: ele.designtype,
      };
      this.gemstoneval.push(data);
    }
  }

  transitionImage(data) {
    let res = this.Stub_model.filter(
      (x) =>
        x.tooltype == data.designpart.toLowerCase() &&
        x.partid == data.id &&
        x.selectColor == this.selectedColor
    );

    if (res.length == 0) {
      this.recalculateprcing(data);
      this.Stub_tree.forEach((element) => {
        if (element.tooltype == data.designpart.toLowerCase()) {
          data.image.forEach((imageelement) => {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor
            ) {
              element.img_path = imageelement.images;
              this.replaceImage = element.img_path = imageelement.images;
            }
          });
          element.partid = data.id;
          element.selectColor = this.selectedColor;
          this.midbottomoffset =
            data.midbottomoffset != null
              ? Number(data.midbottomoffset)
              : this.midbottomoffset;
          this.dropupoffset =
            data.dropupoffset != null
              ? Number(data.dropupoffset)
              : this.dropupoffset;
          this.topbottomoffset =
            data.topbottomoffset != null
              ? Number(data.topbottomoffset)
              : this.topbottomoffset;
          this.midupoffset =
            data.midupoffset != null
              ? Number(data.midupoffset)
              : this.midupoffset;
        }
      });

      this.Stub_tree.forEach((element) => {
        let midmove = this.topbottomoffset + this.midupoffset;
        let dropmove =
          this.topbottomoffset +
          this.midupoffset +
          this.dropupoffset +
          this.midbottomoffset;
        if (element.tooltype === "drop") {
          element.dragposition = {
            x: element.odp.x,
            y: element.odp.y + Number(dropmove),
          };
        }
        if (element.tooltype === "mid") {
          element.dragposition = {
            x: element.odp.x,
            y: element.odp.y + Number(midmove),
          };
        }
      });
      this.Stub_model.forEach((element) => {
        if (element.tooltype == data.designpart.toLowerCase()) {
          data.image.forEach((imageelement) => {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor
            ) {
              element.img_path = imageelement.images;
            }
          });
          element.partid = data.id;
          element.selectColor = this.selectedColor;
          this.midbottomoffsetmodel =
            data.midbottomoffsetmodel != null
              ? Number(data.midbottomoffsetmodel)
              : this.midbottomoffsetmodel;
          this.dropupoffsetmodel =
            data.dropupoffsetmodel != null
              ? Number(data.dropupoffsetmodel)
              : this.dropupoffsetmodel;
          this.topbottomoffsetmodel =
            data.topbottomoffsetmodel != null
              ? Number(data.topbottomoffsetmodel)
              : this.topbottomoffsetmodel;
          this.midupoffsetmodel =
            data.midupoffsetmodel != null
              ? Number(data.midupoffsetmodel)
              : this.midupoffsetmodel;
        }
      });
      this.Stub_model.forEach((element) => {
        let midmove = this.topbottomoffsetmodel + this.midupoffsetmodel;
        let dropmove =
          this.topbottomoffsetmodel +
          this.midupoffsetmodel +
          this.dropupoffsetmodel +
          this.midbottomoffsetmodel;
        if (element.tooltype === "drop") {
          element.dragposition = {
            x: element.odp.x,
            y: element.odp.y + Number(dropmove),
          };
        }
        if (element.tooltype === "mid") {
          element.dragposition = {
            x: element.odp.x,
            y: element.odp.y + Number(midmove),
          };
        }
      });
    }
  }

  transitionCsImage(data, designpart) {
    this.recalculateprcingcs(data, designpart);
    this.Stub_model.forEach((element) => {
      if (element.tooltype == designpart.toLowerCase()) {
        if (element.tooltype == "drop") {
          data.image.forEach((imageelement) => {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor
            ) {
              element.img_path = imageelement.images;
            }
          });
        } else {
          data.Image.forEach((imageelement) => {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor
            ) {
              element.img_path = imageelement.images;
            }
          });
        }

        if (element.tooltype == "centre stone") {
        }
      }
    });

    this.Stub_tree.forEach((element) => {
      if (element.tooltype == designpart.toLowerCase()) {
        if (element.tooltype == "drop") {
          data.image.forEach((imageelement) => {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor
            ) {
              element.img_path = imageelement.images;
            }
          });
        } else {
          data.Image.forEach((imageelement) => {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor
            ) {
              element.img_path = imageelement.images;
            }
          });
        }
      }
    });
    if (this.shapechange) {
      this.shapechange = false;
      this.setFramebandonchange();
    }
  }

  transitionCsFrameBandImage(data, designpart) {
    this.recalculateprcingcs(data, designpart);
    let cssizelist = [];
    data.cs_frameband.forEach((element) => {
      cssizelist.push(element.csSize);
    });
    let listimage = [];
    let cszize;
    if (this.selectedcssize == 1.5) cszize = cssizelist[2];
    if (this.selectedcssize == 1) cszize = cssizelist[1];
    if (this.selectedcssize == 0.75 || this.selectedcssize == 0)
      cszize = cssizelist[0];
    this.Stub_model.forEach((element) => {
      if (element.tooltype == designpart.toLowerCase()) {
        data.cs_image_comm.forEach((imageelement) => {
          if (this.selectedcssize == 0) {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor
            ) {
              element.img_path = imageelement.images;
            }
          }
          if (this.selectedcssize == 0.75 || this.selectedcssize == 0) {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor &&
              imageelement.csSize == cszize
            ) {
              element.img_path = imageelement.images;
            }
          }
          if (this.selectedcssize == 1) {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor &&
              imageelement.csSize == cszize
            ) {
              element.img_path = imageelement.images;
            }
          }
          if (this.selectedcssize == 1.5) {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor &&
              imageelement.csSize == cszize
            ) {
              element.img_path = imageelement.images;
            }
          }
        });
      }
    });

    this.Stub_tree.forEach((element) => {
      if (element.tooltype == designpart.toLowerCase()) {
        data.cs_image_comm.forEach((imageelement) => {          
          if (this.selectedcssize == 0) {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor
            ) {
              element.img_path = imageelement.images;
            }
          }
          if (this.selectedcssize == 0.75 || this.selectedcssize == 0) {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor &&
              imageelement.csSize == cszize
            ) {
              element.img_path = imageelement.images;
            }
          }
          if (this.selectedcssize == 1) {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor &&
              imageelement.csSize == cszize
            ) {
              element.img_path = imageelement.images;
            }
          }
          if (this.selectedcssize == 1.5) {
            if (
              imageelement.Position == element.position &&
              imageelement.selectColor == this.selectedColor &&
              imageelement.csSize == cszize
            ) {
              element.img_path = imageelement.images;
            }
          }
        });
      }
    });
  }

  getDotTypeClasses(dragType) {
    let dynamicClasses = "";

    if (dragType === "TOP") {
      dynamicClasses += "right-class";
    } else if (dragType === "MID") {
      dynamicClasses += "left-class ";
    } else if (dragType === "DROP") {
      dynamicClasses += "right-class";
    } else if (dragType === "Drop") {
      dynamicClasses += "right-class";
    } else if (dragType === "Design 1") {
      dynamicClasses += "left-class";
    } else if (dragType === "Design 2") {
      dynamicClasses += "right-class";
    } else if (dragType === "Design 3") {
      dynamicClasses += "left-class";
    } else if (dragType === "Band") {
      dynamicClasses += "right-class";
    } else if (dragType === "Frame") {
      dynamicClasses += "left-class";
    } else if (dragType === "Center Stone") {
      dynamicClasses += "left-class assignWidth";
    } else if (dragType === "Center Design") {
      dynamicClasses += "left-class assignWidth";
    }

    return dynamicClasses.trim();
  }

  selectedShape(data) {
    this.selectShape = data;
    this.shapechange = true;
    for (const iterator of this.customizationPredefinedetail.frameband) {
      let gemres = this.merchantCenterVariantList.filter(
        (x) => x.id == iterator.cs_frameband[0].variant
      );
      if (this.selectShape.cs_shape == gemres[0].cs_shape) {
        this.framecssizes = [];
        iterator.cs_frameband.forEach((element) => {
          this.framecssizes.push(element.csSize);
        });

        break;
      }
    }
    if (this.productType == "cs") {
      this.showDesign1 = true;
      this.showFrameBand = false;
      this.showDesign2 = false;
      this.showDesign3 = false;
      this.showCsDrop = false;
      // this.textLabel = data.dragType;
      this.design1Text = "Center Stone";
    }
    this.setImageValue();
  }

  setFramebandonchange() {
    for (const iterator of this.customizationPredefinedetail.frameband) {
      let gemres = this.merchantCenterVariantList.filter(
        (x) => x.id == iterator.cs_frameband[0].variant
      );
      if (this.selectShape.cs_shape == gemres[0].cs_shape) {
        this.framecssizes = [];
        iterator.cs_frameband.forEach((element) => {
          this.framecssizes.push(element.csSize);
        });
        this.transitionCsFrameBandImage(iterator, "frameband");
        break;
      }
    }
  }

  goldchange(e: any) {
    this.selectedColor = e.value;
    this.setImageValue();
  }

  colorchange(e: any) {
    this.selectedGemstone == e.value;
    this.setImageValue();
  }
  setcssize(data) {
    this.selectedsizepos = this.centerStoneSizePositionList.filter(
      (x) =>
        x.variant &&
        // x.variant == this.predefinedDetail.frameband.data[0].variant &&
        x.sizechangefact[0].csSize == this.framecssizes[1]
    );
    if (this.selectedsizepos.length == 0) {
      alert("Bigger Sizes not defined");
      return;
    }
    this.selectedcssize = data;
    if (this.productId == 4) {
      this.Stub_model.forEach((element) => {
        if (element.tooltype == "item1") {
          if (this.selectedcssize == 1)
            element.dragposition = {
              x:
                element.odp.x -
                Number(this.selectedsizepos[0].sizechangefact[0].heightWidth),
              y:
                element.odp.y -
                Number(this.selectedsizepos[0].sizechangefact[0].heightWidth),
            };
          if (this.selectedcssize == 1.5)
            element.dragposition = {
              x:
                element.odp.x -
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth),
              y:
                element.odp.y -
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth),
            };
          if (this.selectedcssize == 0.75)
            element.dragposition = {
              x: element.odp.x,
              y: element.odp.y,
            };
        }
        if (this.autosizeval) {
          if (element.tooltype == "frameband" || element.tooltype == "drop") {
            if (this.selectedcssize == 1)
              element.dragposition = {
                x:
                  element.odp.x -
                  Number(this.selectedsizepos[0].sizechangefact[0].heightWidth),
                y:
                  element.odp.y -
                  Number(this.selectedsizepos[0].sizechangefact[0].heightWidth),
              };
            if (this.selectedcssize == 1.5)
              element.dragposition = {
                x:
                  element.odp.x -
                  Number(this.selectedsizepos[0].sizechangefact[1].heightWidth),
                y:
                  element.odp.y -
                  Number(this.selectedsizepos[0].sizechangefact[1].heightWidth),
              };
            if (this.selectedcssize == 0.75)
              element.dragposition = {
                x: element.odp.x,
                y: element.odp.y,
              };
          }
        }
      });
    }
    if (this.productId == 3) {
      this.Stub_model.forEach((element) => {
        if (this.autosizeval) {
          if (element.tooltype == "item1") {
            if (this.selectedcssize == 1) {
              (this.designwidth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[0].heightWidth)),
                (this.designheigth =
                  125 +
                  Number(
                    this.selectedsizepos[0].sizechangefact[0].heightWidth
                  )),
                (element.dragposition = {
                  x:
                    element.odp.x -
                    Number(
                      this.selectedsizepos[0].sizechangefact[0].heightWidth
                    ) /
                      2,
                  y: element.odp.y,
                });
            }
            if (this.selectedcssize == 1.5) {
              this.designwidth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              this.designheigth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              element.dragposition = {
                x:
                  element.odp.x -
                  Number(
                    this.selectedsizepos[0].sizechangefact[1].heightWidth
                  ) /
                    2,
                y: element.odp.y,
              };
            }
            if (this.selectedcssize == 0.75) {
              this.designwidth = 125;
              this.designheigth = 125;
              element.dragposition = {
                x: element.odp.x,
                y: element.odp.y,
              };
            }
          }
          if (element.tooltype == "frameband") {
            if (this.selectedcssize == 1) {
              (this.framewidth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[0].heightWidth)),
                (this.frameheigth =
                  125 +
                  Number(
                    this.selectedsizepos[0].sizechangefact[0].heightWidth
                  )),
                (element.dragposition = {
                  x:
                    element.odp.x -
                    Number(
                      this.selectedsizepos[0].sizechangefact[0].heightWidth
                    ) /
                      2,
                  y: element.odp.y,
                });
            }
            if (this.selectedcssize == 1.5) {
              this.framewidth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              this.frameheigth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              element.dragposition = {
                x:
                  element.odp.x -
                  Number(
                    this.selectedsizepos[0].sizechangefact[1].heightWidth
                  ) /
                    2,
                y: element.odp.y,
              };
            }
            if (this.selectedcssize == 0.75) {
              this.framewidth = 125;
              this.frameheigth = 125;
              element.dragposition = {
                x: element.odp.x,
                y: element.odp.y,
              };
            }
          }
          if (element.tooltype == "drop") {
            if (this.selectedcssize == 1) {
              (this.dropwidth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[0].heightWidth)),
                (this.dropheigth =
                  125 +
                  Number(
                    this.selectedsizepos[0].sizechangefact[0].heightWidth
                  )),
                (element.dragposition = {
                  x:
                    element.odp.x -
                    Number(
                      this.selectedsizepos[0].sizechangefact[0].heightWidth
                    ) /
                      2,
                  y:
                    element.odp.y +
                    Number(
                      this.selectedsizepos[0].sizechangefact[0].heightWidth
                    ) /
                      2,
                });
            }
            if (this.selectedcssize == 1.5) {
              this.dropwidth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              this.dropheigth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              element.dragposition = {
                x:
                  element.odp.x -
                  Number(
                    this.selectedsizepos[0].sizechangefact[1].heightWidth
                  ) /
                    2,
                y:
                  element.odp.y +
                  Number(
                    this.selectedsizepos[0].sizechangefact[1].heightWidth
                  ) /
                    2,
              };
            }
            if (this.selectedcssize == 0.75) {
              this.dropwidth = 125;
              this.dropheigth = 125;
              element.dragposition = {
                x: element.odp.x,
                y: element.odp.y,
              };
            }
          }
        } else {
          if (element.tooltype == "item1") {
            if (this.selectedcssize == 1) {
              (this.designwidth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[0].heightWidth)),
                (this.designheigth =
                  125 +
                  Number(
                    this.selectedsizepos[0].sizechangefact[0].heightWidth
                  )),
                (element.dragposition = {
                  x:
                    element.odp.x -
                    Number(
                      this.selectedsizepos[0].sizechangefact[0].heightWidth
                    ) /
                      2,
                  y: element.odp.y,
                });
            }
            if (this.selectedcssize == 1.5) {
              this.designwidth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              this.designheigth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              element.dragposition = {
                x:
                  element.odp.x -
                  Number(
                    this.selectedsizepos[0].sizechangefact[1].heightWidth
                  ) /
                    2,
                y: element.odp.y,
              };
            }
            if (this.selectedcssize == 0.75) {
              this.designwidth = 125;
              this.designheigth = 125;
              element.dragposition = {
                x: element.odp.x,
                y: element.odp.y,
              };
            }
          }
          if (element.tooltype == "drop") {
            if (this.selectedcssize == 1) {
              (this.dropwidth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[0].heightWidth)),
                (this.dropheigth =
                  125 +
                  Number(
                    this.selectedsizepos[0].sizechangefact[0].heightWidth
                  )),
                (element.dragposition = {
                  x: element.odp.x,
                  y:
                    element.odp.y +
                    Number(
                      this.selectedsizepos[0].sizechangefact[0].heightWidth
                    ),
                });
            }
            if (this.selectedcssize == 1.5) {
              this.dropwidth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              this.dropheigth =
                125 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              element.dragposition = {
                x: element.odp.x,
                y:
                  element.odp.y +
                  Number(this.selectedsizepos[0].sizechangefact[1].heightWidth),
              };
            }
            if (this.selectedcssize == 0.75) {
              this.dropwidth = 125;
              this.dropheigth = 125;
              element.dragposition = {
                x: element.odp.x,
                y: element.odp.y,
              };
            }
          }
        }
      });
    }

    if (this.productId == 2) {
      this.Stub_model.forEach((element) => {
        if (this.autosizeval) {
          if (this.selectedcssize == 1) {
            this.frameheigth =
              200 +
              Number(this.selectedsizepos[0].sizechangefact[0].heightWidth);
            this.framewidth =
              200 +
              Number(this.selectedsizepos[0].sizechangefact[0].heightWidth);
            this.designheigth =
              200 +
              Number(this.selectedsizepos[0].sizechangefact[0].heightWidth);
            this.designwidth =
              200 +
              Number(this.selectedsizepos[0].sizechangefact[0].heightWidth);
            element.dragposition = {
              x:
                element.odp.x -
                Number(this.selectedsizepos[0].sizechangefact[0].heightWidth) /
                  2,
              y:
                element.odp.y -
                Number(this.selectedsizepos[0].sizechangefact[0].heightWidth) /
                  2,
            };
          }
          if (this.selectedcssize == 1.5) {
            this.frameheigth =
              200 +
              Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
            this.framewidth =
              200 +
              Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
            this.designheigth =
              200 +
              Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
            this.designwidth =
              200 +
              Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
            element.dragposition = {
              x:
                element.odp.x -
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth) /
                  2,
              y:
                element.odp.y -
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth) /
                  2,
            };
            // element.dragposition = {
            //   x:
            //     element.odp.x - Number(this.selectedsizepos[0].sizechangefact[1].heightWidth),
            //   y:
            //     element.odp.y + Number(this.selectedsizepos[0].sizechangefact[1].heightWidth),
            // };
          }
          if (this.selectedcssize == 0.75) {
            this.frameheigth = 200;
            this.framewidth = 200;
            this.designheigth = 200;
            this.designwidth = 200;
            // element.dragposition = {
            //   x: element.odp.x,
            //   y: element.odp.y,
            // };
          }
        } else {
          if (element.tooltype == "frameband") {
            this.frameheigth = 200;
            this.framewidth = 200;
          }
          if (element.tooltype == "item1") {
            if (this.selectedcssize == 1) {
              this.designheigth =
                200 +
                Number(this.selectedsizepos[0].sizechangefact[0].heightWidth);
              this.designwidth =
                200 +
                Number(this.selectedsizepos[0].sizechangefact[0].heightWidth);
              element.dragposition = {
                x:
                  element.odp.x -
                  Number(
                    this.selectedsizepos[0].sizechangefact[0].heightWidth
                  ) /
                    2,
                y:
                  element.odp.y -
                  Number(
                    this.selectedsizepos[0].sizechangefact[0].heightWidth
                  ) /
                    2,
              };
            }
            if (this.selectedcssize == 1.5) {
              this.designheigth =
                200 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              this.designwidth =
                200 +
                Number(this.selectedsizepos[0].sizechangefact[1].heightWidth);
              element.dragposition = {
                x:
                  element.odp.x -
                  Number(
                    this.selectedsizepos[0].sizechangefact[1].heightWidth
                  ) /
                    2,
                y:
                  element.odp.y -
                  Number(
                    this.selectedsizepos[0].sizechangefact[1].heightWidth
                  ) /
                    2,
              };
            }
            if (this.selectedcssize == 0.75) {
              this.designheigth = 200;
              this.designwidth = 200;
              element.dragposition = {
                x: element.odp.x,
                y: element.odp.y,
              };
            }
          }
        }
      });
    }
    let res = this.csFrameband.filter(
      (x) => x.id == this.centrestonedata?.frame_band_id
    );
    let cssizelist = [];
    res[0].cs_frameband.forEach((element) => {
      cssizelist.push(element.csSize);
    });
    let listimage = [];
    let cszize;
    if (this.selectedcssize == 1.5) cszize = cssizelist[2];
    if (this.selectedcssize == 1) cszize = cssizelist[1];
    if (this.selectedcssize == 0.75 || this.selectedcssize == 0)
      cszize = cssizelist[0];
    listimage = res[0].cs_image_comm.filter((x) => x.csSize == cszize);
    this.Stub_model.forEach((element) => {
      if (element.tooltype == "frameband") {
        listimage.forEach((imageelement) => {
          if (
            imageelement.Position == element.position &&
            imageelement.selectColor == this.selectedColor
          ) {
            element.img_path = imageelement.images;
          }
        });
      }
    });
    this.centrestonedata.csSize = this.selectedcssize;
    this.setImageValue();
    this.LongDesignPredefineService.getFrontendCenteStoneCustomizationCost(
      this.centrestonedata
    ).subscribe((data) => {
      this.predefinedDetail = data["data"]["predefinedetail"];
      this.setpricing(data);
    });
  }

  setImageValue() {
    if (this.productType == "ld") {
      this.predefinedDetailTop = [];
      this.predefinedDetailMid = [];
      this.predefinedDetailDrop = [];
      for (const iterator of this.customizationPredefinedetail?.top) {
        let res = iterator.image.filter(
          (x) => x.selectColor == this.selectedColor
        );
        if (res.length > 0) {
          this.predefinedDetailTop.push(iterator);
        }
      }
      for (const iterator of this.customizationPredefinedetail?.mid) {
        let res = iterator.image.filter(
          (x) => x.selectColor == this.selectedColor
        );
        if (res.length > 0) {
          this.predefinedDetailMid.push(iterator);
        }
      }
      for (const iterator of this.customizationPredefinedetail?.drop) {
        let res = iterator.image.filter(
          (x) => x.selectColor == this.selectedColor
        );
        if (res.length > 0) {
          this.predefinedDetailDrop.push(iterator);
        }
      }
    } else if (this.productType == "cs") {
      this.csDrop = [];
      this.csDesign1 = [];
      this.csDesign2 = [];
      this.csDesign3 = [];
      this.csFrameband = [];
      for (const iterator of this.customizationPredefinedetail?.frameband) {
        let res: any;
        res = iterator.cs_image_comm.filter(
          (x) => x.selectColor == this.selectedColor
        );
        if (res.length > 0) {
          this.csFrameband.push(iterator);
        }
      }
      for (const iterator of this.customizationPredefinedetail?.drop) {
        let res = iterator.image.filter(
          (x) => x.selectColor == this.selectedColor
        );
        if (res.length > 0) {
          this.csDrop.push(iterator);
        }
      }
      for (const iterator of this.customizationPredefinedetail?.design1) {
        let res = iterator.Image.filter(
          (x) => x.selectColor == this.selectedColor
        );

        if (iterator.type_id == 4) {
          iterator.name = iterator.design[0].name;
        }
        if (iterator.type_id == 3) {
          iterator.name = iterator.illusion[0].name;
        }
        if (iterator.type_id == 2) {
          let gemres = this.gemstoneList.filter(
            (x) => x.id == iterator.gemstone[0].name
          );
          if (res.length > 0)
            iterator.name = gemres[0].name + " | " + res[0].prongSelect;
          else iterator.name = gemres[0].name;
        }
        if (iterator.type_id == 1) {
          let gemres = this.merchantCenterVariantList.filter(
            (x) => x.id == iterator.variant_id
          );
          if (res.length > 0)
            iterator.name = gemres[0].name + " | " + res[0].prongSelect;
          else iterator.name = gemres[0].name;
        }
        // if(!!this.selectedGemstone) {
        //   if (res.length > 0 && iterator?.gemstone[0].color == this.selectedGemstone ) {
        //     this.csDesign1.push(iterator);
        //   }
        // } else {
        //   if (res.length > 0) {
        //     this.csDesign1.push(iterator);
        //   }
        // }
        if (res.length > 0) {
          this.csDesign1.push(iterator);
        }
      }
      for (const iterator of this.customizationPredefinedetail?.design2) {
        let res = iterator.Image.filter(
          (x) => x.selectColor == this.selectedColor
        );
        if (iterator.type_id == 4) {
          iterator.name = iterator.design[0].name;
        }
        if (iterator.type_id == 3) {
          iterator.name = iterator.illusion[0].name;
        }
        if (iterator.type_id == 2) {
          let gemres = this.gemstoneList.filter(
            (x) => x.id == iterator.gemstone[0].name
          );
          if (res.length > 0)
            iterator.name = gemres[0].name + " | " + res[0].prongSelect;
          else iterator.name = gemres[0].name;
        }
        if (iterator.type_id == 1) {
          let gemres = this.merchantCenterVariantList.filter(
            (x) => x.id == iterator.variant_id
          );
          if (res.length > 0)
            iterator.name = gemres[0].name + " | " + res[0].prongSelect;
          else iterator.name = gemres[0].name;
        }
        if (!!this.selectedGemstone) {
          if (
            res.length > 0 &&
            iterator.gemstone[0].color == this.selectedGemstone
          ) {
            this.csDesign2.push(iterator);
          }
        } else {
          if (res.length > 0) {
            this.csDesign2.push(iterator);
          }
        }
      }
      for (const iterator of this.customizationPredefinedetail?.design3) {
        let res = iterator.Image.filter(
          (x) => x.selectColor == this.selectedColor
        );
        if (iterator.type_id == 4) {
          iterator.name = iterator.design[0].name;
        }
        if (iterator.type_id == 3) {
          iterator.name = iterator.illusion[0].name;
        }
        if (iterator.type_id == 2) {
          let gemres = this.gemstoneList.filter(
            (x) => x.id == iterator.gemstone[0].name
          );
          if (res.length > 0)
            iterator.name = gemres[0].name + " | " + res[0].prongSelect;
          else iterator.name = gemres[0].name;
        }
        if (iterator.type_id == 1) {
          let gemres = this.merchantCenterVariantList.filter(
            (x) => x.id == iterator.variant_id
          );
          if (res.length > 0)
            iterator.name = gemres[0].name + " | " + res[0].prongSelect;
          else iterator.name = gemres[0].name;
        }
        if (res.length > 0) {
          this.csDesign3.push(iterator);
        }
      }
      if (this.displaywithcssize && !!this.selectShape) {
        let res = this.merchantCenterVariantList.filter(
          (x) => x.cs_shape == this.selectShape.cs_shape
        );

        let csFramebandResult = [];
        let csDesignResult1 = [];
        let csDesignResult2 = [];
        let csDesignResult3 = [];
        for (const iterator of this.csFrameband) {
          let temp = res.filter(
            (x) => x.id == iterator.cs_frameband[0].variant
          );
          if (temp.length > 0) {
            csFramebandResult.push(iterator);
          }
        }

        for (const iterator of this.csDesign1) {
          let temp = res.filter((x) => x.id == iterator.variant_id);
          let cssize;
          if (this.selectedcssize == 0.75 || this.selectedcssize == 0) {
            cssize = this.framecssizes[0];
          }
          if (this.selectedcssize == 1) {
            cssize = this.framecssizes[1];
          }
          if (this.selectedcssize == 1.5) {
            cssize = this.framecssizes[1];
          }
          if (temp.length > 0) {
            if (!!this.selectedGemstone) {
              if (iterator.type_id == 2) {
                if (this.selectedcssize == 0.75 || this.selectedcssize == 0) {
                  if (cssize == iterator.gemstone[0].csSize) {
                    if (!!this.selectedGemstone) {
                      if (iterator.gemstone[0].color == this.selectedGemstone) {
                        csDesignResult1.push(iterator);
                      }
                    } else csDesignResult1.push(iterator);
                  }
                }
                if (this.selectedcssize == 1) {
                  if (cssize == iterator.gemstone[1].csSize)
                    if (!!this.selectedGemstone) {
                      if (iterator.gemstone[0].color == this.selectedGemstone) {
                        csDesignResult1.push(iterator);
                      }
                    } else csDesignResult1.push(iterator);
                }
                if (this.selectedcssize == 1.5) {
                  if (cssize == iterator.gemstone[2].csSize)
                    if (!!this.selectedGemstone) {
                      if (iterator.gemstone[0].color == this.selectedGemstone) {
                        csDesignResult1.push(iterator);
                      }
                    } else csDesignResult1.push(iterator);
                }
              }
            } else {
              if (iterator.type_id == 1) {
                // if (this.selectedcssize == 0.75) {
                if (this.framecssizes[0] == iterator.diamond[0].csSize)
                  csDesignResult1.push(iterator);
                // }
                // if (this.selectedcssize == 1) {
                //   if (cssize == iterator.diamond[1]?.csSize)
                //     csDesignResult1.push(iterator);
                // }
                // if (this.selectedcssize == 1.5) {
                //   if (cssize == iterator.diamond[2]?.csSize)
                //     csDesignResult1.push(iterator);
                // }
              }
              if (iterator.type_id == 2) {
                // if (this.selectedcssize == 0.75) {
                if (this.framecssizes[0] == iterator.gemstone[0].csSize)
                  csDesignResult1.push(iterator);
                // }
                // if (this.selectedcssize == 1) {
                //   if (cssize == iterator.gemstone[1]?.csSize)
                //     csDesignResult1.push(iterator);
                // }
                // if (this.selectedcssize == 1.5) {
                //   if (cssize == iterator.gemstone[2]?.csSize)
                //     csDesignResult1.push(iterator);
                // }
              }

              if (iterator.type_id == 3) {
                // if (this.selectedcssize == 0.75) {
                if (this.framecssizes[0] == iterator.illusion[0].csSize)
                  csDesignResult1.push(iterator);
                // }
                // if (this.selectedcssize == 1) {
                //   if (cssize == iterator.illusion[1].csSize)
                //     csDesignResult1.push(iterator);
                // }
                // if (this.selectedcssize == 1.5) {
                //   if (cssize == iterator.illusion[2].csSize)
                //     csDesignResult1.push(iterator);
                // }
              }

              if (iterator.type_id == 4) {
                // if (this.selectedcssize == 0.75) {
                if (this.framecssizes[0] == iterator.design[0].csSize)
                  csDesignResult1.push(iterator);
                // }
                // if (this.selectedcssize == 1) {
                //   if (cssize == iterator.design[1].csSize)
                //     csDesignResult1.push(iterator);
                // }
                // if (this.selectedcssize == 1.5) {
                //   if (cssize == iterator.design[2].csSize)
                //     csDesignResult1.push(iterator);
                // }
              }
            }
            // csDesignResult1.push(iterator);
          }
        }
        for (const iterator of this.csDesign2) {
          let temp = res.filter((x) => x.id == iterator.variant_id);
          if (temp.length > 0) {
            csDesignResult2.push(iterator);
          }
        }
        for (const iterator of this.csDesign3) {
          let temp = res.filter((x) => x.id == iterator.variant_id);
          if (temp.length > 0) {
            csDesignResult3.push(iterator);
          }
        }
        this.csFrameband = csFramebandResult;
        this.csDesign1 = csDesignResult1;
        this.csDesign2 = csDesignResult2;
        this.csDesign3 = csDesignResult3;
      } else if (this.singlecssize && !!this.selectShape) {
        let res = this.merchantCenterVariantList.filter(
          (x) => x.cs_shape == this.selectShape.cs_shape
        );

        let csFramebandResult = [];
        let csDesignResult1 = [];
        let csDesignResult2 = [];
        let csDesignResult3 = [];
        for (const iterator of this.csFrameband) {
          let temp = res.filter(
            (x) => x.id == iterator.cs_frameband[0].variant
          );
          if (temp.length > 0) {
            csFramebandResult.push(iterator);
          }
        }

        for (const iterator of this.csDesign1) {
          let temp = res.filter((x) => x.id == iterator.variant_id);
          let cssize;
          if (this.selectedcssize == 0.75 || this.selectedcssize == 0) {
            cssize = this.framecssizes[0];
          }
          if (this.selectedcssize == 1) {
            cssize = this.framecssizes[1];
          }
          if (this.selectedcssize == 1.5) {
            cssize = this.framecssizes[1];
          }
          if (temp.length > 0) {
            if (!!this.selectedGemstone) {
              if (iterator.type_id == 2) {
                if (this.selectedcssize == 0.75 || this.selectedcssize == 0) {
                  if (cssize == iterator.gemstone[0].csSize) {
                    if (!!this.selectedGemstone) {
                      if (iterator.gemstone[0].color == this.selectedGemstone) {
                        csDesignResult1.push(iterator);
                      }
                    } else csDesignResult1.push(iterator);
                  }
                }
                if (this.selectedcssize == 1) {
                  if (cssize == iterator.gemstone[1].csSize)
                    if (!!this.selectedGemstone) {
                      if (iterator.gemstone[0].color == this.selectedGemstone) {
                        csDesignResult1.push(iterator);
                      }
                    } else csDesignResult1.push(iterator);
                }
                if (this.selectedcssize == 1.5) {
                  if (cssize == iterator.gemstone[2].csSize)
                    if (!!this.selectedGemstone) {
                      if (iterator.gemstone[0].color == this.selectedGemstone) {
                        csDesignResult1.push(iterator);
                      }
                    } else csDesignResult1.push(iterator);
                }
              }
            } else {
              if (iterator.type_id == 1) {
                if (this.framecssizes[0] == iterator.diamond[0].csSize)
                  csDesignResult1.push(iterator);
              }
              if (iterator.type_id == 2) {
                if (this.framecssizes[0] == iterator.gemstone[0].csSize)
                  csDesignResult1.push(iterator);
              }

              if (iterator.type_id == 3) {
                if (this.framecssizes[0] == iterator.illusion[0].csSize)
                  csDesignResult1.push(iterator);
              }

              if (iterator.type_id == 4) {
                if (this.framecssizes[0] == iterator.design[0].csSize)
                  csDesignResult1.push(iterator);
              }
            }
          }
        }
        for (const iterator of this.csDesign2) {
          let temp = res.filter((x) => x.id == iterator.variant_id);
          if (temp.length > 0) {
            csDesignResult2.push(iterator);
          }
        }
        for (const iterator of this.csDesign3) {
          let temp = res.filter((x) => x.id == iterator.variant_id);
          if (temp.length > 0) {
            csDesignResult3.push(iterator);
          }
        }
        this.csFrameband = csFramebandResult;
        this.csDesign1 = csDesignResult1;
        this.csDesign2 = csDesignResult2;
        this.csDesign3 = csDesignResult3;
      } else if (!this.displaywithcssize) {
        this.csDesign1 = this.csDesign1.filter(
          (x) => x.variant_id == this.predefinedDetail.design1.data.variant_id
        );
        this.csDesign2 = this.csDesign2.filter(
          (x) => x.variant_id == this.predefinedDetail.design2.data.variant_id
        );
      }
    }
  }
  recalculateprcing(data) {
    if (this.productType == "ld") {
      switch (data.designpart) {
        case "Top":
          this.longdesigndata.topval = data.id;
          break;
        case "Mid":
          this.longdesigndata.midval = data.id;
          break;
        case "Drop":
          this.longdesigndata.dropval = data.id;
          break;
        default:
          break;
      }
      this.LongDesignPredefineService.getFrontendLongDesignCustomizationCost(
        this.longdesigndata
      ).subscribe((data) => {
        console.log("🚀 ~ file: client-design-customize-page.component.ts:2141 ~ ClientDesignCustomizePageComponent ~ ).subscribe ~ data:", data)
        this.predefinedDetail = data["data"]["predefinedetail"];
        this.allData.predefinedetail = data["data"]["predefinedetail"];
        this.setpricing(data);
      });
    }
  }

  recalculateprcingcs(data, designpart) {
    this.centrestonedata.csSize = this.selectedcssize;
    switch (designpart) {
      case "drop":
        this.centrestonedata.drop_name = data.id;
        break;
      case "item1":
        this.centrestonedata.cs_predefine1 = data.id;
        break;
      case "item2":
        this.centrestonedata.cs_predefine2 = data.id;
        break;
      case "item3":
        this.centrestonedata.cs_predefine3 = data.id;
        break;
      case "frameband":
        this.centrestonedata.frame_band_id = data.id;
        break;
      default:
        break;
    }
    this.LongDesignPredefineService.getFrontendCenteStoneCustomizationCost(
      this.centrestonedata
    ).subscribe((data) => {
      this.predefinedDetail = data["data"]["predefinedetail"];
      this.allData.predefinedetail = data["data"]["predefinedetail"];
      this.setpricing(data);
    });
  }

  resetDesign() {
    this.ProductSubTypeService.getfrontendcustomizationdata({
      merchant_id: this.merchant_id,
      product_subtype_id: this.subproductID,
      predefine_id: this.predefinedId,
      type: this.productType,
    }).subscribe((data) => {
      if (data) {
        this.customizationData = data["data"];
        ///Root Image Data
        this.customizationRootImage = this.customizationData?.rootImage;
        this.customizationPredefinedata =
          this.customizationData.predefinedata[0];
        this.customizationPredefinedetail =
          this.customizationData.predefinedetail;
        this.customizationAnnotation = this.customizationData.annotation;

        console.log(
          "🚀 ~ file: client-design-customize-page.component.ts:1049 ~ ClientDesignCustomizePageComponent ~ resetDesign ~ this.customizationPredefinedetail:",
          this.customizationPredefinedetail
        );
        if (this.productType == "cs") {
          if (
            this.customizationPredefinedetail.frameband[0].cs_frameband[0]
              .noAUtoSizing == ""
          ) {
            this.autosizeval = true;
          } else {
            this.autosizeval = false;
          }
        }

        for (let i = 0; i < this.customizationRootImage.length; i++) {
          this.customizationRootImage[i].ModelImage =
            this.path +
            "/imagepreview/getImage?imagename=" +
            this.customizationRootImage[i].modelimage;
          this.customizationRootImage[i].resprestativeImg =
            this.path +
            "/imagepreview/getImage?imagename=" +
            this.customizationRootImage[i].representationImage;
        }
        this.rootImageData = this.customizationRootImage[0];
        // console.log("🚀 ~ file: client-design-customize-page.component.ts:2221 ~ ClientDesignCustomizePageComponent ~ resetDesign ~ this.rootImageData:", this.rootImageData)
        this.Stub = this.rootImageData.coord;
        this.NumberOfStub = this.Stub.length;

        this.Stub.forEach(element => {
          console.log("🚀 ~ file: client-design-customize-page.component.ts:2226 ~ ClientDesignCustomizePageComponent ~ resetDesign ~ element:", element.tooltype)
          if(element.tooltype =='Center Stone')
          this.centreStonepresent = true;
        });

        this.Stub_model = [];
        this.Stub_tree = [];
        ////Annotation data//
        for (const iterator of this.customizationAnnotation[0]
          .designcoordModel) {
          iterator.odp = iterator.dragposition;
          iterator.partid = 0;
          iterator.selectedColor = this.selectedColor;
          // iterator.midpartid = this.customizationPredefinedata.midval;
          // iterator.droppartid = this.customizationPredefinedata.dropval
          if (iterator.tooltype == "top")
            iterator.partid = this.customizationPredefinedata.topval;
          if (iterator.tooltype == "mid")
            iterator.partid = this.customizationPredefinedata.midval;
          if (iterator.tooltype == "drop")
            iterator.partid = this.customizationPredefinedata.dropval;
          if (iterator.tooltype == "frameband")
            iterator.partid = this.customizationPredefinedata.frame_band_id;
          if (iterator.tooltype == "item1")
            iterator.partid =
              this.customizationPredefinedata.cs_predefine[0].csDesign_name;
          if (iterator.tooltype == "item2")
            iterator.partid =
              this.customizationPredefinedata.cs_predefine[1].csDesign_name;
          if (iterator.tooltype == "item2")
            iterator.partid =
              this.customizationPredefinedata.cs_predefine[0].csDesign_name;
          this.Stub_model.push(iterator);
        }
        for (const iterator of this.customizationAnnotation[0].designcoord) {
          iterator.odp = iterator.dragposition;
          iterator.partid = 0;
          iterator.selectedColor = this.selectedColor;
          // iterator.midpartid = this.customizationPredefinedata.midval;
          // iterator.droppartid = this.customizationPredefinedata.dropval
          if (iterator.tooltype == "top")
            iterator.partid = this.customizationPredefinedata.topval;
          if (iterator.tooltype == "mid")
            iterator.partid = this.customizationPredefinedata.midval;
          if (iterator.tooltype == "drop")
            iterator.partid = this.customizationPredefinedata.dropval;
          if (iterator.tooltype == "frameband")
            iterator.partid = this.customizationPredefinedata.frame_band_id;
          if (iterator.tooltype == "item1")
            iterator.partid =
              this.customizationPredefinedata.cs_predefine[0].csDesign_name;
          if (iterator.tooltype == "item2")
            iterator.partid =
              this.customizationPredefinedata.cs_predefine[1].csDesign_name;
          if (iterator.tooltype == "item2")
            iterator.partid =
              this.customizationPredefinedata.cs_predefine[0].csDesign_name;
          this.Stub_tree.push(iterator);
        }
      }
      if (this.productType == "ld") {
        this.LongDesignPredefineService.getFrontendLongDesignPredefinebyid({
          id: this.predefinedId,
        }).subscribe((data) => {
          if (data) {
            this.allData = data["data"];
            this.predefinedData = data["data"]["predefinedata"];
            this.predefinedDetail = data["data"]["predefinedetail"];
            var JsonImgData = this.predefinedData.image;
            let arrayList = [];

            this.longdesigndata = {
              dropval: this.predefinedData.dropval,
              midval: this.predefinedData.midval,
              topval: this.predefinedData.topval,
              merchantid: this.predefinedData.merchantid,
              merchantCollection: this.predefinedData.merchantCollection[0],
              product_id: this.predefinedData.product_id,
            };

            for (let i = 0; i < JsonImgData.length; i++) {
              if (
                JsonImgData[i]?.displayUser === true &&
                JsonImgData[i]?.secondOption === false
              ) {
                arrayList.push(JsonImgData[i].images);
              }
              if (
                JsonImgData[i]?.secondOption === true &&
                JsonImgData[i]?.displayUser === false
              ) {
                arrayList.push(JsonImgData[i].images);
                JsonImgData.splice(i, 1);
              }
            }
            for (let i = 0; i < JsonImgData.length; i++) {
              arrayList.push(JsonImgData[i].images);
            }
            this.productViewImages = arrayList;
            this.setImageValue();
            this.setpricing(data);
          }
        });
      } else if (this.productType == "cs") {
        this.CenterStonePredefineService.getFrontendCenteStonePredefineById({
          id: this.predefinedId,
        }).subscribe((data) => {
          if (data) {
            this.allData = data["data"];
            this.predefinedData = data["data"]["predefinedata"];
            console.log(
              "🚀 ~ file: client-design-customize-page.component.ts:2259 ~ ClientDesignCustomizePageComponent ~ resetDesign ~ this.predefinedData:",
              this.predefinedData
            );
            this.predefinedDetail = data["data"]["predefinedetail"];
            // console.log(
            //   "🚀 ~ file: client-design-customize-page.component.ts:1013 ~ ClientDesignCustomizePageComponent ~ resetDesign ~ this.predefinedDetail:",
            //   this.predefinedDetail
            // );

            if (
              !!this.predefinedDetail.frameband.data &&
              this.predefinedDetail.frameband.data.length > 1
            ) {
              this.displaywithcssize = true;
              this.selectedcssize = 0.75;
              this.predefinedDetail.frameband.data.forEach((element) => {
                this.framecssizes.push(element.csSize);
              });
            }
            if (
              !!this.predefinedDetail.frameband.data &&
              this.predefinedDetail.frameband.data.length == 1
            ) {
              this.singlecssize = true;
              this.selectedcssize = 0;
              this.predefinedDetail.frameband.data.forEach((element) => {
                this.framecssizes.push(element.csSize);
              });
            }
            var JsonImgData = this.predefinedData.Image;
            for (let index = 0; index < JsonImgData.length; index++) {
              const element = JsonImgData[index].images;
              this.productViewImages.push(element);
            }
            if(this.centreStonepresent) {
            if (this.displaywithcssize || this.singlecssize) {
              let res = this.merchantCenterVariantList.filter(
                (x) => x.id == this.predefinedDetail.design1.data.variant_id
              );
              this.selectShape = this.shapes.filter(
                (x) => x.cs_shape == res[0].cs_shape
              )[0];
            } }

            this.centrestonedata = {
              frame_band_id: this.predefinedData.frame_band_id,
              cs_predefine1: this.predefinedData.cs_predefine[0].csDesign_name,
              cs_predefine2: this.predefinedData.cs_predefine[1]?.csDesign_name,
              cs_predefine3: this.predefinedData.cs_predefine[2]?.csDesign_name,
              drop_name: this.predefinedData.drop_name,
              merchantid: this.predefinedData.merchant_id,
              merchantCollection: this.predefinedData.merchantCollection[0],
              product_id: this.predefinedData.productid,
              csSize: this.selectedcssize,
            };
            this.setImageValue();
            this.setpricing(data);
          }
        });
      }
      this.showRemoveDrop = true;
      this.shoAddDrop = false;
    });
  }

  removeddroppart: any;
  removeDrop() {
    if (this.productType == "ld") {
      this.removeddroppart = this.longdesigndata.dropval;
      this.longdesigndata.dropval = null;
      this.LongDesignPredefineService.getFrontendLongDesignCustomizationCost(
        this.longdesigndata
      ).subscribe((data) => {
        this.predefinedDetail = data["data"]["predefinedetail"];
        this.setpricing(data);
      });
    } else {
      this.removeddroppart = this.centrestonedata.drop_name;
      this.centrestonedata.drop_name = null;
      this.LongDesignPredefineService.getFrontendCenteStoneCustomizationCost(
        this.centrestonedata
      ).subscribe((data) => {
        this.predefinedDetail = data["data"]["predefinedetail"];
        this.setpricing(data);
      });
    }
    this.Stub_model.forEach((element) => {
      if (element.tooltype === "drop") {
        this.dropImgPath = element.img_path;
        element.img_path = "";
      }
    });

    this.Stub_tree.forEach((element) => {
      if (element.tooltype === "drop") {
        this.dropImgPath = element.img_path;
        element.img_path = "";
      }
    });
    this.showRemoveDrop = false;
    this.shoAddDrop = true;
  }

  addDrop() {
    if (this.productType == "ld") {
      this.longdesigndata.dropval = this.removeddroppart;
      this.LongDesignPredefineService.getFrontendLongDesignCustomizationCost(
        this.longdesigndata
      ).subscribe((data) => {
        this.predefinedDetail = data["data"]["predefinedetail"];
        this.setpricing(data);
      });
    } else {
      this.centrestonedata.drop_name = this.removeddroppart;
      this.LongDesignPredefineService.getFrontendCenteStoneCustomizationCost(
        this.centrestonedata
      ).subscribe((data) => {
        this.predefinedDetail = data["data"]["predefinedetail"];
        this.setpricing(data);
      });
    }
    this.Stub_model.forEach((element) => {
      if (element.tooltype === "drop") {
        element.img_path = this.dropImgPath;
      }
    });
    this.Stub_tree.forEach((element) => {
      if (element.tooltype === "drop") {
        element.img_path = this.dropImgPath;
      }
    });
    this.showRemoveDrop = true;
    this.shoAddDrop = false;
    this.removeddroppart = "";
  }

  setpricing(data) {
    if (this.productType == "ld") {
      this.calculationPart = this.predefinedDetail.totalgold;

      this.KTValues = [...new Set(this.calculationPart.map((item) => item.kt))];

      for (let index = 0; index < this.KTValues.length; index++) {
        if (this.KTValues[index] == 18) this.goldkt = this.KTValues[index];
      }

      let res = this.calculationPart.filter((x) => x.kt == this.goldkt)[0];

      this.goldrate = parseFloat(res.rate).toFixed(3);

      let goldprice: any = Number(res.rate) * Number(res.wt);
      this.goldprice = parseFloat(goldprice).toFixed(3);

      this.goldwt = parseFloat(res.wt).toFixed(3);

      this.DiamondValues = [
        ...new Set(this.predefinedDetail.totaldiamond.map((item) => item.type)),
      ];
      this.diamondval = [];
      this.gemstoneval = [];
      this.DiamondSolitaireValues = [];
      this.diamondval = this.predefinedDetail.totaldiamond?.[0];
      this.dropCalData = this.predefinedDetail.drop.cal?.gemstoneResult;
      this.topCalData = this.predefinedDetail.top.cal?.gemstoneResult;
      this.midCalData = this.predefinedDetail.mid.cal?.gemstoneResult;
      this.DropGemstoneNatural = [];
      this.MidGemstoneNatural = [];
      this.TopGemstoneNatural = [];
      if (this.predefinedDetail.totalgemstone.length > 0) {
        if (this.predefinedDetail.totalgemstone[0] == "NA") {
          this.gemstoneval = this.predefinedDetail.totalgemstone;
        } else {
          this.GemstoneNatural = this.predefinedDetail.totalgemstone.filter(
            (item) => item.type == "Natural"
          );

          this.GesmtoneSynthetic = this.predefinedDetail.totalgemstone.filter(
            (item) => item.type == "Synthetic"
          );
          if (this.GesmtoneSynthetic.length > 0) {
            this.showQualityList("Synthetic");
          }
          if (
            this.GemstoneNatural.length > 0 &&
            this.GesmtoneSynthetic.length == 0
          ) {
            this.showQualityList("Natural");
          }
        }
      }

      if (this.topCalData?.length > 0) {
        if (this.topCalData[0] == "NA") {
          this.gemstoneval = this.topCalData;
        } else {
          this.TopGemstoneNatural = this.topCalData.filter(
            (item) => item.type == "Natural"
          );

          this.TopGesmtoneSynthetic = this.topCalData.filter(
            (item) => item.type == "Synthetic"
          );

          if (this.TopGesmtoneSynthetic.length > 0) {
            this.showQualityList("Synthetic");
          }
          if (
            this.TopGemstoneNatural.length > 0 &&
            this.TopGesmtoneSynthetic.length == 0
          ) {
            this.showQualityList("Natural");
          }
        }
      }

      if (this.midCalData?.length > 0) {
        if (this.midCalData[0] == "NA") {
          this.gemstoneval = this.midCalData;
        } else {
          this.MidGemstoneNatural = this.midCalData.filter(
            (item) => item.type == "Natural"
          );

          this.MidGesmtoneSynthetic = this.midCalData.filter(
            (item) => item.type == "Synthetic"
          );

          if (this.MidGesmtoneSynthetic.length > 0) {
            this.showQualityList("Synthetic");
          }
          if (
            this.MidGemstoneNatural.length > 0 &&
            this.MidGesmtoneSynthetic.length == 0
          ) {
            this.showQualityList("Natural");
          }
        }
      }

      if (this.dropCalData?.length > 0) {
        if (this.dropCalData[0] == "NA") {
          this.gemstoneval = this.dropCalData;
        } else {
          this.DropGemstoneNatural = this.dropCalData.filter(
            (item) => item.type == "Natural"
          );

          this.DropGesmtoneSynthetic = this.dropCalData.filter(
            (item) => item.type == "Synthetic"
          );

          if (this.DropGesmtoneSynthetic.length > 0) {
            this.showQualityList("Synthetic");
          }
          if (
            this.DropGemstoneNatural.length > 0 &&
            this.DropGesmtoneSynthetic.length == 0
          ) {
            this.showQualityList("Natural");
          }
        }
      }

      this.calculateTotal();
    } else {
      this.calculationPart = this.predefinedDetail.totalgold;
      this.DiamondValues = [
        ...new Set(this.predefinedDetail.totaldiamond.map((item) => item.type)),
      ];
      let res;
      if (this.productID == 1 || this.productID == 4) {
        this.brSizeValues = [
          ...new Set(this.calculationPart.map((item) => item.brsize)),
        ];

        this.selectSize = this.brSizeValues.reduce((a, b) => Math.min(a, b)); // 1
        res = this.calculationPart.filter(
          (x) => x.brsize == this.selectSize && x.kt == this.goldkt
        )[0];
      } else {
        res = this.calculationPart.filter((x) => x.kt == this.goldkt)[0];
      }

      this.KTValues = [...new Set(this.calculationPart.map((item) => item.kt))];

      for (let index = 0; index < this.KTValues.length; index++) {
        if (this.KTValues[index] == 18) this.goldkt = this.KTValues[index];
      }
      this.diamondval = [];
      this.gemstoneval = [];
      this.DiamondSolitaireValues = [];
      this.goldrate = parseFloat(res.rate).toFixed(3);
      let goldprice: any = Number(res.rate) * Number(res.wt);
      this.goldprice = parseFloat(goldprice).toFixed(3);
      this.goldwt = parseFloat(res.wt).toFixed(3);

      // this.DiamondValues = [
      //   ...new Set(this.predefinedDetail.totaldiamond.map((item) => item.type)),
      // ];
      this.DiamondSolitaireValues = [
        ...new Set(
          this.predefinedDetail.totalsolitaire.map((item) => item.type)
        ),
      ];
      //

      // if (!!this.selectSize) {
      //   this.diamondval = this.predefinedDetail.totaldiamond.filter(
      //     (x) => x.brsize == this.selectSize
      //   )[0];
      // } else {
      //   this.diamondval = this.predefinedDetail.totaldiamond?.[0];
      // }
      this.diamondval = this.predefinedDetail?.totaldiamond?.[0];
      let prediamondval = this.diamondval;
      if(!!this.selectSize) {
        this.diamondval = this.predefinedDetail.totaldiamond.filter(
          (x) =>x.brsize == this.selectSize
        )[0];
      } 
      if(!this.diamondval) {
        this.diamondval = prediamondval;
      }                

      this.diamondActiveClass = this.diamondval?.type;
      // this.diamondval = this.predefinedDetail.totaldiamond?.[0];
      this.diamondsolitaireval = this.predefinedDetail.totalsolitaire?.[0];
      this.design1calData =
        this.predefinedDetail.design1?.calc[0]?.gemstoneResult;
      this.framebandcalData =
        this.predefinedDetail.framband?.calc[0]?.gemstoneResult;
      // if(this.predefinedDetail.design2 != {});
      this.design2calData =
        this.predefinedDetail.design2?.calc[0]?.gemstoneResult;
      this.design3calData =
        this.predefinedDetail.design3?.calc[0]?.gemstoneResult;
      this.dropcalData = this.predefinedDetail.drop?.calc[0]?.gemstoneResult;

      if (this.predefinedDetail.totalgemstone.length > 0) {
        if (this.predefinedDetail.totalgemstone[0] == "NA") {
          this.gemstoneval = this.predefinedDetail.totalgemstone;
        } else {
          this.GemstoneNatural = this.predefinedDetail.totalgemstone.filter(
            (item) => item.type == "Natural"
          );

          this.GesmtoneSynthetic = this.predefinedDetail.totalgemstone.filter(
            (item) => item.type == "Synthetic"
          );
          if (this.GesmtoneSynthetic.length > 0) {
            this.showQualityList("Synthetic");
          }
          if (
            this.GemstoneNatural.length > 0 &&
            this.GesmtoneSynthetic.length == 0
          ) {
            this.showQualityList(data);
          }
        }
      }

      // /center stone
      if (this.design1calData?.length > 0) {
        if (this.design1calData[0] == "NA") {
          this.gemstoneval = this.design1calData;
        } else {
          this.Design1GemstoneNatural = this.design1calData.filter(
            (item) => item.type == "Natural"
          );

          this.Design1GesmtoneSynthetic = this.design1calData.filter(
            (item) => item.type == "Synthetic"
          );

          if (this.Design1GesmtoneSynthetic.length > 0) {
            this.showQualityList("Synthetic");
          }
          if (
            this.Design1GemstoneNatural.length > 0 &&
            this.Design1GesmtoneSynthetic.length == 0
          ) {
            this.showQualityList(data);
          }
        }
      }

      // design2
      if (this.design2calData?.length > 0) {
        if (this.design2calData[0] == "NA") {
          this.gemstoneval = this.design2calData;
        } else {
          this.Design2GemstoneNatural = this.design2calData.filter(
            (item) => item.type == "Natural"
          );

          this.Design2GesmtoneSynthetic = this.design2calData.filter(
            (item) => item.type == "Synthetic"
          );

          if (this.Design2GesmtoneSynthetic.length > 0) {
            this.showQualityList("Synthetic");
          }
          if (
            this.Design2GemstoneNatural.length > 0 &&
            this.Design2GesmtoneSynthetic.length == 0
          ) {
            this.showQualityList(data);
          }
        }
      }

      // design3

      if (this.design3calData?.length > 0) {
        if (this.design3calData[0] == "NA") {
          this.gemstoneval = this.design3calData;
        } else {
          this.Design3GemstoneNatural = this.design3calData.filter(
            (item) => item.type == "Natural"
          );

          this.Design3GesmtoneSynthetic = this.design3calData.filter(
            (item) => item.type == "Synthetic"
          );

          if (this.Design3GesmtoneSynthetic.length > 0) {
            this.showQualityList("Synthetic");
          }
          if (
            this.Design3GemstoneNatural.length > 0 &&
            this.Design3GesmtoneSynthetic.length == 0
          ) {
            this.showQualityList(data);
          }
        }
      }

      ///Drop//
      if (this.dropcalData?.length > 0) {
        if (this.dropcalData[0] == "NA") {
          this.gemstoneval = this.dropcalData;
        } else {
          this.DropGemstoneNatural = this.dropcalData.filter(
            (item) => item.type == "Natural"
          );

          this.DropGesmtoneSynthetic = this.dropcalData.filter(
            (item) => item.type == "Synthetic"
          );

          if (this.DropGesmtoneSynthetic.length > 0) {
            this.showQualityList("Synthetic");
          }
          if (
            this.DropGemstoneNatural.length > 0 &&
            this.DropGesmtoneSynthetic.length == 0
          ) {
            this.showQualityList(data);
          }
        }
      }

      //frame/
      if (this.framebandcalData?.length > 0) {
        if (this.framebandcalData[0] == "NA") {
          this.gemstoneval = this.framebandcalData;
        } else {
          this.FrameGemstoneNatural = this.framebandcalData.filter(
            (item) => item.type == "Natural"
          );

          this.FrameGesmtoneSynthetic = this.framebandcalData.filter(
            (item) => item.type == "Synthetic"
          );

          if (this.FrameGesmtoneSynthetic.length > 0) {
            this.showQualityList("Synthetic");
          }
          if (
            this.FrameGemstoneNatural.length > 0 &&
            this.FrameGesmtoneSynthetic.length == 0
          ) {
            this.showQualityList(data);
          }
        }
      }

      this.calculateTotal();
      // }
    }
  }
}
