import { Component } from "@angular/core";
import { VendordiamondrateService } from "@/_services/vendordiamondrate.service";
import { AlertService } from "@/_services";
import { FormBuilder } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { merchantBannerService } from "@/_services/merchant-banner.service";

@Component({
  selector: "app-client-design-product-listing-page",
  templateUrl: "./client-design-product-listing-page.component.html",
  styleUrls: ["./client-design-product-listing-page.component.css"],
})
export class ClientDesignProductListingPageComponent {
  vendorcompanyname;
  merchant_id: number;
  vendoruniquekey;
  collectionList: any = [];
  bannerList: any = [];
  subproductID: any;
  predefinedList: any = [];
  url_companyname;
  collectionid: any;
  productType: any;
  productName: any;
  productSubList: any=[];
  productSubtypeList: any=[];
  productId: any;
  getSubProductList: any =[];
  productSubName: string;
  product: any;



  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private VendordiamondrateService: VendordiamondrateService,
    private ProductSubTypeService: ProductSubTypeService,
    private merchantBannerService: merchantBannerService
  ) {
    //   this.vendoruniquekey = this.route.snapshot.paramMap.get("vendoruniquekey");
    // var this.url_companyname = this.route.snapshot.paramMap.get("companyname");
    let companyUrl: any = []
    let data = this.router.url
    companyUrl = data.split('/');
    console.log('companyUrl:', companyUrl);
    

    this.url_companyname = companyUrl[1];
    this.vendoruniquekey = companyUrl[2];
    this.product = companyUrl[3];
    this.productName = companyUrl[4];
    this.productId = companyUrl[5];

    this.subproductID = JSON.parse(this.route.snapshot.paramMap.get("subProductid"));


    localStorage.setItem("vendorcompany", this.url_companyname);
    localStorage.setItem("vendorkey", this.vendoruniquekey);

    this.VendordiamondrateService.vendordetailwithuniquekey(this.vendoruniquekey).subscribe((data: any) => {
      this.merchant_id = data.id;
      this.vendorcompanyname = data.company;

        //// Subproduct  list end////

        if(this.product === 'product'){
          this.ProductSubTypeService.getfrontendProductSubtype({merchantid: this.merchant_id})
          .subscribe(data => {
            this.productSubList =data['data'];
            
            this.getSubProductList = this.productSubList.filter(f => (f.product_id  == this.productId))
            console.log('this.getSubProductList:', this.getSubProductList);
            
          });
        }

    });
  }

  ngOnInit() {

  }

  replaceAll(input: string, find: string, replace: string): string {
    return input.replace(new RegExp(find, 'g'), replace);
  }

  

  //// product  list end////
  goToListing(subProductid){
    this.productName = this.replaceAll(subProductid.productname, ' ', '');
    this.productSubName = this.replaceAll(subProductid.name, ' ', '');
    var det = this.url_companyname + "/" + this.vendoruniquekey + '/' +  this.productName + "/" + this.productSubName + "/" + 'subproduct' + "/" + subProductid.id;
    this.router.navigate( [det]);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  goToHome(){
    var det = this.url_companyname + "/" + this.vendoruniquekey;
    this.router.navigate([det]);
  }

  goToSub(data){
    console.log('data:', data);
    var det = this.url_companyname + "/" + this.vendoruniquekey;
    this.router.navigate([det]);
  }

}