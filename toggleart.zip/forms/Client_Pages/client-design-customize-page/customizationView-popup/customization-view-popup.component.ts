import { Component } from "@angular/core";
import { OwlOptions } from 'ngx-owl-carousel-o';


@Component({
  selector: "app-customization-view-popup",
  templateUrl: "./customization-view-popup.component.html",
  styleUrls: ["./customization-view-popup.component.css"],
})
export class CustomizationViewPopupComponent {
  bannerOptions: OwlOptions = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 500,
    margin: 15,
    center: true,
    autoplay: false,
    autoplayTimeout: 5000,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    responsive: {
      0: {
        items: 1,
        nav: false,
      },
      400: {
        items: 1,
        nav: false,
      },
      740: {
        items: 1,
        nav: true,
      },
      940: {
        items: 1,
        nav: true,
      },
      1200: {
        items: 1,
        nav: true,
      },
    },
  };

  getBannerData = [
    {
      src: '../../../../assets/images/Dropuneven.jpg',
      name: 'Peppa pig',
    },
    {
      src: '../../../../assets/images/Dropuneven.jpg',
      name: 'Peppa pig',
    },
  ];


    constructor(

    ) {}
   
    ngOnInit() {
     
      }

     

      backToDesign(){
        
      }
}