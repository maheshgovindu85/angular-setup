import { Component, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { OwlOptions } from 'ngx-owl-carousel-o';
import { DiamondShapeService, GemstoneService } from "@/_services";
export interface DialogData {
  image: any;
  gold: string;
  goldkt: string;
  id: string;
  diamond: string;
  gemstone: string;
  design: any;
  vendor_id: any;
  solitaire:string;
  cs_image_comm: any;
  partname: string;
  designpart:string;
}


@Component({
  selector: "app-customization-view-popup",
  templateUrl: "./customization-view-popup.component.html",
  styleUrls: ["./customization-view-popup.component.css"],
})

export class CustomizationViewPopupComponent {
  isDiamond: boolean = false;
  isGemstone: boolean =false;
  isSolitaire: boolean = false;
  

  bannerOptions: OwlOptions = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 500,
    margin: 15,
    center: true,
    autoplay: false,
    autoplayTimeout: 5000,
    navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
    responsive: {
      0: {
        items: 1,
        nav: false,
      },
      400: {
        items: 1,
        nav: false,
      },
      740: {
        items: 1,
        nav: true,
      },
      940: {
        items: 1,
        nav: true,
      },
      1200: {
        items: 1,
        nav: true,
      },
    },
  };

  getBannerData = [
    {
      src: '../../../../assets/images/Dropuneven.jpg',
      name: 'Peppa pig',
    },
    {
      src: '../../../../assets/images/Dropuneven.jpg',
      name: 'Peppa pig',
    },
  ];
  popData: DialogData;
  predeifnedImagesv: any=[];
  diamondData: any=[];
  gemstoneData: any=[];
  goldData: any=[];
  solitaireData:any=[];
  diamondShapeList: any=[];
  filteredDiamondShapeList: any;
  shape_id:any;
  matchingshape: any;
  gemstoneName: any;
  gemstone12: any;
  
 


    constructor(
      public dialogRef: MatDialogRef<CustomizationViewPopupComponent>,
      private DiamondShapeService: DiamondShapeService,
      private Gemstoneservice:GemstoneService,
      @Inject(MAT_DIALOG_DATA) public data: DialogData

    ) {
      
   this.DiamondShapeService.getAll().subscribe((data) => {
      if (data) {
          this.diamondShapeList = data;
           this.filteredDiamondShapeList=this.diamondShapeList.filter((c)=>
           (c.id==this.diamondData[0].shape));
          this.diamondData[0].shape=this.filteredDiamondShapeList[0]?.shape;
      }
    });

    this.Gemstoneservice.getAll().subscribe((data)=>{
      if(data){
          this.gemstoneName=data;
          for (let i = 0; i < this.gemstoneData.length; i++) {
            this.gemstone12 = this.gemstoneData[i];
            const filteredList = this.gemstoneName.filter((c) =>
              c.id ==  this.gemstone12.name
            );
              this.gemstone12.name = filteredList[0]?.name;
          }
      }
    })

  


    this.popData = data['data']
    console.log(' this.popData:',  this.popData);
    this.predeifnedImagesv= this.popData.image || this.popData.cs_image_comm
    console.log('this.predeifnedImagesv:', this.predeifnedImagesv);
    this.diamondData= this.popData.diamond 
   console.log('abc1',this.diamondData);
   
    
    if(this.diamondData[0].nos !== "" &&
       this.diamondData[0].shape !== "" && 
      this.diamondData[0].twt !== ""&& 
      this.diamondData[0].type  !== ""&& 
      this.diamondData[0].wt !== "") {
      this.isDiamond = true;
    }else{
      this.isDiamond = false;
    }   
        
    this.gemstoneData= this.popData.gemstone
    if(this.gemstoneData[0].nos !== "" &&
    this.gemstoneData[0].shape !== "" && 
   this.gemstoneData[0].twt !== ""&& 
   this.gemstoneData[0].type  !== ""&& 
   this.gemstoneData[0].wt !== "") {
   this.isGemstone = true;
 }else{
   this.isGemstone = false;
 }   
    this.goldData= this.popData.gold
    console.log('this.predeifnedImagesv:', this.predeifnedImagesv);
    this.solitaireData=this.popData.solitaire


    }
   
    ngOnInit() {
     
      }
     

      backToDesign(){
        this.dialogRef.close();
      }


      
      
}