import { Component } from "@angular/core";
import { VendordiamondrateService } from "@/_services/vendordiamondrate.service";
import { AlertService } from "@/_services";
import { FormBuilder } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { merchantBannerService } from "@/_services/merchant-banner.service";
import { CenterStonePredefineService } from "@/_services/cs_predefine.service";
import { LongDesignPredefineService } from "@/_services/long-design-predefine.service";
import { CollectionService } from "@/_services/collection.service";
import { filter } from "rxjs/operators";
import { MerchantCollectionService } from "@/_services/merchant-collection.service";

@Component({
  selector: "app-client-design-listing-page",
  templateUrl: "./client-design-listing-page.component.html",
  styleUrls: ["./client-design-listing-page.component.css"],
})
export class ClientDesignListingPageComponent {
  vendorcompanyname;
  merchant_id: number;
  vendoruniquekey;
  collectionList: any = [];
  bannerList: any = [];
  subproductID: any;
  predefinedList: any = [];
  url_companyname;
  collectionid: any;
  productType: any;
  productName: any;
  subProduct: string;
  calculationPart: any;
  predefinedDetail: any;
  KTValues: any = [];
  predefinedType: string;
  predefinedid: any;
  goldkt: unknown;
  goldrate: string;
  goldprice: string;
  goldwt: string;
  DiamondValues: any = [];
  diamondval: any;
  dropCalData: any;
  topCalData: any;
  midCalData: any;
  gemstoneval: any = [];
  GemstoneNatural: any;
  GesmtoneSynthetic: any;
  TopGemstoneNatural: any;
  TopGesmtoneSynthetic: any;
  MidGemstoneNatural: any;
  MidGesmtoneSynthetic: any;
  DropGemstoneNatural: any;
  DropGesmtoneSynthetic: any;
  diamondsolitaireval: any;
  total: string;
  gsttotal: string;
  grandtotal: number;
  productID: number;
  brSizeValues: any = [];
  selectSize: any;
  DiamondSolitaireValues: any = [];
  design1calData: any;
  framebandcalData: any;
  design2calData: any;
  design3calData: any;
  dropcalData: any;
  Design1GemstoneNatural: any;
  Design1GesmtoneSynthetic: any;
  Design2GemstoneNatural: any;
  Design2GesmtoneSynthetic: any;
  Design3GemstoneNatural: any;
  Design3GesmtoneSynthetic: any;
  collection: any;
  Collection_name: any;
  collectionData: any;
  filteredCollections: any;
  predefinedName: any;
  listCollection: any = [];
  collectionId: any;

  constructor(
    private router: Router,
    private Collectionservice: CollectionService,
    private route: ActivatedRoute,
    private VendordiamondrateService: VendordiamondrateService,
    private ProductSubTypeService: ProductSubTypeService,
    private merchantBannerService: merchantBannerService,
    private LongDesignPredefineService: LongDesignPredefineService,
    private centerstonPredefinedService: CenterStonePredefineService,
    private MerchantCollectionService: MerchantCollectionService
  ) {
    let companyUrl: any = [];
    let data = this.router.url;
    companyUrl = data.split("/");

    this.url_companyname = companyUrl[1];
    this.vendoruniquekey = companyUrl[2];
    this.productName = decodeURIComponent(companyUrl[3]);
    this.predefinedName = companyUrl[4];
    this.collectionId = companyUrl[4];
    console.log("this.collectionId:", this.collectionId);

    this.productType = companyUrl[5];

    this.subproductID = JSON.parse(
      this.route.snapshot.paramMap.get("subProductid")
    );
    this.collectionid = JSON.parse(
      this.route.snapshot.paramMap.get("collectionid")
    );
    this.collection = companyUrl[3];

    localStorage.setItem("vendorcompany", this.url_companyname);
    localStorage.setItem("vendorkey", this.vendoruniquekey);

    this.VendordiamondrateService.vendordetailwithuniquekey(
      this.vendoruniquekey
    ).subscribe((data: any) => {
      this.merchant_id = data.id;
      this.vendorcompanyname = data.company;

      /////Front end predefined list ////
      if (this.productType === "subproduct") {
        this.ProductSubTypeService.getpredefinebysubproductid({
          merchant_id: this.merchant_id,
          productsubtypeid: this.subproductID,
        }).subscribe((data) => {
          if (data) {
            this.predefinedList = data["data"];

            this.calculateprice(this.predefinedList);
          }
        });
      }

      /////Front end Collection  list ////
      if (this.collection === "collection") {
        this.ProductSubTypeService.getpredefinebycollectionid({
          merchant_id: this.merchant_id,
          collection_id: this.collectionid,
        }).subscribe((data) => {
          if (data) {
            this.predefinedList = data["data"];
            this.calculateprice(this.predefinedList);
          }
        });

        this.MerchantCollectionService.getAll().subscribe((data) => {
          if (data) {
            this.listCollection = data["data"].filter((x) => x.isactive == "Y");

            this.filteredCollections = this.listCollection.filter(
              (c) => c.id == this.collectionId
            );
            console.log("this.filteredCollections:", this.filteredCollections);
            this.Collection_name = this.filteredCollections[0]?.name;
            console.log("this.Collection_name:", this.Collection_name);
          }
        });
      }
    });
  }

  ngOnInit() {}

  replaceAll(input: string, find: string, replace: string): string {
    return input.replace(new RegExp(find, "g"), replace);
  }

  goProductPage(data) {
    var det =
      this.url_companyname +
      "/" +
      this.vendoruniquekey +
      "/" +
      "product" +
      "/" +
      this.productName +
      "/" +
      data[0].product_id;
    console.log("det:", det);
    this.router.navigate([det]);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  goToProductView(data) {
    let type = data.type;

    if (type === "ld") {
      var det =
        this.url_companyname +
        "/" +
        this.vendoruniquekey +
        "/viewproduct/" +
        data.type +
        "/" +
        data.product_id +
        "/" +
        data.product_subtype_id +
        "/" +
        data.id;
      this.router.navigate([det]);
    } else if (type === "cs") {
      var det =
        this.url_companyname +
        "/" +
        this.vendoruniquekey +
        "/viewproduct/" +
        data.type +
        "/" +
        data.product_id +
        "/" +
        data.product_subtype_id +
        "/" +
        data.id;
      this.router.navigate([det]);
    }
  }

  goToCustomization(data) {
    var det =
      this.url_companyname +
      "/" +
      this.vendoruniquekey +
      "/customization/" +
      data.type +
      "/" +
      data.id +
      "/" +
      data.product_subtype_id +
      "/" +
      data.product_id;
    this.router.navigate([det]);
  }

  goToHome() {
    var det = this.url_companyname + "/" + this.vendoruniquekey;
    this.router.navigate([det]);
  }
  goToSub(data) {
    var det = this.url_companyname + "/" + this.vendoruniquekey;
    this.router.navigate([det]);
  }
  goToProduct(data) {
    var det = this.url_companyname + "/" + this.vendoruniquekey;
    this.router.navigate([det]);
  }

  calculateprice(data) {
    for (const element of data) {
      // element.grandtotal = 'NA'
      if (element.type === "ld") {
        this.LongDesignPredefineService.getFrontendLongDesignPredefinebyid({
          id: element.id,
        }).subscribe((data) => {
          if (data) {
            this.predefinedDetail = data["data"]["predefinedetail"];
            
            this.calculationPart = this.predefinedDetail.totalgold;

            this.KTValues = [
              ...new Set(this.calculationPart.map((item) => item.kt)),
            ];

            for (let index = 0; index < this.KTValues.length; index++) {
              if (this.KTValues[index] == 18)
                this.goldkt = this.KTValues[index];
            }

            let res = this.calculationPart.filter(
              (x) => x.kt == this.goldkt
            )[0];

            this.goldrate = parseFloat(res.rate).toFixed(3);
            let goldprice: any = Number(res.rate) * Number(res.wt);
            this.goldprice = parseFloat(goldprice).toFixed(3);
            this.goldwt = parseFloat(res.wt).toFixed(3);

            this.DiamondValues = [
              ...new Set(
                this.predefinedDetail.totaldiamond.map((item) => item.type)
              ),
            ];

            this.diamondval = this.predefinedDetail.totaldiamond?.[0];
            this.gemstoneval= [];
            if (this.predefinedDetail.totalgemstone.length > 0) {
              if (this.predefinedDetail.totalgemstone[0] == "NA") {
                this.gemstoneval = this.predefinedDetail.totalgemstone;
              } else {
                this.GemstoneNatural =
                  this.predefinedDetail.totalgemstone.filter(
                    (item) => item.type == "Natural"
                  );

                this.GesmtoneSynthetic =
                  this.predefinedDetail.totalgemstone.filter(
                    (item) => item.type == "Synthetic"
                  );
                if (this.GesmtoneSynthetic.length > 0) {
                  for (const ele of this.GesmtoneSynthetic) {
                    let data = {
                      type: ele.type,
                      shape: ele.shape,
                      name: ele.name,
                      wt: ele.wt,
                      rate: ele.rate1,
                      price: ele.price1,
                    };
                    this.gemstoneval.push(data);
                    
                  }
                }
              }
            }
            
            let totalmake: any =
              this.predefinedDetail.makingcharges * Number(this.goldwt);
            let totalmakingcharges = parseFloat(totalmake).toFixed(3);
            const gemstonesum = this.gemstoneval.reduce(
              (accumulator, object) => {
                return accumulator + Number(object.price);
              },
              0
            );
            let tot: any = Number(this.goldprice) + Number(totalmakingcharges);

            if (this.diamondval?.price)
              tot = tot + Number(this.diamondval?.price);
            if (this.diamondsolitaireval?.price)
              tot = tot + Number(this.diamondsolitaireval?.price);
            if (gemstonesum) tot = tot + Number(gemstonesum);

            this.total = parseFloat(tot).toFixed(3);

            let gst: any = 0.03 * Number(this.total);

            this.gsttotal = parseFloat(gst).toFixed(3);
            let gt: any = Number(this.total) + Number(this.gsttotal);

            this.grandtotal = Math.round(gt);
            element.grandtotal = this.grandtotal;
          }
        });
      } else if (element.type === "cs") {
        this.centerstonPredefinedService
          .getFrontendCenteStonePredefineById({ id: element.id })
          .subscribe((data) => {
            if (data) {
              this.predefinedDetail = data["data"]["predefinedetail"];
              this.calculationPart = this.predefinedDetail.totalgold;
              this.KTValues = [
                ...new Set(this.calculationPart.map((item) => item.kt)),
              ];

              for (let index = 0; index < this.KTValues.length; index++) {
                if (this.KTValues[index] == 18)
                  this.goldkt = this.KTValues[index];
              }
              let res;
              if (element.product_id == 1 || element.product_id == 4) {
                this.brSizeValues = [
                  ...new Set(this.calculationPart.map((item) => item.brsize)),
                ];

                this.selectSize = this.brSizeValues.reduce((a, b) =>
                  Math.min(a, b)
                ); // 1
                res = this.calculationPart.filter(
                  (x) => x.brsize == this.selectSize && x.kt == this.goldkt
                )[0];
              } else {
                res = this.calculationPart.filter(
                  (x) => x.kt == this.goldkt
                )[0];
              }

              this.goldrate = parseFloat(res.rate).toFixed(3);
              let goldprice: any = Number(res.rate) * Number(res.wt);
              this.goldprice = parseFloat(goldprice).toFixed(3);
              this.goldwt = parseFloat(res.wt).toFixed(3);

              this.DiamondValues = [
                ...new Set(
                  this.predefinedDetail.totaldiamond.map((item) => item.type)
                ),
              ];
              this.DiamondSolitaireValues = [
                ...new Set(
                  this.predefinedDetail.totalsolitaire.map((item) => item.type)
                ),
              ];
              this.diamondval = this.predefinedDetail.totaldiamond?.[0];
              this.diamondsolitaireval =
                this.predefinedDetail.totalsolitaire?.[0];

              if (this.predefinedDetail.totalgemstone.length > 0) {
                if (this.predefinedDetail.totalgemstone[0] == "NA") {
                  this.gemstoneval = this.predefinedDetail.totalgemstone;
                } else {
                  this.GemstoneNatural =
                    this.predefinedDetail.totalgemstone.filter(
                      (item) => item.type == "Natural"
                    );

                  this.GesmtoneSynthetic =
                    this.predefinedDetail.totalgemstone.filter(
                      (item) => item.type == "Synthetic"
                    );
                  if (this.GesmtoneSynthetic.length > 0) {
                    for (const ele of this.GesmtoneSynthetic) {
                      let data = {
                        type: ele.type,
                        shape: ele.shape,
                        name: ele.name,
                        wt: ele.wt,
                        rate: ele.rate1,
                        price: ele.price1,
                      };
                      this.gemstoneval.push(data);
                    }
                  }
                }
              }

              let totalmake: any =
                this.predefinedDetail.makingcharges * Number(this.goldwt);
              let totalmakingcharges = parseFloat(totalmake).toFixed(3);
              const gemstonesum = this.gemstoneval.reduce(
                (accumulator, object) => {
                  return accumulator + Number(object.price);
                },
                0
              );
              let tot: any =
                Number(this.goldprice) + Number(totalmakingcharges);

              if (this.diamondval?.price)
                tot = tot + Number(this.diamondval?.price);
              if (this.diamondsolitaireval?.price)
                tot = tot + Number(this.diamondsolitaireval?.price);
              if (gemstonesum) tot = tot + Number(gemstonesum);

              this.total = parseFloat(tot).toFixed(3);

              let gst: any = 0.03 * Number(this.total);

              this.gsttotal = parseFloat(gst).toFixed(3);
              let gt: any = Number(this.total) + Number(this.gsttotal);

              this.grandtotal = Math.round(gt);
              element.grandtotal = this.grandtotal;
            }
          });
      }
    }
  }
  showQualityList(arg0: string) {
    throw new Error("Method not implemented.");
  }
  calculateTotal() {
    throw new Error("Method not implemented.");
  }
}
