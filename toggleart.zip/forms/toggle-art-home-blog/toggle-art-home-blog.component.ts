import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toggle-art-home-blog',
  templateUrl: './toggle-art-home-blog.component.html',
  styleUrls: ['./toggle-art-home-blog.component.css']
})
export class ToggleArtHomeBlogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
