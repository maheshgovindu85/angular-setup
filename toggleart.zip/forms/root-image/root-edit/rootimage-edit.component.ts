import { customMethod } from "@/masters/common.master";
import { rootImage } from "@/_models/root_image";
import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { ProductTypeService } from "@/_services/product-type.service";
import { rootImageService } from "@/_services/root_image.service";
import { VendorService } from "@/_services/vendor.service";
import { CdkDragEnd } from "@angular/cdk/drag-drop";
import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { environment } from "environments/environment";

@Component({
  selector: "app-rootimage-edit",
  templateUrl: "./rootimage-edit.component.html",
  styleUrls: ["./rootimage-edit.component.css"],
})
export class RootImageEditComponent implements OnInit {
  rootImageForm: FormGroup;
  submitted: boolean;
  productList: any = [];
  productSubList: any = [];
  list: any = [];
  merchantList: any = [];
  selectSubList: any = [];
  // dataObj: { base64format: any; representationImage: string; };
  datarepresentationObj: any;
  dataModelObj: any;
  representationImagePath: any;
  public path = `${environment.apiUrl}`;
  modelimage: any;
  representationImage: any;
  showImage: boolean = true;
  rootimage_id: any;
  rootimage: any;
  customMethod = customMethod;
  dragPositionTop = { x: 0, y: 0 };
  dragPositionMid = { x: 0, y: 0 };
  dragPositionDrop = { x: 0, y: 0 };
  xInitial: 0;
  yInitial: 0;
  filteredProductSubList: any = [];
  modelImagePath: any;
  representImagePath: any;
  public adminId = `${environment.adminId}`;
  vendor_id: number;
  merchant_id: any;
  earingPendant: boolean = false;
  ringBracelet: boolean = false;
  allProduct: boolean = false;
  Stub: any[] = [];
  NumberOfStub: number = 0;
  product_id: any;
  displaySubProductList: any = [];
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private producttypeService: ProductTypeService,
    private ProductSubTypeService: ProductSubTypeService,
    private vendorservices: VendorService,
    private authenticationService: AuthenticationService,
    private rootImageService: rootImageService,
    private route: ActivatedRoute,
    private vendorauthenticationService: VendorAuthenticationService
  ) {
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id =
        this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.rootimage_id = this.route.snapshot.params.id;
    // this.getProductSubTypeData();
    this.createForm();
    this.getProductList();
    this.getMerchantList();
    this.getAllProductById();
  }

  get f() {
    return this.rootImageForm.controls;
  }

  createForm() {
    this.rootImageForm = this.formBuilder.group({
      product_id: ["", Validators.required],
      merchant_id: [this.merchant_id, Validators.required],
      product_subtype_id: ["", Validators.required],
      representationImage: [""],
      modelimage: [""],
      color: [""],
      customizationmethod: ["", Validators.required],
      coord: [""],
    });
  }

  getAllProductById() {
    this.rootImageService
      .getRootImagebyid({ id: this.rootimage_id })
      .subscribe((data) => {
        if (data) {
          this.setFormValue(data);
        }
      });
  }

  setFormValue(data) {
    this.rootimage = data.data;
    this.rootImageForm
      .get("customizationmethod")
      ?.setValue(this.rootimage[0].customizationmethod);
    this.rootImageForm
      .get("product_id")
      ?.setValue(this.rootimage[0].product_id);
    this.rootImageForm
      .get("merchant_id")
      ?.setValue(this.rootimage[0].merchant_id);

    this.representationImagePath =
      this.path +
      "/imagepreview/getImage?imagename=" +
      this.rootimage[0].representationImage;
    this.modelImagePath =
      this.path +
      "/imagepreview/getImage?imagename=" +
      this.rootimage[0].modelimage;
    this.Stub = this.rootimage[0].coord;
    this.NumberOfStub = this.Stub.length;
    this.rootImageForm
      .get("product_subtype_id")
      ?.setValue(this.rootimage[0].product_subtype_id);
      this.rootImageForm
      .get("color")
      ?.setValue(this.rootimage[0].color);
      this.merchant_id = this.rootimage[0].merchant_id;
      this.getProductSubTypeData();
    this.productChange();
    console.log('here');
  }
  //// product  list////

  getProductList() {
    this.producttypeService.getAll().subscribe((data) => {
      if (data) {
        //
        setTimeout(() => {
          this.productList = data;
        });
      }
    });
  }
  //// product  list end////

  //// product sub type list////
  getProductSubTypeData() {
    this.ProductSubTypeService.getProductsubtypebyMerchantId({
      merchantid: this.merchant_id,
    }).subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.productSubList = this.list.data;
          this.selectSubList = this.productSubList;
          this.displaySubProductList = this.selectSubList.filter(
            (c) =>
              c.merchantid === this.merchant_id &&
              c.product_id === this.rootImageForm.value.product_id
          );
        });
      }
    });
  }
  //// product sub type list End////

  ////merchant list

  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantList = data.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });
        });
      }
    });
  }
  ////onUploadSelect list
  onRepresentationImageSelect(files: File[]) {
    var base64value;
    const reader = new FileReader();

    reader.readAsDataURL(files[0]);
    reader.onload = (event: any) => {
      this.representationImagePath = (<FileReader>event.target).result;
      if (event.target.result) {
        base64value = event.target.result;
        this.datarepresentationObj = {
          base64format: base64value,
          representationImage: files[0].name,
        };

        this.ProductSubTypeService.upload(this.datarepresentationObj).subscribe(
          (data) => {
            this.representationImage = data["data"];
            this.representationImagePath =
              this.path + "/imagepreview/getImage?imagename=" + data["data"];
          }
        );
      }
    };
  }

  ////merchant list
  onModelImageSelect(files: File[]) {
    var base64valueModel;
    const readerModel = new FileReader();
    readerModel.readAsDataURL(files[0]);
    readerModel.onload = (event: any) => {
      this.modelImagePath = (<FileReader>event.target).result;
      if (event.target.result) {
        base64valueModel = event.target.result;
        this.dataModelObj = {
          base64format: base64valueModel,
          modelimage: files[0].name,
        };
        // this.rootimage.get('modelimage').setValue(files[0].name);

        this.ProductSubTypeService.upload(this.dataModelObj).subscribe(
          (data) => {
            this.modelimage = data["data"];
          }
        );
      }
    };
  }

  // dragEndTop($event: CdkDragEnd) {
  //   let element = $event.source.getRootElement();
  //   let boundingClientRect = element.getBoundingClientRect();
  //   let parentPosition = this.getPosition(element);
  //   this.rootImageForm
  //     .get("topx")
  //     .setValue(boundingClientRect.x - parentPosition.left);
  //   this.rootImageForm
  //     .get("topy")
  //     .setValue(boundingClientRect.y - parentPosition.top);
  // }

  // dragEndMid($event: CdkDragEnd) {
  //   let element = $event.source.getRootElement();
  //   let boundingClientRect = element.getBoundingClientRect();
  //   let parentPosition = this.getPosition(element);
  //   this.rootImageForm
  //     .get("midx")
  //     .setValue(boundingClientRect.x - parentPosition.left);
  //   this.rootImageForm
  //     .get("midy")
  //     .setValue(boundingClientRect.y - parentPosition.top);
  // }
  // dragEndDrop($event: CdkDragEnd) {
  //   let element = $event.source.getRootElement();
  //   let boundingClientRect = element.getBoundingClientRect();
  //   let parentPosition = this.getPosition(element);
  //   this.rootImageForm
  //     .get("dropx")
  //     .setValue(boundingClientRect.x - parentPosition.left);
  //   this.rootImageForm
  //     .get("dropy")
  //     .setValue(boundingClientRect.y - parentPosition.top);
  // }

  getPosition(el) {
    let x = 0;
    let y = 0;
    while (el && !isNaN(el.offsetLeft) && !isNaN(el.offsetTop)) {
      x += el.offsetLeft - el.scrollLeft;
      y += el.offsetTop - el.scrollTop;
      el = el.offsetParent;
    }
    return { top: y, left: x };
  }

  merchantChange(event: any) {
    this.merchant_id = event.value;
    this.displaySubProductList = this.selectSubList.filter(
      (c) =>
        c.merchantid === this.merchant_id &&
        c.product_id === this.rootImageForm.value.product_id
    );
    let itm = this.displaySubProductList[0];
    // this.rootImageForm.controls["product_subtype_id"].setValue(itm.merchantid);
  }

  productChange() {
    this.product_id = this.rootImageForm.value.product_id;
    this.displaySubProductList = this.productSubList.filter(
      (c) =>
        c.product_id === this.product_id && c.merchantid === this.merchant_id
    );

    if (
      this.rootImageForm.value.customizationmethod == "Center Stone Design" &&
      this.product_id == 2
    ) {
      this.earingPendant = true;
      this.allProduct = false;
      this.ringBracelet = false;
    } else if (
      this.rootImageForm.value.customizationmethod == "Center Stone Design" &&
      this.product_id == 3
    ) {
      this.earingPendant = true;
      this.allProduct = false;
      this.ringBracelet = false;
    } else if (
      this.rootImageForm.value.customizationmethod == "Center Stone Design" &&
      this.product_id == 1
    ) {
      this.ringBracelet = true;
      this.allProduct = false;
      this.earingPendant = false;
    } else if (
      this.rootImageForm.value.customizationmethod == "Center Stone Design" &&
      this.product_id == 4
    ) {
      this.ringBracelet = true;
      this.allProduct = false;
      this.earingPendant = false;
    } else if (this.rootImageForm.value.customizationmethod == "Long Design") {
      this.allProduct = true;
      this.ringBracelet = false;
      this.earingPendant = false;
    }
  }

  AddDragDot(e, type) {
    this.addDragDot(e, type);
  }
  addDragDot(e, type) {
    this.Stub.push({
      id: this.NumberOfStub,
      flatIndex: type + "_" + this.NumberOfStub,
      IDNumber: 0,
      addFrom: "insert",
      compontIndex: this.NumberOfStub,
      tooltype: type,
      dragType: type,
      offsetX: 0,
      offsetY: 0,
      valid: false,
      dragposition: {
        x: 0,
        y: 0,
      },
    });
    // const image = type.target.cloneNode();

    this.NumberOfStub++;
    var capa1_load = setInterval(() => {
      var cls = ".stubNumber_" + this.NumberOfStub;
      if (document.querySelector(cls)) {
        clearInterval(capa1_load);
        // var parents_elm = document.querySelector(cls);
        // parents_elm.appendChild(image);
        this.NumberOfStub++;
        if (type == "addon") {
          type.target.style.height = 45 + "px";
          type.target.style.width = 45 + "px";
        } else {
          type.target.style.height = 65 + "px";
          type.target.style.width = 65 + "px";
        }
      }
    }, 0);
  }

  onDragEnded(event, i) {
    let data = event.source.getFreeDragPosition();
    // let element = event.source.getRootElement();
    // let boundingClientRect = element.getBoundingClientRect();
    // let parentPosition = this.getPosition(element);
    var InnerID = event.source.element.nativeElement.children[1].innerHTML;

    this.Stub.forEach((e) => {
      if (e.id === InnerID * 1) {
        // (e.offsetX = boundingClientRect.x - parentPosition.left),
        //   (e.offsetY = boundingClientRect.y - parentPosition.top);
        // e.dragposition.x = e.offsetX;
        // e.dragposition.y = e.offsetY;
        e.dragposition = data;
      }
    });
  }

  delete_stub(i: number, id: number) {
    this.Stub.forEach((element, index) => {
      if (element.id === id) {
        var ckk = false;
        if (!ckk) {
          this.NumberOfStub = this.NumberOfStub - 1;
          this.Stub.splice(index, 1);
        } else {
          alert("This tool are link with some model image..!");
        }
      }
    });
    for (let index = 0; index < this.Stub.length; index++) {
      this.Stub[index].id = index;
      this.Stub[index].compontIndex = index;
      this.Stub[index].flatIndex =
        "Flat " + this.Stub[index].tooltype + "_" + index;
      this.NumberOfStub = index + 1;
    }

    var autoincrement_id = 0;
  }

  onSubmit() {
    this.submitted = true;
    if (this.rootImageForm.valid) {
      this.rootImageForm.value.representationImage = this.representationImage;
      this.rootImageForm.value.modelimage = this.modelimage;
      this.rootImageForm.value.id = this.rootimage_id;      
      this.rootImageForm.value.coord = this.Stub;

       this.rootImageService
        .updateRootImage(this.rootImageForm.value)
        .subscribe((data: rootImage) => {
          this.alertService.success("Root Image updated successfully!", true);
          this.router.navigate(["rootImage/list"]);
        });
    }
  }
  backToList() {
    this.router.navigate(["rootImage/list"]);
  }

  subProductChange(event) {
    let produdtId = event.value;
    this.filteredProductSubList = this.productSubList.filter(
      (c) => c.product_id === produdtId
    );
    let itm = this.filteredProductSubList[0];
    // this.rootImageForm.controls["product_subtype_id"].setValue(itm.product_id);
  }

  selectImage() {
    this.showImage = true;
  }

  dragPosition = { x: 100, y: 100 };

  changePosition() {
    this.dragPosition = {
      x: this.dragPosition.x + 50,
      y: this.dragPosition.y + 50,
    };
  }

  showCOlor(event: any) {
    this.rootImageForm.get("color")?.setValue(event.value);
  }
  removeColor() {
    this.rootImageForm.value.color = "";
    this.rootImageForm.get("color")?.setValue("");
  }
}
