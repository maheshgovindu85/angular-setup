import { ProductSubtype } from "@/_models/productsubtype";
import { AlertService, AuthenticationService } from "@/_services";
import { rootImageService } from "@/_services/root_image.service";
import {Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { Router } from "@angular/router";

@Component({
    selector: "app-rootimage-list",
    templateUrl: "./rootimage-list.component.html",
    styleUrls: ["./rootimage-list.component.css"],
  })

export class RootImageListComponent implements OnInit {
  
  list: any=[];
  searchForm: FormGroup;
  rootImageData:any =[];
  isChecked:boolean;
  activeStatus: any;
  rootImageList: any=[];
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private rootImageService: rootImageService,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
  ) {
    if (!this.authenticationService.currentUserValue) {
    }
  }

  ngOnInit() {
    this.getRootImage();
    this.createSearchForm();
   }
   

   getRootImage(){
    this.rootImageService.getAll()
     .subscribe(data => {
       if (data) {
         setTimeout(() => {
           this.list = data;
          this.rootImageData = this.list.data;
          for(let i =0; i <this.rootImageData.length;i++){
           this.rootImageData[i].isactive = this.rootImageData[i].isactive === 'N' ? false : true;
           this.rootImageData[i].SrNo = i+1;
         }
          
         this.rootImageList = this.rootImageData
         });
       }
     });
 }

// Search button function start
createSearchForm() {
 this.searchForm = this.formBuilder.group({
   keyword: [''],
 });
}
clear() {
 this.searchForm.get('keyword')?.setValue('');
 this.searchGrid();
}
searchGrid() {
 let keyword = this.searchForm.controls['keyword'].value;
 if (keyword === '') {
   this.rootImageList = this.rootImageData;
 } else {
   keyword = keyword.toLowerCase();
   this.rootImageList = this.rootImageData.filter((event) => {
     return (
       (event.product_sub_type && event.product_sub_type.toLowerCase().includes(keyword)) ||
       (event.productname && event.productname.toLowerCase().includes(keyword)) ||
       (event.merchantname && event.merchantname.toLowerCase().includes(keyword)) ||
       (event.merchantid===Number(keyword)) 
     );
   });
 }
}

}