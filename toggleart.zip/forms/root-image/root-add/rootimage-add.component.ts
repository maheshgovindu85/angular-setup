import { AlertService, AuthenticationService, VendorAuthenticationService } from "@/_services";
import { ProductTypeService } from "@/_services/product-type.service";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { VendorService } from "@/_services/vendor.service";
import { rootImageService } from "@/_services/root_image.service";


import { environment } from "environments/environment";
import { rootImage } from "@/_models/root_image";
import { CdkDragEnd } from "@angular/cdk/drag-drop";
import { customMethod } from "@/masters/common.master";

@Component({
  selector: "app-rootimage-add",
  templateUrl: "./rootimage-add.component.html",
  styleUrls: ["./rootimage-add.component.css"],
})
export class RootImageAddComponent implements OnInit {
  rootImageForm: FormGroup;
  submitted: boolean;
  productList: any = [];
  productSubList: any = [];
  list: any = [];
  merchantList: any = [];
  selectSubList: any = [];
  customMethod = customMethod;
  // dataObj: { base64format: any; representationImage: string; };
  datarepresentationObj: any;
  dataModelObj: any;
  representationImagePath: any;
  public path=`${environment.apiUrl}`;
  modelimage: any;
  representationImage: any;
  showImage: boolean = false;
  merchant_id: any;
  product_id:  any;
  displaySubProductList: any=[];
  public adminId = `${environment.adminId}`;
  vendor_id:number;
  dragPositionTop = { x: 0, y: 0 };
  dragPositionMid = { x: 0, y: 0 };
  dragPositionDrop = { x: 0, y: 0 };
  earingPendant: boolean =false;
  ringBracelet: boolean =false;
  allProduct: boolean = false;
  Stub: any[] = [];
  NumberOfStub: number =0;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private producttypeService: ProductTypeService,
    private ProductSubTypeService: ProductSubTypeService,
    private vendorservices: VendorService,
    private authenticationService: AuthenticationService,
    private rootImageService: rootImageService,
    private vendorauthenticationService: VendorAuthenticationService,

  ) {
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id =
        this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.createForm();
    this.getProductList();
    this.getMerchantList();
    this.getProductSubTypeData();
  }

  get f() {
    return this.rootImageForm.controls;
  }

  createForm() {
    this.rootImageForm = this.formBuilder.group({
      product_id: ["", Validators.required],
      merchant_id: [this.merchant_id, Validators.required],
      product_subtype_id: ["", Validators.required],
      representationImage: ["", Validators.required],
      modelimage: ["", Validators.required],
      color: [""],
      customizationmethod: ["", Validators.required],
      coord: [""],
      // topx: [""],
      // topy: [""],
      // midx: [""],
      // midy: [""],
      // dropx: [""],
      // dropy: [""],
      // centerdesign:[''],
      // centerstone:[''],
      // design1:[''],
      // design2:[''],
      // stone1:[''],
      // stone2:[''],
      // band:[''],
      // frame:[''],
      // drop:['']
    });
  }

  //// product  list////

  getProductList() {
    this.producttypeService.getAll().subscribe((data) => {
      if (data) {
        //
        setTimeout(() => {
          this.productList = data;
          // this.rootImageForm.controls["product_id"].setValue(1);
        });
      }
    });
  }
  //// product  list end////

  //// product sub type list////

  getProductSubTypeData() {
    this.ProductSubTypeService.getavailablesubproduct().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.productSubList = this.list.data;
          this.selectSubList = this.productSubList;
        });
      }
    });
  }
  //// product sub type list End////

  ////merchant list

  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantList = data.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });
        });
      }
    });
  }
  ////onUploadSelect list
  onRepresentationImageSelect(files: File[]) {
    var base64value;
    const reader = new FileReader();

    reader.readAsDataURL(files[0]);
    reader.onload = (event: any) => {
      if (event.target.result) {
        base64value = event.target.result;
        this.datarepresentationObj = {
          base64format: base64value,
          representationImage: files[0].name,
        };
        this.ProductSubTypeService.upload(this.datarepresentationObj).subscribe((data) => {          
          this.representationImage = data['data'];
          this.representationImagePath = this.path + "/imagepreview/getImage?imagename=" + data['data'];
        });
      }
    };
  }

  ////merchant list
  onModelImageSelect(files: File[]) {
    var base64valueModel;
    const readerModel = new FileReader();
    readerModel.readAsDataURL(files[0]);
    readerModel.onload = (event: any) => {
      if (event.target.result) {
        base64valueModel = event.target.result;
        this.dataModelObj = {
          base64format: base64valueModel,
          representationImage: files[0].name,
        };
        this.ProductSubTypeService.upload(this.dataModelObj).subscribe((data) => {
          this.modelimage= data['data'];
        });
      }
    };
  }

  // dragEndTop($event: CdkDragEnd) {
  //   let element = $event.source.getRootElement();
  //   let boundingClientRect = element.getBoundingClientRect();
  //   let parentPosition = this.getPosition(element);
  //   this.rootImageForm
  //     .get("topx")
  //     .setValue(boundingClientRect.x - parentPosition.left);
  //   this.rootImageForm
  //     .get("topy")
  //     .setValue(boundingClientRect.y - parentPosition.top);
  // }

  // dragEndMid($event: CdkDragEnd) {
  //   let element = $event.source.getRootElement();
  //   let boundingClientRect = element.getBoundingClientRect();
  //   let parentPosition = this.getPosition(element);
  //   this.rootImageForm
  //     .get("midx")
  //     .setValue(boundingClientRect.x - parentPosition.left);
  //   this.rootImageForm
  //     .get("midy")
  //     .setValue(boundingClientRect.y - parentPosition.top);
  // }
  // dragEndDrop($event: CdkDragEnd) {
  //   let element = $event.source.getRootElement();
  //   let boundingClientRect = element.getBoundingClientRect();
  //   let parentPosition = this.getPosition(element);
  //   this.rootImageForm
  //     .get("dropx")
  //     .setValue(boundingClientRect.x - parentPosition.left);
  //   this.rootImageForm
  //     .get("dropy")
  //     .setValue(boundingClientRect.y - parentPosition.top);
  // }

  getPosition(el) {
    let x = 0;
    let y = 0;
    while (el && !isNaN(el.offsetLeft) && !isNaN(el.offsetTop)) {
      x += el.offsetLeft - el.scrollLeft;
      y += el.offsetTop - el.scrollTop;
      el = el.offsetParent;
    }
    return { top: y, left: x };
  }

  onSubmit() {
    this.submitted = true;
    if(this.rootImageForm.valid) {
      this.rootImageForm.value.representationImage = this.representationImage;
      this.rootImageForm.value.modelimage = this.modelimage;
      this.rootImageForm.value.coord = this.Stub;
      this.rootImageService.save(this.rootImageForm.value).subscribe((data: rootImage) => {
        this.alertService.success('Root Image saved successfully!', true);
        this.router.navigate(['rootImage/list']);
      });
    }
  }
  backToList() {
    this.router.navigate(["rootImage/list"]);
  }

  productChange(event) {
    this.product_id  = event.value;
    this.displaySubProductList = this.productSubList.filter(
      (c) => c.product_id === this.product_id  && c.merchantid === this.merchant_id
    );

    if (this.rootImageForm.value.customizationmethod == 'Center Stone Design' && this.product_id == 2) {
      this.earingPendant = true;
      this.allProduct = false;
      this.ringBracelet = false;
    } else if (this.rootImageForm.value.customizationmethod == 'Center Stone Design' && this.product_id == 3) {
      this.earingPendant = true;
      this.allProduct = false;
      this.ringBracelet = false;
    }else if(this.rootImageForm.value.customizationmethod == 'Center Stone Design' && this.product_id == 1){
      this.ringBracelet = true;
      this.allProduct = false;
      this.earingPendant = false;
    }else if(this.rootImageForm.value.customizationmethod == 'Center Stone Design' && this.product_id == 4){
      this.ringBracelet = true;
      this.allProduct = false;
      this.earingPendant = false;
    }else if(this.rootImageForm.value.customizationmethod == 'Long Design'){
      this.allProduct = true;
      this.ringBracelet = false;
      this.earingPendant = false;
    }
  }

  AddDragDot(e, type){
    this.addDragDot(e, type);
  }
  addDragDot(e, type){
    this.Stub.push({
      id: this.NumberOfStub,
      flatIndex: type + "_" + this.NumberOfStub,
      IDNumber: 0,
      addFrom: "insert",
      compontIndex: this.NumberOfStub,
      tooltype: type,
      dragType:type,
      offsetX: 0,
      offsetY: 0,
      valid: false,
      dragposition: {
        x: 0, y:0
      }
    });
    const image = type.target.cloneNode();

    this.NumberOfStub++;
    var capa1_load = setInterval(() => {
      var cls = ".stubNumber_" + this.NumberOfStub;
      if (document.querySelector(cls)) {
        clearInterval(capa1_load);
        var parents_elm = document.querySelector(cls);
        parents_elm.appendChild(image);
        this.NumberOfStub++;
        if (type == "addon") {
          type.target.style.height = 45 + "px";
          type.target.style.width = 45 + "px";
        } else {
          type.target.style.height = 65 + "px";
          type.target.style.width = 65 + "px";
        }
      }
    }, 0);
   
  }

  onDragEnded(event) {
    let data = event.source.getFreeDragPosition();
    // let element = event.source.getRootElement();
    // let boundingClientRect = element.getBoundingClientRect();
    // let parentPosition = this.getPosition(element);
    var InnerID = event.source.element.nativeElement.children[1].innerHTML;

    this.Stub.forEach((e) => {
      if (e.id === InnerID * 1) {
        // (e.offsetX = boundingClientRect.x - parentPosition.left),
        //   (e.offsetY = boundingClientRect.y - parentPosition.top);
        //   e.dragposition.x = e.offsetX;
        //   e.dragposition.y = e.offsetY;
        e.dragposition = data;        
      }
    });
  }


  delete_stub(i: number, id: number) {
    this.Stub.forEach((element, index) => {
      if (element.id === id) {

        var ckk = false;
        if (!ckk) {
          this.NumberOfStub = this.NumberOfStub - 1;
          this.Stub.splice(index, 1);
         
        } else {
          alert("This tool are link with some model image..!")
        }
      }
    })
    for (let index = 0; index < this.Stub.length; index++) {
      this.Stub[index].id = index;
      this.Stub[index].compontIndex = index;
      this.Stub[index].flatIndex = "Flat " + this.Stub[index].tooltype + "_" + index;
      this.NumberOfStub = index + 1
    }

  
    var autoincrement_id = 0;
   
  }


  merchantChange(event: any) {
    this.merchant_id = event.value;    
    this.displaySubProductList = this.selectSubList.filter(c => c.merchantid === this.merchant_id 
      && c.product_id === this.rootImageForm.value.product_id);
    let itm = this.displaySubProductList[0];
    this.rootImageForm.controls['product_subtype_id'].setValue(itm.merchantid);
  }


  selectImage() {
    this.showImage = true;
  }
  showCOlor(event:any){

    this.rootImageForm.get("color")?.setValue(event.value);
  }
  removeColor(){
    this.rootImageForm.value.color = ''
    this.rootImageForm.get("color")?.setValue('');
  }
}
