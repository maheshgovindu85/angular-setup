import { CenterStoneSize } from "@/_models/cs_size";
import { CenterStoneType } from "@/_models/cs_type";
import { AlertService, AuthenticationService, VendorAuthenticationService } from "@/_services";
import { CenterStoneSizeService } from "@/_services/cs_size.service";
import { VendorService } from "@/_services/vendor.service";
import { Component, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";

@Component({
  selector: "app-center-stone-size-list",
  templateUrl: "./center-stone-size-list.component.html",
  styleUrls: ["./center-stone-size-list.component.css"],
})
export class CenterStoneSizeListComponent {

  centerstonesizeFilterForm: FormGroup;
  centerstonesizes: Observable<CenterStoneType[]>;
  dataSource: MatTableDataSource<CenterStoneType>;
  closeResult: string;
  search_text = "";
  centerstoneSizeList: any= [];
  searchForm:FormGroup;
  filtercenterstoneSizeList: any=[]
  isChecked:boolean;
  list: any=[];

  displayedColumns: string[] = [ 'cs_length', 'cs_width','merchant_id','merchantname','isactive', 'actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

    constructor(
      private router: Router,
      private formBuilder: FormBuilder,
      private alertService: AlertService,
      private authenticationService: AuthenticationService,
      private centerstonsizeService: CenterStoneSizeService,
      private store: Store<{ centerstonsize: CenterStoneSize[] }>
    ) {
     
    }
   
    ngOnInit() {
      this.getCenterStonesizeList()
      this.createSearchForm()
      }

      getCenterStonesizeList(){
        this.centerstonsizeService.getAll()
        .subscribe(data => {
          if (data) {
            this.list = data;
            
              this.centerstoneSizeList = this.list.data;
              
              for (let i = 0; i < this.centerstoneSizeList.length; i++) {
                this.centerstoneSizeList[i].isactive = this.centerstoneSizeList[i].isactive === 'N' ? false : true;
                this.centerstoneSizeList[i].SrNo = i + 1;
              }
              this.filtercenterstoneSizeList = this.centerstoneSizeList; 
          }
        });
      }

      changeStatus(e,data: any){
        this.isChecked = e.checked;
        const dataObj = {
          id: data.id,
          isactive : this.isChecked ? 'Y' : 'N',
        };
        this.centerstonsizeService.updateCenterStoneSize(dataObj).subscribe((data: CenterStoneSize) => {
          this.getCenterStonesizeList();
          this.alertService.success('Status Updated successfully!', true);
          this.router.navigate(['AdminCenterStoneSize/list']);
        });
      
      }

      createSearchForm() {
        this.searchForm = this.formBuilder.group({
          keyword: [''],
        });
      }
      clear() {
        this.searchForm.get('keyword')?.setValue('');
        this.searchGrid();
      }

      searchGrid() {
        let keyword = this.searchForm.controls['keyword'].value;
        if (keyword === '') {
          this.filtercenterstoneSizeList = this.centerstoneSizeList;
        } else {
          keyword = keyword.toLowerCase();
          this.filtercenterstoneSizeList = this.centerstoneSizeList.filter((event) => {
            return (
              (event.cs_length && event.cs_length.toLowerCase().includes(keyword))||
              (event.cs_width && event.cs_width.toLowerCase().includes(keyword))||
              (event.merchantname  && event.merchantname.toLowerCase().includes(keyword))
            );
          });
        }
      }
}