import { CenterStoneSize } from "@/_models/cs_size";
import { AlertService, AuthenticationService, VendorAuthenticationService } from "@/_services";
import { CenterStoneSizeService } from "@/_services/cs_size.service";
import { VendorService } from "@/_services/vendor.service";
import { Component } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { environment } from "environments/environment";
import { Observable } from "rxjs";

@Component({
  selector: "app-center-stone-size-add",
  templateUrl: "./center-stone-size-add.component.html",
  styleUrls: ["./center-stone-size-add.component.css"],
})
export class CenterStoneSizeAddComponent {

  centerStoneSizeAddForm: FormGroup;
  loading = false;
  submitted = false;
  submitted2 = false;
  stonsize: Observable<CenterStoneSize[]>;
  vendor_id:any;
  merchantListAll:any=[];
  merchant_id:number;
  public adminId=`${environment.adminId}`;
  merchantData: any =[];
  merchantSetData: any =[];

  public isactive: boolean = true;
 

    constructor(
      private router: Router,
      private formBuilder: FormBuilder,
      private alertService: AlertService,
      private authenticationService: AuthenticationService,
      private centerstonsizeService: CenterStoneSizeService,
      private vendorauthenticationService:VendorAuthenticationService,
      private vendorservices: VendorService,
      private store: Store<{ centerstonSize: CenterStoneSize[] }>
     
    ) {
      if (!this.authenticationService.currentUserValue) {
        this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id; 
        this.merchant_id = this.vendor_id;
      } else {
        this.adminId = JSON.parse(this.adminId);
        this.merchant_id = JSON.parse(this.adminId);
      }
    }
   
    ngOnInit() {
      this.createForm();
      this.getMerchantList();
      }
      get formValidationState() {
        return this.centerStoneSizeAddForm.controls;
      }
      get f() {
        return this.centerStoneSizeAddForm.controls;
      }
    
      createForm() {
        this.centerStoneSizeAddForm = this.formBuilder.group({
        
          merchant_id: [this.merchant_id],
          cs_length: ['', Validators.required],
          cs_width: ['',Validators.required],
         
        });
      }

      getMerchantList() {
        this.vendorservices.getAll().subscribe((data) => {
          if (data) {
            setTimeout(() => {
              
              this.merchantData = data;
    
              this.merchantSetData = this.merchantData.map((user) => {
                user.merchantId =
                  user.id + " | " + user.firstname + " | " + user.company;
                return user;
              });
              this.merchantListAll = this.merchantSetData;
            });
          }
        });
      }

      onSubmit(){
        this.submitted = true;
        this.submitted2 = true;
        this.alertService.clear();
    
        if (this.centerStoneSizeAddForm.invalid) {
          return;
        }

        this.loading = true;
        this.centerstonsizeService
        .save(this.centerStoneSizeAddForm.value)
        .subscribe((data: CenterStoneSize) => {
        //  console.log("my name.......",data)
          this.alertService.success('Center Stone Size saved successfully!', true);
          if(this.vendor_id){
            this.router.navigate(["MerchantAdminCenterStoneSize/list"]);
          } else{
            this.router.navigate(["AdminCenterStoneSize/list"]);
          }
        });
      }

      backToList() {
        if(this.vendor_id){
          this.router.navigate(["MerchantAdminCenterStoneSize/list"]);
        } else{
          this.router.navigate(["AdminCenterStoneSize/list"]);
        }
      }
}