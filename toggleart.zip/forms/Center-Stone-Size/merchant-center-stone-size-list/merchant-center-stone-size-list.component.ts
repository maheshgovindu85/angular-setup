import { AlertService, AuthenticationService, VendorAuthenticationService } from "@/_services";
import { CenterStoneSizeService } from "@/_services/cs_size.service";
import { Component } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { Router } from "@angular/router";

@Component({
  selector: "app-merchant-center-stone-size-list",
  templateUrl: "./merchant-center-stone-size-list.component.html",
  styleUrls: ["./merchant-center-stone-size-list.component.css"],
})
export class MerchantCenterStoneSizeListComponent {

  merchantCenterStoneList: any =[];
  filterMerchantCenterStoneList:any =[]
  merchant_id:any;
  searchForm:FormGroup;
  isChecked:boolean;
  list: any=[];

    constructor(
      private router: Router,
      private formBuilder: FormBuilder,
      private alertService: AlertService,
      private authenticationService: AuthenticationService,
      private centerstonsizeService: CenterStoneSizeService,
      private vendorauthenticationService: VendorAuthenticationService,
    ) {
       // redirect if already logged in
   if (!this.vendorauthenticationService.vendorcurrentUserValue) {
    this.router.navigate(['merchant']);
    this.merchant_id = this.vendorauthenticationService.vendorcurrentUserValue.id;
  }
    }
   
    ngOnInit() {
    
      this.merchant_id = this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.getCenterStoneSize()
      this.createSearchForm()
      }

      getCenterStoneSize(){
        const dataObj={
          "merchant_id": this.merchant_id
        }
        this.centerstonsizeService.getCS_SizebyMerchantid(dataObj)
         .subscribe(data => {

          //console.log("all data....",data)
           if (data) {
            this.list = data;
            this.merchantCenterStoneList = this.list.data;
            for(let i =0; i <this.merchantCenterStoneList.length;i++){
              this.merchantCenterStoneList[i].isactive = this.merchantCenterStoneList[i].isactive === 'N' ? false : true;
              this.merchantCenterStoneList[i].srNo = i+1;
            }
             this.filterMerchantCenterStoneList = this.merchantCenterStoneList;
           }
         });
     }

     createSearchForm() {
      this.searchForm = this.formBuilder.group({
        keyword: [''],
      });
    }
    clear() {
      this.searchForm.get('keyword')?.setValue('');
      this.searchGrid();
    }

    searchGrid() {
      let keyword = this.searchForm.controls['keyword'].value;
      if (keyword === '') {
        this.filterMerchantCenterStoneList = this.merchantCenterStoneList;
      } else {
        keyword = keyword.toLowerCase();
        this.filterMerchantCenterStoneList = this.merchantCenterStoneList.filter((event) => {
          return (
            (event.cs_length && event.cs_length.toLowerCase().includes(keyword))||
            (event.cs_width && event.cs_width.toLowerCase().includes(keyword))
          );
        });
      }
    }

    changeStatus(e,data: any){
      this.isChecked = e.checked;
      const dataObj = {
        id: data.id,
        isactive : this.isChecked ? 'Y' : 'N',
      };
      this.centerstonsizeService.updateCenterStoneSize(dataObj).subscribe((data: CenterStoneSizeService) => {
        this.getCenterStoneSize();
        this.alertService.success('Status Updated successfully!', true);
      });
     
     }
      
}