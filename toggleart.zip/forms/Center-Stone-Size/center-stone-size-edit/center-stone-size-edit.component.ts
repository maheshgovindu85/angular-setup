import { CenterStoneSize } from "@/_models/cs_size";
import { AlertService, AuthenticationService, VendorAuthenticationService } from "@/_services";
import { CenterStoneSizeService } from "@/_services/cs_size.service";
import { VendorService } from "@/_services/vendor.service";
import { Component } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { environment } from "environments/environment";

@Component({
  selector: "app-center-stone-size-edit",
  templateUrl: "./center-stone-size-edit.component.html",
  styleUrls: ["./center-stone-size-edit.component.css"],
})
export class CenterStoneSizeEditComponent {

  submitted = false;
  submitted2 = false;
  centerstonetypeEditForm: FormGroup;
  loading = false;
  vendor_id:any;
  merchant_id:number;
  sizeid: number;
  merchantListAll:any=[];
  public adminId=`${environment.adminId}`;
  sizeData: any = [];
  merchantData: any =[];
  merchantSetData: any =[];
  merchantListLogin: any;

    constructor(
      private route: ActivatedRoute,
      private router: Router,
      private formBuilder: FormBuilder,
      private alertService: AlertService,
      private authenticationService: AuthenticationService,
      private centerstonsizeService: CenterStoneSizeService,
      private vendorauthenticationService:VendorAuthenticationService,
      private vendorservices: VendorService,
      private store: Store<{ centerstonesize: CenterStoneSize[] }>
    ) {
      if (!this.authenticationService.currentUserValue) {
        this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id; 
        this.merchant_id = this.vendor_id;
      } else {
        this.adminId = JSON.parse(this.adminId);
        this.merchant_id = JSON.parse(this.adminId);
      }
    }
   
    ngOnInit() {
       this.sizeid = this.route.snapshot.params.id;
      this.createForm() 
      this.getAllSizeById()
      this.getMerchantList()
      }

      createForm() {
        this.centerstonetypeEditForm = this.formBuilder.group({
          merchant_id: [this.merchant_id],
          cs_length: ['', Validators.required],
          cs_width: ['',Validators.required],
          isactive: [''],
         
        });
      }
      get f() { 
        return this.centerstonetypeEditForm.controls; 
      }
      get formValidationState() {
        return this.centerstonetypeEditForm.controls;
      }

      getAllSizeById() {
        this.centerstonsizeService.getCenterStoneSizebyid({
          id: this.sizeid,
        }).subscribe((data) => {
          if (data) {
            this.setFormValue(data);
          }
        });
      }

      getMerchantList() {
        this.vendorservices.getAll().subscribe((data) => {
          if (data) {
            setTimeout(() => {
              this.merchantData = data;
    
              this.merchantSetData = this.merchantData.map((user) => {
                user.merchantId =
                  user.id + " | " + user.firstname + " | " + user.company;
                return user;
              });
    
              if (!this.vendor_id) {
                this.merchantListAll = this.merchantSetData;
              } else {
                this.merchantListLogin = this.merchantSetData.filter(
                  (e) => e.id === this.vendor_id
                );
              }
            });
          }
        });
      }

      setFormValue(data) {
        this.sizeData = data.data;
        this.centerstonetypeEditForm
        .get("merchant_id")
        ?.setValue(this.sizeData[0].merchant_id);
        this.centerstonetypeEditForm
        .get("cs_length")
        ?.setValue(this.sizeData[0].cs_length);
        this.centerstonetypeEditForm
        .get("cs_width")
        ?.setValue(this.sizeData[0].cs_width);
        this.centerstonetypeEditForm
        .get("isactive")
        ?.setValue(this.sizeData[0].isactive === "Y" ? true : false);
       
      }
  
      onSubmit() {
        this.submitted = true;
        this.submitted2 = true;
  
        this.alertService.clear();
    
        if (this.centerstonetypeEditForm.valid) {
          const dataObj = {
            id: this.sizeid,
            merchant_id:this.centerstonetypeEditForm.value.merchant_id,
            cs_length: this.centerstonetypeEditForm.value.cs_length, 
            cs_width: this.centerstonetypeEditForm.value.cs_width,
            isactive: this.centerstonetypeEditForm.value.isactive ? "Y" : "N"
          };
  
          this.centerstonsizeService.updateCenterStoneSize(dataObj).subscribe(
            (data: CenterStoneSize) => {
              this.alertService.success(
                "Center Stone Size Updated successfully!",
                true
              );
              this.alertService.success('Center Stone Size updated successfully!', true);
              if(this.vendor_id){
                this.router.navigate(["MerchantAdminCenterStoneSize/list"]);
              } else{
                this.router.navigate(["AdminCenterStoneSize/list"]);
              }
            }
          );
        }
  
      }

      backToList() {
        if(this.vendor_id){
          this.router.navigate(["MerchantAdminCenterStoneSize/list"]);
        } else{
          this.router.navigate(["AdminCenterStoneSize/list"]);
        }
      }
}