import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductSubTypeAddComponent } from './product-subtype-add.component';

describe('ProductSubTypeAddComponent', () => {
  let component: ProductSubTypeAddComponent;
  let fixture: ComponentFixture<ProductSubTypeAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductSubTypeAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductSubTypeAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
