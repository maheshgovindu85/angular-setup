import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators, FormControl } from "@angular/forms";
import { Router } from "@angular/router";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs";

import { Producttype } from "@/_models/producttype";
import { producttypeAdd } from "@/_store/producttype/product.actions";

import { AlertService, AuthenticationService, MetalService } from "@/_services";
import { ProductTypeService } from '@/_services/product-type.service';
import { VendorService } from "@/_services/vendor.service";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { ProductSubtype } from "@/_models/productsubtype";
import { customMethod } from "@/masters/common.master";
import { environment } from "environments/environment";

@Component({
  selector: "app-product-subtype-add",
  templateUrl: "./product-subtype-add.component.html",
  styleUrls: ["./product-subtype-add.component.css"],
})
export class ProductSubTypeAddComponent implements OnInit {
  productSubTypeAddForm: FormGroup;
  loading = false;
  submitted = false;
  currencies: Observable<Producttype[]>;
  productList:any =[];
  public isactive: boolean = true;
  merchantList:any=[];
  dataObj: any={};

  customMethod = customMethod;
  noSize_Status: string;
  flat_center: string;
  flat_left: string;
  flat_right: string;
  side: string;
  model_center: string;
  model_left: string;
  model_right: string;
  other: string;
  merchantId: any;
  public adminId=`${environment.adminId}`;


  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private producttypeService: ProductTypeService,
    private vendorservices: VendorService,
    private ProductSubTypeService: ProductSubTypeService ,
    private authenticationService: AuthenticationService,
    private store: Store<{ producttypes: Producttype[] }>
  ) {
    if (!this.authenticationService.currentUserValue) {
    }
  }

  ngOnInit() {
    this.createForm();
    this.getProductList();
    this.getMerchantList();
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.productSubTypeAddForm.controls;
  }

  createForm(){
    this.productSubTypeAddForm = this.formBuilder.group({
      product_id: ['', Validators.required],
      name: ['', Validators.required],
      aboutus: ['', Validators.required],
      merchantid: [JSON.parse(this.adminId), Validators.required], 
      customizationmethod: ['', Validators.required],
      size_variation:[''],
      flat_center: [''],
      flat_left: [''],
      flat_right: [''],
      side: [''],
      model_center: [''],
      model_left: [''],
      model_right: [''],
      other: ['Y'],
      imagePath: ['',Validators.required],
      base64format: ['',Validators.required],
      frontEndimage:[''],

    });
    
  }



  backToList(){
    this.router.navigate(["productSubType/list"]);
  }

  getProductList(){
    this.producttypeService.getAll()
    .subscribe(data => {
      if (data) {
        setTimeout(() => {
          this.productList = data;
        });
      }
    });
  }

  getMerchantList(){
    this.vendorservices.getAll()
    .subscribe(data => {
      if (data) {
        setTimeout(() => {
          this.merchantList = data.map(user => {
            user.merchantId = user.id + ' | ' + user.firstname + ' | ' + user.company;
            return user;
          });
          
        });
      }
    });
  }



  onSubmit() {
    this.submitted = true;
    if (this.productSubTypeAddForm.valid) {
      this.imagSubmit();
    }
  }


  onSelectedFiles(files: File[]) {
    var base64value;
    const reader = new FileReader();
    
    reader.readAsDataURL(files[0]);
    reader.onload = (event: any) => {
      if (event.target.result) {
        base64value = event.target.result;
        this.dataObj= {
          base64format: base64value,
          imagePath: files[0].name,
        }
        this.productSubTypeAddForm.get('base64format').setValue(base64value);
        this.productSubTypeAddForm.get('imagePath').setValue(files[0].name);
      }
    }
  }

  imagSubmit(){
    this.ProductSubTypeService.upload(this.dataObj).subscribe(data => {
      this.productSubTypeAddForm.value.size_variation = this.productSubTypeAddForm.value.size_variation === true ? 'Y' :  'N';
      this.productSubTypeAddForm.value.flat_center = this.productSubTypeAddForm.value.flat_center === true ? 'Y' :  'N';
      this.productSubTypeAddForm.value.flat_left = this.productSubTypeAddForm.value.flat_left === true ? 'Y' :  'N';
      this.productSubTypeAddForm.value.flat_right = this.productSubTypeAddForm.value.flat_right === true ? 'Y' :  'N';
      this.productSubTypeAddForm.value.side = this.productSubTypeAddForm.value.side === true ? 'Y' :  'N';
      this.productSubTypeAddForm.value.model_center = this.productSubTypeAddForm.value.model_center === true ? 'Y' :  'N';
      this.productSubTypeAddForm.value.model_left = this.productSubTypeAddForm.value.model_left === true ? 'Y' :  'N';
      this.productSubTypeAddForm.value.model_right = this.productSubTypeAddForm.value.model_right === true ? 'Y' :  'N';
      this.productSubTypeAddForm.value.other = this.productSubTypeAddForm.value.other;
      this.productSubTypeAddForm.value.frontEndimage = data['data'];
      delete this.productSubTypeAddForm.value.base64format;
      delete this.productSubTypeAddForm.value.imagePath;
      
      this.ProductSubTypeService.save(this.productSubTypeAddForm.value).subscribe((data: ProductSubtype) => {
        this.alertService.success('Product Sub Type saved successfully!', true);
        this.router.navigate(['productSubType/list']);
      });
      // this.alertService.success('image Upload Successfully!');
    })
  }
  
}
