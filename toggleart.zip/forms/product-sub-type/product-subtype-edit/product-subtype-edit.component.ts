import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators, FormControl } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs";

import { Producttype } from "@/_models/producttype";
import { producttypeAdd } from "@/_store/producttype/product.actions";

import { AlertService, AuthenticationService, MetalService } from "@/_services";
import { ProductTypeService } from '@/_services/product-type.service';
import { VendorService } from "@/_services/vendor.service";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { ProductSubtype } from "@/_models/productsubtype";
import { MetalgoldcolorService } from "@/_services/metalgoldcolor.service";
import { customMethod } from "@/masters/common.master";
import { environment } from "environments/environment";

@Component({
  selector: "app-product-subtype-edit",
  templateUrl: "./product-subtype-edit.component.html",
  styleUrls: ["./product-subtype-edit.component.css"],
})
export class ProductSubTypeEditComponent implements OnInit {
  productSubTypeEditForm: FormGroup;
  loading = false;
  submitted = false;
  currencies: Observable<Producttype[]>;
  productList: any = [];
  public isactive: boolean = true;
  merchantList: any = [];

  customMethod = customMethod;
  noSize_Status: string;
  flat_center: string;
  flat_left: string;
  flat_right: string;
  side: string;
  model_center: string;
  model_left: string;
  model_right: string;
  other: string;
  merchantId: any;
  public getByIdData: ProductSubtype;
  prod_subtype_id: any;
  productSubType: any;
  dataObj: { base64format: any; imagePath: string; };
  productImagePath: any;
  public path = `${environment.apiUrl}`;
  product_image: string;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private producttypeService: ProductTypeService,
    private vendorservices: VendorService,
    private ProductSubTypeService: ProductSubTypeService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private authenticationService: AuthenticationService,
    private store: Store<{ producttypes: Producttype[] }>
  ) {
    if (!this.authenticationService.currentUserValue) {
    }
  }

  ngOnInit() {
    this.prod_subtype_id = this.route.snapshot.params.id;
    this.createForm();
    this.getProductList();
    this.getMerchantList();
    this.getAllProductById();
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.productSubTypeEditForm.controls;
  }

  createForm() {
    this.productSubTypeEditForm = this.formBuilder.group({
      product_id: ['', Validators.required],
      name: ['', Validators.required],
      aboutus: ['', Validators.required],
      merchantid: ['', Validators.required],
      customizationmethod: ['', Validators.required],
      size_variation: [''],
      flat_center: [''],
      flat_left: [''],
      flat_right: [''],
      side: [''],
      model_center: [''],
      model_left: [''],
      model_right: [''],
      other: [true],
      isactive: [''],
      imagePath: [''],
      base64format: [''],
      frontEndimage: [''],
    });
  }



  backToList() {
    this.router.navigate(["productSubType/list"]);
  }

  getProductList() {
    this.producttypeService.getAll()
      .subscribe(data => {
        if (data) {
          setTimeout(() => {
            this.productList = data;
          });
        }
      });
  }

  getMerchantList() {
    this.vendorservices.getAll()
      .subscribe(data => {
        if (data) {
          setTimeout(() => {
            this.merchantList = data.map(user => {
              user.merchantId = user.id + ' | ' + user.firstname + ' | ' + user.company;
              return user;
            });

          });
        }
      });
  }

  getAllProductById() {
    this.ProductSubTypeService.getProductSubTypeById({ id: this.prod_subtype_id }).subscribe(data => {
      if (data) {
        this.setFormValue(data)
      }
    })
  }

  setFormValue(data) {
    this.productSubType = data.data;


    this.productSubTypeEditForm.get('name')?.setValue(this.productSubType[0].name);
    this.productSubTypeEditForm.get('product_id')?.setValue(this.productSubType[0].product_id);
    this.productSubTypeEditForm.get('aboutus')?.setValue(this.productSubType[0].aboutus);
    this.productSubTypeEditForm.get('merchantid')?.setValue(JSON.parse(this.productSubType[0].merchantid));
    this.productSubTypeEditForm.get('customizationmethod')?.setValue(this.productSubType[0].customizationmethod);
    this.productSubTypeEditForm.get('size_variation')?.setValue(this.productSubType[0].size_variation === 'Y' ? true : false);
    this.productSubTypeEditForm.get('flat_center')?.setValue(this.productSubType[0].flat_center === 'Y' ? true : false);
    this.productSubTypeEditForm.get('flat_left')?.setValue(this.productSubType[0].flat_left === 'Y' ? true : false);
    this.productSubTypeEditForm.get('flat_right')?.setValue(this.productSubType[0].flat_right === 'Y' ? true : false);
    this.productSubTypeEditForm.get('side')?.setValue(this.productSubType[0].side === 'Y' ? true : false);
    this.productSubTypeEditForm.get('model_center')?.setValue(this.productSubType[0].model_center === 'Y' ? true : false);
    this.productSubTypeEditForm.get('model_left')?.setValue(this.productSubType[0].model_left === 'Y' ? true : false);
    this.productSubTypeEditForm.get('model_right')?.setValue(this.productSubType[0].model_right === 'Y' ? true : false);
    this.productSubTypeEditForm.get('other')?.setValue(this.productSubType[0].other === 'Y' ? true : false);
    this.productSubTypeEditForm.get('isactive')?.setValue(this.productSubType[0].isactive === 'Y' ? true : false);
    this.productImagePath = this.productSubType[0].frontendimage

  }


  onSubmit() {
    this.submitted = true;
    if (this.productSubTypeEditForm.valid) {
      this.imagSubmit();
    }
  }


  onSelectedFiles(files: File[]) {
    var base64value;
    const reader = new FileReader();
    reader.readAsDataURL(files[0]);
    reader.onload = (event: any) => {
      this.productImagePath = (<FileReader>event.target).result;
      if (event.target.result) {
        base64value = event.target.result;
        this.dataObj = {
          base64format: base64value,
          imagePath: files[0].name,
        }
        this.productSubTypeEditForm.get('base64format').setValue(base64value);
        this.productSubTypeEditForm.get('imagePath').setValue(files[0].name);
        this.ProductSubTypeService.upload(this.dataObj).subscribe(data => {
          this.product_image = this.path + "/imagepreview/getImage?imagename=" + data['data']


        })
      }
    }
  }

  imagSubmit() {
    const dataObj = {
      id: this.prod_subtype_id,
      product_id: this.productSubTypeEditForm.value.product_id,
      name: this.productSubTypeEditForm.value.name,
      aboutus: this.productSubTypeEditForm.value.aboutus,
      merchantid: this.productSubTypeEditForm.value.merchantid,
      customizationmethod: this.productSubTypeEditForm.value.customizationmethod,
      size_variation: this.productSubTypeEditForm.value.size_variation === true ? 'Y' : 'N',
      flat_center: this.productSubTypeEditForm.value.flat_center === true ? 'Y' : 'N',
      flat_left: this.productSubTypeEditForm.value.flat_left === true ? 'Y' : 'N',
      flat_right: this.productSubTypeEditForm.value.flat_right === true ? 'Y' : 'N',
      side: this.productSubTypeEditForm.value.side === true ? 'Y' : 'N',
      model_center: this.productSubTypeEditForm.value.model_center === true ? 'Y' : 'N',
      model_left: this.productSubTypeEditForm.value.model_left === true ? 'Y' : 'N',
      model_right: this.productSubTypeEditForm.value.model_right === true ? 'Y' : 'N',
      other: this.productSubTypeEditForm.value.other === true ? 'Y' : 'N',
      isactive: this.productSubTypeEditForm.value.isactive === true ? 'Y' : 'N',
      frontEndimage: this.product_image,
    }

    this.ProductSubTypeService.getProductSubTypeUpdate(dataObj).subscribe((data: ProductSubtype) => {
      this.alertService.success('Product Sub Type Updated successfully!', true);
      this.router.navigate(['productSubType/list']);
    });
  }

}
