import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { select, Store } from "@ngrx/store";
import { Observable } from "rxjs";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";

import { AlertService, AuthenticationService, MetalService } from "@/_services";
import { ProductSubtype } from "@/_models/productsubtype";
@Component({
  selector: "app-product-subtype-list",
  templateUrl: "./product-subtype-list.component.html",
  styleUrls: ["./product-subtype-list.component.css"],
})
export class ProductSubTypeListComponent implements OnInit {
  loading = false;
  submitted = false;
  public isactive: boolean = true;
  productSubTypeList: any =[];
  list: any=[];
  searchForm: FormGroup;
  productSubList:any =[];
  isChecked:boolean;
  activeStatus: any;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private ProductSubTypeService: ProductSubTypeService ,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
  ) {
    if (!this.authenticationService.currentUserValue) {
    }
  }

  ngOnInit() {
   this.getProductSubTypeData();
   this.createSearchForm();
  }

  getProductSubTypeData(){
     this.ProductSubTypeService.getAll()
      .subscribe(data => {
        if (data) {
          setTimeout(() => {
            this.list = data;
           this.productSubList = this.list.data;
           for(let i =0; i <this.productSubList.length;i++){
            this.productSubList[i].isactive = this.productSubList[i].isactive === 'N' ? false : true;
            this.productSubList[i].SrNo = i+1;
          }
           this.productSubTypeList = this.productSubList;
          });
        }
      });
  }
 
// Search button function start
createSearchForm() {
  this.searchForm = this.formBuilder.group({
    keyword: [''],
  });
}
clear() {
  this.searchForm.get('keyword')?.setValue('');
  this.searchGrid();
}
searchGrid() {
  let keyword = this.searchForm.controls['keyword'].value;
  if (keyword === '') {
    this.productSubTypeList = this.productSubList;
  } else {
    keyword = keyword.toLowerCase();
    this.productSubTypeList = this.productSubList.filter((event) => {
      return (
        (event.name && event.name.toLowerCase().includes(keyword)) ||
        (event.productname && event.productname.toLowerCase().includes(keyword)) ||
        (event.customizationmethod && event.customizationmethod.toLowerCase().includes(keyword)) ||
        (event.merchantname && event.merchantname.toLowerCase().includes(keyword))
      );
    });
  }
}

changeStatus(e,data: any){
  this.isChecked = e.checked;
  const dataObj = {
    id: data.id,
    isactive : this.isChecked ? 'Y' : 'N',
  };
  this.ProductSubTypeService.getProductSubTypeUpdate(dataObj).subscribe((data: ProductSubtype) => {
    this.getProductSubTypeData();
    this.alertService.success('Status Updated successfully!', true);
    this.router.navigate(['productSubType/list']);
  });

}
 

  
}
