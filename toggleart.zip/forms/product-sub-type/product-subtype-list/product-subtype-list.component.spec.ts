import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductSubTypeListComponent } from './product-subtype-list.component';

describe('ProductSubTypeListComponent', () => {
  let component: ProductSubTypeListComponent;
  let fixture: ComponentFixture<ProductSubTypeListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductSubTypeListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductSubTypeListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
