import { CenterStoneSize } from "@/_models/cs_size";
import { CenterStoneType } from "@/_models/cs_type";
import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { CenterStoneDefinitionService } from "@/_services/cs_definition.service";
import { VendorService } from "@/_services/vendor.service";
import { Component, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";

@Component({
  selector: "app-center-stone-definition-list",
  templateUrl: "./center-stone-definition-list.component.html",
  styleUrls: ["./center-stone-definition-list.component.css"],
})
export class CenterStoneDefinitionListComponent {
  centerStoneDefinitionList: any = [];
  searchForm: FormGroup;
  filterCenterStoneDefinitionList: any = [];
  isChecked: boolean;
  list: any = [];

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private CenterStoneDefinitionService: CenterStoneDefinitionService,
    private store: Store<{ centerstonsize: CenterStoneSize[] }>
  ) { }

  ngOnInit() {
    this.getCenterStoneDefinition();
    this.createSearchForm();
  }

  getCenterStoneDefinition() {
    this.CenterStoneDefinitionService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;

        this.centerStoneDefinitionList = this.list.data;

        for (let i = 0; i < this.centerStoneDefinitionList.length; i++) {
          this.centerStoneDefinitionList[i].isactive =
            this.centerStoneDefinitionList[i].isactive === "N" ? false : true;
          this.centerStoneDefinitionList[i].SrNo = i + 1;
        }
        this.filterCenterStoneDefinitionList = this.centerStoneDefinitionList;
      }
    });
  }

  changeStatus(e, data: any) {
    this.isChecked = e.checked;
    const dataObj = {
      id: data.id,
      isactive: this.isChecked ? "Y" : "N",
    };
    this.CenterStoneDefinitionService.updateCenterStoneDefinition(
      dataObj
    ).subscribe((data: CenterStoneSize) => {
      this.getCenterStoneDefinition();
      this.alertService.success("Status Updated successfully!", true);
      this.router.navigate(["AdminCenterStoneDefinition/list"]);
    });
  }

  createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [""],
    });
  }
  clear() {
    this.searchForm.get("keyword")?.setValue("");
    this.searchGrid();
  }

  searchGrid() {
    let keyword = this.searchForm.controls["keyword"].value;   
    if (keyword === "") {
      this.filterCenterStoneDefinitionList = this.centerStoneDefinitionList;
    } else {
      keyword = keyword.toLowerCase();
      this.filterCenterStoneDefinitionList =
        this.centerStoneDefinitionList.filter((event) => {
          return (
            (event.variant_name &&
              event.variant_name.toLowerCase().includes(keyword)) ||
            (event.csType &&
              event.csType.toLowerCase().includes(keyword)) ||
            (event.csSize && event.csSize.includes(keyword)) ||
            (event.designName &&
              event.designName.toLowerCase().includes(keyword)) ||
            (event.merchantname &&
              event.merchantname.toLowerCase().includes(keyword))
          );
        });
    }
  }
}
