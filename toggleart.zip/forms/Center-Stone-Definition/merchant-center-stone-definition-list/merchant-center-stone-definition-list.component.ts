import { CenterStoneSize } from "@/_models/cs_size";
import { CenterStoneType } from "@/_models/cs_type";
import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { CenterStoneDefinitionService } from "@/_services/cs_definition.service";
import { VendorService } from "@/_services/vendor.service";
import { Component, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";

@Component({
  selector: "app-merchant-center-stone-definition-list",
  templateUrl: "./merchant-center-stone-definition-list.component.html",
  styleUrls: ["./merchant-center-stone-definition-list.component.css"],
})
export class MerchantCenterStoneDefinitionListComponent {
  merchantCenterStoneDefinitionList: any = [];
  searchForm: FormGroup;
  filterMerchantCenterStoneDefinitionList: any = [];
  isChecked: boolean;
  list: any = [];
  vendor_id: any;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private CenterStoneDefinitionService: CenterStoneDefinitionService,
    private store: Store<{ centerstonsize: CenterStoneSize[] }>,
    private vendorauthenticationService: VendorAuthenticationService

  ) {
    if (!this.vendorauthenticationService.vendorcurrentUserValue) {
      this.router.navigate(["merchant"]);
    }
  }

  ngOnInit() { 
      this.vendor_id  = this.vendorauthenticationService.vendorcurrentUserValue.id;
    this.getCenterStoneDefinition();
    this.createSearchForm();
  }

  getCenterStoneDefinition() {
    const dataObj = {
      merchant_id: this.vendor_id,
    };
    this.CenterStoneDefinitionService.getCS_definitionbyMerchantid(
      dataObj
    ).subscribe((data) => {
      if (data) {
        this.list = data;

        this.merchantCenterStoneDefinitionList = this.list.data;

        for (let i = 0; i < this.merchantCenterStoneDefinitionList.length; i++) {
          this.merchantCenterStoneDefinitionList[i].isactive =
            this.merchantCenterStoneDefinitionList[i].isactive === "N" ? false : true;
          this.merchantCenterStoneDefinitionList[i].SrNo = i + 1;
        }
        this.filterMerchantCenterStoneDefinitionList = this.merchantCenterStoneDefinitionList;
      }
    });
  }

  changeStatus(e, data: any) {
    this.isChecked = e.checked;
    const dataObj = {
      id: data.id,
      isactive: this.isChecked ? "Y" : "N",
    };
    this.CenterStoneDefinitionService.updateCenterStoneDefinition(
      dataObj
    ).subscribe((data: CenterStoneSize) => {
      this.getCenterStoneDefinition();
      this.alertService.success("Status Updated successfully!", true);
      this.router.navigate(["MerchantAdminCenterStoneDefinition/list"]);
    });
  }

  createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [""],
    });
  }
  clear() {
    this.searchForm.get("keyword")?.setValue("");
    this.searchGrid();
  }

  searchGrid() {
    let keyword = this.searchForm.controls["keyword"].value;
    if (keyword === "") {
      this.filterMerchantCenterStoneDefinitionList = this.merchantCenterStoneDefinitionList;
    } else {
      keyword = keyword.toLowerCase();
      this.filterMerchantCenterStoneDefinitionList =
        this.merchantCenterStoneDefinitionList.filter((event) => {
          return (
            (event.variant_name &&
              event.variant_name.toLowerCase().includes(keyword)) ||
            (event.csType &&
              event.csType.toLowerCase().includes(keyword)) ||
            (event.csSize && event.csSize.includes(keyword)) ||
            (event.designName &&
              event.designName.toLowerCase().includes(keyword)) ||
            (event.merchantname &&
              event.merchantname.toLowerCase().includes(keyword))
          );
        });
    }
  }
}
