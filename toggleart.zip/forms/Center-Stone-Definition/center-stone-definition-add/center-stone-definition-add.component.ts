import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { CenterStoneTypeService } from "@/_services/cs_type.service";
import { CenterStoneVariantService } from "@/_services/cs_variant.service";
import { VendorService } from "@/_services/vendor.service";
import { Component, ViewChild } from "@angular/core";
import { FormArray, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { environment } from "environments/environment";
import {
  colorList,
  diamondType,
  goldCalculate,
  prongList,
} from "@/masters/common.master";
import { DiamondCaratService } from "@/_services/diamondcarat.service";
import { GlobalColorPreferenceService } from "@/_services/global-color-preference.service";
import { DiamondShapeService } from "@/_services/diamondshape.service";
import { GemstoneService } from "@/_services/gemstone.service";
import { CenterStoneSizeService } from "@/_services/cs_size.service";
import { CenterStoneDefinitionService } from "@/_services/cs_definition.service";
import { CenterStoneDefinition } from "@/_models/cs_definition";
import { CenterStoneFamilynameService } from "@/_services/cs_familyname.service";
import { CenterStoneFamilyname } from "@/_models/cs_familyname";
@Component({
  selector: "app-center-stone-definition-add",
  templateUrl: "./center-stone-definition-add.component.html",
  styleUrls: ["./center-stone-definition-add.component.css"],
})
export class CenterStoneDefinitionAddComponent {
  centerStoneDefinitionAddForm: FormGroup;
  centerStoneDesignIllusionForm: FormGroup;
  addFamilyForm: FormGroup;
  loading = false;
  submitted = false;
  merchantId: any;
  public adminId = `${environment.adminId}`;
  merchantList: any = [];
  vendor_id: any;
  merchant_id: any;
  centerStoneVariantList: any = [];
  list: any = [];
  gemstoneList: any = [];
  centerTypeStoneList: any = [];
  goldCalculate = goldCalculate;
  subProduct: any = [];
  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();
  selectSubList: any = [];
  modelImage: any;
  partImagePath: any;
  AllImages: any = [];
  optionList: any = [];
  diamondCaratList: any = [];
  public path = `${environment.apiUrl}`;
  diamondType = diamondType;
  positionOptions: any = [];
  arrayData: any = [];
  merchantData: any = [];
  merchantSetData: any = [];
  merchantListAll: any = [];
  gemstoneColorList: any = [];
  merchantListLogin: any;
  meData: any;
  positionList: any = [
    { id: "other" },
    { id: "flat-left" },
    { id: "flat-centre" },
    { id: "flat-right" },
    { id: "model-left" },
    { id: "model-centre" },
    { id: "model-right" },
    { id: "side" },
  ];
  colorList = colorList;
  wtValue: any;
  nosValue: any;
  calValue: number;
  wt: number = 0;
  diamondShapeList: any = [];
  centerStoneSizeList: any = [];
  csSizeList: any = [];
  prongList = prongList;
  showDiamondSection: boolean = false;
  showGemStoneSection: boolean = false;
  showIllusionDesignSection: boolean = false;
  displayText: string;
  filterCenterStoneVariantList: any = [];
  displayFamilyPop: boolean = false;
  getCsFamilyNames: any = [];
  famList: any = [];
  getCsFamilyNamesIllusionSet: any = [];
  getCsFamilyNamesDesign: any = [];
  FilterCsFamilyNames: any = [];
  isDisabled: boolean = false;
  dataId: any;
  mode: any;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private centerStoneTypeService: CenterStoneTypeService,
    private alertService: AlertService,
    private vendorservices: VendorService,
    private authenticationService: AuthenticationService,
    private vendorauthenticationService: VendorAuthenticationService,
    private centerstonvarianService: CenterStoneVariantService,
    private ProductSubTypeService: ProductSubTypeService,
    private DiamondCaratService: DiamondCaratService,
    private GlobalColorPreferenceService: GlobalColorPreferenceService,
    private DiamondShapeService: DiamondShapeService,
    private GemstoneService: GemstoneService,
    private centerstonsizeService: CenterStoneSizeService,
    private CenterStoneDefinitionService: CenterStoneDefinitionService,
    private CenterStoneFamilynameService: CenterStoneFamilynameService
  ) {
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id =
        this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }
  get f() {
    return this.centerStoneDefinitionAddForm.controls;
  }

  ngOnInit() {
    this.createForm();
    this.getMerchantList();
    this.centerStoneSizevariantList();
    this.getAllCenterStoneList();
    this.getDiamondCaratList();
    this.gemStoneColor();
    this.diamondShapeData();
    this.genStoneData();    
    this.famForm();
    this.getFamilyName();
    this.route.params.subscribe((params) => {
      if (!!params.id) {
        this.dataId = params.id;
        this.mode = "EDIT";
        this.getCenteStoneDefById(params);
      }
    });
  }

  createForm() {
    this.centerStoneDefinitionAddForm = this.formBuilder.group({
      isactive: [""],
      variantName: [""],
      type: ["", Validators.required],
      imagecolor: [""],
      merchant_Id: [this.merchant_id],
      img_type: ["illusion"],
      singleDiamond: this.formBuilder.array([this.Initial_SingleDiamond()]),
      singleGemstone: this.formBuilder.array([this.Initial_SingleGemstone()]),
      illusionDesign: this.formBuilder.array([this.Initial_IllusionDesign()]),
      multipleImages: this.formBuilder.array([this.Initial_Multiple()]),
    });
    this.getCenterStoneSizeList();
    // this.centerStoneDesignIllusionForm = this.formBuilder.group({
    //   name: [''],
    //   cssize: ['',Validators.required],
    //   merchantId: [this.merchant_id ],
    //   img_type: ['illusion'],
    //   Diamond: this.formBuilder.array([this.Initial_Diamond()]),
    //   Gemstone: this.formBuilder.array([this.Initial_GemStones()]),
    //   multipleImages:this.formBuilder.array([this.Initial_Multiple()]),
    // })
  }
  nameValidator(control) {
    if (control.parent) {
      const type = control.parent.get(this.singleDiamond).value;
      if (type !== "Single Diamond" && !control.value) {
        return { required: true };
      }
    }
    return null;
  }

  //#region Master Data
  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantList = data.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });
        });
      }
    });
  }
  centerStoneSizevariantList() {
    this.centerstonvarianService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;
        this.centerStoneVariantList = this.list.data;
        this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(
          (c) =>
            c.merchantid == this.centerStoneDefinitionAddForm.value.merchant_Id
        );
        console.log(
          "this.filterCenterStoneVariantList:",
          this.filterCenterStoneVariantList
        );
      }
    });
  }

  getAllCenterStoneList() {
    this.centerStoneTypeService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;
        this.centerTypeStoneList = this.list.data;
      }
    });
  }

  gemStoneColor() {
    this.GlobalColorPreferenceService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneColorList = data;
        });
      }
    });
  }
  diamondShapeData() {
    this.DiamondShapeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.diamondShapeList = data;
        });
      }
    });
  }
  selectedFiles(files: File[], index) {
    for (var i = 0; i < files.length; i++) {
      this.fileindexposition++;
      this.FileListMap.set(index, files[i]);
    }
  }

  genStoneData() {
    this.GemstoneService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneList = data;
        });
      }
    });
  }

  getCenterStoneSizeList() {
    this.centerstonsizeService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;
        this.centerStoneSizeList = this.list.data.filter(
          (x) => x.isactive == "Y"
        );
        this.centerStoneSizeList.map((data) => {
          data.csSize = data.cs_length + " * " + data.cs_width;
          return data;
        });
        this.csSizeList = this.centerStoneSizeList.filter(
          (c) =>
            c.merchantid ===
            this.centerStoneDefinitionAddForm.get("merchant_Id").value
        );
      }
    });
  }

  showFormSection(event) {
    if (this.centerStoneDefinitionAddForm.get("type").value !== 4) {
      this.centerStoneDefinitionAddForm
        .get("variantName")
        .setValidators([Validators.required]);
      this.centerStoneDefinitionAddForm
        .get("variantName")
        .updateValueAndValidity();
    } else {
      this.centerStoneDefinitionAddForm.get("variantName").clearValidators();
      this.centerStoneDefinitionAddForm
        .get("variantName")
        .updateValueAndValidity();
    }

    this.showDiamondSection = false;
    this.showGemStoneSection = false;
    this.showIllusionDesignSection = false;
    if (event.value == 1) {
      this.showDiamondSection = true;
    } else if (event.value == 2) {
      this.showGemStoneSection = true;
    } else {
      this.showIllusionDesignSection = true;
      let frmArray = this.centerStoneDefinitionAddForm.get(
        "illusionDesign"
      ) as FormArray;
      frmArray.clear();
      this.illusionDesign().push(this.Initial_IllusionDesign());
      if (event.value === 3) this.displayText = "Illusion Set";
      else {
        this.displayText = "Design";
        let frmArray = this.centerStoneDefinitionAddForm.get(
          "illusionDesign"
        ) as FormArray;
        frmArray.clear();
        this.illusionDesign().push(this.Initial_IllusionDesign());
      }
    }
  }

  //#endregion
  //#region  add family...

  showAddFamilyPop() {
    this.displayFamilyPop = true;
  }

  famForm() {
    this.addFamilyForm = this.formBuilder.group({
      name: [""],
      merchant_Id: [""],
      type: ["Design"],
    });
  }

  submitFamilyPop() {
    this.addFamilyForm
      .get("merchant_Id")
      .setValue(this.centerStoneDefinitionAddForm.value.merchant_Id);
    const dataObj = {
      name: this.addFamilyForm.value.name,
      merchant_id: this.addFamilyForm.value.merchant_Id,
      type: this.addFamilyForm.value.type,
    };
    if (this.addFamilyForm.valid) {
      this.CenterStoneFamilynameService.save(dataObj).subscribe(
        (data: CenterStoneFamilyname) => {
          this.getFamilyName();
          this.alertService.success("Family Added successfully!", true);
          this.displayFamilyPop = false;
        }
      );
    }
  }

  getFamilyName() {
    this.CenterStoneFamilynameService.getAll().subscribe((data) => {
      if (data) {       
        this.famList = data;
        this.getCsFamilyNames = this.famList.data.filter(x => x.type == 'Design');
        this.FilterCsFamilyNames = this.getCsFamilyNames.filter(
          (c) => c.merchantid == this.centerStoneDefinitionAddForm.value.merchant_Id
        );
      }
    });
  }

  //#endregion

  Initial_Multiple() {
    return this.formBuilder.group({
      images: [""],
      displayUser: [""],
      selectColor: [""],
      secondOption: [""],
      Position: [""],
      modelImage: [""],
      prongSelect: [""],
    });
  }

  get multipleImages() {
    return this.centerStoneDefinitionAddForm.get("multipleImages") as FormArray;
  }

  removeRow(index: number) {
    this.multipleImages.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  ///  // // /add single diamond data form
  Initial_SingleDiamond() {
    return this.formBuilder.group({
      csSize: [""],
      csDiaTYpe: [""],
      csDiaWt: [""],
      displayType: [""],
      gold: [""],
      wt: [""],
      wt14: [""],
      wt18: [""],
      wt22: [""],
    });
  }

  get singleDiamond(): FormArray {
    return this.centerStoneDefinitionAddForm.get("singleDiamond") as FormArray;
  }

  addSingleDiamond() {
    this.singleDiamond.push(this.Initial_SingleDiamond());
  }

  removeSingleDiamondList(index: number) {
    this.singleDiamond.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  ///  // // /add single diamond data form
  Initial_SingleGemstone() {
    return this.formBuilder.group({
      name: [""],
      color: [""],
      csSize: [""],
      diaWt: [""],
      displayType: [""],
      gold: [],
      wt: [],
      wt14: [],
      wt18: [],
      wt22: [],
    });
  }

  get singleGemstone(): FormArray {
    return this.centerStoneDefinitionAddForm.get("singleGemstone") as FormArray;
  }

  addSingleGemstone() {
    this.singleGemstone.push(this.Initial_SingleGemstone());
  }

  removeSingleGemstoneList(index: number) {
    this.singleGemstone.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }

  //#region IllusionDesign

  Initial_IllusionDesign() {
    return this.formBuilder.group({
      name: [""],
      csSize: [""],
      csFamilyName: [""],
      displayType: [""],
      noAUtoSizing: [""],
      diamond: this.formBuilder.array([this.Initial_Diamond()]),
      gemstone: this.formBuilder.array([this.Initial_GemStones()]),
      gold: [""],
      wt: [""],
      wt14: [""],
      wt18: [""],
      wt22: [""],
    });
  }

  illusionDesign(): FormArray {
    return this.centerStoneDefinitionAddForm.get("illusionDesign") as FormArray;
  }

  addIllusionSingleGemstone() {
    this.illusionDesign().push(this.Initial_IllusionDesign());
  }

  removeIllusionSingleGemstone(index: number) {
    this.illusionDesign().removeAt(index);
    // this.fileindexposition--;
    // this.FileListMap.delete(index);
  }

  // // /add diamond data form
  Initial_Diamond() {
    return this.formBuilder.group({
      type: [""],
      wt: [""],
      nos: [""],
      shape: [""],
      twt: [""],
    });
  }

  designdiamond(empIndex: number): FormArray {
    return this.illusionDesign().at(empIndex).get("diamond") as FormArray;
  }

  designgemstone(empIndex: number): FormArray {
    return this.illusionDesign().at(empIndex).get("gemstone") as FormArray;
  }

  diamond(diamondIndex): FormArray {
    return this.illusionDesign().at(diamondIndex).get("diamond") as FormArray;
  }

  addDiamond(diamondIndex) {
    this.designdiamond(diamondIndex).push(this.Initial_Diamond());
  }

  removeDiamondList(illusiondesignIndex: number, diamondIndex: number) {
    this.designdiamond(illusiondesignIndex).removeAt(diamondIndex);
  }

  Initial_GemStones() {
    return this.formBuilder.group({
      name: [""],
      size: [""],
      shape: [""],
      wt: [""],
      nos: [""],
      color: [""],
      twt: [""],
    });
  }

  get gemstone(): FormArray {
    return this.centerStoneDefinitionAddForm.get("gemstone") as FormArray;
  }

  addGemStones(gemstoneIndex) {
    this.designgemstone(gemstoneIndex).push(this.Initial_GemStones());
  }

  removeFGemStoneList(illusiondesignIndex: number, gemstoneIndex: number) {
    this.designgemstone(illusiondesignIndex).removeAt(gemstoneIndex);
    // this.fileindexposition--;
    // this.FileListMap.delete(index);
  }

  // /add Gemstones data Form End

  wtChange(e: any, i: any, illusiondesignIndex: any) {
    this.wtValue = e;
    let diaWt = this.designdiamond(illusiondesignIndex)["controls"][i].value.wt
    let val =
    diaWt *
      this.designdiamond(illusiondesignIndex)["controls"][i].value.nos;
    let data = Math.round(val * 100) / 100;
    this.designdiamond(illusiondesignIndex)["controls"][i]["controls"][
      "twt"
    ].setValue(data);
  }
  nosChange(e: any, i: any, illusiondesignIndex: any) {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)
        : t;
    // let result = this.diamondCaratList.filter(
    //   (c) =>
    //     c.id === this.designdiamond(illusiondesignIndex)["controls"][i].value.wt
    // );
    let diaWt = this.designdiamond(illusiondesignIndex)["controls"][i].value.wt
    let val =
    diaWt *
      this.designdiamond(illusiondesignIndex)["controls"][i].value.nos;
    let data = Math.round(val * 100) / 100;
    this.designdiamond(illusiondesignIndex)["controls"][i]["controls"][
      "twt"
    ].setValue(data);
  }

  twtChange(e: any, i: any, illusiondesignIndex: any) {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)
        : t;
    // let result = this.diamondCaratList.filter(
    //   (c) =>
    //     c.id === this.designdiamond(illusiondesignIndex)["controls"][i].value.wt
    // );
    let diaWt = this.designdiamond(illusiondesignIndex)["controls"][i].value.wt

    let val = this.designdiamond(illusiondesignIndex)["controls"][i].value.twt / diaWt;
    let data = Math.round(val * 100) / 100;
    this.designdiamond(illusiondesignIndex)["controls"][i]["controls"][
      "nos"
    ].setValue(data);
  }

  // /add diamond data  End form

  showAddFamily() {
    this.displayFamilyPop = true;
  }

  ///gemstone add form value chnage''
  gemWtChange(e: any, i: any, illusiondesignIndex: any) {
    this.wtValue = e;
    let result =
    this.designgemstone(illusiondesignIndex)["controls"][i].value.wt;
  let val =
    result *
    this.designgemstone(illusiondesignIndex)["controls"][i].value.nos;
  let data = Math.round(val * 100) / 100;
  this.designgemstone(illusiondesignIndex)["controls"][i]["controls"][
    "twt"
  ].setValue(data);
  }
  gemNosChange(e: any, i: any, illusiondesignIndex: any) {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)
        : t;
    let result =
      this.designgemstone(illusiondesignIndex)["controls"][i].value.wt;
    let val =
      result *
      this.designgemstone(illusiondesignIndex)["controls"][i].value.nos;
    let data = Math.round(val * 100) / 100;
    this.designgemstone(illusiondesignIndex)["controls"][i]["controls"][
      "twt"
    ].setValue(data);
  }

  gemTwtChange(e: any, i: any, illusiondesignIndex: any) {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)
        : t;
    let result =
      this.designgemstone(illusiondesignIndex)["controls"][i].value.wt;
    let val =
      this.designgemstone(illusiondesignIndex)["controls"][i].value.twt /
      result;
    let data = Math.round(val * 100) / 100;
    this.designgemstone(illusiondesignIndex)["controls"][i]["controls"][
      "nos"
    ].setValue(data);
  }

  getDiamondCaratList() {
    this.DiamondCaratService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.diamondCaratList = data;
          this.diamondCaratList.sort((a, b) => {
            return a.carat_name - b.carat_name;
          });
        });
      }
    });
  }

  onModelImageSelect(files: File[]) {
    var base64valueModel;
    for (var element = 0; element < files.length; element++) {
      const readerModel = new FileReader();
      readerModel.readAsDataURL(files[element]);
      readerModel.onload = (event: any) => {
        if (event.target.result) {
          base64valueModel = event.target.result;
          let dataModelObj = {
            base64format: base64valueModel,
            imagePath: files[0].name,
          };
          this.ProductSubTypeService.upload(dataModelObj).subscribe((data) => {
            this.modelImage = data["data"];
            this.partImagePath =
              this.path + "/imagepreview/getImage?imagename=" + this.modelImage;
            this.multipleImages.push(
              this.formBuilder.group({
                images: [this.partImagePath],
                displayUser: [
                  this.centerStoneDefinitionAddForm.value.multipleImages
                    .displayUser === true
                    ? "Y"
                    : "N",
                ],
                selectColor: [
                  this.centerStoneDefinitionAddForm.value.imagecolor,
                ],
                secondOption: [
                  this.centerStoneDefinitionAddForm.value.multipleImages
                    .secondOption === true
                    ? "Y"
                    : "N",
                ],
                Position: [""],
                modelImage: [this.modelImage],
                prongSelect: [""],
              })
            );
          });
        }
      };
    }
  }

  showVariantName(e: any) {
    let merchantId = e.value;
    this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(
      (c) => c.merchantid == merchantId
    );
    this.FilterCsFamilyNames = this.getCsFamilyNames.filter(
      (c) => c.merchantid == merchantId
    );
    // this.csSizeList=this.centerStoneSizeList.filter(
    //   (c)=> c.merchantid == merchantId
    // );
    this.getCenterStoneSizeList();
  }

  @ViewChild('myImage') myImage;
  clearFile(){
    this.myImage.nativeElement.value = '';
  }

  onSubmit() {
    this.submitted = true;
    if(this.centerStoneDefinitionAddForm.get('type').value !==4){
      this.centerStoneDefinitionAddForm.get('variantName').setValidators([Validators.required]);
      this.centerStoneDefinitionAddForm.get('variantName').updateValueAndValidity();
    }
    else{
      this.centerStoneDefinitionAddForm.get('variantName').clearValidators();
      this.centerStoneDefinitionAddForm.get('variantName').updateValueAndValidity();
    }
    this.centerStoneDefinitionAddForm.value.multipleImages.shift();

    if (this.centerStoneDefinitionAddForm.valid) {
      const dataObj = {
        variant_id: this.centerStoneDefinitionAddForm.value.variantName,
        type_id: this.centerStoneDefinitionAddForm.value.type,
        merchant_id: this.centerStoneDefinitionAddForm.value.merchant_Id,
        diamond: null,
        gemstone: null,
        illusion: null,
        design: null,
        Image: this.centerStoneDefinitionAddForm.value.multipleImages,
      };
      if (dataObj.type_id === 1) {
        dataObj.diamond = this.centerStoneDefinitionAddForm.value.singleDiamond;
      } else if (dataObj.type_id === 2) {
        dataObj.gemstone =
          this.centerStoneDefinitionAddForm.value.singleGemstone;
      } else if (dataObj.type_id === 4) {
        dataObj.design = this.centerStoneDefinitionAddForm.value.illusionDesign;
      } else if (dataObj.type_id === 3) {
        dataObj.illusion =
          this.centerStoneDefinitionAddForm.value.illusionDesign;
      }

      this.CenterStoneDefinitionService.save(dataObj).subscribe(
        (data: CenterStoneDefinition) => {
          this.alertService.success(
            "Center Stone Definition saved successfully",
            true
          );
          if (this.vendor_id) {
            this.router.navigate(["MerchantAdminCenterStoneDefinition/list"]);
          } else {
            this.router.navigate(["AdminCenterStoneDefinition/list"]);
          }
        }
      );
    }
  }

  showListOfOptions(event) {
    this.ProductSubTypeService.getProductSubTypeById({
      id: event.value,
    }).subscribe((data) => {
      if (data) {
        let result = data["data"][0];
        if (result.flat_center == "Y")
          this.positionList.push({ id: "flat_center" });
        if (result.flat_left == "Y")
          this.positionList.push({ id: "flat_left" });
        if (result.flat_right == "Y")
          this.positionList.push({ id: "flat_right" });
        if (result.model_center == "Y")
          this.positionList.push({ id: "model_center" });
        if (result.model_left == "Y")
          this.positionList.push({ id: "model_left" });
        if (result.model_right == "Y")
          this.positionList.push({ id: "model_right" });
        if (result.side == "Y") this.positionList.push({ id: "side" });
      }
    });
  }

  toggledisplayuser(i: number, color: string) {
    if (
      this.centerStoneDefinitionAddForm.value.multipleImages[i].displayUser ==
      true
    ) {
      this.centerStoneDefinitionAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["secondOption"].setValue(false);
    }
    this.checkforuniquedisplay(i, color, "displayUser");
  }

  togglesecond(i: number, color: string) {
    if (
      this.centerStoneDefinitionAddForm.value.multipleImages[i].secondOption ==
      true
    ) {
      this.centerStoneDefinitionAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["displayUser"].setValue(false);
    }
    this.checkforuniquedisplay(i, color, "secondOption");
  }

  checkforuniquedisplay(i, color, type) {
    let aFormArray = this.centerStoneDefinitionAddForm.get("multipleImages");
    let count = 0;
    for (let c of aFormArray["controls"]) {
      if (
        c.controls["selectColor"].value == color &&
        c.controls[type].value == type
      ) {
        count++;
        if (count > 1) {
          this.centerStoneDefinitionAddForm.controls["multipleImages"][
            "controls"
          ][i].controls[type].setValue(false);
          this.alertService.success(
            "Selection already available for color",
            false
          );
          break;
        }
      }
    }
  }

  valColor(e: any, i: number, pos: any, prong: any) {
    let aFormArray = this.centerStoneDefinitionAddForm.get("multipleImages");
    let count = 0;
    for (let c of aFormArray["controls"]) {
      if (
        c.controls["selectColor"].value === e.value &&
        c.controls["Position"].value === pos &&
        c.controls["prongSelect"].value === prong
      ) {
        count++;
        if (count > 1) {
          this.centerStoneDefinitionAddForm.controls["multipleImages"][
            "controls"
          ][i].controls["selectColor"].setValue("");
          this.centerStoneDefinitionAddForm.controls["multipleImages"][
            "controls"
          ][i].controls["Position"].setValue("");
          this.centerStoneDefinitionAddForm.controls["multipleImages"][
            "controls"
          ][i].controls["prongSelect"].setValue("");
          this.alertService.success(
            "Selection already available for color",
            false
          );
          break;
        }
      }
    }
  }

  validatePosition(e: any, i: number, color: string, prong: any) {
    console.log(e.value !== "other");

    let aFormArray = this.centerStoneDefinitionAddForm.get("multipleImages");
    if (e.value !== "other") {
      this.centerStoneDefinitionAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["displayUser"].setValue(false);
      this.centerStoneDefinitionAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["secondOption"].setValue(false);

      let countPos = 0;
      for (let c of aFormArray["controls"]) {
        if (
          c.controls["Position"].value === e.value &&
          c.controls["selectColor"].value === color &&
          c.controls["prongSelect"].value === prong
        ) {
          countPos++;
        }
        // if (countPos > 1) {
        //   this.centerStoneDefinitionAddForm.controls["multipleImages"]["controls"][
        //     i
        //   ].controls["Position"].setValue("");
        //   this.alertService.success("Postion Already available for selected color", false);
        //   break;
        // }
      }
    }
  }

  validateProng(e: any, i: number, color: string, pos: any) {
    let aFormArray = this.centerStoneDefinitionAddForm.get("multipleImages");
    let countProng = 0;
    if (
      this.centerStoneDefinitionAddForm.controls["multipleImages"]["controls"][
        i
      ].controls["Position"].value !== "other"
    ) {
      for (let c of aFormArray["controls"]) {
        if (
          c.controls["prongSelect"].value === e.value &&
          c.controls["selectColor"].value === color &&
          c.controls["Position"].value === pos
        )
          countProng++;
        if (countProng > 1) {
          this.centerStoneDefinitionAddForm.controls["multipleImages"][
            "controls"
          ][i].controls["prongSelect"].setValue("");
          this.alertService.success(
            "Prong Already available for selected color",
            false
          );
          break;
        }
      }
    }
  }

  noAutoSize(e, i) {
    if (e.checked[0] === "noAUtoSizing" || e.checked[12] === "noAUtoSizing") {
      this.centerStoneDefinitionAddForm.controls["illusionDesign"]["controls"][
        i
      ].controls["displayType"].setValue("image");
    } else {
      this.centerStoneDefinitionAddForm.controls["illusionDesign"]["controls"][
        i
      ].controls["displayType"].setValue("Auto-Sized");
    }
  }

  autoSize(e, i) {
    if (e.value === "Auto-Sized") {
      this.centerStoneDefinitionAddForm.controls["illusionDesign"]["controls"][
        i
      ].controls["noAUtoSizing"].setValue("noAUtoSizing");
    } else {
      this.centerStoneDefinitionAddForm.controls["illusionDesign"]["controls"][
        i
      ].controls["noAUtoSizing"].setValue("");
    }
  }

  getCenteStoneDefById(id) {
    this.CenterStoneDefinitionService.getCenterStoneDefinitionbyid(
      id
    ).subscribe((data) => {
      if (data) {
        this.setFormValue(data);
      }
    });
  }

  setFormValue(data) {
    let editData = data.data;
    this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(
      (c) => c.merchantid == editData[0].merchant_id
    );
    this.FilterCsFamilyNames = this.getCsFamilyNames.filter(
      (c) => c.merchantid == editData[0].merchant_id
    );
    this.csSizeList = this.centerStoneSizeList.filter(
      (c) =>
        c.merchantid == editData[0].merchant_id
    );
    
    this.centerStoneDefinitionAddForm
      .get("isactive")
      .setValue(editData[0].isactive == "Y" ? true : false);
    this.centerStoneDefinitionAddForm
      .get("merchant_Id")
      .setValue(editData[0].merchant_id);
    this.centerStoneDefinitionAddForm
      .get("variantName")
      .setValue(editData[0].variant_id);
    this.centerStoneDefinitionAddForm.get("type").setValue(editData[0].type_id);

    var JsonData = editData[0].Image;
    var dataOfImage = JsonData;
    this.centerStoneDefinitionAddForm.setControl(
      "multipleImages",
      this.setImageForm(dataOfImage)
    );

    if (this.centerStoneDefinitionAddForm.value.type === 1) {
      this.showDiamondSection = true;
      var JsonData = editData[0].diamond;
      var dataOfSingleDiamond = JsonData;
      this.centerStoneDefinitionAddForm.setControl(
        "singleDiamond",
        this.setSingleDiamondForm(dataOfSingleDiamond)
      );
    } else if (this.centerStoneDefinitionAddForm.value.type === 2) {
      this.showGemStoneSection = true;
      var JsonData = editData[0].gemstone;
      var dataOfSingleGemstone = JsonData;
      this.centerStoneDefinitionAddForm.setControl(
        "singleGemstone",
        this.setSingleGemstoneForm(dataOfSingleGemstone)
      );
    } else if (this.centerStoneDefinitionAddForm.value.type === 3) {
      this.showIllusionDesignSection = true;
      this.displayText = "Illusion Set";
      var JsonImgData = editData[0].illusion;
      console.log('JsonImgDataillusion:', JsonImgData);
      for (let index = 0; index < JsonImgData.length; index++) {
        const element = JsonImgData[index];
        console.log('elementIllusion:', element);
        this.setIllusionForm(element);
      }
      console.log("JsonImgData", JsonImgData);
      this.SetillusionDesign.removeAt(0);
    } else if (this.centerStoneDefinitionAddForm.value.type === 4) {
      this.showIllusionDesignSection = true;
      this.displayText = "Design";
      var JsonImgData = editData[0].design;
      for (let index = 0; index < JsonImgData.length; index++) {
        const element = JsonImgData[index];
        this.setDesignForm(element);
      }
      console.log("JsonImgData", JsonImgData);
      this.SetillusionDesign.removeAt(0);
    }
  }

  setIllusionForm(s) {
    const lessonForm = this.formBuilder.group({
      name: [s.name],
      csSize: [s.csSize],
      noAUtoSizing: [s.noAUtoSizing],
      displayType: [s.displayType],
      diamond: this.formBuilder.array([]),
      gemstone: this.formBuilder.array([]),
      gold: [s.gold],
      wt: [s.wt],
      wt14: [s.wt14],
      wt18: [s.wt18],
      wt22: [s.wt22],
    });
    let varydiamond = lessonForm.controls["diamond"] as FormArray;
    for (let index = 0; index < s.diamond.length; index++) {
      let result = this.adddiamondForm(s);
      varydiamond.push(result);
    }

    let varygemstone = lessonForm.controls["gemstone"] as FormArray;
    for (let index = 0; index < s.gemstone.length; index++) {
      let result = this.addgemstoneForm(s);
      varygemstone.push(result);
    }
    lessonForm.patchValue(s);
    this.SetillusionDesign.push(lessonForm);
  }

  setDesignForm(s) {
    const lessonForm = this.formBuilder.group({
      name: [s.name],
      csSize: [s.csSize],
      noAUtoSizing: [s.noAUtoSizing],
      displayType: [s.displayType],
      diamond: this.formBuilder.array([]),
      gemstone: this.formBuilder.array([]),
      csFamilyName: [s.csFamilyName],
      gold: [s.gold],
      wt: [s.wt],
      wt14: [s.wt14],
      wt18: [s.wt18],
      wt22: [s.wt22],
    });
    let varydiamond = lessonForm.controls["diamond"] as FormArray;
    for (let index = 0; index < s.diamond.length; index++) {
      let result = this.adddiamondForm(s);
      varydiamond.push(result);
    }

    let varygemstone = lessonForm.controls["gemstone"] as FormArray;
    for (let index = 0; index < s.gemstone.length; index++) {
      let result = this.addgemstoneForm(s);
      varygemstone.push(result);
    }
    lessonForm.patchValue(s);
    this.SetillusionDesign.push(lessonForm);
  }

  adddiamondForm(s) {
    const lessonForm = this.formBuilder.group({
      type: [""],
      wt: [""],
      nos: [""],
      shape: [""],
      twt: [""],
    });

    lessonForm.patchValue(s);
    return lessonForm;
  }

  addgemstoneForm(s) {
    const lessonForm = this.formBuilder.group({
      name: [""],
      size: [""],
      shape: [""],
      wt: [""],
      nos: [""],
      color: [""],
      twt: [""],
    });

    lessonForm.patchValue(s);
    return lessonForm;
  }

  get SetillusionDesign() {
    return this.centerStoneDefinitionAddForm.controls[
      "illusionDesign"
    ] as FormArray;
  }

  setSingleDiamondForm(dataOfSingleDiamond): FormArray {
    const formArray = new FormArray([]);
    dataOfSingleDiamond.forEach((s) => {
      formArray.push(
        this.formBuilder.group({
          csDiaTYpe: [s.csDiaTYpe],
          csDiaWt: [s.csDiaWt],
          csSize: [s.csSize],
          displayType: [s.displayType],
          gemstone_name: [s.gemstone_name],
          gold: [s.gold],
          wt: [s.wt],
          wt14: [s.wt14],
          wt18: [s.wt18],
          wt22: [s.wt22],
        })
      );
    });
    return formArray;
  }

  setSingleGemstoneForm(dataOfSingleGemstone): FormArray {
    const formArray = new FormArray([]);
    dataOfSingleGemstone.forEach((s) => {
      formArray.push(
        this.formBuilder.group({
          name: [s.name],
          color: [s.color],
          csSize: [s.csSize],
          diaWt: [s.diaWt],
          displayType: [s.displayType],
          gold: [s.gold],
          wt: [s.wt],
          wt14: [s.wt14],
          wt18: [s.wt18],
          wt22: [s.wt22],
        })
      );
    });
    return formArray;
  }

  setImageForm(dataOfMultipleImages): FormArray {
    const formArray = new FormArray([]);

    for (const s of dataOfMultipleImages) {
      //do something
      formArray.push(
        this.formBuilder.group({
          images: [s.images],
          displayUser: [s.displayUser],
          selectColor: [s.selectColor],
          secondOption: [s.secondOption],
          Position: [s.Position],
          prongSelect: [s.prongSelect],
        })
      );
    }

    return formArray;
  }

  onUpdate() {
    this.submitted = true;
    if (this.centerStoneDefinitionAddForm.valid) {
      const dataObj = {
        id: this.dataId,
        isactive:
          this.centerStoneDefinitionAddForm.value.isactive === true ? "Y" : "N",
        variant_id: this.centerStoneDefinitionAddForm.value.variantName,
        type_id: this.centerStoneDefinitionAddForm.value.type,
        merchant_id: this.centerStoneDefinitionAddForm.value.merchant_Id,
        diamond: null,
        gemstone: null,
        illusion: null,
        design: null,
        Image: this.centerStoneDefinitionAddForm.value.multipleImages,
      };
      if (dataObj.type_id === 1) {
        dataObj.diamond = this.centerStoneDefinitionAddForm.value.singleDiamond;
      } else if (dataObj.type_id === 2) {
        dataObj.gemstone =
          this.centerStoneDefinitionAddForm.value.singleGemstone;
      } else if (dataObj.type_id === 4) {
        dataObj.design = this.centerStoneDefinitionAddForm.value.illusionDesign;
      } else if (dataObj.type_id === 3) {
        dataObj.illusion =
          this.centerStoneDefinitionAddForm.value.illusionDesign;
      }

      this.CenterStoneDefinitionService.updateCenterStoneDefinition(
        dataObj
      ).subscribe((data: CenterStoneDefinition) => {
        this.alertService.success(
          "Center Stone Definition Updated successfully",
          true
        );
        if (this.vendor_id) {
          this.router.navigate(["MerchantAdminCenterStoneDefinition/list"]);
        } else {
          this.router.navigate(["AdminCenterStoneDefinition/list"]);
        }
      });
    }
  }

  backList() {
    if (this.vendor_id) {
      this.router.navigate(["/MerchantAdminCenterStoneDefinition/list"]);
    } else {
      this.router.navigate(["/AdminCenterStoneDefinition/list"]);
    }
  }

  goldCalculation(itemROw, i, type) {
    if (itemROw.value.gold != "" && itemROw.value.wt != 0) {
      let kt = itemROw.value.gold;
      let wt = itemROw.value.wt;

      if (kt == 22) {
        this.centerStoneDefinitionAddForm.controls[type]["controls"][
          i
        ].controls["wt22"].setValue(wt);
        this.centerStoneDefinitionAddForm.controls[type]["controls"][
          i
        ].controls["wt18"].setValue(wt * 0.873);
        this.centerStoneDefinitionAddForm.controls[type]["controls"][
          i
        ].controls["wt14"].setValue(wt * 0.873 * 0.864);
      } else if (kt == 18) {
        this.centerStoneDefinitionAddForm.controls[type]["controls"][
          i
        ].controls["wt18"].setValue(wt);
        this.centerStoneDefinitionAddForm.controls[type]["controls"][
          i
        ].controls["wt14"].setValue(wt * 0.864);
      } else {
        this.centerStoneDefinitionAddForm.controls[type]["controls"][
          i
        ].controls["wt14"].setValue(wt);
      }
    }
  }
}
