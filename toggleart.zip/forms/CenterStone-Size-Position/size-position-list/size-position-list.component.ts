import { CenterStoneVariant } from "@/_models/cs_variant";
import { AlertService, AuthenticationService } from "@/_services";
import { CenterStoneSizePositionService } from "@/_services/cs_size_position.service";
import { Component, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs/internal/Observable";

@Component({
  selector: "app-size-position-list",
  templateUrl: "./size-position-list.component.html",
  styleUrls: ["./size-position-list.component.css"],
})
export class SizePositionListComponent {

  centerStoneSizePositionList: any = [];
  searchForm: FormGroup;
  filterCenterStoneSizePositionList: any = [];
  isChecked: boolean;
  list: any = [];

    constructor(
      private router: Router,
      private formBuilder: FormBuilder,
      private alertService: AlertService,
      private authenticationService: AuthenticationService,
      private CenterStoneSizePositionService: CenterStoneSizePositionService,
      private store: Store<{ producttypes: CenterStoneVariant[] }>
    ) {
      
    }
   
    ngOnInit() {
      this.centerStoneSizevariantList()
      this.createSearchForm()
      }

      centerStoneSizevariantList(){
        this.CenterStoneSizePositionService.getAll()
        .subscribe(data => {
          if (data) {
            this.list = data;
            
              this.centerStoneSizePositionList = this.list.data;
              
              for (let i = 0; i < this.centerStoneSizePositionList.length; i++) {
                this.centerStoneSizePositionList[i].isactive = this.centerStoneSizePositionList[i].isactive === 'N' ? false : true;
                this.centerStoneSizePositionList[i].SrNo = i + 1;
              }
              this.filterCenterStoneSizePositionList = this.centerStoneSizePositionList;
              
          }
        });
      }

      changeStatus(e,data: any){
        this.isChecked = e.checked;
        const dataObj = {
          id: data.id,
          isactive : this.isChecked ? 'Y' : 'N',
        };
        this.CenterStoneSizePositionService.updateCenterStoneSizePosition(dataObj).subscribe((data: CenterStoneVariant) => {
          this.centerStoneSizevariantList();
          this.alertService.success('Status Updated successfully!', true);
          this.router.navigate(['AdminSizePosition/list']);
        });
      
      }

      createSearchForm() {
        this.searchForm = this.formBuilder.group({
          keyword: [''],
        });
      }
      clear() {
        this.searchForm.get('keyword')?.setValue('');
        this.searchGrid();
      }

      searchGrid() {
        let keyword = this.searchForm.controls['keyword'].value;
        if (keyword === '') {
          this.filterCenterStoneSizePositionList = this.centerStoneSizePositionList;
        } else {
          keyword = keyword.toLowerCase();
          this.filterCenterStoneSizePositionList = this.centerStoneSizePositionList.filter((event) => {
            return (
              (event.variant && event.variant.toLowerCase().includes(keyword))||
              (event.framefamily && event.framefamily.toLowerCase().includes(keyword))||
              (event.csSize && event.csSize.includes(keyword))||
              (event.design && event.design.toLowerCase().includes(keyword))||
              (event.merchantname && event.merchantname.toLowerCase().includes(keyword))
              // (event.merchantname && event.merchantname.toLowerCase().includes(keyword))
              
            );
          });
        }
      }
}