import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { VendorService } from "@/_services/vendor.service";
import { Component } from "@angular/core";
import { FormArray, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { environment } from "environments/environment";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { CenterStoneVariantService } from "@/_services/cs_variant.service";
import { CenterStoneSizeService } from "@/_services/cs_size.service";
import { CenterStoneFrameBandService } from "@/_services/cs_frame_band.service";
import { CenterStoneSizePositionService } from "@/_services/cs_size_position.service"
import { CenterStoneSizePosition } from "@/_models/cs_size_position";
import { CenterStoneDefinitionService } from "@/_services/cs_definition.service";


@Component({
  selector: "app-size-position-add",
  templateUrl: "./size-position-add.component.html",
  styleUrls: ["./size-position-add.component.css"],
})
export class SizePositionAddComponent {
  centerStoneSizePositionAddForm: FormGroup;
  centerStoneSizeFactor: FormGroup;
  centerStonePositionDef: FormGroup;
  submitted:boolean;
  merchant_id: number;
  merchantListAll: any = [];
  merchantData: any = [];
  merchantSetData: any = [];
  vendor_id: number;
  merchantListLogin: any;
  merchantCollectionList: any = [];
  centerStoneVariantList: any = [];
  list: any = [];
  productList: any = [];
  productSubList: any = [];
  filteredProductSubList: any = [];
  public adminId = `${environment.adminId}`;
  filtermerchantCollectionList: any = [];
  filterCenterStoneVariantList: any=[];
  centerStoneSizeList: any=[];
  csSizeList: any=[];
  famList: any=[];
  getFrameBandFamilyNames: any=[];
  FilterFrameBandFamilyNames: any=[];
  FilterCsSizeList: any=[];
  public fileindexposition: number = 0;
  FileListMap: Map<number, File> = new Map<number, File>();
  getCsFamilyList:any=[];
  FilterGetCsFamilyList: any = [];
  dataId: any;
  mode: any;
  isslusionDesignnameList: any=[];
  filterIllusionDesignnameList: any=[];
  public selection: string;
  centerStoneFrameBandList: any=[];
  merchantcenterStoneFrameBandList: any=[];
  filtercenterStoneFrameBandList: any=[];
  posIndex: number;
  sizeIndex: number;
  offset1Selected: boolean = false;
offset2Selected: boolean = false;
offset3Selected: boolean = false;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private vendorservices: VendorService,
    private authenticationService: AuthenticationService,
    private vendorauthenticationService: VendorAuthenticationService,
    private ProductSubTypeService: ProductSubTypeService,
    private centerstonvarianService: CenterStoneVariantService,
    private centerstonsizeService: CenterStoneSizeService,
    private CenterStoneFramebandService:CenterStoneFrameBandService,
    private CenterStoneSizePositionService: CenterStoneSizePositionService,
    private CenterStoneDefinitionService: CenterStoneDefinitionService,

  ) {
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id =
        this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.getMerchantList();
    this.createForm();
    this.centerStonevariantList();
    this.getCenterStoneSizeList();
    this.getCSFamilyFamilyBrand();
    this.getCsFamilyDesignList();
    this.getCenterStoneDesign();
    this.getCenterStoneFrameband();
  
    this.route.params.subscribe((params) => {
      if (!!params.id) {
        this.dataId = params.id;

        this.mode = "EDIT";
        this.getCenteStoneSizePosById();
      }
    });
  }
  get f() {
    return this.centerStoneSizePositionAddForm.controls;
  }

  createForm() {
    this.centerStoneSizePositionAddForm = this.formBuilder.group({
      isactive:[''],
      merchant_Id: [this.merchant_id],
      variantName: [""],
      csSize:[''],
      typeSelection:[''],
      offSetSelection:['']
    });

    this.centerStoneSizeFactor = this.formBuilder.group({
      sizeFactor: this.formBuilder.array([this.Initial_SizeFactor()]),
    });

    this.centerStonePositionDef = this.formBuilder.group({
      positiondef: this.formBuilder.array([this.Initial_PositionDef()]),
    });

  }
 
  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantData = data;

          this.merchantSetData = this.merchantData.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });
          this.merchantListAll = this.merchantSetData;
        });
      }
    });
  }


  centerStonevariantList() {
    this.centerstonvarianService.getAll().subscribe((data) => {
      if (data) {
        this.list = data;
        this.centerStoneVariantList = this.list.data;
        this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(c=>c.merchantid == this.centerStoneSizePositionAddForm.value.merchant_Id);
      }
    });
  }
  getCenterStoneDesign() {
    this.CenterStoneDefinitionService.getCenterStoneIllusionDesign().subscribe(
      (data) => {
        
        
        if (data) {
          this.list = data;         
          this.isslusionDesignnameList = this.list.data.filter(x=>x.designName);
          this.filterIllusionDesignnameList =
            this.isslusionDesignnameList.filter(c =>c.merchantId === this.centerStoneSizePositionAddForm.get('merchant_Id').value && c.designName !== "");
          }
      });
  }


  showVariantName(e:any){
    this.getCenterStoneDesign()
    let merchantId = e.value;
    this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(c=>c.merchantid == merchantId);
    this.FilterFrameBandFamilyNames = this.getFrameBandFamilyNames.filter( (c) => c.merchant_id == merchantId);
    this.FilterCsSizeList = this.centerStoneSizeList.filter( (c) => c.merchant_id == merchantId);
    this.FilterGetCsFamilyList = this.getCsFamilyList.filter(
      (c) => c.merchant_id == merchantId
    );
    
      this.filtercenterStoneFrameBandList = this.centerStoneFrameBandList.filter(
        (c) => c.merchantid == merchantId
        );
      this.merchantcenterStoneFrameBandList = this.filtercenterStoneFrameBandList;
      
  }

  showFramebrand(e) {
    let result = [];
    
   this.merchantcenterStoneFrameBandList.forEach(element => {
       if(element.frame_family.some(item => e.value.includes(item)))
       result.push(element);
    });

    this.filtercenterStoneFrameBandList = result;
       
  }

 

  getCenterStoneSizeList(){
    this.centerstonsizeService.getAll()
    .subscribe(data => {
      if (data) {
        this.list = data;
          this.centerStoneSizeList = this.list.data.filter(
            (x) => x.isactive == "Y"
          );
          this.centerStoneSizeList.map(data => {
            data.csSize = data.cs_length + ' * ' + data.cs_width;
            return data;
          });
          this.FilterCsSizeList = this.centerStoneSizeList.filter( (c) => c.merchant_id == this.centerStoneSizePositionAddForm.value.merchant_Id);
      }
    });
  }

   ///#Regin Family Brand 
   getCSFamilyFamilyBrand() {
    this.CenterStoneFramebandService.getCSFamilyFamilyBrand().subscribe((data) => {
      if (data) {
        this.famList = data;
        this.getFrameBandFamilyNames = this.famList.data;
        this.FilterFrameBandFamilyNames = this.getFrameBandFamilyNames.filter( (c) => c.merchant_id == this.centerStoneSizePositionAddForm.value.merchant_Id);
      }
      
      
    });
  }

  getCenterStoneFrameband() {
    this.CenterStoneFramebandService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          //
          this.centerStoneFrameBandList = this.list.data;          
            this.filtercenterStoneFrameBandList = this.centerStoneFrameBandList.filter(
              (c) => c.merchantid == this.centerStoneSizePositionAddForm.value.merchant_Id
              );
              
              this.merchantcenterStoneFrameBandList = this.filtercenterStoneFrameBandList;              
        });
      }
    });
  }

  showFrameBand(e){
    let frameBandFamId = e.value;
    // this.filtercenterStoneFrameBandList = this.centerStoneFrameBandList.filter(c => c.family.every(val => frameBandFamId.includes(val)) );

  }

    /// //// Cs Family   list////

    getCsFamilyDesignList() {
      this.CenterStoneFramebandService.getCSFamilyDesign().subscribe((data) => {
        if (data) {
          setTimeout(() => {
            this.list = data;
            this.getCsFamilyList = this.list.data;
            this.FilterGetCsFamilyList = this.getCsFamilyList.filter(
              (c) => c.merchant_id == this.centerStoneSizePositionAddForm.value.merchant_Id
            );
          });
        }
      });
    }

 

// siZefactor
  Initial_SizeFactor() {
    return this.formBuilder.group({
      csSize: ['',Validators.required],
      heightWidth: [''],
    });
  }

  get sizeFactor() {
    return this.centerStoneSizeFactor.get('sizeFactor') as FormArray;
  }

  addSizeFactor(index: number) {
    this.sizeFactor.push(this.Initial_SizeFactor());
    this.sizeIndex = index;
  }

  removeRowSizeFactor(index: number) {
    this.sizeFactor.removeAt(index);
    this.fileindexposition--;
    this.FileListMap.delete(index);
  }
// sidefactor


// positiondefc
Initial_PositionDef() {
  return this.formBuilder.group({
    frame_family: ['',Validators.required],
    frame_band_id: [''],
    csSize: [''],
    csDesign_name:[''],

    offSetSelection: [''],

    onexOffSetCoordinate:[''],
    oneXOffSetModel: [''],
    oneYOffSetCoordinate:[''],
    oneYOffSetModel:[''],
    
    twoXOffSetCoordinate:[''],
    twoXOffSetModel:[''],
    twoYOffSetCoordinate:[''],
    twoYOffSetModel:[''],

    CXOffSetCoordinate:[''],
    CXOffSetModel:[''],
    CYOffSetCoordinate:[''],
    CYOffSetModel:[''],
  });
}

get positiondef() {
  return this.centerStonePositionDef.get('positiondef') as FormArray;
}

addPositionDef(index: number) {
  this.positiondef.push(this.Initial_PositionDef());
  this.posIndex = index;
}

removeRowPositionDef(index: number) {
  this.positiondef.removeAt(index);
  this.fileindexposition--;
  this.FileListMap.delete(index);
}
// positiondefc


  onSubmit() {
    this.submitted = true;
    if(this.centerStoneSizePositionAddForm.valid && (this.centerStoneSizeFactor.valid || this.centerStonePositionDef.valid)){      const dataObj = {
        merchant_id: this.centerStoneSizePositionAddForm.value.merchant_Id,
        variant: this.centerStoneSizePositionAddForm.value.variantName,
        sizechangefact: this.centerStoneSizeFactor.value.sizeFactor,
        positiondef: this.centerStonePositionDef.value.positiondef,
      }
      
      this.CenterStoneSizePositionService.save(dataObj).subscribe((data: CenterStoneSizePosition) => {
          this.alertService.success('Center Stone Size Position saved successfully!', true);
          if(this.vendor_id){
            this.router.navigate(["MerchantSizePositionList/list"]);
          } else{
            this.router.navigate(["AdminSizePosition/list"]);
          }
        });
    }
  }

  onUpdate(){
    this.submitted = true;
    if(this.centerStoneSizePositionAddForm.valid && (this.centerStoneSizeFactor.valid || this.centerStonePositionDef.valid)){      const dataObj = {
        id:this.dataId,
        isactive: this.centerStoneSizePositionAddForm.value.isactive  === true ? 'Y' :  'N',
        merchant_id: this.centerStoneSizePositionAddForm.value.merchant_Id,
        variant: this.centerStoneSizePositionAddForm.value.variantName,
        sizechangefact: this.centerStoneSizeFactor.value.sizeFactor,
        positiondef: this.centerStonePositionDef.value.positiondef,
      }
      this.CenterStoneSizePositionService.updateCenterStoneSizePosition(dataObj).subscribe((data: CenterStoneSizePosition) => {
          this.alertService.success('Center Stone Size Position Updated successfully!', true);
          if(this.vendor_id){
            this.router.navigate(["MerchantSizePositionList/list"]);
          } else{
            this.router.navigate(["AdminSizePosition/list"]);
          }
        });
    }
  }

  backList() {
    if(this.vendor_id){
      this.router.navigate(["MerchantSizePositionList/list"]);
    } else{
      this.router.navigate(["AdminSizePosition/list"]);
    }
  }

  getCenteStoneSizePosById() {
    this.CenterStoneSizePositionService.getCenterStoneSizePositionbyid({id: this.dataId}).subscribe((data) => {
      if (data) {
        this.setFormValue(data);
        this.getCenterStoneFrameband();
        this.filtercenterStoneFrameBandList = this.centerStoneFrameBandList.filter(
          (c) => c.merchantid == this.centerStoneSizePositionAddForm.value.merchant_Id
          );
          this.centerStonevariantList();
        this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(c=>c.merchantid == this.centerStoneSizePositionAddForm.value.merchant_Id);

      }
    });
  }

  typeSelection(e){
    if(e.value === "SizeFactors"){
      this.sizeFactor.at(this.sizeIndex).get('csSize').setValidators([Validators.required]);
      this.positiondef.at(this.posIndex).get('frame_family')?.clearValidators();
    }
    else if(e.value === "PositionDefinition"){
      this.positiondef.at(this.posIndex).get('frame_family').setValidators([Validators.required]);
      this.sizeFactor.at(this.sizeIndex).get('csSize')?.clearValidators();
    }
  }

  
  setFormValue(data) {
    let editData = data.data;
    this.filterCenterStoneVariantList = this.centerStoneVariantList.filter(c=>c.merchantid == editData[0].merchant_id);
    this.FilterFrameBandFamilyNames = this.getFrameBandFamilyNames.filter( (c) => c.merchant_id == editData[0].merchant_id);
    this.FilterCsSizeList = this.centerStoneSizeList.filter( (c) => c.merchant_id == editData[0].merchant_id);
    this.FilterGetCsFamilyList = this.getCsFamilyList.filter((c) => c.merchant_id == editData[0].merchant_id);
   
   

      if(editData[0].sizechangefact[0].csSize !== ''){
        this.centerStoneSizePositionAddForm.get('typeSelection').setValue('SizeFactors')
      } 
      else if(editData[0].positiondef[0].frame_family !== ''){
        this.centerStoneSizePositionAddForm.get('typeSelection').setValue('PositionDefinition');
      } 

    this.centerStoneSizePositionAddForm.get('isactive').setValue(editData[0].isactive  === "Y" ? true : false );
    this.centerStoneSizePositionAddForm.get('merchant_Id').setValue(editData[0].merchant_id);
    this.centerStoneSizePositionAddForm.get('variantName').setValue(editData[0].variant);    
    var JsonData = editData[0].sizechangefact;
    var dataOfFactor = JsonData;
    this.centerStoneSizeFactor.setControl(
      "sizeFactor",
      this.setSizefactor(dataOfFactor)
    );
      
    
    var JsonData = editData[0].positiondef;
    var dataOFPosition = JsonData;
    this.centerStonePositionDef.setControl(
      "positiondef",
      this.setPoistioDef(dataOFPosition)
    );
 
  }

  // siZefactor
  setSizefactor(dataOfFactor): FormArray {
    const formArray = new FormArray([]);
    for (const s of dataOfFactor) {
      //do something
      formArray.push(
        this.formBuilder.group({
          csSize: [s.csSize],
          heightWidth: [s.heightWidth],
        }) 
      );
    }
    return formArray;
  }
  

// positiondefc
setPoistioDef(dataOFPosition): FormArray {
  
  const formArray = new FormArray([]);
  for (const s of dataOFPosition) {
    //do something
    formArray.push(
      this.formBuilder.group({
        frame_family: [s.frame_family, Validators.required],
        frame_band_id: [s.frame_band_id],
        csSize: [s.csSize],
        csDesign_name:[s.csDesign_name],

        offSetSelection:[s.offSetSelection],

        onexOffSetCoordinate:[s.onexOffSetCoordinate],
        oneXOffSetModel:[s.oneXOffSetModel],
        oneYOffSetCoordinate:[s.oneYOffSetCoordinate],
        oneYOffSetModel:[s.oneYOffSetModel],

        twoXOffSetCoordinate:[s.twoXOffSetCoordinate],
        twoXOffSetModel:[s.twoXOffSetModel],
        twoYOffSetCoordinate:[s.twoYOffSetCoordinate],
        twoYOffSetModel:[s.twoYOffSetModel],

        CXOffSetCoordinate:[s.CXOffSetCoordinate],
        CXOffSetModel:[s.CXOffSetModel],
        CYOffSetCoordinate:[s.CYOffSetCoordinate],
        CYOffSetModel:[s.CYOffSetModel]
      }) 
    );
  }

  return formArray;
}

showForms(e){
  
}


}
