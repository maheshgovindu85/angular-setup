import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportAllDbComponent } from './export-all-db.component';

describe('ExportAllDbComponent', () => {
  let component: ExportAllDbComponent;
  let fixture: ComponentFixture<ExportAllDbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExportAllDbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportAllDbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
