import { AlertService, AuthenticationService } from '@/_services';
import { ImportexportviewService } from '@/_services/importexportview.service';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-export-all-db',
  templateUrl: './export-all-db.component.html',
  styleUrls: ['./export-all-db.component.css']
})
export class ExportAllDbComponent implements OnInit {

  public export_path;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private http: HttpClient,
    private importexportservice: ImportexportviewService
  ) {
    if (!this.authenticationService.currentUserValue) {
      this.router.navigate(['login']);
    } else {
      this.export_path = this.importexportservice.export_path_csv;
    }
  }

  ngOnInit(): void {
  }

}
