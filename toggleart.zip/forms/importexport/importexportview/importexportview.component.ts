import { AlertService, AuthenticationService } from '@/_services';
import { ImportexportviewService } from '@/_services/importexportview.service';
import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import * as XLSX from "xlsx";
import {
  HttpClient,
  HttpEventType,
  HttpErrorResponse,
  HttpResponse,
  HttpEvent
} from "@angular/common/http";
import { map, catchError, tap } from "rxjs/operators";
import { Observable, throwError } from "rxjs";
// npm install xlsx

@Component({
  selector: 'app-importexportview',
  templateUrl: './importexportview.component.html',
  styleUrls: ['./importexportview.component.css']
})
export class ImportexportviewComponent implements OnInit {

  public lock_export: boolean = false;
  public lock_import: boolean = false;
  progress: number;
  uploadedFiles: File;

  JsonData: any;
  allMaps: any;
  frmdata: Map<String, object>[];
  public lock_upload: boolean = true;

  public export_path;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private http: HttpClient,
    private importexportservice: ImportexportviewService
  ) {
    if (!this.authenticationService.currentUserValue) {
      this.router.navigate(['login']);
    } else {

      this.export_path = this.importexportservice.export_path;
      this.importexportservice.getMultipledetails()
        .subscribe((data) => {
          this.frmdata = data;
          console.log(this.frmdata);
          this.JsonData = JSON.parse(JSON.stringify(data));
          this.allMaps = this.JsonData.allMaps;
          // var metal = this.JsonData.metal;
          // var metalpurity = this.JsonData.metalpurity;
          // var metalrates = this.JsonData.metalrates;
          // var metalcolor = this.JsonData.metalcolor;


        })
    }
  }

  ngOnInit(): void {
  }

  exportfile() {
    this.importexportservice.exportnew().subscribe(
      res => {
        console.log(res);
      }
    );
  }
  exportfile1() {
    this.alertService.clear();
    this.lock_export = true;
    const EXCEL_EXTENSION = '.xlsx';
    var currentdate = new Date();
    var final_date = currentdate.getDate() + '/' + (currentdate.getMonth() + 1) + '/' + currentdate.getFullYear() + '_' + currentdate.getHours() + ':' + currentdate.getMinutes();
    var wb: XLSX.WorkBook = XLSX.utils.book_new();;

    const fileName = "ToggleArt";

    this.allMaps.forEach(element => {
      const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.JsonData[element], { header: this.getHeaders(element) });

      XLSX.utils.book_append_sheet(wb, ws, element);
    });
    XLSX.writeFile(wb, fileName + '_export_' + final_date + EXCEL_EXTENSION);
    this.alertService.success('Export Excel File successfully!', true);
  }

  importfile(files: File) {
    this.uploadedFiles = null;
    this.alertService.clear();
    this.lock_import = true;

    var file_format = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    if (file_format === files[0].type) {
      this.uploadedFiles = files[0];
      this.lock_upload = false;
    } else {
      this.alertService.success('Please Select xlxs file Format', true);
      this.lock_import = false;
      this.lock_upload = true;
    }
  }

  UploadFile1() {

    this.progress = 1;
    var formdata = new FormData();
    formdata.append('excelfile', this.uploadedFiles);
    this.importexportservice.upload(formdata)
      .subscribe(
        (event: any) => {
          if (event.type === HttpEventType.UploadProgress) {
            this.progress = Math.round(100 * event.loaded / event.total);

          }
          //  else if (event instanceof HttpResponse) {
          //   console.log(event.body.responseMessage);
          // }
        },
        // (err: any) => {
        //   console.log(err);

        //   if (err.error && err.error.responseMessage) {
        //     console.log(err.error.responseMessage);
        //   } else {
        //     'Error occurred while uploading a file!';
        //   }
        // }
      );
  }
  UploadFile() {
    this.progress = 1;
    var formdata = new FormData();
    formdata.append('excelfile', this.uploadedFiles);
    this.importexportservice.import(formdata)
      .subscribe((event: HttpEvent<any>) => {
        console.log(event);
        switch (event.type) {
          case HttpEventType.Sent:
            console.log('Request has been made!');
            break;
          case HttpEventType.ResponseHeader:
            console.log('Response header has been received!');
            break;
          case HttpEventType.UploadProgress:
            this.progress = Math.round(event.loaded / event.total * 100);
            console.log(`Uploaded! ${this.progress}%`);
            break;
          case HttpEventType.Response:
            console.log('User successfully created!', event.body);
            this.lock_upload = true;
            this.alertService.success('Import Excel File successfully!', true);

            setTimeout(() => {
              this.progress = 0;
            }, 1500);

        }
      })

  }
  // this.lock_upload = true;
  //           this.alertService.success('Import Excel File successfully!', true);

  getHeaders(name: String) {
    switch (name) {
      case "metal":
        return ['id', 'name', 'isdelete', 'savedate', 'modifydate'];
        break;

      case "metalpurity":
        return ['id', 'metal_id', 'carat', 'purity', 'isdefault', 'isbase', 'isdelete', 'savedate', 'modifydate'];
        break;

      case "metalrates":
        return ['id', 'metal_id', 'metal_purity_id', 'rate_date', 'rate_per_gm', 'from_api', 'margin_perc', 'isdelete', 'savedate', 'modifydate'];
        break;

      case "metalcolor":
        return ['id', 'color', 'org_file_name', 'image_path', 'isactive', 'isdelete', 'savedate', 'modifydate'];
        break;
      // Diamond
      case "diamondcarat":
        return ['id', 'carat_name', 'is_active', 'isdelete', 'savedate', 'modifydate'];
        break;

      case "diamondpurity":
        return ['id', 'purity', 'is_active', 'isdelete', 'savedate', 'modifydate'];
        break;

      case "diamondrates":
        return ['id', 'carat', 'shape', 'color', 'purity', 'rate_date', 'rate', 'toggleart_rate', 'isdelete', 'savedate', 'modifydate'];
        break;

      case "diamondcolor":
        return ['id', 'color', 'is_active', 'isdelete', 'savedate', 'modifydate'];
        break;

      case "vendorRangeSolitaireRef":
        return ['id', 'range_id', 'rate', 'diamond_type', 'solitaire_wt', 'ref_date', 'colorid', 'purityid', 'shapeid', 'isactive', 'isdelete', 'savedate', 'modifydate'];
        break;
      // gemstone
      case "gemstone":
        return ['id', 'name', 'isdelete', 'savedate', 'modifydate'];
        break;

      case "centralshapeStoneAssignment":
        return ['id', 'gemstone_id', 'shape_id', 'color_id', 'image_url', 'org_file_name', 'isactive', 'isdelete', 'savedate', 'modifydate'];
        break;

      case "gemstonerate":
        return ['id', 'gemstone_id', 'size', 'weight', 'rate_per_carat', 'rate_date', 'shape', 'pearl', 'color_name', 'typeid', 'isactive', 'savedate', 'modifydate'];
        break;

      case "gemstonetype":
        return ['id', 'type_name', 'isactive', 'isdelete', 'savedate', 'modifydate'];
        break;

      case "globalcolorPreferance":
        return ['id', 'color_name', 'image_path', 'isactive', 'isdelete', 'savedate', 'modifydate'];
        break;

      // Global Shapes
      case "globalshapes":
        return ['id', 'shape', 'is_active', 'isdelete', 'savedate', 'modifydate'];
        break;
    }
  }

}
