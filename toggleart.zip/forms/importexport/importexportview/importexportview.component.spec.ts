import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportexportviewComponent } from './importexportview.component';

describe('ImportexportviewComponent', () => {
  let component: ImportexportviewComponent;
  let fixture: ComponentFixture<ImportexportviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportexportviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportexportviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
