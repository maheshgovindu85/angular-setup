import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChainDesignAnnotationComponent } from './chain-design-annotation.component';

describe('ChainDesignAnnotationComponent', () => {
  let component: ChainDesignAnnotationComponent;
  let fixture: ComponentFixture<ChainDesignAnnotationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChainDesignAnnotationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChainDesignAnnotationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
