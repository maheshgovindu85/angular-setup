import {
  Component,
  OnInit,
  Input,
  OnDestroy,
  ViewChild,
  ViewContainerRef,
  Output,
  HostListener,
  EventEmitter,
  ComponentRef,
  ComponentFactory,
  ElementRef,
  ComponentFactoryResolver
} from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { BehaviorSubject, fromEvent, Observable, Subject } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
// import { CdkDragDrop, moveItemInArray, transferArrayItem, copyArrayItem } from '@angular/cdk/drag-drop';

import { AlertService, AuthenticationService } from '@/_services';

import { AnnotationButtonComponent } from '../../_components/annotation-button/annotation-button.component';
import { resetFakeAsyncZone } from '@angular/core/testing';
import { ChaindesignannotationService } from '@/_services/chaindesignannotation.service';
import { threadId } from 'worker_threads';
import { MetalgoldcolorService } from '@/_services/metalgoldcolor.service';
import { JewelleryDeleteBtnComponent } from '@/_components/jewellery-delete-btn/jewellery-delete-btn.component';
import { Loosebraceletpattern } from '@/_models/loosebraceletpattern';
import { MatTabChangeEvent, MatTabsModule } from '@angular/material/tabs';
import { HeaderComponent } from '@/navigation/header/header.component';
import { NavbarservicesService } from '@/_services/navbarservices.service';
import { $ } from 'protractor';

@Component({
  selector: 'app-chain-design-annotation',
  templateUrl: './chain-design-annotation.component.html',
  styleUrls: ['./chain-design-annotation.component.css']
})
export class ChainDesignAnnotationComponent implements OnInit {
  @Output() public sidenavToggle = new EventEmitter();

  predefinestructureCtrl = new FormControl();
  predefineBracelet: any[];
  filteredPredefineBaracelet: Observable<any[]>;

  public chain_images;
  public addon_images;
  public charm_images;
  public ring_images;
  public lock_images;
  public loosepattern_dtl: Loosebraceletpattern;

  public has_predefinesPattern: boolean = false;
  public flatImageHidenComp = 0;
  public ModelImagesHidComp = 0;

  loading = false;
  submitted = false;
  public topaxisIndex: number = 0;
  public topaxisIndexModel: number = 0;
  public delete_flatIds = 1;

  public topaxisPixel_flat = 100;
  public topaxisPixel_model = 100;
  public columnCount_flat = 1;
  public columnCount_model = 1;

  public ServerURL;
  designForm: FormGroup;
  left: number = 0;
  cmpt = this;

  public activetab = 0;

  @ViewChild('capa', { read: ViewContainerRef }) capa1: ViewContainerRef;
  @ViewChild('capa') capaElementRef1: ElementRef;

  @ViewChild('capa2', { read: ViewContainerRef }) capa2: ViewContainerRef;
  @ViewChild('capa2') capaElementRef2: ElementRef;
  private number1 = 1;
  private number2 = 1;
  private components: [ComponentRef<AnnotationButtonComponent>];
  private Img_dlt_components: [ComponentRef<JewelleryDeleteBtnComponent>];

  items1: any = [];
  items2: any = [];

  message: Subject<string> = new BehaviorSubject('loading :(');


  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private ChaindesignannotationService: ChaindesignannotationService,
    private metalgoldcolorservice: MetalgoldcolorService,
    private NavbarservicesService: NavbarservicesService,
    private resolver: ComponentFactoryResolver) {

    if (!this.authenticationService.currentUserValue) {
      this.router.navigate(['login']);
    }

    // For Product get Details
    ChaindesignannotationService.getPredefinedBracelet().subscribe(
      (data) => {
        this.predefineBracelet = data;
        this.filteredPredefineBaracelet = this.predefinestructureCtrl.valueChanges
          .pipe(
            startWith(''),
            map(m => m ? this.filterPredefinedBaceltetStructure(m) : this.predefineBracelet.slice())
          );
      });
    this.createForm();

    this.ServerURL = metalgoldcolorservice.path;
  }
  ngAfterViewInit() {
    this.NavbarservicesService.isvisible.next(false);
    this.NavbarservicesService.isvisible_menu.next(true);
    // this.NavbarservicesService.disable_menu=true
  }

  ngOnInit() {

    this.designForm.get('pre_braceletpattern').valueChanges.subscribe(
      data => {
        this.ChaindesignannotationService.getMultipleModelDetails(data).subscribe(
          data => {
            var JsonData = JSON.parse(JSON.stringify(data));
            var Braceletstructure_chain = JsonData.Braceletstructure_chain;
            var Braceletstructure_addon = JsonData.Braceletstructure_addon;
            var Braceletstructure_charm = JsonData.Braceletstructure_charm;
            var Braceletstructure_lock = JsonData.Braceletstructure_lock;
            var Braceletstructure_ring = JsonData.Braceletstructure_ring;
            var getLooseBraceletPattern = JsonData.getLooseBraceletPattern;

            this.chain_images = Braceletstructure_chain;
            this.addon_images = Braceletstructure_addon;
            this.charm_images = Braceletstructure_charm;
            this.ring_images = Braceletstructure_ring;
            this.lock_images = Braceletstructure_lock;
            this.loosepattern_dtl = getLooseBraceletPattern;

            this.number1 = 1;
            this.number2 = 1;
            this.items1 = [];
            this.items2 = [];

            if (Braceletstructure_chain)
              this.has_predefinesPattern = true;
          }
        );
      }
    );
  }

  imagesPreview(image_path: string) {
    return this.ServerURL + '/images/' + image_path;
  }

  createForm() {
    this.designForm = this.formBuilder.group({
      id: [0, Validators.required],
      name: ['Bracelet_Design', Validators.required],
      pre_braceletpattern: [0, Validators.required],
      loosebraceletPatternid: [0, Validators.required],
      braceletchain_id: [0, Validators.required],
      isdelete: [false, Validators.required],

      flat_chain_designAnnotation: this.formBuilder.array([]),
      model_chain_designAnnotation: this.formBuilder.array([])
    });
  }

  get Getchain_designAnnotationArray() {
    return this.designForm.get('flat_chain_designAnnotation') as FormArray;
  }
  get GetModel_designAnnotationArray() {
    return this.designForm.get('model_chain_designAnnotation') as FormArray;
  }

  flatchaindesign(tools: any) {
    this.Getchain_designAnnotationArray.push(this.formBuilder.group({
      id: [0, Validators.required],
      chaindesign_id: [0, Validators.required],
      compontIndex: [tools.id, Validators.required],
      tooltype: [tools.toolstype, Validators.required],
      tool_id: [tools.toolsid, Validators.required],
      offsetX: [tools.x, Validators.required],
      offsetY: [tools.y, Validators.required],
      img_path: [tools.img_path, Validators.required],
      isdelete: ['N', Validators.required]
    }));
  }
  modelChainDesign(tools: any) {
    this.GetModel_designAnnotationArray.push(this.formBuilder.group({
      id: [0, Validators.required],
      chaindesign_id: [0, Validators.required],
      compontIndex: [tools.id, Validators.required],
      tooltype: [tools.toolstype, Validators.required],
      tool_id: [tools.toolsid, Validators.required],
      offsetX: [tools.x, Validators.required],
      offsetY: [tools.y, Validators.required],
      img_path: [tools.img_path, Validators.required],
      isdelete: ['N', Validators.required]
    }));
  }

  tabChanged(tabChangeEvent: MatTabChangeEvent): void {
    console.log('tabChangeEvent => ', tabChangeEvent);
    console.log('index => ', tabChangeEvent.index);

    this.activetab = tabChangeEvent.index;
  }

  onSubmit() {
    console.log(this.designForm.value);
    console.log(this.items1);
    console.log(this.items2);
    this.items1.forEach(s => {
      if (s.valid === 'Yes')
        this.flatchaindesign(s);
    });

    this.items2.forEach(s => {
      if (s.valid === 'Yes')
        this.modelChainDesign(s);
    });

    this.designForm.get('name').setValue(this.loosepattern_dtl[0].name);
    this.designForm.get('loosebraceletPatternid').setValue(this.loosepattern_dtl[0].id);
    this.designForm.get('braceletchain_id').setValue(this.chain_images[0].chain_d_w_id);

    this.submitted = true;
    // reset alerts on submit
    this.alertService.clear();
    console.log(this.designForm.value);

    // stop here if form is invalid
    if (this.designForm.invalid) {
      return;
    }
    this.loading = true;
    this.ChaindesignannotationService
      .save(JSON.stringify(this.designForm.value))
      .subscribe((data: any) => {
        // console.log(this.store);
        this.alertService.success('Bracelet Design Add successfully!', true);
        this.NavbarservicesService.isvisible.next(true)
        // this.NavbarservicesService.show();
        this.NavbarservicesService.isvisible_menu.next(false)
        this.router.navigate(['chaindesignannotations_list']);
      });
  }
  callCancelMethod() {
    this.NavbarservicesService.isvisible.next(true);
    // this.NavbarservicesService.show();
    this.NavbarservicesService.isvisible_menu.next(false)
  }

  // convenience getter for easy access to form fields
  get f() { return this.designForm.controls; }

  // ngOnDestroy() {
  //   this.components.forEach((component) => {
  //     component.destroy();
  //   });
  // }


  DeleteAnnotation_Flat(event) {
    const delbtn = event.path[0];
    const instance = (<JewelleryDeleteBtnComponent>delbtn.closest('app-jewellery-delete-btn').closest('#button'));
    const del_no = delbtn.id;
    console.log('flat instant :' + del_no + 'Size :' + this.items1.length)
    document.querySelector('[meta-id="capa"]').removeChild(delbtn.closest('app-jewellery-delete-btn'));
    this.delete_flatIds++;
    this.items1.forEach((element, index) => {
      if (element.id * 1 === del_no * 1) this.items1.splice(index, 1);
    });
    this.resetAnnotations_FlatImages();

  }

  DeleteAnnotation_Model(event) {
    const delbtn = event.path[0];
    const instance = (<AnnotationButtonComponent>delbtn.closest('app-annotation-button').closest('#button'));
    const del_no = delbtn.id;
    document.querySelector('[meta-id="capa2"]').removeChild(delbtn.closest('app-annotation-button'));
    this.items2.forEach((element, index) => {
      if (element.id * 1 === del_no * 1) this.items2.splice(index, 1);
    });
    this.resetAnnotations_ModelImages();
  }

  resetAnnotations_FlatImages() {
    const a: any = document.getElementsByTagName('app-jewellery-delete-btn');
    // if (a.length > 0) {
    //   this.number1 = 0;
    //   for (var i = 0; i < document.getElementsByTagName('app-jewellery-delete-btn').length; i++) {
    //     a[i].getElementsByClassName('delete_annotation_img')[0].id = i + 1 + '';
    //     // a[i].getElementsByTagName('p')[0].innerText = i + 1 + '';
    //     this.number1 = i + 1;
    //   };
    //   this.number1++;
    // }
    // this.items1.forEach((element, index) => {
    //   element.id = index + 1;
    // });

    console.log('from remove instatnt :');
    console.log(this.items1);
  }

  resetAnnotations_ModelImages() {
    const a: any = document.getElementsByTagName('app-annotation-button');
    // if (a.length > 0) {
    //   this.number2 = 0;
    //   for (var i = 0; i < document.getElementsByTagName('app-annotation-button').length; i++) {
    //     a[i].getElementsByClassName('delete_annotation')[0].id = i + 1 + '';
    //     // a[i].getElementsByTagName('p')[0].innerText = i + 1 + '';
    //     this.number2 = i + 1;
    //   };
    //   this.number2++;
    // }
    // this.items2.forEach((element, index) => {
    //   element.id = index + 1;
    // });

  }

  GetcomponentInfo($event) {
    console.log("from canvas class :" + $event);
  }

  AddComponents_TabWise(clickfrom, img, type, typeId, img_path) {
    console.log(this.activetab);
    if (this.activetab === 0) {
      if (this.flatImageHidenComp === 0) {
        this.AppendComponent_flat(clickfrom, img, type, typeId);
      }
      this.addComponent_flat(clickfrom, img, type, typeId, img_path);
    } else {
      if (this.ModelImagesHidComp === 0) {
        this.AppendComponent_model(clickfrom, img, type, typeId);
      }
      this.addComponent_model(clickfrom, img, type, typeId, img_path);

    }
  }

  // change code like
  addComponent_flat(clickfrom, img, type, typeId, img_path) {
    // console.log(this.capaElementRef);
    const factory: ComponentFactory<JewelleryDeleteBtnComponent> = this.resolver.resolveComponentFactory(JewelleryDeleteBtnComponent);
    const viewContainer: ViewContainerRef = this.capa1;
    const component: ComponentRef<JewelleryDeleteBtnComponent> = viewContainer.createComponent(factory, 0);
    // this.componentRef = viewContainer.createComponent(factory, 0);
    this.Img_dlt_components === void 0 ? this.Img_dlt_components = [component] : this.Img_dlt_components.push(component);
    this.initialiseAttribute_flat(component);
    this.insertComponentInLayer_flat(component, img, type, typeId, img_path);
    this.setEvents_flat(component, type, typeId, img_path);

    // this.addComponent_model(clickfrom, img, type, typeId);
  }

  initialiseAttribute_flat(component: ComponentRef<JewelleryDeleteBtnComponent>) {
    component.location.nativeElement.style.position = 'absolute';
    if (this.columnCount_flat === 1) {
      if (this.topaxisIndex === 0) {
        component.location.nativeElement.style.left = 100 + 'px';
        component.location.nativeElement.style.top = 100 + 'px';
      } else {
        const coordinatesX = (100 + (20 * this.topaxisIndex));
        const coordinatesY = (100 + (30 * this.topaxisIndex));
        component.location.nativeElement.style.left = coordinatesX + 'px';
        component.location.nativeElement.style.top = coordinatesY + 'px';
      }
    } else {
      const coordinatesX = ((100 * this.columnCount_flat) + (10 * this.topaxisIndex));
      const coordinatesY = (100 + (50 * this.topaxisIndex));
      component.location.nativeElement.style.left = coordinatesX + 'px';
      component.location.nativeElement.style.top = coordinatesY + 'px';
    }

    this.topaxisPixel_flat = component.location.nativeElement.style.top;
    console.log(this.topaxisPixel_flat)
    if (String(this.topaxisPixel_flat) == '400px') { this.columnCount_flat++; this.topaxisIndex = 1 }
    component.location.nativeElement.setAttribute('draggable', 'true');
    this.topaxisIndex++;
  }

  setEvents_flat(component: ComponentRef<JewelleryDeleteBtnComponent>, type, typeid, img_path) {
    component.location.nativeElement.ondrag = (e) => {
      //return false;
      e.preventDefault();
      component.location.nativeElement.style.display = 'none';

      // component.location.nativeElement.style.left = ((e.x - this.capaElementRef1.nativeElement.offsetLeft - 25) - 160) + scrollX + 'px';
      // component.location.nativeElement.style.top = ((e.y - this.capaElementRef1.nativeElement.offsetTop - 25) - 90) + scrollY + 'px';
      var x_axis = e.offsetX ? (e.offsetX) : e.pageXOffset - this.capaElementRef1.nativeElement.offsetLeft;
      var y_axis = e.offsetY ? (e.offsetY) : e.pageYOffset - this.capaElementRef1.nativeElement.offsetTop;

      component.location.nativeElement.style.left = (e.offsetX + 25) + 'px';
      component.location.nativeElement.style.top = (e.offsetY + 25) + 'px';

      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
    };
    component.location.nativeElement.ondragstart = function (e) {
      //return false;
      const clone = this.cloneNode(true);
      clone.style.backgroundColor = 'red';
      clone.style.display = 'none'; /* or visibility: hidden, or any of the above */
      document.body.appendChild(clone);
      e.dataTransfer.setDragImage(clone, 0, 0);
    };
    component.location.nativeElement.ondragend = (e) => {
      console.log("call on ondraged");
      const scrollX = window.pageXOffset;
      const scrollY = window.pageYOffset;

      e.preventDefault();
      component.location.nativeElement.style.display = 'block';
      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
      const annotation_no = e.path[0].innerText.replace('x', '');

      // const left = (e.x - this.capaElementRef1.nativeElement.offsetLeft - 25) + scrollX;
      // const top = (e.y - this.capaElementRef1.nativeElement.offsetTop - 25) + scrollY;
      // component.location.nativeElement.style.left = (left - 120) + 'px';
      // component.location.nativeElement.style.top = (top - 75) + 'px';


      var left = e.offsetX ? (e.offsetX) : e.pageXOffset - this.capaElementRef1.nativeElement.offsetLeft;
      var top = e.offsetY ? (e.offsetY) : e.pageYOffset - this.capaElementRef1.nativeElement.offsetTop;
      component.location.nativeElement.style.left = e.offsetX + 'px';
      component.location.nativeElement.style.top = e.offsetY + 'px';


      const componentId = component.instance.n;

      this.items1 = this.items1.map(i => {
        if (i.id * 1 === componentId * 1) {
          return { ...i, x: left, y: top, toolstype: type, toolsid: typeid, img_path: img_path, valid: 'Yes' };
        }
        return i;
      });

    };
  }

  insertComponentInLayer_flat(component: ComponentRef<JewelleryDeleteBtnComponent>, img, type, typeid, img_path) {
    document.querySelector('[meta-id="capa"]').appendChild(component.location.nativeElement);
    const instance = (<JewelleryDeleteBtnComponent>component.instance);
    const a = this.capaElementRef1.nativeElement.getElementsByTagName('app-jewellery-delete-btn')
    // instance.n = this.number1;
    // this.number1++;

    instance.n = this.items1.length + 1;

    const delbtn = component.location.nativeElement.getElementsByClassName('delete_annotation_img')[0];
    delbtn.addEventListener('click', this.DeleteAnnotation_Flat.bind(this), false);

    let instant_value;
    const b = this.capaElementRef1.nativeElement.getElementsByTagName('app-jewellery-delete-btn')

    // if (this.items1.length === 0 && instance.n > 1) {
    //   console.log('1')
    //   instant_value = 0
    //   instance.n = 1;
    //   this.number1 = (Number(this.delete_flatIds - this.number1) < 0) ? 0 : (this.delete_flatIds - this.number1);
    // }
    // else {
    console.log('from add instatnt :' + instance.n);
    console.log(this.items1);
    instant_value = instance.n - 1
    // }

    const parent_element = this.capaElementRef1.nativeElement.getElementsByTagName('app-jewellery-delete-btn')[instant_value];
    const image = img.target.cloneNode();
    parent_element.appendChild(image);


    this.items1.push({
      id: instance.n,
      x: component.location.nativeElement.offsetLeft,
      y: component.location.nativeElement.offsetTop,
      toolstype: type,
      toolsid: typeid,
      img_path: img_path, valid: 'Yes'
    });
  }
  // End set Images Directly

  // model Images Bind Dynamically
  // addComponent_model(clickfrom, img, type, typeId, img_path) {
  //   const factory: ComponentFactory<AnnotationButtonComponent> = this.resolver.resolveComponentFactory(AnnotationButtonComponent);
  //   const viewContainer: ViewContainerRef = this.capa2;
  //   const component: ComponentRef<AnnotationButtonComponent> = viewContainer.createComponent(factory, 0);
  //   this.components === void 0 ? this.components = [component] : this.components.push(component);
  //   this.initialiseAttribute_model(component);
  //   this.insertComponentInLayer_model(component, img, type, typeId, img_path);
  //   this.setEvents_model(component, type, typeId, img_path);
  // }

  // initialiseAttribute_model(component: ComponentRef<AnnotationButtonComponent>) {
  //   component.location.nativeElement.style.position = 'absolute';

  //   if (this.columnCount_model === 1) {
  //     if (this.topaxisIndexModel === 0) {
  //       component.location.nativeElement.style.left = 100 + 'px';
  //       component.location.nativeElement.style.top = 100 + 'px';
  //     } else {
  //       const coordinatesY = (100 + (50 * this.topaxisIndexModel));
  //       const coordinatesX = (100 + (20 * this.topaxisIndexModel));
  //       component.location.nativeElement.style.left = coordinatesX + 'px';
  //       component.location.nativeElement.style.top = coordinatesY + 'px';
  //     }
  //   } else {
  //     const coordinatesX = ((100 * this.columnCount_model) + (10 * this.topaxisIndexModel));
  //     const coordinatesY = (100 + (50 * this.topaxisIndexModel));
  //     component.location.nativeElement.style.left = coordinatesX + 'px';
  //     component.location.nativeElement.style.top = coordinatesY + 'px';
  //   }
  //   this.topaxisPixel_model = component.location.nativeElement.style.top;
  //   if (String(this.topaxisPixel_model) == '400px') { this.columnCount_model++; this.topaxisIndexModel = 1 }

  //   component.location.nativeElement.setAttribute('draggable', 'true');
  //   this.topaxisIndexModel++;
  // }

  // setEvents_model(component: ComponentRef<AnnotationButtonComponent>, type, typeid, img_path) {

  //   component.location.nativeElement.ondrag = (e) => {
  //     //return false;
  //     e.preventDefault();

  //     component.location.nativeElement.style.display = 'none';
  //     const scrollX = window.pageXOffset;
  //     const scrollY = window.pageYOffset;

  //     var x_axis = e.offsetX ? (e.offsetX) : e.pageXOffset - this.capaElementRef2.nativeElement.offsetLeft;
  //     var y_axis = e.offsetY ? (e.offsetY) : e.pageYOffset - this.capaElementRef2.nativeElement.offsetTop;
  //     console.log('1 pahila')
  //     console.log(e)
  //     component.location.nativeElement.style.left = (e.offsetX) + 'px'
  //     component.location.nativeElement.style.top = (e.offsetY) + 'px'

  //     e.dataTransfer.effectAllowed = 'none';
  //     e.dataTransfer.dropEffect = 'none';
  //   };
  //   component.location.nativeElement.ondragstart = function (e) {

  //     //return false;
  //     const clone = this.cloneNode(true);
  //     clone.style.backgroundColor = 'red';
  //     clone.style.display = 'none'; /* or visibility: hidden, or any of the above */
  //     document.body.appendChild(clone);
  //     e.dataTransfer.setDragImage(clone, 0, 0);
  //   };
  //   component.location.nativeElement.ondragend = (e) => {
  //     //return false;
  //     const scrollX = window.pageXOffset;
  //     const scrollY = window.pageYOffset;
  //     e.preventDefault();
  //     component.location.nativeElement.style.display = 'block';
  //     e.dataTransfer.effectAllowed = 'none';
  //     e.dataTransfer.dropEffect = 'none';
  //     const annotation_no = e.path[0].innerText.replace('x', '');

  //     const left = (e.x - this.capaElementRef2.nativeElement.offsetLeft) + scrollX;
  //     const top = (e.y - this.capaElementRef2.nativeElement.offsetTop) + scrollY;

  //     console.log('sencond')
  //     console.log(window.screenLeft)

  //     var coordx = (e.screenX - window.screenLeft);
  //     var coordy = (e.screenY - window.screenLeft);

  //     // console.log(this.capaElementRef2.nativeElement.offsetLeft + ' && ' + this.capaElementRef2.nativeElement.offsetTop + " fesrr" + e.offsetX + " oofseY :" + e.offsetY);

  //     component.location.nativeElement.style.left = (e.pageX) + 'px';
  //     component.location.nativeElement.style.top = (e.pageY) + 'px';

  //     const componentId = component.instance.n;

  //     this.items2 = this.items2.map(i => {
  //       if (i.id * 1 === componentId * 1) {
  //         return { ...i, x: left, y: top, toolstype: type, toolsid: typeid, img_path: img_path, valid: 'Yes' };
  //       }
  //       return i;
  //     });

  //   };
  // }

  // insertComponentInLayer_model(component: ComponentRef<AnnotationButtonComponent>, img, type, typeid, img_path) {

  //   document.querySelector('[meta-id="capa2"]').appendChild(component.location.nativeElement);
  //   const instance = (<AnnotationButtonComponent>component.instance);
  //   // instance.n = this.number2;
  //   // this.number2++;

  //   instance.n = this.items2.length + 1;

  //   const delbtn = component.location.nativeElement.getElementsByClassName('delete_annotation')[0];
  //   delbtn.addEventListener('click', this.DeleteAnnotation_Model.bind(this), false);

  //   let model_instant_value;

  //   model_instant_value = instance.n - 1

  //   const parent_element = this.capaElementRef2.nativeElement.getElementsByTagName('app-annotation-button')[model_instant_value];

  //   const image = img.target.cloneNode();
  //   parent_element.appendChild(image);

  //   this.items2.push({
  //     id: instance.n,
  //     x: component.location.nativeElement.offsetLeft,
  //     y: component.location.nativeElement.offsetTop,
  //     toolstype: type,
  //     toolsid: typeid,
  //     img_path: img_path, valid: 'Yes'
  //   });

  // }
  // end  Bind Model images dynamically

  removeAllChildNodes(parent) {
    while (parent.firstChild) {
      parent.removeChild(parent.firstChild);
    }
  }

  filterPredefinedBaceltetStructure(name: string) {
    if (!this.isNumber(name))
      return this.predefineBracelet.filter(m => m.predefine_pattern.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getPredefinedBraceletName(typeId: number) {
    if (this.predefineBracelet != null && typeId != null && typeId != 0) {
      return this.predefineBracelet.filter(s => s.pdbs_id === typeId)[0].predefine_pattern;
    }
  }
  //common for All autocomplete
  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }

  // change code like
  AppendComponent_flat(clickfrom, img, type, typeId) {
    this.flatImageHidenComp = 1;
    // console.log(this.capaElementRef);
    const factory: ComponentFactory<JewelleryDeleteBtnComponent> = this.resolver.resolveComponentFactory(JewelleryDeleteBtnComponent);
    const viewContainer: ViewContainerRef = this.capa1;
    const component: ComponentRef<JewelleryDeleteBtnComponent> = viewContainer.createComponent(factory, 0);
    // this.componentRef = viewContainer.createComponent(factory, 0);
    this.Img_dlt_components === void 0 ? this.Img_dlt_components = [component] : this.Img_dlt_components.push(component);
    this.AppendComponent_initialiseAttribute_flat(component);
    this.AppendComponent_insertComponentInLayer_flat(component, img, type, typeId);
    this.AppendComponent_setEvents_flat(component, type, typeId);
  }

  AppendComponent_initialiseAttribute_flat(component: ComponentRef<JewelleryDeleteBtnComponent>) {
    component.location.nativeElement.style.position = 'absolute';

    if (this.topaxisIndex === 0) {
      component.location.nativeElement.style.left = 100 + 'px';
      component.location.nativeElement.style.top = 100 + 'px';
      component.location.nativeElement.style.display = 'none';
    } else {
      const coordinatesY = (50 + (50 * this.topaxisIndex));
      const coordinatesX = (100 + (20 * this.topaxisIndex));
      component.location.nativeElement.style.left = coordinatesX + 'px';
      component.location.nativeElement.style.top = coordinatesY + 'px';
      component.location.nativeElement.style.display = 'none';
    }
    component.location.nativeElement.setAttribute('draggable', 'true');
    this.topaxisIndex++
  }


  AppendComponent_setEvents_flat(component: ComponentRef<JewelleryDeleteBtnComponent>, type, typeid) {
    component.location.nativeElement.ondrag = (e) => {
      //return false;
      e.preventDefault();

      component.location.nativeElement.style.left = (e.x - this.capaElementRef1.nativeElement.offsetLeft - 25) + scrollX + 'px';
      component.location.nativeElement.style.top = (e.y - this.capaElementRef1.nativeElement.offsetTop - 25) + scrollY + 'px';

      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
    };
    component.location.nativeElement.ondragstart = function (e) {
      //return false;
      const clone = this.cloneNode(true);
      clone.style.backgroundColor = 'red';
      clone.style.display = 'none'; /* or visibility: hidden, or any of the above */
      document.body.appendChild(clone);
      e.dataTransfer.setDragImage(clone, 0, 0);
    };
    component.location.nativeElement.ondragend = (e) => {
      console.log("call on ondraged");
      const scrollX = window.pageXOffset;
      const scrollY = window.pageYOffset;

      e.preventDefault();
      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
      const annotation_no = e.path[0].innerText.replace('x', '');
      console.log('flat anotation no :' + annotation_no);
      console.log('scrolling Y :' + scrollY);
      const left = (e.x - this.capaElementRef1.nativeElement.offsetLeft - 25) + scrollX;
      const top = (e.y - this.capaElementRef1.nativeElement.offsetTop - 25) + scrollY;

      component.location.nativeElement.style.left = left + 'px';
      component.location.nativeElement.style.top = top + 'px';

      const componentId = component.instance.n;

      this.items1 = this.items1.map(i => {
        if (i.id * 1 === componentId * 1) {
          return { ...i, x: left, y: top };
        }
        return i;
      });


    };
  }

  AppendComponent_insertComponentInLayer_flat(component: ComponentRef<JewelleryDeleteBtnComponent>, img, type, typeid) {
    document.querySelector('[meta-id="capa"]').appendChild(component.location.nativeElement);
    const instance = (<JewelleryDeleteBtnComponent>component.instance);
    const a = this.capaElementRef1.nativeElement.getElementsByTagName('app-jewellery-delete-btn')
    instance.n = this.number1;
    this.number1++;

    const delbtn = component.location.nativeElement.getElementsByClassName('delete_annotation_img')[0];
    delbtn.addEventListener('click', this.DeleteAnnotation_Flat.bind(this), false);

    let instant_value;
    const b = this.capaElementRef1.nativeElement.getElementsByTagName('app-jewellery-delete-btn')

    instant_value = instance.n - 1

    const parent_element = this.capaElementRef1.nativeElement.getElementsByTagName('app-jewellery-delete-btn')[instant_value];

    const image = img.target.cloneNode();
    parent_element.appendChild(image);

    this.items1.push({
      id: instance.n,
      x: component.location.nativeElement.offsetLeft,
      y: component.location.nativeElement.offsetTop,
      toolstype: type,
      toolsid: typeid,
      valid: 'No'
    });
  }

  // model Images Bind Dynamically
  AppendComponent_model(clickfrom, img, type, typeId) {
    this.ModelImagesHidComp = 1;
    const factory: ComponentFactory<AnnotationButtonComponent> = this.resolver.resolveComponentFactory(AnnotationButtonComponent);
    const viewContainer: ViewContainerRef = this.capa2;
    const component: ComponentRef<AnnotationButtonComponent> = viewContainer.createComponent(factory, 0);
    // this.Img_dlt_components === void 0 ? this.Img_dlt_components = [component] : this.Img_dlt_components.push(component);
    this.components === void 0 ? this.components = [component] : this.components.push(component);
    this.AppendComponentinitialiseAttribute_model(component);
    this.AppendComponentinsertComponentInLayer_model(component, img, type, typeId);
    this.AppendComponentsetEvents_model(component, type, typeId);
  }

  AppendComponentinitialiseAttribute_model(component: ComponentRef<AnnotationButtonComponent>) {
    component.location.nativeElement.style.position = 'absolute';

    if (this.topaxisIndexModel === 0) {
      component.location.nativeElement.style.left = 100 + 'px';
      component.location.nativeElement.style.top = 100 + 'px';
      component.location.nativeElement.style.display = 'none';
    } else {
      const coordinatesY = (100 + (50 * this.topaxisIndexModel));
      const coordinatesX = (196 + (20 * this.topaxisIndexModel));
      component.location.nativeElement.style.left = coordinatesX + 'px';
      component.location.nativeElement.style.top = coordinatesY + 'px';
      component.location.nativeElement.style.display = 'none';
    }
    component.location.nativeElement.setAttribute('draggable', 'true');
    this.topaxisIndexModel++;
  }


  AppendComponentsetEvents_model(component: ComponentRef<AnnotationButtonComponent>, type, typeid) {

    component.location.nativeElement.ondrag = (e) => {
      //return false;
      e.preventDefault();
      const scrollX = window.pageXOffset;
      const scrollY = window.pageYOffset;
      component.location.nativeElement.style.left = (e.x - this.capaElementRef2.nativeElement.offsetLeft - 25) + scrollX + 'px';
      component.location.nativeElement.style.top = (e.y - this.capaElementRef2.nativeElement.offsetTop - 25) + scrollY + 'px';
      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
    };
    component.location.nativeElement.ondragstart = function (e) {
      //return false;
      const clone = this.cloneNode(true);
      clone.style.backgroundColor = 'red';
      clone.style.display = 'none'; /* or visibility: hidden, or any of the above */
      document.body.appendChild(clone);
      e.dataTransfer.setDragImage(clone, 0, 0);
    };
    component.location.nativeElement.ondragend = (e) => {
      //return false;
      const scrollX = window.pageXOffset;
      const scrollY = window.pageYOffset;
      e.preventDefault();
      // console.log('Drag end', e);
      // console.log(e.dataTransfer);
      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
      // console.log(e.path);
      const annotation_no = e.path[0].innerText.replace('x', '');

      const left = (e.x - this.capaElementRef2.nativeElement.offsetLeft - 25) + scrollX;
      const top = (e.y - this.capaElementRef2.nativeElement.offsetTop - 25) + scrollY;
      component.location.nativeElement.style.left = left + 'px';
      component.location.nativeElement.style.top = top + 'px';

      const componentId = component.instance.n;

      this.items2 = this.items2.map(i => {
        if (i.id * 1 === componentId * 1) {
          return { ...i, x: left, y: top, toolstype: type, toolsid: typeid, valid: 'No' };
        }
        return i;
      });
    };

  }

  AppendComponentinsertComponentInLayer_model(component: ComponentRef<AnnotationButtonComponent>, img, type, typeid) {

    document.querySelector('[meta-id="capa2"]').appendChild(component.location.nativeElement);
    const instance = (<AnnotationButtonComponent>component.instance);
    instance.n = this.number2;
    this.number2++;

    const delbtn = component.location.nativeElement.getElementsByClassName('delete_annotation')[0];
    delbtn.addEventListener('click', this.DeleteAnnotation_Model.bind(this), false);

    // console.log('model instant :' + instance.n + 'Size :' + this.items2.length)
    let model_instant_value;
    // if (this.items2.length === 0) {
    //   model_instant_value = 0
    // } else {
    model_instant_value = instance.n - 1
    // }

    const parent_element = this.capaElementRef2.nativeElement.getElementsByTagName('app-annotation-button')[model_instant_value];

    const image = img.target.cloneNode();
    parent_element.appendChild(image);

    this.items2.push({
      id: instance.n,
      x: component.location.nativeElement.offsetLeft,
      y: component.location.nativeElement.offsetTop,
      toolstype: type,
      toolsid: typeid,
      valid: 'No'
    });

  }


  // ____________________________________________________________________________________________________________________________________________

  addComponent_model(clickfrom, img, type, typeId, img_path) {
    const factory: ComponentFactory<AnnotationButtonComponent> = this.resolver.resolveComponentFactory(AnnotationButtonComponent);
    const viewContainer: ViewContainerRef = this.capa2;
    const component: ComponentRef<AnnotationButtonComponent> = viewContainer.createComponent(factory, 0);
    this.components === void 0 ? this.components = [component] : this.components.push(component);
    this.initialiseAttribute_model(component);
    this.insertComponentInLayer_model(component, img, type, typeId, img_path);
    this.setEvents_model(component, type, typeId, img_path);
  }

  initialiseAttribute_model(component: ComponentRef<AnnotationButtonComponent>) {
    component.location.nativeElement.style.position = 'absolute';

    if (this.columnCount_model === 1) {
      if (this.topaxisIndexModel === 0) {
        component.location.nativeElement.style.left = 100 + 'px';
        component.location.nativeElement.style.top = 100 + 'px';
      } else {
        const coordinatesY = (100 + (50 * this.topaxisIndexModel));
        const coordinatesX = (100 + (20 * this.topaxisIndexModel));
        component.location.nativeElement.style.left = coordinatesX + 'px';
        component.location.nativeElement.style.top = coordinatesY + 'px';
      }
    } else {
      const coordinatesX = ((100 * this.columnCount_model) + (10 * this.topaxisIndexModel));
      const coordinatesY = (100 + (50 * this.topaxisIndexModel));
      component.location.nativeElement.style.left = coordinatesX + 'px';
      component.location.nativeElement.style.top = coordinatesY + 'px';
    }
    this.topaxisPixel_model = component.location.nativeElement.style.top;
    if (String(this.topaxisPixel_model) == '400px') { this.columnCount_model++; this.topaxisIndexModel = 1 }

    component.location.nativeElement.setAttribute('draggable', 'true');
    this.topaxisIndexModel++;
  }

  setEvents_model(component: ComponentRef<AnnotationButtonComponent>, type, typeid, img_path) {

    component.location.nativeElement.ondrag = (e) => {
      //return false;
      e.preventDefault();

      component.location.nativeElement.style.display = 'none';
      const scrollX = window.pageXOffset;
      const scrollY = window.pageYOffset;

      // var x_axis = e.offsetX ? (e.offsetX) : e.pageXOffset - this.capaElementRef2.nativeElement.offsetLeft;
      // var y_axis = e.offsetY ? (e.offsetY) : e.pageYOffset - this.capaElementRef2.nativeElement.offsetTop;

      component.location.nativeElement.style.left = (e.offsetX + 15) + 'px'
      component.location.nativeElement.style.top = (e.offsetY + 15) + 'px'

      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
    };
    component.location.nativeElement.ondragstart = function (e) {

      //return false;
      const clone = this.cloneNode(true);
      clone.style.backgroundColor = 'red';
      clone.style.display = 'none'; /* or visibility: hidden, or any of the above */
      document.body.appendChild(clone);
      e.dataTransfer.setDragImage(clone, 0, 0);
    };
    component.location.nativeElement.ondragend = (e) => {
      //return false;
      const scrollX = window.pageXOffset;
      const scrollY = window.pageYOffset;
      e.preventDefault();
      component.location.nativeElement.style.display = 'block';
      e.dataTransfer.effectAllowed = 'none';
      e.dataTransfer.dropEffect = 'none';
      const annotation_no = e.path[0].innerText.replace('x', '');

      const left = (e.x - this.capaElementRef2.nativeElement.offsetLeft) + scrollX;
      const top = (e.y - this.capaElementRef2.nativeElement.offsetTop) + scrollY;

      // console.log(this.capaElementRef2.nativeElement.offsetLeft + ' && ' + this.capaElementRef2.nativeElement.offsetTop + " fesrr" + e.offsetX + " oofseY :" + e.offsetY);

      // let el = e.srcElement;
      // let offsetLeft = 0;
      // let offsetTop = 0;
      // while (el) {
      //   offsetLeft += el.offsetLeft;
      //   offsetTop += el.offsetTop;
      //   el = el.parentElement;
      // }
      // console.log(offsetLeft + " && " + offsetTop);
      // console.log(e)

      component.location.nativeElement.style.left = (e.offsetX - 15) + 'px';
      component.location.nativeElement.style.top = (e.offsetY - 15) + 'px';

      const componentId = component.instance.n;

      this.items2 = this.items2.map(i => {
        if (i.id * 1 === componentId * 1) {
          return { ...i, x: left, y: top, toolstype: type, toolsid: typeid, img_path: img_path, valid: 'Yes' };
        }
        return i;
      });

    };

    // component.location.nativeElement.ondrag = (ev) => {
    //   ev.dataTransfer.setData("text", ev.target.id);
    // }

    //  component.location.nativeElement.ondragend = function (ev) {

    //   ev.preventDefault();
    //   //return false;
    //   const clone = this.cloneNode(true);
    //   clone.style.backgroundColor = 'red';
    //   clone.style.display = 'none'; /* or visibility: hidden, or any of the above */
    //   document.body.appendChild(clone);
    //   ev.dataTransfer.setDragImage(clone, 0, 0);
    // };

  }

  insertComponentInLayer_model(component: ComponentRef<AnnotationButtonComponent>, img, type, typeid, img_path) {

    document.querySelector('[meta-id="capa2"]').appendChild(component.location.nativeElement);
    const instance = (<AnnotationButtonComponent>component.instance);
    // instance.n = this.number2;
    // this.number2++;

    instance.n = this.items2.length + 1;

    const delbtn = component.location.nativeElement.getElementsByClassName('delete_annotation')[0];
    delbtn.addEventListener('click', this.DeleteAnnotation_Model.bind(this), false);

    let model_instant_value;

    model_instant_value = instance.n - 1

    const parent_element = this.capaElementRef2.nativeElement.getElementsByTagName('app-annotation-button')[model_instant_value];

    const image = img.target.cloneNode();
    parent_element.appendChild(image);

    this.items2.push({
      id: instance.n,
      x: component.location.nativeElement.offsetLeft,
      y: component.location.nativeElement.offsetTop,
      toolstype: type,
      toolsid: typeid,
      img_path: img_path, valid: 'Yes'
    });
  }
}
