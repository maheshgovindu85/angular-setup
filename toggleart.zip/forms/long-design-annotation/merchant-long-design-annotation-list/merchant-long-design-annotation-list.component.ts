import { ProductSubtype } from "@/_models/productsubtype";
import { AlertService, AuthenticationService, VendorAuthenticationService } from "@/_services";
import { LongDesignAnnotationService } from "@/_services/long_design_annotation.service";
import {Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { Router } from "@angular/router";

@Component({
    selector: "app-merchant-long-design-annotation-list",
    templateUrl: "./merchant-long-design-annotation-list.component.html",
    styleUrls: ["./merchant-long-design-annotation-list.component.css"],
  })

export class MerchantLongDesignAnnotationListComponent implements OnInit {
  
  list: any=[];
  searchForm: FormGroup;
  merchantAnnotationList:any =[];
  isChecked:boolean;
  activeStatus: any;
  filterMerchantAnnotation: any=[];
  vendor_id: number;
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private LongDesignAnnotationService: LongDesignAnnotationService,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private vendorauthenticationService: VendorAuthenticationService,

  ) {
    if (!this.vendorauthenticationService.vendorcurrentUserValue) {
      this.router.navigate(['merchant']);
    }
  }

  ngOnInit() {
    this.vendor_id = this.vendorauthenticationService.vendorcurrentUserValue.id;

    this.getallAnnotationData();
    this.createSearchForm();
   }
   

   getallAnnotationData(){
    this.LongDesignAnnotationService.getAll()
     .subscribe(data => {
       if (data) {
         setTimeout(() => {
           this.list = data;
          this.merchantAnnotationList = this.list.data;
          for(let i =0; i <this.merchantAnnotationList.length;i++){
           this.merchantAnnotationList[i].isactive = this.merchantAnnotationList[i].isactive === 'N' ? false : true;
           this.merchantAnnotationList[i].SrNo = i+1;
         }
          this.filterMerchantAnnotation = this.merchantAnnotationList
         });
       }
     });
 }

// Search button function start
createSearchForm() {
 this.searchForm = this.formBuilder.group({
   keyword: [''],
 });
}
clear() {
 this.searchForm.get('keyword')?.setValue('');
 this.searchGrid();
}
searchGrid() {
 let keyword = this.searchForm.controls['keyword'].value;
 if (keyword === '') {
   this.filterMerchantAnnotation = this.merchantAnnotationList;
 } else {
   keyword = keyword.toLowerCase();
   this.filterMerchantAnnotation = this.merchantAnnotationList.filter((event) => {
     return (
       (event.product_sub_type && event.product_sub_type.toLowerCase().includes(keyword)) ||
       (event.productname && event.productname.toLowerCase().includes(keyword)) ||
       (event.merchantname && event.merchantname.toLowerCase().includes(keyword)) ||
       (event.designno && event.designno.toLowerCase().includes(keyword)) 
     );
   });
 }
}

changeStatus(e,data: any){
  this.isChecked = e.checked;
  const dataObj = {
    id: data.id,
    isactive : this.isChecked ? 'Y' : 'N',
  };
  this.LongDesignAnnotationService.updateAnnotation(dataObj).subscribe((data: ProductSubtype) => {
    this.getallAnnotationData();
    this.alertService.success('Status Updated successfully!', true);
    this.router.navigate(['MerchantlongDesignAnnotation/list']);
  });

}
 

}