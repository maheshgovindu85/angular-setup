import { ProductSubtype } from "@/_models/productsubtype";
import { AlertService, AuthenticationService } from "@/_services";
import { LongDesignAnnotationService } from "@/_services/long_design_annotation.service";
import {Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { Router } from "@angular/router";

@Component({
    selector: "app-long-design-annotation-list",
    templateUrl: "./long-design-annotation-list.component.html",
    styleUrls: ["./long-design-annotation-list.component.css"],
  })

export class LongDesignAnnotationListComponent implements OnInit {
  
  list: any=[];
  searchForm: FormGroup;
  annotationList:any =[];
  isChecked:boolean;
  activeStatus: any;
  filterAnnotation: any=[];
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private LongDesignAnnotationService: LongDesignAnnotationService,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
  ) {
    if (!this.authenticationService.currentUserValue) {
    }
  }

  ngOnInit() {
    this.getallAnnotationData();
    this.createSearchForm();
   }
   

   getallAnnotationData(){
    this.LongDesignAnnotationService.getAll()
     .subscribe(data => {
       if (data) {
         setTimeout(() => {
           this.list = data;
          this.annotationList = this.list.data;
          for(let i =0; i <this.annotationList.length;i++){
           this.annotationList[i].isactive = this.annotationList[i].isactive === 'N' ? false : true;
           this.annotationList[i].SrNo = i+1;
         }
         this.filterAnnotation = this.annotationList
          
         });
       }
     });
 }

// Search button function start
createSearchForm() {
 this.searchForm = this.formBuilder.group({
   keyword: [''],
 });
}
clear() {
 this.searchForm.get('keyword')?.setValue('');
 this.searchGrid();
}
searchGrid() {
 let keyword = this.searchForm.controls['keyword'].value;
 if (keyword === '') {
   this.filterAnnotation = this.annotationList;
 } else {
   keyword = keyword.toLowerCase();
   this.filterAnnotation = this.annotationList.filter((event) => {
     return (
      (event.product_sub_type && event.product_sub_type.toLowerCase().includes(keyword)) ||
      (event.productname && event.productname.toLowerCase().includes(keyword)) ||
      (event.merchantname && event.merchantname.toLowerCase().includes(keyword)) ||
      (event.designno && event.designno.toLowerCase().includes(keyword)) 
     );
   });
 }
}

changeStatus(e,data: any){
  this.isChecked = e.checked;
  const dataObj = {
    id: data.id,
    isactive : this.isChecked ? 'Y' : 'N',
  };
  this.LongDesignAnnotationService.updateAnnotation(dataObj).subscribe((data: ProductSubtype) => {
    this.getallAnnotationData();
    this.alertService.success('Status Updated successfully!', true);
    this.router.navigate(['longDesignAnnotation/list']);
  });

}
 

}