import {
  AlertService,
  AuthenticationService,
  VendorAuthenticationService,
} from "@/_services";
import { ProductTypeService } from "@/_services/product-type.service";
import { ProductSubTypeService } from "@/_services/product-sub-type.service";
import { Component, OnInit } from "@angular/core";
import { FormArray, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { VendorService } from "@/_services/vendor.service";
import { LongDesignPredefineService } from "@/_services/long-design-predefine.service";
import { environment } from "environments/environment";
import { LongDesignDefinitionService } from "@/_services/long-design-defifnition.service";
import { LongDesignAnnotation } from "@/_models/long_design_annotation";
import { LongDesignAnnotationService } from "@/_services/long_design_annotation.service";
import { rootImageService } from "@/_services/root_image.service";
import { rootImage } from "@/_models/root_image";
import { MetalgoldcolorService } from "@/_services/metalgoldcolor.service";
import { CenterStonePredefineService } from "@/_services/cs_predefine.service";

@Component({
  selector: "app-long-design-annotation-edit",
  templateUrl: "./long-design-annotation-edit.component.html",
  styleUrls: ["./long-design-annotation-edit.component.css"],
})
export class LongDesignAnnotationEditComponent implements OnInit {
  longDesignAnnotationEditForm: FormGroup;
  customizationmethod: string;
  submitted: boolean;
  productList: any = [];
  productSubList: any = [];
  list: any = [];
  merchantList: any = [];
  selectSubList: any = [];
  // dataObj: { base64format: any; imagePath: string; };
  dataObj = {};
  dataObjModel = {};
  showFlat: boolean = true;
  showModel: boolean = false;
  predefineData: any = [];
  selectPredefinedList: any = [];
  merchantData: any = [];
  merchantSetData: any = [];
  produdtId: any;
  productSub_id: any;
  longDesignDefList: any = [];
  definiList: any = [];
  selectDefinitionData: any = [];
  displaySubProductList: any = [];
  topImages: any = [];
  MidImages: any = [];
  DropImages: any = [];
  Item1Images: any = [];
  Item2Images: any = [];
  Item3Images: any = [];
  FrameBandImages: any = [];
  flatFrameBandImages: any = [];
  flattopImages: any = [];
  flatMidImages: any = [];
  flatDropImages: any = [];
  flatItem1Images: any = [];
  flatItem2Images: any = [];
  flatItem3Images: any = [];
  modelFrameBandImages: any = [];
  modeltopImages: any = [];
  modelMidImages: any = [];
  modelDropImages: any = [];
  modelItem1Images: any = [];
  modelItem2Images: any = [];
  modelItem3Images: any = [];
  displayImages: boolean = false;
  displayItem1: boolean = false;
  displayItem2: boolean = false;
  displayItem3: boolean = false;
  selectedpredefineid: number;

  public path = `${environment.apiUrl}`;
  merchant_id: any;
  public adminId = `${environment.adminId}`;
  vendor_id: any;
  Stub: any[] = [];
  NumberOfStub: number = 0;
  annotationID: number;
  Stub_model: any[] = [];
  NumberOfStub_model: number = 0;
  annotationData: any = [];
  modelImage: any;
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private producttypeService: ProductTypeService,
    private ProductSubTypeService: ProductSubTypeService,
    private vendorservices: VendorService,
    private LongDesignPredefineService: LongDesignPredefineService,
    private authenticationService: AuthenticationService,
    private LongDesignDefinitionService: LongDesignDefinitionService,
    private LongDesignAnnotationService: LongDesignAnnotationService,
    private vendorauthenticationService: VendorAuthenticationService,
    private rootImageService: rootImageService,
    private route: ActivatedRoute,
    private metalgoldcolorservice: MetalgoldcolorService,
    private centerStonePredefineService: CenterStonePredefineService
  ) {
    if (!this.authenticationService.currentUserValue) {
      this.vendor_id =
        this.vendorauthenticationService.vendorcurrentUserValue.id;
      this.merchant_id = this.vendor_id;
    } else {
      this.adminId = JSON.parse(this.adminId);
      this.merchant_id = JSON.parse(this.adminId);
    }
  }

  ngOnInit() {
    this.annotationID = this.route.snapshot.params.id;

    this.createForm();
    this.getAllProductById();
    this.getProductSubTypeData();
    this.getProductList();
    this.getMerchantList();
    this.getPredefineData();

    this.getLongDesignDefiniData();
  }

  get f() {
    return this.longDesignAnnotationEditForm.controls;
  }

  createForm() {
    this.longDesignAnnotationEditForm = this.formBuilder.group({
      isactive: [""],
      product_id: ["", Validators.required],
      predefined: ["", Validators.required],
      product_sub_type: ["", Validators.required],
      merchantid: [this.merchant_id],
    });
  }

  onSubmit() {
    this.submitted = true;

    if (this.longDesignAnnotationEditForm.valid) {
      const dataObj = {
        id: this.annotationID,
        isactive: this.longDesignAnnotationEditForm.value.isactive ? "Y" : "N",
        product_id: this.longDesignAnnotationEditForm.value.product_id,
        ld_predefine_id: this.selectedpredefineid,
        customizationmethod: this.customizationmethod,
        sub_product_id:
          this.longDesignAnnotationEditForm.value.product_sub_type,
        merchantid: this.longDesignAnnotationEditForm.value.merchantid,
        designcoord: this.Stub,
        designcoordModel: this.Stub_model,
      };
      this.LongDesignAnnotationService.updateAnnotation(dataObj).subscribe(
        (data: LongDesignAnnotation) => {
          this.alertService.success(
            "Long Design Annotation Updated successfully!",
            true
          );
          if (this.vendor_id) {
            this.router.navigate(["MerchantlongDesignAnnotation/list"]);
          } else {
            this.router.navigate(["longDesignAnnotation/list"]);
          }
        }
      );
    }
  }

  getAllProductById() {
    this.LongDesignAnnotationService.getLongDesignAnnotationbyid({
      id: this.annotationID,
    }).subscribe((data) => {
      if (data) {
        this.setFormValue(data);
      }
    });
  }

  setFormValue(data) {
    this.annotationData = data.data;
    this.longDesignAnnotationEditForm
      .get("isactive")
      ?.setValue(this.annotationData[0].isactive === "Y" ? true : false);
    this.customizationmethod = this.annotationData[0].customizationmethod;
    this.longDesignAnnotationEditForm
      .get("product_id")
      ?.setValue(this.annotationData[0].product_id);
    this.longDesignAnnotationEditForm
      .get("merchantid")
      ?.setValue(this.annotationData[0].merchantid);
    this.longDesignAnnotationEditForm
      .get("product_sub_type")
      ?.setValue(this.annotationData[0].sub_product_id);
    this.longDesignAnnotationEditForm
      .get("predefined")
      ?.setValue(
        this.annotationData[0].customizationmethod +
          "-" +
          this.annotationData[0].ld_predefine_id
      );
    this.Stub = this.annotationData[0].designcoord;
    console.log("this.Stub:", this.Stub);
    this.Stub_model = this.annotationData[0].designcoordModel;
    this.showDefinitionData();
    this.getModelImage(
      this.annotationData[0].merchantid,
      this.annotationData[0].sub_product_id
    );
  }
  //// product  list////

  getProductList() {
    this.producttypeService.getAll().subscribe((data) => {
      if (data) {
        //
        setTimeout(() => {
          this.productList = data;
        });
      }
    });
  }
  //// product  list end////

  getMerchantList() {
    this.vendorservices.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.merchantData = data;

          this.merchantSetData = this.merchantData.map((user) => {
            user.merchantId =
              user.id + " | " + user.firstname + " | " + user.company;
            return user;
          });

          // if(!this.vendor_id){
          //   this.merchantListAll = this.merchantSetData;
          //
          // } else {
          //   this.merchantListLogin = this.merchantSetData.filter(e=>e.id === this.vendor_id)
          // }
        });
      }
    });
  }

  getLongDesignDefiniData() {
    this.LongDesignDefinitionService.getAll().subscribe((data) => {
      if (data) {
        this.definiList = data;
        this.longDesignDefList = this.definiList.data;
      }
    });
  }

  //// product sub type list////

  getProductSubTypeData() {
    this.ProductSubTypeService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.productSubList = this.list.data;
          this.displaySubProductList = this.productSubList;
          // this.getproductSubType();
        });
      }
    });
  }
  //// product sub type list End////

  ////merchant list

  getPredefineData() {
    this.LongDesignPredefineService.getAllpredefine().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.list = data;
          this.predefineData = this.list.data;
          this.selectPredefinedList = this.predefineData;
        });
      }
    });
  }

  subProductChange(event) {
    this.produdtId = event.value;
    this.displaySubProductList = this.productSubList.filter(
      (c) =>
        c.product_id === this.produdtId && c.merchantid === this.merchant_id
    );
  }

  merchantChange(event: any) {
    this.merchant_id = event.value;
    this.displaySubProductList = this.selectSubList.filter(
      (c) => c.merchantid === this.merchant_id
    );
  }

  showPredefined(event: any) {
    this.productSub_id = event.value;
    this.getModelImage(this.merchant_id, this.productSub_id);
    this.selectPredefinedList = this.predefineData.filter(
      (e) => e.product_sub_typeId === this.productSub_id
    );
    // let item = this.selectPredefinedList[0];
  }

  showDefinitionData() {
    this.displayImages = true;

    this.selectedpredefineid = this.annotationData[0].ld_predefine_id;
    this.customizationmethod = this.annotationData[0].customizationmethod;
    if (this.customizationmethod == "ld") {
      this.LongDesignDefinitionService.getLongDesignPredefineDetailbyid({
        id: this.selectedpredefineid,
      }).subscribe((data) => {
        if (data) {
          this.definiList = data;
          this.longDesignDefList = this.definiList.data;
          this.flattopImages = this.longDesignDefList?.topval[0]?.image.filter(
            (f) =>
              f.images !== "" &&
              f.Position !== "other" &&
              !f.Position.includes("model")
          );
          this.flatMidImages = this.longDesignDefList?.midval[0]?.image.filter(
            (f) =>
              f.images !== "" &&
              f.Position !== "other" &&
              !f.Position.includes("model")
          );
          if (this.longDesignDefList.dropval.length > 0) {
            this.flatDropImages =
              this.longDesignDefList?.dropval[0]?.image.filter(
                (f) =>
                  f.images !== "" &&
                  f.Position !== "other" &&
                  !f.Position.includes("model")
              );
            this.modelDropImages =
              this.longDesignDefList?.dropval[0]?.image.filter(
                (f) =>
                  f.images !== "" &&
                  f.Position !== "other" &&
                  f.Position.includes("model")
              );
          }
          this.modeltopImages = this.longDesignDefList?.topval[0]?.image.filter(
            (f) =>
              f.images !== "" &&
              f.Position !== "other" &&
              f.Position.includes("model")
          );
          this.modelMidImages = this.longDesignDefList?.midval[0]?.image.filter(
            (f) =>
              f.images !== "" &&
              f.Position !== "other" &&
              f.Position.includes("model")
          );

          this.setImages(this.showFlat);
        }
      });
    } else if (this.customizationmethod == "cs") {
      this.centerStonePredefineService
        .getCS_PredefineDetailbyid({
          id: this.selectedpredefineid,
        })
        .subscribe((data) => {
          this.definiList = data;
          this.longDesignDefList = this.definiList.data;
          if (this.longDesignDefList.item1) {
            this.flatItem1Images = this.longDesignDefList?.item1[0]?.Image.filter(
              (f) =>
                f.images !== "" &&
                f.Position !== "other" &&
                !f.Position.includes("model")
            );
            this.modelItem1Images =
              this.longDesignDefList.item1[0].Image.filter(
                (f) =>
                  f.images !== "" &&
                  f.Position !== "other" &&
                  f.Position.includes("model")
              );
          }
          if (this.longDesignDefList.item2) {
            this.flatItem2Images = this.longDesignDefList?.item2[0]?.Image.filter(
              (f) =>
                f.images !== "" &&
                f.Position !== "other" &&
                !f.Position.includes("model")
            );
            this.modelItem2Images =
              this.longDesignDefList.item2[0].Image.filter(
                (f) =>
                  f.images !== "" &&
                  f.Position !== "other" &&
                  f.Position.includes("model")
              );
          }
          if (this.longDesignDefList.item3) {
            this.flatItem3Images = this.longDesignDefList?.item3[0]?.Image.filter(
              (f) =>
                f.images !== "" &&
                f.Position !== "other" &&
                !f.Position.includes("model")
            );
            this.modelItem3Images =
              this.longDesignDefList?.item3[0]?.Image.filter(
                (f) =>
                  f.images !== "" &&
                  f.Position !== "other" &&
                  f.Position.includes("model")
              );
          }

          this.flatFrameBandImages =
            this.longDesignDefList?.frame_band[0]?.cs_image_comm.filter(
              (f) =>
                f.images !== "" &&
                f.Position !== "other" &&
                !f.Position.includes("model")
            );
          this.modelFrameBandImages =
            this.longDesignDefList?.frame_band[0]?.cs_image_comm.filter(
              (f) =>
                f.images !== "" &&
                f.Position !== "other" &&
                f.Position.includes("model")
            );
          if (this.longDesignDefList.dropval.length > 0) {
            this.flatDropImages =
              this.longDesignDefList?.dropval[0]?.image.filter(
                (f) =>
                  f.images !== "" &&
                  f.Position !== "other" &&
                  !f.Position.includes("model")
              );
            this.modelDropImages =
              this.longDesignDefList?.dropval[0]?.image.filter(
                (f) =>
                  f.images !== "" &&
                  f.Position !== "other" &&
                  f.Position.includes("model")
              );
          }
          this.setImages(this.showFlat);
        });
    }

    // this.displayImages = true;
  }

  setImages(check) {
    if (check) {
      this.topImages = this.flattopImages;
      this.MidImages = this.flatMidImages;
      this.DropImages = this.flatDropImages;
      this.FrameBandImages = this.flatFrameBandImages;
      this.Item1Images = this.flatItem1Images;
      this.Item2Images = this.flatItem2Images;
      this.Item3Images = this.flatItem3Images;
    } else {
      this.topImages = this.modeltopImages;
      this.MidImages = this.modelMidImages;
      this.DropImages = this.modelDropImages;
      this.FrameBandImages = this.modelFrameBandImages;
      this.Item1Images = this.modelItem1Images;
      this.Item2Images = this.modelItem2Images;
      this.Item3Images = this.modelItem3Images;
    }
  }

  toggleTab(data) {
    if (data === "flat") {
      this.showFlat = true;
      this.showModel = false;
    } else if (data === "model") {
      this.showFlat = false;
      this.showModel = true;
    }
    this.setImages(this.showFlat);
  }

  backToList() {
    if (this.vendor_id) {
      this.router.navigate(["MerchantlongDesignAnnotation/list"]);
    } else {
      this.router.navigate(["longDesignAnnotation/list"]);
    }
  }
  AddComponents_TabWise(img, type, img_path, position, color) {
    if (this.showFlat) {
      this.addComponent_flat(img, type, img_path, position, color);
    } else {
      this.addComponent_model(img, type, img_path, position, color);
    }
  }
  addComponent_flat(img, type, img_path, position, color) {
    this.Stub.push({
      id: this.NumberOfStub,
      flatIndex: type + "_" + this.NumberOfStub,
      IDNumber: 0,
      addFrom: "insert",
      compontIndex: this.NumberOfStub,
      tooltype: type,
      offsetX: 0,
      offsetY: 0,
      img_path: img_path,
      valid: false,
      position: position,
      color: color,
      dragposition: {
        x: 0,
        y: 0,
      },
    });

    // img.target.style.height = charmdetails.charmlength + 'px';
    // img.target.style.width = charmdetails.charmlength + 'px';
    const image = img.target.cloneNode();

    this.Stub.forEach((e) => {
      if (e.id === this.NumberOfStub * 1) {
        // this.flatchaindesign(e);
      }
    });
    this.NumberOfStub++;
    // var capa1_load = setInterval(() => {
    //   var cls = ".stubNumber_" + this.NumberOfStub;
    //   if (document.querySelector(cls)) {
    //     clearInterval(capa1_load);
    //     var parents_elm = document.querySelector(cls);
    //     parents_elm.appendChild(image);
    //     this.NumberOfStub++;
    //     if (type == "addon") {
    //       img.target.style.height = 45 + "px";
    //       img.target.style.width = 45 + "px";
    //     } else {
    //       img.target.style.height = 65 + "px";
    //       img.target.style.width = 65 + "px";
    //     }
    //   }
    // }, 0);
  }

  addComponent_model(img, type, img_path, position, color) {
    this.Stub_model.push({
      id: this.NumberOfStub_model,
      flatIndex: type + "_" + this.NumberOfStub_model,
      IDNumber: 0,
      addFrom: "insert",
      compontIndex: this.NumberOfStub_model,
      tooltype: type,
      offsetX: 0,
      offsetY: 0,
      img_path: img_path,
      valid: false,
      position: position,
      color: color,
      dragposition: {
        x: 0,
        y: 0,
      },
    });

    // img.target.style.height = charmdetails.charmlength + 'px';
    // img.target.style.width = charmdetails.charmlength + 'px';
    const image = img.target.cloneNode();

    this.Stub_model.forEach((e) => {
      if (e.id === this.NumberOfStub_model * 1) {
        // this.flatchaindesign(e);
      }
    });
    this.NumberOfStub_model++;
    // var capa1_load = setInterval(() => {
    //   var cls = ".stubNumber_" + this.NumberOfStub_model;
    //   if (document.querySelector(cls)) {
    //     clearInterval(capa1_load);
    //     var parents_elm = document.querySelector(cls);
    //     parents_elm.appendChild(image);
    //     this.NumberOfStub_model++;
    //     if (type == "addon") {
    //       img.target.style.height = 45 + "px";
    //       img.target.style.width = 45 + "px";
    //     } else {
    //       img.target.style.height = 65 + "px";
    //       img.target.style.width = 65 + "px";
    //     }
    //   }
    // }, 0);
  }

  onDragEnded(event, i) {
    let data = event.source.getFreeDragPosition();
    // let element = event.source.getRootElement();
    // let boundingClientRect = element.getBoundingClientRect();
    // let parentPosition = this.getPosition(element);

    var InnerID = event.source.element.nativeElement.children[1].innerHTML;

    this.Stub.forEach((e) => {
      if (e.id === InnerID * 1) {
        // (e.offsetX = boundingClientRect.x - parentPosition.left),
        //   (e.offsetY = boundingClientRect.y - parentPosition.top);
        // e.dragposition.x = e.offsetX;
        // e.dragposition.y = e.offsetY;
        e.dragposition = data;
      }
    });
  }

  setFlatStub() {}

  onDragEndedModel(event, i) {
    let data = event.source.getFreeDragPosition();
    // console.log(data);
    
    // let element = event.source.getRootElement();
    // let boundingClientRect = element.getBoundingClientRect();
    // let parentPosition = this.getPosition(element);
    var InnerID = event.source.element.nativeElement.children[1].innerHTML;
    // console.log(this.Stub_model);
    this.Stub_model.forEach((e) => {
      if (e.id === InnerID * 1) {
        e.dragposition = data;
        // (e.offsetX = boundingClientRect.x - parentPosition.left),
        //   (e.offsetY = boundingClientRect.y - parentPosition.top);
        // e.dragposition.x = e.offsetX;
        // console.log("🚀 ~ file: long-design-annotation-edit.component.ts:636 ~ LongDesignAnnotationEditComponent ~ this.Stub_model.forEach ~ e.dragposition.x:", e.dragposition.x)
        // e.dragposition.y = e.offsetY;
        // console.log("🚀 ~ file: long-design-annotation-edit.component.ts:638 ~ LongDesignAnnotationEditComponent ~ this.Stub_model.forEach ~ e.dragposition.y:", e.dragposition.y)
      }
    });
  }

  getPosition(el) {
    let x = 0;
    let y = 0;
    while (el && !isNaN(el.offsetLeft) && !isNaN(el.offsetTop)) {
      x += el.offsetLeft - el.scrollLeft;
      y += el.offsetTop - el.scrollTop;
      el = el.offsetParent;
    }
    return { top: y, left: x };
  }
  delete_stub(i: number, id: number) {
    this.Stub.forEach((element, index) => {
      if (element.id === id) {
        var ckk = false;
        // this.GetModel_designAnnotationArray.controls.forEach((e2123: FormArray, index) => {
        //   if (String(element.flatIndex) === String(e2123.controls['toolsLink'].value)) {
        //     ckk = true;
        //   }
        // });

        if (!ckk) {
          // this.NumberOfStub = this.NumberOfStub - 1;
          this.Stub.splice(index, 1);
          this.NumberOfStub = this.Stub.length;

          // this.Getchain_designAnnotationArray.removeAt(element.id);

          // this.flat_relation_details.controls.forEach((elementm, index) => {
          //   if (id === elementm.value.index) {
          //     console.log('Match Conditions ' + index);
          //     this.flat_relation_details.removeAt(index);
          //   }
          // });
        } else {
          alert("This tool are link with some model image..!");
        }
      }
    });
    for (let index = 0; index < this.Stub.length; index++) {
      this.Stub[index].id = index;
      this.Stub[index].compontIndex = index;
      this.Stub[index].flatIndex =
        "Flat " + this.Stub[index].tooltype + "_" + index;
      this.NumberOfStub = index + 1;
    }

    // var rearangelinkcharm = this.designForm.get('model_chain_designAnnotation') as FormArray;
    // rearangelinkcharm.controls.forEach((e: FormArray) => {
    //   e.get('toolsLink').setValue("");
    // })

    // var autoincrement_id = 0;
    // var deleteflatchainannotation = this.designForm.get('flat_chain_designAnnotation') as FormArray;
    // deleteflatchainannotation.controls.forEach((e: FormArray) => {
    //   e.get('compontIndex').setValue(autoincrement_id);
    //   e.get('flatIndex').setValue("Flat " + e.get("tooltype").value + "_" + autoincrement_id);
    //   autoincrement_id++;
    // })
  }

  delete_stubModel(i: number, id: number) {
    this.Stub_model.forEach((element, index) => {
      if (element.id === id) {
        var ckk = false;
        // this.GetModel_designAnnotationArray.controls.forEach((e2123: FormArray, index) => {
        //   if (String(element.flatIndex) === String(e2123.controls['toolsLink'].value)) {
        //     ckk = true;
        //   }
        // });

        if (!ckk) {
          // this.NumberOfStub_model = this.NumberOfStub_model - 1;
          this.Stub_model.splice(index, 1);
          this.NumberOfStub_model = this.Stub_model.length
          // this.Getchain_designAnnotationArray.removeAt(element.id);

          // this.flat_relation_details.controls.forEach((elementm, index) => {
          //   if (id === elementm.value.index) {
          //     console.log('Match Conditions ' + index);
          //     this.flat_relation_details.removeAt(index);
          //   }
          // });
        } else {
          alert("This tool are link with some model image..!");
        }
      }
    });
    for (let index = 0; index < this.Stub_model.length; index++) {
      this.Stub_model[index].id = index;
      this.Stub_model[index].compontIndex = index;
      this.Stub_model[index].flatIndex =
        "Model " + this.Stub_model[index].tooltype + "_" + index;
      this.NumberOfStub_model = index + 1;
    }

    // var rearangelinkcharm = this.designForm.get('model_chain_designAnnotation') as FormArray;
    // rearangelinkcharm.controls.forEach((e: FormArray) => {
    //   e.get('toolsLink').setValue("");
    // })

    var autoincrement_id = 0;
    // var deleteflatchainannotation = this.designForm.get('flat_chain_designAnnotation') as FormArray;
    // deleteflatchainannotation.controls.forEach((e: FormArray) => {
    //   e.get('compontIndex').setValue(autoincrement_id);
    //   e.get('flatIndex').setValue("Flat " + e.get("tooltype").value + "_" + autoincrement_id);
    //   autoincrement_id++;
    // })
  }

  getModelImage(merchant_id, product_subtype_id) {
    this.rootImageService
      .getRootImagebysubPr_mercharhantId({
        merchant_id: merchant_id,
        product_subtype_id: product_subtype_id,
      })
      .subscribe((data: rootImage) => {
        this.modelImage =this.metalgoldcolorservice.path +"/imagepreview/getImage?imagename=" +data["data"][0].modelimage;
      });
  }

  getUrl() {
    return "url('" + this.modelImage + "')";
  }
}
