import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerOrdersService } from '@/forms/Client_Pages/customer-orders.service';
import { DiamondShapeService, GemstoneService } from "@/_services";
import { GlobalColorPreferenceService } from "@/_services/global-color-preference.service";
import { CenterStoneSizeService } from '@/_services/cs_size.service';
import { CenterStoneVariantService } from '@/_services/cs_variant.service';




@Component({
  selector: 'app-customer-order-view',
  templateUrl: './customer-order-view.component.html',
  styleUrls: ['./customer-order-view.component.css']
})
export class CustomerOrderViewComponent implements OnInit {
  input: any;
  orderId: number;
  getOrderDetail: any = [];
  diamondShapeList: any = [];
  filteredDiamondShapeList: any;
  diamondData: any;

  allDiamondDataDetails: any = []
  allGemstoneDataDetails: any = [];
  filteredGemShapeList: any = [];
  gemstoneList: any = [];
  filteredGemNameList: any = [];
  diamondDataList: any = [];
  gemstoneDataList: any = [];
  gemstoneColorList: any = [];
  filteredGemColorList: any = [];
  solitaireData: any = [];
  DiamondData: any = [];
  gemStoneData: any = [];
  goldData: any = [];
  dimaondtype: any;
  centerStoneSizeList: any = [];
  merchantCenterVariantList: any = [];
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public CustomerOrdersService: CustomerOrdersService,
    private DiamondShapeService: DiamondShapeService,
    private GemstoneService: GemstoneService,
    private GlobalColorPreferenceService: GlobalColorPreferenceService,
    private centerstonsizeService: CenterStoneSizeService,
    private centerstonvariantService: CenterStoneVariantService

  ) {

    this.orderId = this.route.snapshot.params.order_id;
    
   
   }

  ngOnInit(): void {
    this.GemstoneService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneList = data;
        });
      }
    });

    this.DiamondShapeService.getAll().subscribe((data) => {
      if (data) {
        this.diamondShapeList = data;
        this.viewOrder(this.orderId);
      }
    });

    this.GlobalColorPreferenceService.getAll().subscribe((data) => {
      if (data) {
        setTimeout(() => {
          this.gemstoneColorList = data;
        });
      }
    });

    this.centerstonsizeService.getAll()
      .subscribe(data => {
        if (data) {
            this.centerStoneSizeList = data['data'];
            this.centerStoneSizeList.map(data => {
              data.csSize = data.cs_length + ' * ' + data.cs_width;
              return data;
            });
        }
      });

      this.centerstonvariantService
        .getAll()
        .subscribe((data) => {
          if (data) {
            let res = data;
            this.merchantCenterVariantList = res["data"];
            }
        });
        
  }

 
  viewOrder(orderId) {


    this.CustomerOrdersService.getCustomerOrderDetailbyid({ id: orderId }).subscribe((data) => {
      if (data) {
        this.getOrderDetail = data['data'][0];
        // console.log("🚀 ~ file: customer-order-view.component.ts:84 ~ CustomerOrderViewComponent ~ this.CustomerOrdersService.getCustomerOrderDetailbyid ~ this.getOrderDetail:", this.getOrderDetail)

        if (Object.keys(this.getOrderDetail.gold).length > 0) {
          this.goldData.push(this.getOrderDetail.gold)
        }
        if (Object.keys(this.getOrderDetail.solitaire).length > 0) {
          this.solitaireData.push(this.getOrderDetail.solitaire);
        }

        if (Object.keys(this.getOrderDetail.diamond).length > 0) {
          this.DiamondData.push(this.getOrderDetail.diamond);
        }
        this.dimaondtype = this.DiamondData[0].DiaType;        
        if (this.getOrderDetail?.dropval?.data?.diamond?.length > 0) {
          for(const element of this.getOrderDetail?.dropval?.data?.diamond) {   
            let tempdata = {
              type: element.type,
              wt: element.wt,
              nos: element.nos,
              twt: element.twt,
              shape: this.diamondShapeList.filter((c) => (c.id == element.shape))[0].shape,
              quality: this.dimaondtype
            }
            this.allDiamondDataDetails.push(tempdata)
          }
        } 
        if (this.getOrderDetail?.top?.data?.diamond?.length > 0) {
          for(const element of this.getOrderDetail?.top?.data?.diamond) {   
            let tempdata = {
              type: element.type,
              wt: element.wt,
              nos: element.nos,
              twt: element.twt,
              shape: this.diamondShapeList.filter((c) => (c.id == element.shape))[0].shape,
              quality: this.dimaondtype
            }
            this.allDiamondDataDetails.push(tempdata)
          }
        } 
        if (this.getOrderDetail?.mid?.data?.diamond?.length > 0) {
          for(const element of this.getOrderDetail?.mid?.data?.diamond) {   
           let tempdata = {
              type: element.type,
              wt: element.wt,
              nos: element.nos,
              twt: element.twt,
              shape: this.diamondShapeList.filter((c) => (c.id == element.shape))[0].shape,
              quality: this.dimaondtype
            }
            this.allDiamondDataDetails.push(tempdata)
          }
        } else if (this.getOrderDetail?.design1?.data?.diamond?.length > 0) {
          this.allDiamondDataDetails.push(this.getOrderDetail?.design1?.data?.diamond)
        } else if (this.getOrderDetail?.design2?.data?.diamond?.length > 0) {
          this.allDiamondDataDetails.push(this.getOrderDetail?.design2?.data?.diamond)
        } else if (this.getOrderDetail?.design3?.data?.diamond?.length > 0) {
          this.allDiamondDataDetails.push(this.getOrderDetail?.design3?.data?.diamond)
        } else if (this.getOrderDetail?.frameband?.data[0]?.diamond?.length > 0) {
          let typeprice = this.getOrderDetail?.frameband?.calc?.diamondresult.filter(x=>x.type == this.dimaondtype);
           for(const element of this.getOrderDetail?.frameband?.data[0]?.diamond) {             
            let tempdata = {
              type: element.diaType,
              wt: element.wt,
              nos: element.nos,
              twt: element.twt,
              shape: this.diamondShapeList.filter((c) => (c.id == element.shape))[0].shape,
              quality: this.dimaondtype
            }
            this.allDiamondDataDetails.push(tempdata)
            
          }
        }
      
        // console.log("🚀 ~ file: customer-order-view.component.ts:123 ~ CustomerOrderViewComponent ~ this.CustomerOrdersService.getCustomerOrderDetailbyid ~  this.allDiamondDataDetails:",  this.allDiamondDataDetails)

        if (this.getOrderDetail?.dropval?.cal?.gemstoneResult?.length > 0) {
          for(const element of this.getOrderDetail?.dropval?.data?.gemstone) {     
             let tempdata = {
              name:this.gemstoneList.filter((c) => (c.id == element.name))[0].name,
              color: this.gemstoneColorList.filter((c) => (c.id == element.color))[0].color_name,
              shape: this.diamondShapeList.filter((c) => (c.id == element.shape))[0].shape,
              size: element.size,
              wt: element.wt,
              nos: element.nos,
              twt: element.twt,
              quality: this.getOrderDetail.gemstone[0].type
            }
            this.allGemstoneDataDetails.push(tempdata);            
          }
        } 
        if (this.getOrderDetail?.top?.cal?.gemstoneResult?.length > 0) {
          for(const element of this.getOrderDetail?.top?.data?.gemstone) {     
            let tempdata = {
             name:this.gemstoneList.filter((c) => (c.id == element.name))[0].name,
             color: this.gemstoneColorList.filter((c) => (c.id == element.color))[0].color_name,
             shape: this.diamondShapeList.filter((c) => (c.id == element.shape))[0].shape,
             size: element.size,
             wt: element.wt,
             nos: element.nos,
             twt: element.twt,
             quality: this.getOrderDetail.gemstone[0].type
           }
           this.allGemstoneDataDetails.push(tempdata);            
         }
        } 
        if (this.getOrderDetail?.mid?.cal?.gemstoneResult?.length > 0) {
          for(const element of this.getOrderDetail?.mid?.data?.gemstone) {     
            let tempdata = {
             name:this.gemstoneList.filter((c) => (c.id == element.name))[0].name,
             color: this.gemstoneColorList.filter((c) => (c.id == element.color))[0].color_name,
             shape: this.diamondShapeList.filter((c) => (c.id == element.shape))[0].shape,
             size: element.size,
             wt: element.wt,
             nos: element.nos,
             twt: element.twt,
             quality: this.getOrderDetail.gemstone[0].type
           }
           this.allGemstoneDataDetails.push(tempdata);            
         }
        } 
        if (this.getOrderDetail?.design1?.calc.length > 0) {
          if(this.getOrderDetail?.design1?.data?.gemstone?.length > 0) {
            for(const element of this.getOrderDetail?.design1?.data?.gemstone) {     
              let tempdata = {
                name:this.gemstoneList.filter((c) => (c.id == element.name))[0].name,
                color: this.gemstoneColorList.filter((c) => (c.id == element.color))[0].color_name,
                shape: this.merchantCenterVariantList.filter((c) => (c.id == this.getOrderDetail?.design1?.data?.variant_id))[0].cs_shape,
                size: this.centerStoneSizeList.filter((c) => (c.id == element.csSize))[0].csSize,
                wt: this.getOrderDetail.gemstone[0].wt,
                nos: 1,
                twt: this.getOrderDetail.gemstone[0].wt,
                quality: this.getOrderDetail.gemstone[0].type
              }
              this.allGemstoneDataDetails.push(tempdata)
              
            }
          } else
          this.allGemstoneDataDetails.push(this.getOrderDetail?.design1?.data?.gemstone)
        } else if (this.getOrderDetail?.design2?.data?.gemstone?.length > 0) {
          this.allGemstoneDataDetails.push(this.getOrderDetail?.design2?.data?.gemstone)
        } else if (this.getOrderDetail?.design3?.data?.gemstone?.length > 0) {
          this.allGemstoneDataDetails.push(this.getOrderDetail?.design3?.data?.gemstone)
        } else if (this.getOrderDetail?.frameband?.data?.gemstone?.length > 0) {
          this.allGemstoneDataDetails.push(this.getOrderDetail?.frameband?.data?.gemstone)
        }

        this.diamondDataList = this.allDiamondDataDetails;

        // for (let index = 0; index < this.allDiamondDataDetails.length; index++) {
        //   this.diamondDataList = this.allDiamondDataDetails[index];
        //   this.filteredDiamondShapeList = this.diamondShapeList.filter((c) => (c.id == this.diamondDataList[0]?.shape));
        //   this.diamondDataList[index].shape = this.filteredDiamondShapeList[index]?.shape;
        //   // this.diamondDataList[index].quality = this.DiamondData[0].DiaType;
        // }
        // console.log("🚀 ~ file: customer-order-view.component.ts:170 ~ CustomerOrderViewComponent ~ this.CustomerOrdersService.getCustomerOrderDetailbyid ~ tempdata:", this.allGemstoneDataDetails)
        
        for (let index = 0; index < this.allGemstoneDataDetails.length; index++) {
          this.allGemstoneDataDetails[index].quality = this.getOrderDetail.gemstone[index].type;
        }
        
        this.gemstoneDataList = this.allGemstoneDataDetails;
      }
    });
    
  }

}
