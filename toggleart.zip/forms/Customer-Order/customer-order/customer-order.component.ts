import { CenterStoneSizeService } from '@/_services/cs_size.service';
import { VendorAuthenticationService } from '@/_services/vendorauthentication.service';
import { CustomerOrdersService } from '@/forms/Client_Pages/customer-orders.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// import { CustomerOrdersService } from "../customer-orders.service";
import * as moment from 'moment';

@Component({
  selector: 'app-customer-order',
  templateUrl: './customer-order.component.html',
  styleUrls: ['./customer-order.component.css']
})
export class CustomerOrderComponent implements OnInit {
input:any;
  customerOrderList: any;
  predefineList: any;
  merchant_id: number;
  customerOrder: any =[];
  customerOrderDetails: any=[];
  filterCustomerOrderDetails: any=[];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public CustomerOrdersService: CustomerOrdersService,
    private vendorauthenticationService: VendorAuthenticationService,

  ) { 
    if (!this.vendorauthenticationService.vendorcurrentUserValue) {
      this.router.navigate(['merchant']);
      this.merchant_id = this.vendorauthenticationService.vendorcurrentUserValue.id
    }
  }

  ngOnInit(): void {
    this.merchant_id = this.vendorauthenticationService.vendorcurrentUserValue.id;
    this.getCustomerOrder(this.merchant_id);
  }
  showorderdtl(){}

  
  getCustomerOrder(merchant_id){
    const dataObj = {
      merchant_id :merchant_id
    }
    this.CustomerOrdersService.getCustomerOrder(dataObj)
     .subscribe(data => {
       if (data) {
         setTimeout(() => {
          this.customerOrder = data['data'];
          this.CustomerOrdersService.getCustomerOrderDetail(dataObj)
          .subscribe(data => {
            if (data) {
              setTimeout(() => {
                this.customerOrderDetails = data['data'];
                for(let i =0; i <this.customerOrder.length;i++){
                  const date= moment(this.customerOrder[i].orderdate).format('MM/DD/YYYY');
                  console.log('date:', date);
                  this.customerOrder[i].orderDate = date;
                  this.customerOrder[i].orderList = this.customerOrderDetails.filter(x=> x.order_id == this.customerOrder[i].id)
                }
                
              });
            }
          });
          console.log('this.customerOrder:', this.customerOrder);
         });
       }
     });
 }


  ViewOrderData(){
    this.router.navigate([`merchant/customerorder/view`]);
  }
  goToView(id){
    this.router.navigate([`merchant/customerorder/view`, id]);

  }
}
