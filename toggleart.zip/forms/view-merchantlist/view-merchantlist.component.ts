import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { takeUntil } from 'rxjs/operators';
import { DatePipe } from '@angular/common'

import { AlertService, AuthenticationService, EncryptDecryptService, VendorAuthenticationService } from '@/_services';

import { Studdedtype } from '@/_models/studdedtype';
import { StuddedtypeGetAll, StuddedtypeRemove } from '@/_store/studdedtype/studdedtype.actions';
import * as studdettype_selector from '@/_store/studdedtype/studdedtype.selector';
import { StuddedtypeService } from '@/_services/studdedtype.service';
import { VendormakingchargesService } from '@/_services/vendormakingcharges.service';
import { VendorService } from '@/_services/vendor.service';
import * as XLSX from 'xlsx';
import { MatOption } from '@angular/material/core';

@Component({
  selector: 'app-view-merchantlist',
  templateUrl: './view-merchantlist.component.html',
  styleUrls: ['./view-merchantlist.component.css']
})
export class ViewMerchantlistComponent implements OnInit {

  @ViewChild('allSelected') private allSelected: MatOption;

  unsubscribe$: Subject<boolean> = new Subject<boolean>();
  studdedtypes: Observable<Studdedtype[]>;
  dataSource: MatTableDataSource<Studdedtype>;
  closeResult: string;
  searchForm: FormGroup;
  search_text = "";

  displayedColumns: string[] = ['position', 'vendor', 'totalactivity', 'action',];
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  vendorControl = new FormControl();
  datefilter = new FormGroup({
    start: new FormControl(),
    end: new FormControl(),
  });
  vendorList: any[];
  Vendoractivitylist: any[] = [];
  spinnerload: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private vendorservices: VendorAuthenticationService,
    private vendorauthenticationService: VendorAuthenticationService,
    private VendormakingchargesService: VendormakingchargesService,
    public datepipe: DatePipe
  ) {
    if (!this.authenticationService.currentUserValue) {
      this.router.navigate(['login']);
    }

    vendorservices.VendorList()
      .subscribe(data => {
        if (data) {

          this.vendorList = data;
          setTimeout(() => {
            this.dataSource = new MatTableDataSource(data);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;

            this.dataSource.filterPredicate = ((data, filter) => {
              const a = !filter.search_text ||
                data.vendorname.toString().trim().toLowerCase().includes(filter.search_text) ||
                data.totalactivity.toString().trim().toLowerCase().includes(filter.search_text) ||
                data.id.toString().trim().toLowerCase().includes(filter.search_text);
              return a;
            }) as (PeriodicElement, string) => boolean;
          });
        }
      });

    this.searchForm = formBuilder.group({
      search_text: ''
    });

    this.searchForm.valueChanges.subscribe(value => {
      console.log(value);
      const filter = {
        ...value,
        search_text: value.search_text.trim().toLowerCase()
      } as string;
      this.dataSource.filter = filter;
    });
  }

  toggleAllSelection() {
    if (this.allSelected.selected) {
      this.vendorControl
        .patchValue([...this.vendorList.map(item => item.id), 0]);
    } else {
      this.vendorControl.patchValue([]);
    }
  }

  getReport() {
    this.Vendoractivitylist = [];
    this.spinnerload = true;
    var start = this.datepipe.transform(this.datefilter.get('start').value, 'yyyy-MM-dd');
    var end = this.datepipe.transform(this.datefilter.get('end').value, 'yyyy-MM-dd');

    console.log("dorop down value:" + (this.vendorControl.value == ""));
    this.vendorservices.VendorActivityReposrt((this.vendorControl.value == "") ? null : this.vendorControl.value, start, end).subscribe((data: any) => {
      if (data) {
        this.Vendoractivitylist = data;
        this.spinnerload = false;
      } else {
        this.Vendoractivitylist = [];
        this.spinnerload = false;
      }

    }, error => {
      this.spinnerload = false;
    })
  }

  exportexcel() {

    /* pass here the table id */
    let element = document.getElementById('excel-table');

    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element, { dateNF: 'MMM d, y, h:mm:ss a', cellDates: true, raw: true });

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    /* save to file */
    var fileName = 'MerchantActivityReports_' + this.datepipe.transform(new Date(), 'yyyy/MM/dd hh:mm:') + '.xlsx';
    XLSX.writeFile(wb, fileName);

  }

  ngOnInit() {
  }

  ngAfterViewInit() {

  }

}

