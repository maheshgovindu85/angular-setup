import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { HttpResponse } from '@angular/common/http';
import { of, throwError } from 'rxjs';
import * as CryptoJS from 'crypto-js';

import { EncryptDecryptService } from '@/_services/encryptdecrypt.service';
import { AlertService } from '@/_services/alert.service';
import { AuthenticationService } from '@/_services/authentication.service';
import { SpinnerService } from '@/_services';

@Component({
  selector: 'login',
  templateUrl: 'login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    loading = false;
    submitted = false;
    encryptedPassword: string;
    decryptedPassword: string;
    returnUrl: string;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private alertService: AlertService,
        private encryptdecryptService: EncryptDecryptService
    ) {
        // redirect to home if already logged in
        if (this.authenticationService.currentUserValue) {
            this.router.navigateByUrl('/');
        }
    }

    ngOnInit() {
       this.createForm();
        // get return url from route parameters or default to '/'
        this.returnUrl = '/';
    }


    createForm(){
        this.loginForm = this.formBuilder.group({
            user_id: ['', Validators.required],
            password: ['', Validators.required]
        });
    }
    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }


    VendorSignup() {
        this.router.navigate(["merchant"]);
    }

    onSubmit() {
        this.submitted = true;

        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.loginForm.valid) {
            this.authenticationService.login(this.f.user_id.value, this.encryptdecryptService.encrypt(this.f.password.value))
            .pipe(first())
            .subscribe(
                data => {
                  console.log(data);
                  if(data === null){
                    this.alertService.error('User Id. or Password is incorrect !', true);
                    this.loading = false;
                  }
                  this.router.navigate([this.returnUrl]);
                },
                error => {
                    // console.log('error authenticationService : ' + error);
                    this.alertService.error(error);
                    this.loading = false;
                });
        }else{
            this.alertService.error('Enter User Id. or Password !', false);
        }

        // this.loading = true;
        // console.log('user id. -> ' + this.f.user_id.value);
        // console.log('password -> ' + this.f.password.value);

        // var key = CryptoJS.enc.Utf8.parse("abcdefgabcdefg12");
        // var srcs = CryptoJS.enc.Utf8.parse(this.f.password.value);
        // console.log('parsed password -> ' + srcs);
        // var encryptedPassword = CryptoJS.AES.encrypt(srcs, key, {mode:CryptoJS.mode.ECB,padding: CryptoJS.pad.Pkcs7});
        // console.log('encryptedPassword -> ' + encryptedPassword.toString());

        // this.authenticationService.login(this.f.user_id.value, encryptedPassword.toString())
        // console.log(this.encryptdecryptService.encrypt(this.f.password.value));
       
    }


}
