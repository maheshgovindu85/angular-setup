import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';

import { Vendor } from '@/_models/vendor';
import { VendorAdd } from '@/_store/vendor/vendor.actions';
import * as vendor_selectore from '@/_store/vendor/vendor.selector';

import { Planmaster } from '@/_models/planmaster';
import * as planSelectors from '@/_store/planmaster/planmaster.selector';

import { AlertService, AuthenticationService, MetalService } from '@/_services';
import { VendorService } from '@/_services/vendor.service';
import { States } from '@/_models/states';
import { Cities } from '@/_models/cities';
import { PlanmasterService } from '@/_services/planmaster.service';
import { MailservicesService } from '@/_services/mailservices.service';


@Component({
  selector: 'app-vendor-add',
  templateUrl: './vendor-add.component.html',
  styleUrls: ['./vendor-add.component.css']
})
export class VendorAddComponent implements OnInit {
  VendorAddForm: FormGroup;
  loading = false;
  submitted = false;
  currencies: Observable<Vendor[]>;
  public isactive: boolean = true;
  public active_status;
  disablecalculationsection: boolean = false;
  isvalidemail: boolean = false;

  planMsterCtrl = new FormControl();
  gemstones: any[];
  filteredGemstones: Observable<any[]>;

  stateCtrl = new FormControl();
  collection: any[];
  filteredcollection: Observable<any[]>;

  CityCtrl = new FormControl();
  Collectiontype: any[];
  filteredCollectiontype: Observable<any[]>;

  supportcity: any[];
  public vendor_id;
  public approve: boolean = false;

  account_type =[
    {name: 'Standard', Id: 'Standard'},
    {name: 'Exclusive', Id: 'Exclusive'},
  ]
  filterCityData:any =[];

  // uname:string="Roshani";

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private vendorservices: VendorService,
    private store: Store<{ vendors: Vendor[] }>,
    private planservices: PlanmasterService,
    private MailservicesService: MailservicesService,
    private planmasterStore: Store<{ planmasters: Planmaster[] }>
  ) {
    // redirect if already logged in
    if (!this.authenticationService.currentUserValue) {
      // this.router.navigate(['login']);
    } else {

      // For Product get Details
      // planservices.getAll()
      // planmasterStore.select(planSelectors.getAllActivePlanmasters())
      //   .subscribe(
      //     (data) => {
      //       this.gemstones = data;
      //     });
      // this.filteredGemstones = this.planMsterCtrl.valueChanges
      //   .pipe(
      //     startWith<any>(''),
      //     map(value => typeof value === 'string' ? value : value.name),
      //     map(m => m ? this.filterGemstones(m) : this.gemstones.slice())
      //   );

      // For Collection get Details
      // ProducttypetypeStore.select(productselectore.getAllActiveproducttypes()).subscribe(
      vendorservices.getAllstates().subscribe(
        (data) => {
          this.collection = data;
          this.filteredcollection = this.stateCtrl.valueChanges
            .pipe(
              startWith(''),
              map(coll => coll ? this.filterCollection(coll) : this.collection.slice()),
            );
        });

      vendorservices.getAllCities().subscribe(
        (data) => {
          this.Collectiontype = data;
          this.filterCityData = this.Collectiontype
          this.filteredCollectiontype = this.CityCtrl.valueChanges
            .pipe(
              startWith(''),
              map(ct => ct ? this.filterCollectionTypes(ct) : this.Collectiontype.slice())
            );
        });

      // For Collection type get Details
      // collectiontypeStore.select(coollecionType_selectore.getAllCollectionType()).subscribe(
      // vendorservices.getAllCities().subscribe(
      //   (data) => {
      //     this.Collectiontype = data;
      //     this.filteredCollectiontype = this.CityCtrl.valueChanges
      //       .pipe(
      //         startWith(''),
      //         map(ct => ct ? this.filterCollectionTypes(ct) : this.Collectiontype.slice())
      //       );
      //   });

    }
  }

  ngOnInit() {

    let names=this.account_type[0].name

    this.VendorAddForm = this.formBuilder.group({
      id: 0,
      
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      company: ['', Validators.required],
      account_type: ['Standard',Validators.required],
      companywebsite: [''],
      role: [''],
      pincode: ['', [Validators.required, Validators.pattern(/^[0-9]+(\.[0-9]{1,5})?$/)]],
      vtype: ['NA'],
      gstno: ['', Validators.required],
      plan_type: ['', Validators.required],
      plan_name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
      mobileno: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      address_line1: ['', Validators.required],
      address_line2: ['', Validators.required],
      // address_line3: ['', [Validators.required, Validators.pattern(/[0-9\+\-\ ]/)]],
      address_line3: [''],
      state: ['', Validators.required],
      city: ['', Validators.required],
      state_name: ['', Validators.required],
      city_name: ['', Validators.required],
      isactive: [true],
      approved: [false],
      varified: [true],
      v_password: ['', Validators.required],
      isdelete: ['N']
    });

    // this.planmasterStore.select(planSelectors.getAllActivePlanmasters())
    //   .subscribe(
    //     (data) => {
    //       this.VendorAddForm.get('plan_type').setValue(data[0].id)
    //     });

    this.planservices.getAll()
      .subscribe(
        (data) => {
          this.gemstones = data;
          this.VendorAddForm.get('plan_type').setValue(this.gemstones[0].id)
          this.filteredGemstones = this.planMsterCtrl.valueChanges
            .pipe(
              startWith<any>(''),
              map(value => typeof value === 'string' ? value : value.name),
              map(m => m ? this.filterGemstones(m) : this.gemstones.slice())
            );
        });

    this.CityCtrl.valueChanges.subscribe(
      value => {
        if (this.isNumber(this.CityCtrl.value)) {
          this.VendorAddForm.get('city').setValue(this.CityCtrl.value);
          this.VendorAddForm.get('state').setValue('0');
          let selcityid = value;
          let cityobj = this.Collectiontype.filter(m => m.id === this.VendorAddForm.get("city").value)[0];
          if (cityobj !== undefined) {
            let selstateid = cityobj.stateid;
            this.VendorAddForm.get('state').setValue(selstateid);
            this.stateCtrl.setValue(selstateid);
            this.supportcity = this.collection.filter((ct: States) => ct.id === selstateid);

            this.filteredcollection = this.stateCtrl.valueChanges
              .pipe(
                startWith(''),
                map(coll => coll ? this.filterCollection(coll) : this.collection.slice()),
              );
          }
        }
      }
    );

    this.VendorAddForm.get('email').valueChanges.subscribe(value => {
      if (this.VendorAddForm.get('email').valid) {
        this.disablecalculationsection = true;
        this.vendorservices.CheckValidemail(this.VendorAddForm.get('email').value).subscribe(data => {
          this.isvalidemail = false;
          if (data) {
            this.VendorAddForm.get('email').setValue('')
            this.isvalidemail = true;
          }
          this.disablecalculationsection = false;
        }, error => this.disablecalculationsection = false)
      }
    })
  }
  getCurrentcity() {
    return this.supportcity;
  }

  // convenience getter for easy access to form fields
  get f() { return this.VendorAddForm.controls; }

  SetIsAactive(events) {
    let activestus = events.checked
    this.VendorAddForm.patchValue(
      {
        isactive: events.checked
      }
    );
  }

  Setapprove(events) {
    this.VendorAddForm.patchValue(
      {
        approved: events.checked
      }
    );
  }

  setState(e: any) {
    this.Collectiontype.filter(rescity => {
      if(rescity.id == e.value) {
        this.collection.filter(resstate => {
          if(rescity.stateid == resstate.id){
            let selstateid = resstate.id;
            this.VendorAddForm.get('state').setValue(parseInt(selstateid));
          }
        });
      }
      
    })
    
    
  }

  setCity(event){
    let statsId =  event.value
      this.filterCityData = this.Collectiontype.filter(c=>c.stateid===statsId);
      let  itm=this.filterCityData[0];
      this.VendorAddForm.controls['city'].setValue(itm.stateid);
  }
 
  onSubmit() {
    this.submitted = true;
    // this.VendorAddForm.get("plan_type").setValue(this.planMsterCtrl.value);
    var plan_name = this.gemstones.filter(m => m.id === this.VendorAddForm.get("plan_type").value)[0].plan_name;
    this.VendorAddForm.get("plan_name").setValue(plan_name);

    //this.VendorAddForm.get("state").setValue(this.stateCtrl.value);
    var state_name = this.collection.filter(m => m.id === this.VendorAddForm.get("state").value)[0].name;
    this.VendorAddForm.get("state_name").setValue(state_name);

    //this.VendorAddForm.get("city").setValue(this.CityCtrl.value);
    var city_name = this.Collectiontype.filter(m => m.id === this.VendorAddForm.get("city").value)[0].name;
    this.VendorAddForm.get("city_name").setValue(city_name);


    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.VendorAddForm.invalid) {
     return;
    }
    if (this.VendorAddForm.get('isactive').value === true) {
      this.active_status = 'Y';
    } else { this.active_status = 'N'; }


    this.loading = true;
    this.vendorservices
      .save(this.VendorAddForm.value)
      .subscribe((data: Vendor) => {
        this.VendorAddForm.get('isactive').setValue(this.active_status);
        this.VendorAddForm.get("id").setValue(data.id);
        if (this.VendorAddForm.get("approved").value === true) { this.VendorAddForm.get("approved").setValue('Y') } else { this.VendorAddForm.get("approved").setValue('N') };
        // this.store.dispatch(new VendorAdd(this.VendorAddForm.value));

        this.SendVerificationMail(this.VendorAddForm.get("id").value);

        this.alertService.success('Merchnat saved successfully!', true);
        this.router.navigate(["merchantMaster/list"]);
      });

  }
  SendVerificationMail(vendorid) {
    this.MailservicesService.MailVarification(this.VendorAddForm.get("email").value, vendorid).subscribe(data => {
    });
  }

  // for Product type
  filterGemstones(name: string): any[] {

    const filterValue = name.toLowerCase();

    return this.gemstones.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);

  }
  getGemstoneName(typeId: number) {
    if (this.gemstones != null && typeId != null && typeId != 0) {
      return this.gemstones.filter(s => s.id === typeId)[0].plan_name;
    }
  }
  //For Collcetion 
  filterCollection(name: string) {
    if (!this.isNumber(name))
      return this.collection.filter(m => m.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getCollectionName(typeId: number) {
    if (this.collection != null && typeId != null && typeId != 0) {
      return this.collection.filter(s => s.id === typeId)[0].name;
    }
  }
  //for Colletion Type 
  filterCollectionTypes(name: string) {
    if (!this.isNumber(name))
      return this.Collectiontype.filter(m => m.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getCollectionTypeName(typeId: number) {
    if (this.collection != null && typeId != null && typeId != 0) {
      return this.Collectiontype.filter(s => s.id === typeId)[0].name;
    }
  }
  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }
  convert(str) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day
    ].join("-");
  }

  backToList(){
    this.router.navigate(["merchantMaster/list"]);
  }

  
}
