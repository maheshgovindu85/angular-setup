import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { takeUntil } from 'rxjs/operators';

import { AlertService, AuthenticationService, EncryptDecryptService } from '@/_services';

import { SolitaireRefrate } from '@/_models/solitaire-refrate';
import { VendorGetAll, VendorRemove } from '@/_store/vendor/vendor.actions';
import * as vendor_selector from '@/_store/vendor/vendor.selector';
import { VendorService } from '@/_services/vendor.service';
import { Vendor } from '@/_models/vendor';

@Component({
  selector: 'app-vendor-list',
  templateUrl: './vendor-list.component.html',
  styleUrls: ['./vendor-list.component.css']
})
export class VendorListComponent implements OnInit {
  unsubscribe$: Subject<boolean> = new Subject<boolean>();
  vendors: Observable<Vendor[]>;
  dataSource: MatTableDataSource<Vendor>;
  masterList: any =[];
  closeResult: string;
  searchForm: FormGroup;
  search_text = "";
  loading: boolean = true;
  isChecked: boolean;
  filterMasterList:any = [];

  displayedColumns: string[] = ['position', 'firstname', 'lastname', 'company', 'gstno', 'plan_name', 'email', 'mobileno', 'state_name', 'city_name', 'isdelete', 'actions'];
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private encryptdecryptService: EncryptDecryptService,
    private vendorservices: VendorService,
    private store: Store<{ vendors: Vendor[] }>) {

    // redirect if already logged in
    if (!this.authenticationService.currentUserValue) {
      this.router.navigate(['login']);
    }

    this.searchForm = formBuilder.group({
      search_text: ''
    });

    this.searchForm.valueChanges.subscribe(value => {
      const filter = {
        ...value,
        search_text: value.search_text.trim().toLowerCase()
      } as string;
     
      this.dataSource.filter = filter;
    });
  }

  ngOnInit() {
    this.createSearchForm();
  }

  ngAfterViewInit() {
    // console.log('in metallist ngAfterViewInit');
    // this.store.pipe(select(vendor_selector.getAllveVendorss()))
    this.vendorservices.getAll()
      .subscribe(data => {
        if (data) {
          setTimeout(() => {
            this.dataSource = new MatTableDataSource(data);
            this.masterList = data;
            for(let i =0; i <this.masterList.length;i++){
              this.masterList[i].isactive = this.masterList[i].isactive === 'N' ? false : true;
            }
           this.filterMasterList = this.masterList;
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;

            this.dataSource.filterPredicate = ((data, filter) => {
              const a = !filter.search_text ||
                data.firstname.toString().trim().toLowerCase().includes(filter.search_text) ||
                data.mdlastname.toString().trim().toLowerCase().includes(filter.search_text) ||
                data.company.toString().trim().toLowerCase().includes(filter.search_text) ||
                // data.vtype.toString().trim().toLowerCase().includes(filter.search_text) ||
                data.gstno.toString().trim().toLowerCase().includes(filter.search_text) ||
                data.email.toString().trim().toLowerCase().includes(filter.search_text) ||
                data.mobileno.toString().trim().toLowerCase().includes(filter.search_text) ||
                data.state_name.toString().trim().toLowerCase().includes(filter.search_text) ||
                data.city_name.toString().trim().toLowerCase().includes(filter.search_text) ||
                data.plan_name.toString().trim().toLowerCase().includes(filter.search_text);
              return a;
            }) as (PeriodicElement, string) => boolean;
          });
        }
      });
  }


  changeStatus(e,data: any){
    this.isChecked = e.checked;
    this.vendorservices.delete(data.id, this.isChecked ? 'Y' : 'N').subscribe((data: Vendor[]) => {
    });
  
  }


   // Search button function start
   createSearchForm() {
    this.searchForm = this.formBuilder.group({
      keyword: [''],
    });
  }
  clear() {
    this.searchForm.get('keyword')?.setValue('');
    this.searchGrid();
  }
  searchGrid() {
    let keyword = this.searchForm.controls['keyword'].value;
    if (keyword === '') {
      this.filterMasterList = this.masterList;
    } else {
      keyword = keyword.toLowerCase();
      this.filterMasterList = this.masterList.filter((event) => {
        return (
          (event.firstname && event.firstname.toLowerCase().includes(keyword))
          || (event.mdlastname && event.mdlastname.toLowerCase().includes(keyword)) ||
          (event.company && event.company.toLowerCase().includes(keyword)) ||
          (event.gstno && event.gstno.toLowerCase().includes(keyword)) ||
          (event.email && event.email.toLowerCase().includes(keyword)) ||
          (event.mobileno && event.mobileno.toLowerCase().includes(keyword)) ||
          (event.state_name && event.state_name.toLowerCase().includes(keyword)) ||
          (event.plan_name && event.plan_name.toLowerCase().includes(keyword)) ||
          (event.city_name && event.city_name.toLowerCase().includes(keyword)) 
        );
      });
    }
  }

}
