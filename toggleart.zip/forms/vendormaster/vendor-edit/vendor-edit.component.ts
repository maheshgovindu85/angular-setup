import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { startWith, map } from 'rxjs/operators';

import { Vendor } from '@/_models/vendor';
import { VendorUpdate } from '@/_store/vendor/vendor.actions';
import * as vendor_selectore from '@/_store/vendor/vendor.selector';

import { States } from '@/_models/states';
import { StatesUpdate } from '@/_store/states_store/state.actions';
import * as state_selectore from '@/_store/states_store/state.selector';

import { Cities } from '@/_models/cities';
import { CitiesUpdate } from '@/_store/city_store/city.actions';
import * as cities_selectore from '@/_store/city_store/city.selector';

import { Planmaster } from '@/_models/planmaster';
import * as planSelectors from '@/_store/planmaster/planmaster.selector';

import { AlertService, AuthenticationService, MetalService } from '@/_services';
import { VendorService } from '@/_services/vendor.service';
import { Console } from 'console';
import { PlanmasterService } from '@/_services/planmaster.service';


@Component({
  selector: 'app-vendor-edit',
  templateUrl: './vendor-edit.component.html',
  styleUrls: ['./vendor-edit.component.css']
})
export class VendorEditComponent implements OnInit {

  VendorEditForm: FormGroup;
  loading = false;
  submitted = false;
  currencies: Observable<Vendor[]>;
  public isactive: boolean = false;
  public active_status;

  public vedordetails: Vendor;
  setActivateValue: any;
  is_actived: boolean = false;

  planMsterCtrl = new FormControl();
  gemstones: any[];
  filteredGemstones: Observable<any[]>;

  stateCtrl = new FormControl();
  public collection: any[];
  filteredcollection: Observable<any[]>;

  CityCtrl = new FormControl();
  Collectiontype: any[];
  filteredCollectiontype: Observable<any[]>;

  supportcity: any[];
  public approve: boolean;
  public varified: boolean;

  disablecalculationsection: boolean = false;
  isvalidemail: boolean = false;

  account_type =[
    {name: 'Standard', Id: 'Standard'},
    {name: 'Exclusive', Id: 'Exclusive'},
  ]

  constructor(private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
    private vendorservices: VendorService,
    private store: Store<{ vendors: Vendor[] }>,
    private planservices: PlanmasterService,
    private planmasterStore: Store<{ planmasters: Planmaster[] }>,
    private stateStore: Store<{ states: States[] }>,
    private cityStore: Store<{ cities: Cities[] }>
  ) {

    // redirect if already logged in
    if (this.authenticationService.currentUserValue) {


      this.VendorEditForm = this.formBuilder.group({
        id: 0,
        firstname: ['', Validators.required],
        lastname: ['', Validators.required],
        company: ['', Validators.required],
        account_type:['',Validators.required],
        companywebsite: [''],
        role: [''],
        pincode: ['', [Validators.required, Validators.pattern(/^[0-9]+(\.[0-9]{1,5})?$/)]],
        vtype: ['NA'],
        gstno: ['', Validators.required],
        plan_type: ['', Validators.required],
        plan_name: ['', Validators.required],
        email: ['', [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
        mobileno: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
        address_line1: ['', Validators.required],
        address_line2: ['', Validators.required],
        // address_line3: ['', [Validators.required, Validators.pattern(/[0-9\+\-\ ]/)]],
        address_line3: [''],
        state: ['', Validators.required],
        city: ['', Validators.required],
        state_name: ['', Validators.required],
        city_name: ['', Validators.required],
        isactive: [true],
        approved: [false],
        varified: [true],
        v_password: ['', Validators.required],
        isdelete: ['N']
      });
    }
    else {
      this.router.navigate(['login']);
    }
  }

  async ngOnInit() {

    // cityStore.select(cities_selectore.getAllActivecitys()).subscribe(
    await this.vendorservices.getAllCities().subscribe(
      (data) => {
        this.Collectiontype = data;
        this.filteredCollectiontype = this.CityCtrl.valueChanges
          .pipe(
            startWith(''),
            map(ct => ct ? this.filterCollectionTypes(ct) : this.Collectiontype.slice())
          );
      });

    //Get Selected Vendor Details Here 
    const id = this.route.snapshot.params.id;


    // For Product get Details
    // this.planmasterStore.select(planSelectors.getAllActivePlanmasters())
    //   .subscribe(
    //     (data) => {
    //       this.gemstones = data;
    //     });
    // this.filteredGemstones = this.planMsterCtrl.valueChanges
    //   .pipe(
    //     startWith(''),
    //     map(m => m ? this.filterGemstones(m) : this.gemstones.slice())
    //   );

    this.planservices.getAll()
      .subscribe(
        (data) => {
          this.gemstones = data;
          this.filteredGemstones = this.planMsterCtrl.valueChanges
            .pipe(
              startWith<any>(''),
              map(value => typeof value === 'string' ? value : value.name),
              map(m => m ? this.filterGemstones(m) : this.gemstones.slice())
            );
        });



    // For Collection get Details
    // stateStore.select(state_selectore.getAllActivestates()).subscribe(
    this.vendorservices.getAllstates().subscribe(
      (data) => {
        this.collection = data;
        this.filteredcollection = this.stateCtrl.valueChanges
          .pipe(
            startWith(''),
            map(m => m ? this.filterCollection(m) : this.collection.slice())
          );
      });

    // this.store.select(vendor_selectore.getveVendorsById(id))
    this.vendorservices.getVendors(id)
      .subscribe((data: any) => {
        this.vedordetails = data;
        this.setActivateValue = this.vedordetails.isactive;
        if (this.setActivateValue === 'Y') { this.is_actived = true } else { this.is_actived = false };
        if (this.vedordetails.approved === 'Y') { this.approve = true } else { this.approve = false };
        if (this.vedordetails.varified === 'Y') { this.varified = true } else { this.varified = false };

        this.createForm(this.vedordetails);
      });

    this.CityCtrl.valueChanges
      .subscribe(
        value => {
          if (this.isNumber(this.CityCtrl.value) && this.Collectiontype) {
            this.VendorEditForm.get('city').setValue(this.CityCtrl.value);
            this.VendorEditForm.get('state').setValue('0');
            let selcityid = value;
            let cityobj = this.Collectiontype.filter(m => m.id === this.VendorEditForm.get("city").value)[0];
            if (cityobj !== undefined) {
              let selstateid = cityobj.stateid;
              this.VendorEditForm.get('state').setValue(selstateid);
              this.stateCtrl.setValue(selstateid);
              this.supportcity = this.collection.filter((ct: States) => ct.id === selstateid);

              this.filteredcollection = this.stateCtrl.valueChanges
                .pipe(
                  startWith(''),
                  map(coll => coll ? this.filterCollection(coll) : this.collection.slice()),
                );
            }
          }
        }
      );

    this.VendorEditForm.get('email').valueChanges.subscribe(value => {
      if (this.VendorEditForm.get('email').valid) {
        this.disablecalculationsection = true;
        this.vendorservices.CheckValidemail(this.VendorEditForm.get('email').value).subscribe(data => {
          this.isvalidemail = false;
          if (data) {
            this.VendorEditForm.get('email').setValue('')
            this.isvalidemail = true;
          }
          this.disablecalculationsection = false;
        }, error => this.disablecalculationsection = false)
      }
    })
  }

  SetIsAactive(events) {
    let activestus = events.checked
    this.VendorEditForm.patchValue(
      {
        isactive: events.checked
      }
    );
  }
  Setapprove(events) {
    this.VendorEditForm.patchValue(
      {
        approved: events.checked
      }
    );
  }

  createForm(vedordetails) {
    this.vedordetails = vedordetails;
    this.CityCtrl.setValue(this.vedordetails.city);
    this.stateCtrl.setValue(this.vedordetails.state);

    this.VendorEditForm = this.formBuilder.group({
      id: this.vedordetails.id,
      firstname: [this.vedordetails.firstname, Validators.required],
      lastname: [this.vedordetails.lastname, Validators.required],
      company: [this.vedordetails.company, Validators.required],
      companywebsite: [this.vedordetails.companywebsite],
      role: [this.vedordetails.role],
      pincode: [this.vedordetails.pincode, [Validators.required, Validators.pattern(/^[0-9]+(\.[0-9]{1,5})?$/)]],
      vtype: [this.vedordetails.vtype],
      gstno: [this.vedordetails.gstno, Validators.required],
      plan_type: [this.vedordetails.plan_type, Validators.required],
      plan_name: [this.vedordetails.plan_name, Validators.required],
      email: [this.vedordetails.email, [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
      mobileno: [this.vedordetails.mobileno, [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      address_line1: [this.vedordetails.address_line1, Validators.required],
      address_line2: [this.vedordetails.address_line2, Validators.required],
      address_line3: [this.vedordetails.address_line3],
      state: [this.vedordetails.state, Validators.required],
      city: [this.vedordetails.city, Validators.required],
      state_name: [this.vedordetails.state_name, Validators.required],
      city_name: [this.vedordetails.city_name, Validators.required],
      isactive: [this.is_actived, Validators.required],
      approved: [this.approve, Validators.required],
      varified: [this.varified],
      v_password: [this.vedordetails.v_password],
      isdelete: [this.vedordetails.isdelete],
      account_type: [this.vedordetails.account_type]
    });
  }



  // convenience getter for easy access to form fields
  get f() { return this.VendorEditForm.controls; }

  onSubmit() {
    this.submitted = true;

    // this.VendorAddForm.get("plan_type").setValue(this.planMsterCtrl.value);
    var plan_name = this.gemstones.filter(m => m.id === this.VendorEditForm.get("plan_type").value)[0].plan_name;
    this.VendorEditForm.get("plan_name").setValue(plan_name);

    //this.VendorAddForm.get("state").setValue(this.stateCtrl.value);
    var state_name = this.collection.filter(m => m.id === this.VendorEditForm.get("state").value)[0].state_name;
    this.VendorEditForm.get("state_name").setValue(state_name);

    //this.VendorAddForm.get("city").setValue(this.CityCtrl.value);
    var city_name = this.Collectiontype.filter(m => m.id === this.VendorEditForm.get("city").value)[0].city_name;
    this.VendorEditForm.get("city_name").setValue(city_name);

    this.VendorEditForm.get('city').setValue(this.CityCtrl.value);

    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.VendorEditForm.invalid) {
      return;
    }
    if (this.VendorEditForm.get('isactive').value === true) {
      this.active_status = 'Y';
    } else { this.active_status = 'N'; }

    this.loading = true;
    console.log(this.VendorEditForm.value);
    this.vendorservices
      .save(this.VendorEditForm.value)
      .subscribe((data: Vendor) => {
        // console.log(data);
        this.VendorEditForm.get('isactive').setValue(this.active_status);
        this.VendorEditForm.get("id").setValue(data.id);
        if (this.VendorEditForm.get("approved").value === true) { this.VendorEditForm.get("approved").setValue('Y') } else { this.VendorEditForm.get("approved").setValue('N') };
        // this.store.dispatch(new VendorUpdate(this.VendorEditForm.value));
        //console.log(this.store);
        this.alertService.success('Merchant updated successfully!', true);
        this.backToList();
      });
  }

  // for Product type
  filterGemstones(name: string) {
    if (!this.isNumber(name))
      return this.gemstones.filter(m => m.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getGemstoneName(typeId: number) {
    if (this.gemstones != null && typeId != null && typeId != 0) {
      return this.gemstones.filter(s => s.id === typeId)[0].plan_name;
    }
  }

  //For Collcetion 
  filterCollection(name: string) {
    if (!this.isNumber(name))
      return this.collection.filter(m => m.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getCollectionName(typeId: number) {
    if (this.collection != null && typeId != null && typeId != 0) {
      return this.collection.filter(s => s.id === typeId)[0].state_name;
    }
  }
  //for Colletion Type 
  filterCollectionTypes(name: string) {
    console.log("get the filterCity");
    console.log(name);
    if (!this.isNumber(name))
      return this.Collectiontype.filter(m => m.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  getCollectionTypeName(typeId: number) {
    console.log("From Get CityName");
    console.log(typeId);
    if (this.Collectiontype != null && typeId != null && typeId != 0) {
      return this.Collectiontype.filter(s => s.id == typeId)[0].city_name;
    }
  }
  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }
  convert(str) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day
    ].join("-");
  }
  
  backToList(){
    this.router.navigate(["/merchantMaster/list"]);
  }
}
