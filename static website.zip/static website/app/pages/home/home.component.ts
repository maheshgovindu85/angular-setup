import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {


  bannerChecks = [
    {
      title:'DIY or Account Manager'
    },
    {
      title:'Multiple platforms'
    },
    {
      title:'Analytic tools'
    },
    {
      title:'Manage your Reputation'
    }
  ]

  oneDashboardAll = [
    {
      icon:'../../../assets/badge1.svg',
      title: 'Multiple Platforms',
      description:'Manage all your location data from Google Places, Facebook, Tripadvisor and more platforms'
    },
    {
      icon:'../../../assets/badge2.svg',
      title: 'Multiple Platforms',
      description:'Manage all your location data from Google Places, Facebook, Tripadvisor and more platforms'
    },
    {
      icon:'../../../assets/badge3.svg',
      title: 'Multiple Platforms',
      description:'Manage all your location data from Google Places, Facebook, Tripadvisor and more platforms'
    },
    {
      icon:'../../../assets/badge4.svg',
      title: 'Multiple Platforms',
      description:'Manage all your location data from Google Places, Facebook, Tripadvisor and more platforms'
    },
    {
      icon:'../../../assets/badge5.svg',
      title: 'Multiple Platforms',
      description:'Manage all your location data from Google Places, Facebook, Tripadvisor and more platforms'
    },
    {
      icon:'../../../assets/badge6.svg',
      title: 'Multiple Platforms',
      description:'Manage all your location data from Google Places, Facebook, Tripadvisor and more platforms'
    }

  ]

}
